#include "HitReactionComponent.h"
#include "CombatInterfaces.h"
#include "Animation/AnimInstance.h"
#include "Camera/CameraShakeBase.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "KismetAnimationLibrary.h"
#include "Materials/MaterialInstanceDynamic.h"

UHitReactionComponent::UHitReactionComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}

USkeletalMeshComponent* UHitReactionComponent::GetMesh() const
{
	const ACharacter* C = Cast<ACharacter>(GetOwner());
	return C ? C->GetMesh() : nullptr;
}

void UHitReactionComponent::BeginPlay()
{
	Super::BeginPlay();
	Health = MaxHealth;
	Poise = MaxPoise;
	if (USkeletalMeshComponent* Mesh = GetMesh())
	{
		for (int32 i = 0; i < Mesh->GetNumMaterials(); ++i)
		{
			if (UMaterialInstanceDynamic* M = Mesh->CreateAndSetMaterialInstanceDynamic(i))
			{
				M->SetVectorParameterValue(FlashColorParam, FlashColor);
				M->SetScalarParameterValue(FlashAmountParam, 0.f);
				Materials.Add(M);
			}
		}
	}
}

EHitDirection UHitReactionComponent::GetHitDirection(const FVector& ToAttacker) const
{
	// 0 = the blow came from straight ahead, +90 from the right, 180 from behind.
	const float A = UKismetAnimationLibrary::CalculateDirection(ToAttacker, GetOwner()->GetActorRotation());
	if (FMath::Abs(A) <= 45.f) return EHitDirection::Front;
	if (A > 45.f && A <= 135.f) return EHitDirection::Right;
	if (A < -45.f && A >= -135.f) return EHitDirection::Left;
	return EHitDirection::Back;
}

bool UHitReactionComponent::ReceiveHit(AActor* Attacker, const FHitData& Data, const FHitResult& Hit)
{
	AActor* Owner = GetOwner();
	if (!Owner || bDead || InvulnerableCount > 0) return false;

	const FVector OwnerLoc = Owner->GetActorLocation();
	const FVector AttackerLoc = Attacker ? Attacker->GetActorLocation() : OwnerLoc - Owner->GetActorForwardVector() * 100.f;
	FVector Travel = (OwnerLoc - AttackerLoc).GetSafeNormal2D();
	if (Travel.IsNearlyZero()) Travel = -Owner->GetActorForwardVector();
	const FVector ToAttacker = -Travel;

	AController* InstigatorCtrl = Attacker ? Attacker->GetInstigatorController() : nullptr;
	const float Dealt = UGameplayStatics::ApplyPointDamage(Owner, Data.Damage, Travel, Hit, InstigatorCtrl, Attacker, Data.DamageType);
	bool bKilled = false;
	if (bUseBuiltInHealth)
	{
		Health = FMath::Max(0.f, Health - Dealt);
		bKilled = Health <= 0.f;
	}
	OnHitTaken.Broadcast(Data, Attacker, Dealt);
	StartFlash();

	const FVector Point = Hit.ImpactPoint.IsNearlyZero() ? OwnerLoc : FVector(Hit.ImpactPoint);
	if (bKilled)
	{
		Die(Attacker, Travel * FMath::Max(Data.KnockbackStrength, 300.f) * 3.f + FVector(0, 0, 250.f), Point, Hit.BoneName);
		return true;
	}

	PlayReaction(ToAttacker, Data);
	ApplyKnockback(Travel, Data);
	if (bUsePhysicalReaction) StartPhysicalReaction(Travel, Hit);

	if (const ACharacter* C = Cast<ACharacter>(Owner))
	{
		if (APlayerController* PC = Cast<APlayerController>(C->GetController()))
		{
			if (TakeHitShake) PC->ClientStartCameraShake(TakeHitShake, Data.TakeShakeScale);
		}
	}
	return true;
}

void UHitReactionComponent::PlayReaction(const FVector& ToAttacker, const FHitData& Data)
{
	USkeletalMeshComponent* Mesh = GetMesh();
	UAnimInstance* Anim = Mesh ? Mesh->GetAnimInstance() : nullptr;
	const float Now = GetWorld()->GetTimeSeconds();
	LastPoiseHitTime = Now;
	Poise -= Data.PoiseDamage;
	const EHitDirection Dir = GetHitDirection(ToAttacker);

	const bool bBroken = Data.bForceStagger || Poise <= 0.f;
	if (bBroken)
	{
		Poise = MaxPoise;
		// Super armor only saves you from a poise break, never from a forced stagger.
		if (Data.bForceStagger || SuperArmorCount == 0)
		{
			if (Anim)
			{
				Anim->Montage_Stop(0.1f); // interrupts whatever they were doing
				if (UAnimMontage* M = Stagger.Pick(Dir)) Anim->Montage_Play(M, 1.f);
			}
			OnStaggered.Broadcast();
		}
	}
	else if (SuperArmorCount == 0 && Anim)
	{
		// A flinch on top of what they are doing (additive slot): they keep moving, the body just reacts.
		if (UAnimMontage* M = Flinch.Pick(Dir)) Anim->Montage_Play(M, 1.f);
	}
	SetTickNeeded();
}

void UHitReactionComponent::ApplyKnockback(const FVector& Travel, const FHitData& Data)
{
	ACharacter* C = Cast<ACharacter>(GetOwner());
	if (!C) return;
	// Never shove someone in the middle of a root-motion roll or a warped attack.
	if (C->HasAnyRootMotion()) return;
	const float Scale = 1.f - KnockbackResistance;
	if (Scale <= 0.01f) return;
	const FVector V = Travel * Data.KnockbackStrength * Scale + FVector(0.f, 0.f, Data.KnockbackUpward * Scale);
	C->LaunchCharacter(V, true, Data.KnockbackUpward > 0.f);
}

void UHitReactionComponent::StartFlash()
{
	FlashAmount = 1.f;
	for (UMaterialInstanceDynamic* M : Materials)
	{
		if (M) M->SetScalarParameterValue(FlashAmountParam, 1.f);
	}
	SetTickNeeded();
}

void UHitReactionComponent::StartPhysicalReaction(const FVector& Travel, const FHitResult& Hit)
{
	USkeletalMeshComponent* Mesh = GetMesh();
	if (!Mesh) return;
	Mesh->SetAllBodiesBelowSimulatePhysics(PhysicalBone, true, false);
	Mesh->SetAllBodiesBelowPhysicsBlendWeight(PhysicalBone, PhysicalBlend, false, false);
	const FVector Where = Hit.ImpactPoint.IsNearlyZero() ? Mesh->GetBoneLocation(PhysicalBone) : FVector(Hit.ImpactPoint);
	Mesh->AddImpulseAtLocation(Travel * PhysicalImpulse, Where, Hit.BoneName.IsNone() ? PhysicalBone : Hit.BoneName);
	PhysicalAlpha = 1.f;
	SetTickNeeded();
}

void UHitReactionComponent::SetTickNeeded()
{
	SetComponentTickEnabled(true);
}

void UHitReactionComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (bDead) { SetComponentTickEnabled(false); return; }
	bool bBusy = false;

	if (FlashAmount > 0.f)
	{
		FlashAmount = FMath::Max(0.f, FlashAmount - DeltaTime / FMath::Max(FlashDuration, 0.01f));
		const float Shaped = FlashAmount * FlashAmount; // snaps on, eases off
		for (UMaterialInstanceDynamic* M : Materials)
		{
			if (M) M->SetScalarParameterValue(FlashAmountParam, Shaped);
		}
		bBusy = true;
	}

	if (Poise < MaxPoise)
	{
		if (GetWorld()->GetTimeSeconds() - LastPoiseHitTime > PoiseRegenDelay)
			Poise = FMath::Min(MaxPoise, Poise + PoiseRegenPerSecond * DeltaTime);
		bBusy = true;
	}

	if (PhysicalAlpha > 0.f)
	{
		PhysicalAlpha = FMath::Max(0.f, PhysicalAlpha - DeltaTime / FMath::Max(PhysicalDuration, 0.05f));
		if (USkeletalMeshComponent* Mesh = GetMesh())
		{
			if (PhysicalAlpha <= 0.f)
			{
				Mesh->SetAllBodiesBelowPhysicsBlendWeight(PhysicalBone, 0.f, false, false);
				Mesh->SetAllBodiesBelowSimulatePhysics(PhysicalBone, false, false);
			}
			else
			{
				Mesh->SetAllBodiesBelowPhysicsBlendWeight(PhysicalBone, PhysicalBlend * PhysicalAlpha, false, false);
			}
		}
		bBusy = true;
	}

	if (!bBusy) SetComponentTickEnabled(false);
}

void UHitReactionComponent::Die(AActor* Killer, FVector Impulse, FVector ImpactPoint, FName Bone)
{
	if (bDead) return;
	bDead = true;
	Health = 0.f;
	OnDied.Broadcast(Killer);

	ACharacter* C = Cast<ACharacter>(GetOwner());
	if (!C) return;
	if (UAnimInstance* Anim = C->GetMesh()->GetAnimInstance()) Anim->StopAllMontages(0.05f);
	C->GetCharacterMovement()->DisableMovement();
	C->GetCharacterMovement()->StopMovementImmediately();

	if (bRagdollOnDeath)
	{
		C->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		USkeletalMeshComponent* Mesh = C->GetMesh();
		Mesh->SetCollisionProfileName(TEXT("Ragdoll"));
		Mesh->SetSimulatePhysics(true);
		Mesh->WakeAllRigidBodies();
		const FVector Where = ImpactPoint.IsNearlyZero() ? Mesh->GetComponentLocation() : ImpactPoint;
		Mesh->AddImpulseAtLocation(Impulse, Where, Bone);
	}
	C->SetLifeSpan(DeathLifeSpan);
}
