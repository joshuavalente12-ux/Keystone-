#include "AnimNotifyState_MeleeTrace.h"
#include "CombatComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"

static UCombatComponent* FindCombat(USkeletalMeshComponent* MeshComp)
{
	// Ignore the animation editor preview: only real gameplay worlds deal damage.
	if (!MeshComp || !MeshComp->GetWorld() || !MeshComp->GetWorld()->IsGameWorld()) return nullptr;
	AActor* Owner = MeshComp->GetOwner();
	return Owner ? Owner->FindComponentByClass<UCombatComponent>() : nullptr;
}

FMeleeTraceParams UAnimNotifyState_MeleeTrace::MakeParams() const
{
	FMeleeTraceParams P;
	P.StartSocket = StartSocket;
	P.EndSocket = EndSocket;
	P.Radius = Radius;
	P.SamplePoints = SamplePoints;
	P.DamageScale = DamageScale;
	P.bOverrideHit = bOverrideHit;
	P.Hit = HitData;
	return P;
}

void UAnimNotifyState_MeleeTrace::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	if (UCombatComponent* C = FindCombat(MeshComp)) C->BeginMeleeTrace(MakeParams());
}

void UAnimNotifyState_MeleeTrace::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
	if (UCombatComponent* C = FindCombat(MeshComp)) C->TickMeleeTrace(MakeParams());
}

void UAnimNotifyState_MeleeTrace::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyEnd(MeshComp, Animation, EventReference);
	if (UCombatComponent* C = FindCombat(MeshComp)) C->EndMeleeTrace();
}
