#include "CombatAnimInstance.h"
#include "LockOnComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "KismetAnimationLibrary.h"

void UCombatAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();
	Character = Cast<ACharacter>(TryGetPawnOwner());
	Movement = Character ? Character->GetCharacterMovement() : nullptr;
	if (Character) PrevYaw = Character->GetActorRotation().Yaw;
}

void UCombatAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);
	if (!Character || !Movement) { Character = Cast<ACharacter>(TryGetPawnOwner()); if (Character) Movement = Character->GetCharacterMovement(); return; }

	const FVector Velocity = Movement->Velocity;
	GroundSpeed = FVector(Velocity.X, Velocity.Y, 0.f).Size();
	Direction = UKismetAnimationLibrary::CalculateDirection(Velocity, Character->GetActorRotation());
	bShouldMove = GroundSpeed > 3.f && !Movement->GetCurrentAcceleration().IsNearlyZero();
	bIsInAir = Movement->IsFalling();

	const ULockOnComponent* Lock = Character->FindComponentByClass<ULockOnComponent>();
	bIsLockedOn = Lock && Lock->HasTarget();

	// Lean into turns: yaw rate, smoothed.
	const float Yaw = Character->GetActorRotation().Yaw;
	const float YawRate = DeltaSeconds > KINDA_SMALL_NUMBER ? FMath::FindDeltaAngleDegrees(PrevYaw, Yaw) / DeltaSeconds : 0.f;
	PrevYaw = Yaw;
	Lean = FMath::FInterpTo(Lean, FMath::Clamp(YawRate * LeanScale * (GroundSpeed / 600.f), -1.f, 1.f), DeltaSeconds, 8.f);

	// Aim offset: the difference between where the controller looks (AI focus for monsters) and where the body faces.
	const FRotator Delta = UKismetMathLibrary::NormalizedDeltaRotator(Character->GetBaseAimRotation(), Character->GetActorRotation());
	AimYaw = FMath::FInterpTo(AimYaw, FMath::Clamp(Delta.Yaw, -90.f, 90.f), DeltaSeconds, 10.f);
	AimPitch = FMath::FInterpTo(AimPitch, FMath::Clamp(Delta.Pitch, -60.f, 60.f), DeltaSeconds, 10.f);
}
