#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "HitStopSubsystem.generated.h"

/**
 * Freezes individual actors (attacker + victim) with CustomTimeDilation instead of slowing the
 * whole world. World timers, the HUD and other enemies keep running, so the freeze always
 * lasts exactly the real time you asked for.
 */
UCLASS()
class YOURGAME_API UHitStopSubsystem : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	/** Freeze [Actor] for [Duration] seconds at [Dilation] speed. Overlapping requests extend, never shorten. */
	void RequestHitStop(AActor* Actor, float Duration, float Dilation);

	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;

private:
	struct FEntry
	{
		float EndTime = 0.f;
		float OriginalDilation = 1.f;
	};
	TMap<TWeakObjectPtr<AActor>, FEntry> Entries;
};
