#include "LockOnComponent.h"
#include "CombatInterfaces.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/KismetMathLibrary.h"

ULockOnComponent::ULockOnComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false; // only ticks while locked on
}

bool ULockOnComponent::IsValidTarget(const AActor* A) const
{
	if (!A || A == GetOwner() || A->IsActorBeingDestroyed()) return false;
	if (!TargetTag.IsNone() && !A->ActorHasTag(TargetTag)) return false;
	if (const ICombatTarget* T = Cast<ICombatTarget>(A))
	{
		if (T->IsCombatTargetDead()) return false;
	}
	return true;
}

FVector ULockOnComponent::GetFocusPoint(const AActor* Target) const
{
	FVector P;
	if (const ICombatTarget* T = Cast<ICombatTarget>(Target))
	{
		if (T->GetLockOnPoint(P)) return P;
	}
	return Target->GetActorLocation() + FVector(0.f, 0.f, FocusHeight);
}

bool ULockOnComponent::TryAcquireTarget()
{
	ACharacter* Char = Cast<ACharacter>(GetOwner());
	APlayerController* PC = Char ? Cast<APlayerController>(Char->GetController()) : nullptr;
	if (!PC) return false;

	const FVector Start = Char->GetActorLocation();
	const FVector Forward = FRotator(0.f, PC->GetControlRotation().Yaw, 0.f).Vector();
	FCollisionQueryParams Q(SCENE_QUERY_STAT(LockOnTrace), false, Char);

	// 1) The sphere trace straight ahead: nearest valid enemy inside the sweep.
	TArray<FHitResult> Hits;
	GetWorld()->SweepMultiByChannel(Hits, Start, Start + Forward * TraceDistance, FQuat::Identity, TargetChannel,
		FCollisionShape::MakeSphere(TraceRadius), Q);
	AActor* Best = nullptr;
	float BestDist = TNumericLimits<float>::Max();
	for (const FHitResult& H : Hits)
	{
		AActor* A = H.GetActor();
		if (!IsValidTarget(A)) continue;
		const float D = FVector::DistSquared(Start, A->GetActorLocation());
		if (D < BestDist) { BestDist = D; Best = A; }
	}

	// 2) Nothing dead ahead: pick the enemy closest to where you are facing, inside a cone.
	if (!Best)
	{
		TArray<FOverlapResult> Over;
		GetWorld()->OverlapMultiByChannel(Over, Start, FQuat::Identity, TargetChannel, FCollisionShape::MakeSphere(AssistRadius), Q);
		const float MinDot = FMath::Cos(FMath::DegreesToRadians(AssistHalfAngleDeg));
		float BestScore = -TNumericLimits<float>::Max();
		for (const FOverlapResult& O : Over)
		{
			AActor* A = O.GetActor();
			if (!IsValidTarget(A)) continue;
			const FVector To = (A->GetActorLocation() - Start);
			const float Dist = To.Size();
			const float Dot = FVector::DotProduct(Forward, To.GetSafeNormal2D());
			if (Dot < MinDot) continue;
			const float Score = Dot * 2.f - Dist / AssistRadius;
			if (Score > BestScore) { BestScore = Score; Best = A; }
		}
	}
	if (!Best) return false;
	SetTarget(Best);
	return true;
}

void ULockOnComponent::SwitchTarget(float Direction)
{
	AActor* Cur = CurrentTarget.Get();
	ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Cur || !Char || FMath::IsNearlyZero(Direction)) return;

	const FVector Start = Char->GetActorLocation();
	const float CurYaw = (Cur->GetActorLocation() - Start).Rotation().Yaw;
	FCollisionQueryParams Q(SCENE_QUERY_STAT(LockOnSwitch), false, Char);
	TArray<FOverlapResult> Over;
	GetWorld()->OverlapMultiByChannel(Over, Start, FQuat::Identity, TargetChannel, FCollisionShape::MakeSphere(AssistRadius), Q);

	AActor* Best = nullptr;
	float BestDelta = TNumericLimits<float>::Max();
	for (const FOverlapResult& O : Over)
	{
		AActor* A = O.GetActor();
		if (A == Cur || !IsValidTarget(A)) continue;
		const float Delta = FMath::FindDeltaAngleDegrees(CurYaw, (A->GetActorLocation() - Start).Rotation().Yaw);
		if (Direction > 0.f ? Delta <= 1.f : Delta >= -1.f) continue; // wrong side
		if (FMath::Abs(Delta) < BestDelta) { BestDelta = FMath::Abs(Delta); Best = A; }
	}
	if (Best) SetTarget(Best);
}

void ULockOnComponent::SetTarget(AActor* NewTarget)
{
	AActor* Old = CurrentTarget.Get();
	CurrentTarget = NewTarget;
	LostSightTimer = 0.f;
	ApplyStrafe(NewTarget != nullptr);
	SetComponentTickEnabled(NewTarget != nullptr);
	OnTargetChanged.Broadcast(NewTarget, Old);
}

void ULockOnComponent::ReleaseTarget()
{
	if (CurrentTarget.IsValid() || bStrafeApplied) SetTarget(nullptr);
}

void ULockOnComponent::ApplyStrafe(bool bOn)
{
	ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char) return;
	UCharacterMovementComponent* Move = Char->GetCharacterMovement();
	if (bOn && !bStrafeApplied)
	{
		bSavedOrient = Move->bOrientRotationToMovement;
		bSavedUseYaw = Char->bUseControllerRotationYaw;
		SavedWalkSpeed = Move->MaxWalkSpeed;
		Move->bOrientRotationToMovement = false;   // stop turning toward movement...
		Char->bUseControllerRotationYaw = true;     // ...and always face where the camera (= the enemy) points
		Move->MaxWalkSpeed = StrafeMaxWalkSpeed;
		bStrafeApplied = true;
	}
	else if (!bOn && bStrafeApplied)
	{
		Move->bOrientRotationToMovement = bSavedOrient;
		Char->bUseControllerRotationYaw = bSavedUseYaw;
		Move->MaxWalkSpeed = SavedWalkSpeed;
		bStrafeApplied = false;
	}
}

void ULockOnComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	ACharacter* Char = Cast<ACharacter>(GetOwner());
	AActor* Target = CurrentTarget.Get();
	APlayerController* PC = Char ? Cast<APlayerController>(Char->GetController()) : nullptr;
	if (!Char || !PC || !IsValidTarget(Target)) { ReleaseTarget(); return; }

	const FVector Eye = Char->GetActorLocation() + FVector(0.f, 0.f, PivotHeight);
	const FVector Focus = GetFocusPoint(Target);

	if (FVector::Dist(Eye, Focus) > MaxBreakDistance) { ReleaseTarget(); return; }

	// Lose the lock if a wall has been between you for a while.
	FCollisionQueryParams Q(SCENE_QUERY_STAT(LockOnSight), false, Char);
	Q.AddIgnoredActor(Target);
	const bool bBlocked = GetWorld()->LineTraceTestByChannel(Eye, Focus, ECC_Visibility, Q);
	LostSightTimer = bBlocked ? LostSightTimer + DeltaTime : 0.f;
	if (LostSightTimer > LostSightSeconds) { ReleaseTarget(); return; }

	// The camera orbit: ease the controller rotation toward "look at the target".
	FRotator Want = UKismetMathLibrary::FindLookAtRotation(Eye, Focus);
	Want.Pitch = FMath::Clamp(Want.Pitch + PitchOffset, MinPitch, MaxPitch);
	Want.Roll = 0.f;
	FRotator Next = FMath::RInterpTo(PC->GetControlRotation(), Want, DeltaTime, InterpSpeed);
	Next.Roll = 0.f;
	PC->SetControlRotation(Next);
}
