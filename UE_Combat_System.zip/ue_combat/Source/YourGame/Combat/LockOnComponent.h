#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "LockOnComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnLockTargetChanged, AActor*, NewTarget, AActor*, OldTarget);

/**
 * Attack-to-lock-on. Pressing attack sweeps a sphere forward; whatever it finds becomes CurrentTarget.
 * While locked: the controller rotation eases toward the target every frame, the character stops
 * orienting to movement and follows the controller yaw instead (so it always faces the enemy and
 * the strafe Blend Space takes over).
 */
UCLASS(ClassGroup = (Combat), meta = (BlueprintSpawnableComponent))
class YOURGAME_API ULockOnComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	ULockOnComponent();

	/** Sphere trace forward (with a cone-overlap fallback). Call from the attack input. */
	UFUNCTION(BlueprintCallable, Category = "LockOn") bool TryAcquireTarget();
	UFUNCTION(BlueprintCallable, Category = "LockOn") void ReleaseTarget();
	/** -1 = next target to the left, +1 = to the right (right-stick flick). */
	UFUNCTION(BlueprintCallable, Category = "LockOn") void SwitchTarget(float Direction);

	UFUNCTION(BlueprintPure, Category = "LockOn") bool HasTarget() const { return CurrentTarget.IsValid(); }
	UFUNCTION(BlueprintPure, Category = "LockOn") AActor* GetTarget() const { return CurrentTarget.Get(); }

	// ---- Detection ----
	UPROPERTY(EditAnywhere, Category = "LockOn|Detect") float TraceDistance = 900.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Detect") float TraceRadius = 140.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Detect") float AssistRadius = 1200.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Detect") float AssistHalfAngleDeg = 55.f;
	/** A channel your enemies respond to (Overlap or Block). Create a "LockOn" trace channel and use it here. */
	UPROPERTY(EditAnywhere, Category = "LockOn|Detect") TEnumAsByte<ECollisionChannel> TargetChannel = ECC_Pawn;
	UPROPERTY(EditAnywhere, Category = "LockOn|Detect") FName TargetTag = TEXT("Enemy");

	// ---- Camera ----
	UPROPERTY(EditAnywhere, Category = "LockOn|Camera") float InterpSpeed = 8.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Camera") float PivotHeight = 60.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Camera") float FocusHeight = 70.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Camera") float PitchOffset = -8.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Camera") float MinPitch = -35.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Camera") float MaxPitch = 15.f;

	// ---- Breaking the lock ----
	UPROPERTY(EditAnywhere, Category = "LockOn|Break") float MaxBreakDistance = 1600.f;
	UPROPERTY(EditAnywhere, Category = "LockOn|Break") float LostSightSeconds = 2.5f;

	// ---- Strafing ----
	UPROPERTY(EditAnywhere, Category = "LockOn|Strafe") float StrafeMaxWalkSpeed = 320.f;

	UPROPERTY(BlueprintAssignable) FOnLockTargetChanged OnTargetChanged;

protected:
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	bool IsValidTarget(const AActor* A) const;
	FVector GetFocusPoint(const AActor* Target) const;
	void SetTarget(AActor* NewTarget);
	void ApplyStrafe(bool bOn);

	TWeakObjectPtr<AActor> CurrentTarget;
	float LostSightTimer = 0.f;
	bool bSavedOrient = true;
	bool bSavedUseYaw = false;
	float SavedWalkSpeed = 600.f;
	bool bStrafeApplied = false;
};
