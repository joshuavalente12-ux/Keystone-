#include "AnimNotifyState_CombatWindow.h"
#include "CombatComponent.h"
#include "HitReactionComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"

static void Apply(USkeletalMeshComponent* MeshComp, ECombatWindow Window, bool bOn)
{
	if (!MeshComp || !MeshComp->GetWorld() || !MeshComp->GetWorld()->IsGameWorld()) return;
	AActor* Owner = MeshComp->GetOwner();
	if (!Owner) return;
	switch (Window)
	{
	case ECombatWindow::IFrames:
		if (UHitReactionComponent* H = Owner->FindComponentByClass<UHitReactionComponent>())
		{
			if (bOn) H->AddInvulnerability(); else H->RemoveInvulnerability();
		}
		break;
	case ECombatWindow::SuperArmor:
		if (UHitReactionComponent* H = Owner->FindComponentByClass<UHitReactionComponent>())
		{
			if (bOn) H->AddSuperArmor(); else H->RemoveSuperArmor();
		}
		break;
	case ECombatWindow::ComboWindow:
		if (UCombatComponent* C = Owner->FindComponentByClass<UCombatComponent>()) C->SetComboWindow(bOn);
		break;
	}
}

void UAnimNotifyState_CombatWindow::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	Apply(MeshComp, Window, true);
}

void UAnimNotifyState_CombatWindow::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyEnd(MeshComp, Animation, EventReference);
	Apply(MeshComp, Window, false);
}

FString UAnimNotifyState_CombatWindow::GetNotifyName_Implementation() const
{
	switch (Window)
	{
	case ECombatWindow::IFrames:     return TEXT("I-Frames");
	case ECombatWindow::ComboWindow: return TEXT("Combo Window");
	default:                         return TEXT("Super Armor");
	}
}
