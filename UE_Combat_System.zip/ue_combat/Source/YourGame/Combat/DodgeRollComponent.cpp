#include "DodgeRollComponent.h"
#include "CombatComponent.h"
#include "LockOnComponent.h"
#include "Animation/AnimInstance.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"
#include "KismetAnimationLibrary.h"

UDodgeRollComponent::UDodgeRollComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UDodgeRollComponent::BeginPlay()
{
	Super::BeginPlay();
	// Rolls move the capsule through root motion, so montages must be allowed to drive it.
	if (const ACharacter* C = Cast<ACharacter>(GetOwner()))
	{
		if (UAnimInstance* A = C->GetMesh()->GetAnimInstance())
			A->SetRootMotionMode(ERootMotionMode::RootMotionFromMontagesOnly);
	}
}

bool UDodgeRollComponent::CanRoll(bool bIgnoreCooldown) const
{
	if (bRolling) return false;
	if (!bIgnoreCooldown && GetWorld()->GetTimeSeconds() - LastRollEndTime < Cooldown) return false;
	const ACharacter* C = Cast<ACharacter>(GetOwner());
	return C && C->GetCharacterMovement()->IsMovingOnGround();
}

ERollDirection UDodgeRollComponent::ResolveDirection(bool& bOutUseBackStep)
{
	bOutUseBackStep = false;
	ACharacter* C = Cast<ACharacter>(GetOwner());

	// Input first; if the stick is neutral this frame, fall back to the acceleration the movement component computed.
	FVector Input = C->GetLastMovementInputVector();
	if (Input.IsNearlyZero(0.05f)) Input = C->GetCharacterMovement()->GetCurrentAcceleration();
	Input.Z = 0.f;

	if (Input.IsNearlyZero(0.05f))
	{
		bOutUseBackStep = true;
		return ERollDirection::Backward;
	}
	Input = Input.GetSafeNormal();

	const ULockOnComponent* Lock = C->FindComponentByClass<ULockOnComponent>();
	if (Lock && Lock->HasTarget())
	{
		// Locked on you face the enemy the whole time, so "forward/left/right/back" is relative to that facing.
		const float A = UKismetAnimationLibrary::CalculateDirection(Input, C->GetActorRotation()); // -180..180
		if (FMath::Abs(A) <= 45.f) return ERollDirection::Forward;
		if (A > 45.f && A <= 135.f) return ERollDirection::Right;
		if (A < -45.f && A >= -135.f) return ERollDirection::Left;
		return ERollDirection::Backward;
	}

	// Free roaming: turn to the stick, then roll forward. Reads far better than a sideways roll with no target.
	C->SetActorRotation(FRotator(0.f, Input.Rotation().Yaw, 0.f));
	return ERollDirection::Forward;
}

bool UDodgeRollComponent::RequestRoll()
{
	return TryRoll(false);
}

bool UDodgeRollComponent::TryRoll(bool bIgnoreCooldown)
{
	ACharacter* C = Cast<ACharacter>(GetOwner());
	if (!C) return false;
	const float Now = GetWorld()->GetTimeSeconds();

	if (!CanRoll(bIgnoreCooldown))
	{
		BufferedAt = Now; // remembered; consumed when the current roll ends
		return false;
	}
	bool bBack = false;
	const ERollDirection Dir = ResolveDirection(bBack);

	UAnimMontage* M = nullptr;
	if (bBack && BackStep) M = BackStep;
	else switch (Dir)
	{
	case ERollDirection::Forward:  M = RollForward; break;
	case ERollDirection::Backward: M = RollBackward; break;
	case ERollDirection::Left:     M = RollLeft; break;
	case ERollDirection::Right:    M = RollRight; break;
	}
	if (!M) return false;
	if (!ConsumeStamina(StaminaCost)) return false;

	StartRoll(M);
	return bRolling;
}

void UDodgeRollComponent::StartRoll(UAnimMontage* Montage)
{
	ACharacter* C = Cast<ACharacter>(GetOwner());
	UAnimInstance* Anim = C->GetMesh()->GetAnimInstance();
	if (!Anim) return;

	if (UCombatComponent* Combat = C->FindComponentByClass<UCombatComponent>()) Combat->CancelAttack();
	Anim->StopAllMontages(0.08f);

	if (Anim->Montage_Play(Montage, 1.f) <= 0.f) return;
	ActiveMontage = Montage;
	bRolling = true;

	bSavedOrient = C->GetCharacterMovement()->bOrientRotationToMovement;
	C->GetCharacterMovement()->bOrientRotationToMovement = false; // the montage decides where the body points
	if (AController* Ctrl = C->GetController()) Ctrl->SetIgnoreMoveInput(true);

	FOnMontageEnded End;
	End.BindUObject(this, &UDodgeRollComponent::OnRollEnded);
	Anim->Montage_SetEndDelegate(End, Montage);
}

void UDodgeRollComponent::OnRollEnded(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage != ActiveMontage) return;
	ActiveMontage = nullptr;
	bRolling = false;
	LastRollEndTime = GetWorld()->GetTimeSeconds();

	if (ACharacter* C = Cast<ACharacter>(GetOwner()))
	{
		// If a lock-on started during the roll it owns this flag now; only restore when it is not strafing.
		const ULockOnComponent* Lock = C->FindComponentByClass<ULockOnComponent>();
		if (!(Lock && Lock->HasTarget())) C->GetCharacterMovement()->bOrientRotationToMovement = bSavedOrient;
		if (AController* Ctrl = C->GetController()) Ctrl->SetIgnoreMoveInput(false);
	}
	if (LastRollEndTime - BufferedAt <= InputBufferSeconds) TryRoll(true);
}
