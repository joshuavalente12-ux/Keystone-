#include "EnemyCharacterBase.h"
#include "HitReactionComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "MotionWarpingComponent.h"

AEnemyCharacterBase::AEnemyCharacterBase()
{
	Combat = CreateDefaultSubobject<UCombatComponent>(TEXT("Combat"));
	HitReaction = CreateDefaultSubobject<UHitReactionComponent>(TEXT("HitReaction"));
	MotionWarping = CreateDefaultSubobject<UMotionWarpingComponent>(TEXT("MotionWarping"));

	Tags.Add(TEXT("Enemy"));
	Combat->HittableTags.Add(TEXT("Player"));

	// Monsters turn toward where they walk with a limited turn rate: heavy things do not pivot on a coin.
	bUseControllerRotationYaw = false;
	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.f, 240.f, 0.f);

	// Flash red-ish on monsters so a hit reads instantly; players usually keep white.
	HitReaction->FlashColor = FLinearColor(1.f, 0.85f, 0.7f);
	HitReaction->bUsePhysicalReaction = true;
}

void AEnemyCharacterBase::BeginPlay()
{
	Super::BeginPlay();
	Combat->OnAttackFinished.AddDynamic(this, &AEnemyCharacterBase::HandleAttackFinished);
	HitReaction->OnStaggered.AddDynamic(this, &AEnemyCharacterBase::HandleStaggered);
}

bool AEnemyCharacterBase::IsCombatTargetDead() const
{
	return HitReaction && HitReaction->IsDead();
}

bool AEnemyCharacterBase::GetLockOnPoint(FVector& OutPoint) const
{
	if (GetMesh() && GetMesh()->DoesSocketExist(LockOnSocket))
	{
		OutPoint = GetMesh()->GetSocketLocation(LockOnSocket);
		return true;
	}
	return false;
}

bool AEnemyCharacterBase::IsBusy() const
{
	return Combat && Combat->IsAttacking();
}

bool AEnemyCharacterBase::TryAttack(AActor* Target)
{
	if (!Target || IsBusy() || IsCombatTargetDead()) return false;
	const float Now = GetWorld()->GetTimeSeconds();
	const float Dist = FVector::Dist2D(GetActorLocation(), Target->GetActorLocation());

	TArray<int32> Candidates;
	float TotalWeight = 0.f;
	for (int32 i = 0; i < Attacks.Num(); ++i)
	{
		const FEnemyAttack& A = Attacks[i];
		if (!A.Attack.Montage || Now < A.ReadyAt || Dist < A.MinRange || Dist > A.MaxRange) continue;
		Candidates.Add(i);
		TotalWeight += FMath::Max(A.Weight, 0.01f);
	}
	if (Candidates.Num() == 0) return false;

	// Weighted random pick so the monster does not loop the same move.
	float Roll = FMath::FRandRange(0.f, TotalWeight);
	int32 Chosen = Candidates.Last();
	for (int32 i : Candidates)
	{
		Roll -= FMath::Max(Attacks[i].Weight, 0.01f);
		if (Roll <= 0.f) { Chosen = i; break; }
	}
	if (!Combat->PlayAttack(Attacks[Chosen].Attack, Target)) return false;
	Attacks[Chosen].ReadyAt = Now + Attacks[Chosen].Cooldown;
	return true;
}

void AEnemyCharacterBase::HandleAttackFinished(bool bInterrupted)
{
	OnEnemyAttackFinished.Broadcast(bInterrupted);
}

void AEnemyCharacterBase::HandleStaggered()
{
	// Stagger montages stop the attack montage, which already calls HandleAttackFinished(true).
	// Hook Blueprint here for a roar, a shield-break sound, or an aggro reset.
}
