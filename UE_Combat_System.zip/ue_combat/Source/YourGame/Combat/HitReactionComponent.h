#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CombatTypes.h"
#include "HitReactionComponent.generated.h"

class UCameraShakeBase;
class UMaterialInstanceDynamic;
class USkeletalMeshComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnHitTaken, const FHitData&, Data, AActor*, Attacker, float, DamageDealt);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDied, AActor*, Killer);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnStaggered);

/**
 * Everything that happens to a character that gets hit: damage, poise, directional flinch or
 * stagger, colour flash, knockback, victim camera shake, physical (ragdoll-blend) reaction and death.
 * Put it on the player AND on every enemy.
 */
UCLASS(ClassGroup = (Combat), meta = (BlueprintSpawnableComponent))
class YOURGAME_API UHitReactionComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UHitReactionComponent();

	/** Called by the attacker's melee trace. Returns false if the hit was ignored (dead, i-frames). */
	bool ReceiveHit(AActor* Attacker, const FHitData& Data, const FHitResult& Hit);

	void AddInvulnerability() { ++InvulnerableCount; }
	void RemoveInvulnerability() { InvulnerableCount = FMath::Max(0, InvulnerableCount - 1); }
	void AddSuperArmor() { ++SuperArmorCount; }
	void RemoveSuperArmor() { SuperArmorCount = FMath::Max(0, SuperArmorCount - 1); }

	UFUNCTION(BlueprintPure, Category = "Combat") bool IsDead() const { return bDead; }
	UFUNCTION(BlueprintPure, Category = "Combat") float GetHealth() const { return Health; }
	UFUNCTION(BlueprintPure, Category = "Combat") float GetHealthFraction() const { return MaxHealth > 0.f ? Health / MaxHealth : 0.f; }
	UFUNCTION(BlueprintCallable, Category = "Combat") void Die(AActor* Killer, FVector Impulse, FVector ImpactPoint, FName Bone);

	// ---- Health / poise ----
	/** Off = you drive health from your own system (bind OnHitTaken, call Die yourself). */
	UPROPERTY(EditAnywhere, Category = "Health") bool bUseBuiltInHealth = true;
	UPROPERTY(EditAnywhere, Category = "Health") float MaxHealth = 100.f;
	UPROPERTY(EditAnywhere, Category = "Poise") float MaxPoise = 60.f;
	UPROPERTY(EditAnywhere, Category = "Poise") float PoiseRegenPerSecond = 30.f;
	UPROPERTY(EditAnywhere, Category = "Poise") float PoiseRegenDelay = 2.f;

	// ---- Flinch / stagger montages (put flinches in an additive upper-body slot, staggers in FullBody) ----
	UPROPERTY(EditAnywhere, Category = "Reactions") FDirectionalMontages Flinch;
	UPROPERTY(EditAnywhere, Category = "Reactions") FDirectionalMontages Stagger;

	// ---- Flash (needs HitFlashAmount / HitFlashColor parameters in the character's materials) ----
	UPROPERTY(EditAnywhere, Category = "Flash") FLinearColor FlashColor = FLinearColor::White;
	UPROPERTY(EditAnywhere, Category = "Flash") float FlashDuration = 0.16f;
	UPROPERTY(EditAnywhere, Category = "Flash") FName FlashAmountParam = TEXT("HitFlashAmount");
	UPROPERTY(EditAnywhere, Category = "Flash") FName FlashColorParam = TEXT("HitFlashColor");

	// ---- Knockback ----
	/** 0 = full knockback, 1 = immovable (bosses). */
	UPROPERTY(EditAnywhere, Category = "Knockback", meta = (ClampMin = "0", ClampMax = "1")) float KnockbackResistance = 0.f;

	// ---- Camera (players) ----
	UPROPERTY(EditAnywhere, Category = "Camera") TSubclassOf<UCameraShakeBase> TakeHitShake;

	// ---- Physical reaction: bones below PhysicalBone briefly go ragdoll and blend back. Great on monsters. ----
	UPROPERTY(EditAnywhere, Category = "Physical") bool bUsePhysicalReaction = false;
	UPROPERTY(EditAnywhere, Category = "Physical") FName PhysicalBone = TEXT("spine_01");
	UPROPERTY(EditAnywhere, Category = "Physical") float PhysicalBlend = 0.55f;
	UPROPERTY(EditAnywhere, Category = "Physical") float PhysicalDuration = 0.35f;
	UPROPERTY(EditAnywhere, Category = "Physical") float PhysicalImpulse = 900.f;

	// ---- Death ----
	UPROPERTY(EditAnywhere, Category = "Death") bool bRagdollOnDeath = true;
	UPROPERTY(EditAnywhere, Category = "Death") float DeathLifeSpan = 12.f;

	UPROPERTY(BlueprintAssignable) FOnHitTaken OnHitTaken;
	UPROPERTY(BlueprintAssignable) FOnStaggered OnStaggered;
	UPROPERTY(BlueprintAssignable) FOnDied OnDied;

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	EHitDirection GetHitDirection(const FVector& ToAttacker) const;
	void PlayReaction(const FVector& ToAttacker, const FHitData& Data);
	void ApplyKnockback(const FVector& Travel, const FHitData& Data);
	void StartFlash();
	void StartPhysicalReaction(const FVector& Travel, const FHitResult& Hit);
	void SetTickNeeded();

	USkeletalMeshComponent* GetMesh() const;

	UPROPERTY(Transient) TArray<TObjectPtr<UMaterialInstanceDynamic>> Materials;

	float Health = 100.f;
	float Poise = 60.f;
	float LastPoiseHitTime = -100.f;
	float FlashAmount = 0.f;
	float PhysicalAlpha = 0.f;
	int32 InvulnerableCount = 0;
	int32 SuperArmorCount = 0;
	bool bDead = false;
};
