#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimMontage.h"
#include "CombatTypes.generated.h"

class UDamageType;

UENUM(BlueprintType)
enum class EHitDirection : uint8 { Front, Back, Left, Right };

UENUM(BlueprintType)
enum class ERollDirection : uint8 { Forward, Backward, Left, Right };

/** What an AnimNotifyState_CombatWindow switches on while it is active. */
UENUM(BlueprintType)
enum class ECombatWindow : uint8
{
	IFrames,      // cannot be hurt (dodge roll)
	ComboWindow,  // the next attack input chains immediately
	SuperArmor    // light hits do not flinch you (wind-ups, heavy attacks)
};

/** Everything one hit carries. Lives on the attack, overridable on the notify. */
USTRUCT(BlueprintType)
struct FHitData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) float Damage = 20.f;
	/** Knocks the victim's poise down; at 0 they stagger instead of just flinching. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float PoiseDamage = 25.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float KnockbackStrength = 350.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float KnockbackUpward = 60.f;
	/** Real seconds both fighters freeze for. Light 0.05-0.07, heavy 0.09-0.14. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float HitStopDuration = 0.07f;
	/** Time scale during the freeze. 0.02 = almost frozen. Never use exactly 0. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float HitStopDilation = 0.02f;
	/** Camera shake scale on the attacker's camera when this connects. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float LandShakeScale = 0.6f;
	/** Camera shake scale on the victim's camera if they are a player. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float TakeShakeScale = 1.f;
	/** Always stagger, whatever the victim's poise. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bForceStagger = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TSubclassOf<UDamageType> DamageType;
};

/** Configuration of one melee-trace notify state. */
USTRUCT(BlueprintType)
struct FMeleeTraceParams
{
	GENERATED_BODY()

	FName StartSocket = TEXT("weapon_base");
	FName EndSocket = TEXT("weapon_tip");
	float Radius = 14.f;
	int32 SamplePoints = 4;
	float DamageScale = 1.f;
	bool bOverrideHit = false;
	FHitData Hit;
};

/** Montage lists per direction, so hit reactions and rolls can vary. */
USTRUCT(BlueprintType)
struct FDirectionalMontages
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<TObjectPtr<UAnimMontage>> Front;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<TObjectPtr<UAnimMontage>> Back;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<TObjectPtr<UAnimMontage>> Left;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<TObjectPtr<UAnimMontage>> Right;

	/** A random montage for [Dir], falling back to Front if that side is empty. */
	UAnimMontage* Pick(EHitDirection Dir) const
	{
		const TArray<TObjectPtr<UAnimMontage>>* List = &Front;
		switch (Dir)
		{
		case EHitDirection::Back:  List = &Back; break;
		case EHitDirection::Left:  List = &Left; break;
		case EHitDirection::Right: List = &Right; break;
		default: break;
		}
		if (List->Num() == 0) List = &Front;
		if (List->Num() == 0) return nullptr;
		return (*List)[FMath::RandHelper(List->Num())];
	}
};
