#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CombatTypes.h"
#include "CombatComponent.generated.h"

class UAnimMontage;
class UCameraShakeBase;
class UMeshComponent;
class UAnimInstance;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAttackFinished, bool, bInterrupted);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnHitLanded, AActor*, Victim, const FHitResult&, Hit, const FHitData&, Data);

USTRUCT(BlueprintType)
struct FAttackData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) TObjectPtr<UAnimMontage> Montage = nullptr;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FHitData Hit;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float PlayRate = 1.f;
	/** Name of a Motion Warping target used by a Motion Warping notify in the montage. None = no warping. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FName WarpTargetName = NAME_None;
	/** The warp target stops this far short of the enemy so the swing lands at the right spacing. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float WarpStopDistance = 110.f;
	/** No warping if the target is further than this (avoids lunging across the map). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float MaxWarpDistance = 450.f;
};

/**
 * Owns attacking: the combo chain, input buffering, facing/warping toward the target, and the
 * frame-accurate melee trace that AnimNotifyState_MeleeTrace drives. Works on players and enemies.
 */
UCLASS(ClassGroup = (Combat), meta = (BlueprintSpawnableComponent))
class YOURGAME_API UCombatComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UCombatComponent();

	/** Player entry point: first press acquires a lock-on target and starts the combo, later presses chain it. */
	UFUNCTION(BlueprintCallable, Category = "Combat") bool RequestAttack();
	/** Enemy / scripted entry point. */
	UFUNCTION(BlueprintCallable, Category = "Combat") bool PlayAttack(const FAttackData& Attack, AActor* Target = nullptr);
	UFUNCTION(BlueprintCallable, Category = "Combat") void CancelAttack();
	UFUNCTION(BlueprintPure, Category = "Combat") bool IsAttacking() const { return bAttackActive; }

	// ---- Called by the anim notify states (game thread, once per animation update) ----
	void BeginMeleeTrace(const FMeleeTraceParams& Params);
	void TickMeleeTrace(const FMeleeTraceParams& Params);
	void EndMeleeTrace();
	void SetComboWindow(bool bOpen);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combo") TArray<FAttackData> LightCombo;

	/** Channel the weapon sweeps use. Make a "Weapon" trace channel; capsules ignore it, mesh physics bodies overlap it. */
	UPROPERTY(EditAnywhere, Category = "Trace") TEnumAsByte<ECollisionChannel> TraceChannel = ECC_Pawn;
	/** Only actors carrying one of these tags can be hit (Player hits "Enemy", enemies hit "Player"). Empty = anyone. */
	UPROPERTY(EditAnywhere, Category = "Trace") TArray<FName> HittableTags;
	/** Give the weapon mesh the component tag "Weapon" if the sockets are on a separate weapon mesh. */
	UPROPERTY(EditAnywhere, Category = "Trace") bool bDrawDebugTrace = false;

	UPROPERTY(EditAnywhere, Category = "Feedback") TSubclassOf<UCameraShakeBase> LandHitShake;

	UPROPERTY(BlueprintAssignable) FOnAttackFinished OnAttackFinished;
	UPROPERTY(BlueprintAssignable) FOnHitLanded OnHitLanded;

protected:
	virtual void BeginPlay() override;

private:
	UAnimInstance* GetAnim() const;
	UMeshComponent* GetTraceMesh() const;
	AActor* GetLockedTarget() const;
	void StartAttack(const FAttackData& Attack, AActor* Target);
	void AdvanceCombo();
	void FaceTarget(AActor* Target);
	void UpdateWarp(const FAttackData& Attack, AActor* Target);
	void OnAttackMontageEnded(UAnimMontage* Montage, bool bInterrupted);
	bool ProcessHit(AActor* Victim, const FHitResult& Hit, const FMeleeTraceParams& P);

	FAttackData CurrentAttack;
	UPROPERTY(Transient) TObjectPtr<UAnimMontage> ActiveMontage;
	TWeakObjectPtr<AActor> AttackTarget;
	int32 ComboIndex = 0;
	bool bAttackActive = false;
	bool bComboWindowOpen = false;
	bool bAttackBuffered = false;

	// Per-swing trace state. It lives HERE, not on the notify object, because a notify asset is shared by every character.
	TSet<TWeakObjectPtr<AActor>> HitThisSwing;
	FVector PrevBase = FVector::ZeroVector;
	FVector PrevTip = FVector::ZeroVector;
	bool bHavePrev = false;
};
