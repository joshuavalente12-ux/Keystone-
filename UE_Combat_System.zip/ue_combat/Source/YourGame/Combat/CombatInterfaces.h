#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "CombatInterfaces.generated.h"

UINTERFACE(MinimalAPI, meta = (CannotImplementInterfaceInBlueprint))
class UCombatTarget : public UInterface
{
	GENERATED_BODY()
};

/** Implement on characters that can be locked on to (enemies, bosses). */
class YOURGAME_API ICombatTarget
{
	GENERATED_BODY()

public:
	virtual bool IsCombatTargetDead() const { return false; }
	/** Where the camera should look. Return false to use actor location + the lock-on focus height. */
	virtual bool GetLockOnPoint(FVector& OutPoint) const { return false; }
};
