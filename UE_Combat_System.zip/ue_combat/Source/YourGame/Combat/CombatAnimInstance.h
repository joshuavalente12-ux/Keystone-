#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "CombatAnimInstance.generated.h"

class ACharacter;
class UCharacterMovementComponent;

/**
 * Parent class for the player's AND every humanoid/monster AnimBP. Feeds the locomotion state
 * machine, the strafe Blend Space, lean, and the Aim Offset so heads and torsos track targets.
 */
UCLASS()
class YOURGAME_API UCombatAnimInstance : public UAnimInstance
{
	GENERATED_BODY()

public:
	virtual void NativeInitializeAnimation() override;
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

	/** Horizontal speed in cm/s: X axis of the locomotion Blend Space. */
	UPROPERTY(BlueprintReadOnly, Category = "Locomotion") float GroundSpeed = 0.f;
	/** -180..180, movement direction relative to where the body faces: Y axis of the strafe Blend Space. */
	UPROPERTY(BlueprintReadOnly, Category = "Locomotion") float Direction = 0.f;
	UPROPERTY(BlueprintReadOnly, Category = "Locomotion") bool bShouldMove = false;
	UPROPERTY(BlueprintReadOnly, Category = "Locomotion") bool bIsInAir = false;
	/** True while the LockOnComponent holds a target: switch the state machine to the strafe set. */
	UPROPERTY(BlueprintReadOnly, Category = "Combat") bool bIsLockedOn = false;
	/** -1..1 how hard the body is turning. Drives an additive lean. */
	UPROPERTY(BlueprintReadOnly, Category = "Locomotion") float Lean = 0.f;
	/** Aim Offset inputs: where the head/torso should point relative to the body. */
	UPROPERTY(BlueprintReadOnly, Category = "Aim") float AimYaw = 0.f;
	UPROPERTY(BlueprintReadOnly, Category = "Aim") float AimPitch = 0.f;

	UPROPERTY(EditAnywhere, Category = "Locomotion") float LeanScale = 0.02f;

private:
	UPROPERTY(Transient) TObjectPtr<ACharacter> Character;
	UPROPERTY(Transient) TObjectPtr<UCharacterMovementComponent> Movement;
	float PrevYaw = 0.f;
};
