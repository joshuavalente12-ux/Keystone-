#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "CombatInterfaces.h"
#include "CombatComponent.h"
#include "EnemyCharacterBase.generated.h"

class UHitReactionComponent;
class UMotionWarpingComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEnemyAttackFinished, bool, bInterrupted);

/** One move in a monster's repertoire. */
USTRUCT(BlueprintType)
struct FEnemyAttack
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) FAttackData Attack;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float MinRange = 0.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float MaxRange = 250.f;
	/** Higher = picked more often when several attacks are in range. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float Weight = 1.f;
	/** Seconds before this move can be used again. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float Cooldown = 2.f;

	float ReadyAt = 0.f;
};

/**
 * Base class for monsters: combat + hit reaction + motion warping already wired, plus a move list
 * with range/weight/cooldown selection. Behavior Trees / State Trees just call TryAttack().
 */
UCLASS()
class YOURGAME_API AEnemyCharacterBase : public ACharacter, public ICombatTarget
{
	GENERATED_BODY()

public:
	AEnemyCharacterBase();

	/** Picks an attack that suits the distance to [Target] and plays it. False if nothing is ready/in range. */
	UFUNCTION(BlueprintCallable, Category = "Enemy") bool TryAttack(AActor* Target);
	UFUNCTION(BlueprintPure, Category = "Enemy") bool IsBusy() const;

	virtual bool IsCombatTargetDead() const override;
	virtual bool GetLockOnPoint(FVector& OutPoint) const override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Enemy") TArray<FEnemyAttack> Attacks;
	/** Socket the camera aims at when locked on (chest height reads best). */
	UPROPERTY(EditAnywhere, Category = "Enemy") FName LockOnSocket = TEXT("spine_03");

	UPROPERTY(BlueprintAssignable) FOnEnemyAttackFinished OnEnemyAttackFinished;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UCombatComponent> Combat;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UHitReactionComponent> HitReaction;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UMotionWarpingComponent> MotionWarping;

protected:
	virtual void BeginPlay() override;

private:
	UFUNCTION() void HandleAttackFinished(bool bInterrupted);
	UFUNCTION() void HandleStaggered();
};
