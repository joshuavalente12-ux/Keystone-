#include "HitStopSubsystem.h"
#include "GameFramework/Actor.h"
#include "Engine/World.h"
#include "Stats/Stats.h"

TStatId UHitStopSubsystem::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(UHitStopSubsystem, STATGROUP_Tickables);
}

void UHitStopSubsystem::RequestHitStop(AActor* Actor, float Duration, float Dilation)
{
	if (!Actor || Duration <= 0.f) return;
	const float Now = GetWorld()->GetTimeSeconds();
	Dilation = FMath::Clamp(Dilation, 0.005f, 1.f);

	if (FEntry* Existing = Entries.Find(Actor))
	{
		Existing->EndTime = FMath::Max(Existing->EndTime, Now + Duration);
		Actor->CustomTimeDilation = FMath::Min(Actor->CustomTimeDilation, Dilation);
		return;
	}
	FEntry E;
	E.EndTime = Now + Duration;
	E.OriginalDilation = Actor->CustomTimeDilation;
	Entries.Add(Actor, E);
	Actor->CustomTimeDilation = Dilation;
}

void UHitStopSubsystem::Tick(float DeltaTime)
{
	if (Entries.Num() == 0) return;
	const float Now = GetWorld()->GetTimeSeconds();
	for (auto It = Entries.CreateIterator(); It; ++It)
	{
		AActor* A = It.Key().Get();
		if (!A)
		{
			It.RemoveCurrent();
		}
		else if (Now >= It.Value().EndTime)
		{
			A->CustomTimeDilation = It.Value().OriginalDilation;
			It.RemoveCurrent();
		}
	}
}
