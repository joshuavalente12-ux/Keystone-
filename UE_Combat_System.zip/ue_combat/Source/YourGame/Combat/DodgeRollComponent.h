#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CombatTypes.h"
#include "DodgeRollComponent.generated.h"

class UAnimMontage;
class ULockOnComponent;
class UCombatComponent;

/**
 * Directional dodge roll driven by root-motion montages. Reads the input vector, works out whether
 * that is forward / back / left / right relative to where you are FACING, and plays the matching montage.
 * Add an AnimNotifyState_CombatWindow (IFrames) to each montage for the invulnerable frames.
 */
UCLASS(ClassGroup = (Combat), meta = (BlueprintSpawnableComponent))
class YOURGAME_API UDodgeRollComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UDodgeRollComponent();

	UFUNCTION(BlueprintCallable, Category = "Dodge") bool RequestRoll();
	UFUNCTION(BlueprintPure, Category = "Dodge") bool IsRolling() const { return bRolling; }

	/** Override in Blueprint to spend stamina. Return false to refuse the roll. */
	UFUNCTION(BlueprintNativeEvent, Category = "Dodge") bool ConsumeStamina(float Cost);
	virtual bool ConsumeStamina_Implementation(float Cost) { return true; }

	UPROPERTY(EditAnywhere, Category = "Dodge|Montages") TObjectPtr<UAnimMontage> RollForward;
	UPROPERTY(EditAnywhere, Category = "Dodge|Montages") TObjectPtr<UAnimMontage> RollBackward;
	UPROPERTY(EditAnywhere, Category = "Dodge|Montages") TObjectPtr<UAnimMontage> RollLeft;
	UPROPERTY(EditAnywhere, Category = "Dodge|Montages") TObjectPtr<UAnimMontage> RollRight;
	/** Used when you press dodge with no direction held. */
	UPROPERTY(EditAnywhere, Category = "Dodge|Montages") TObjectPtr<UAnimMontage> BackStep;

	UPROPERTY(EditAnywhere, Category = "Dodge") float StaminaCost = 20.f;
	UPROPERTY(EditAnywhere, Category = "Dodge") float Cooldown = 0.15f;
	/** A dodge pressed this close to the end of a roll or attack is remembered and fires the moment it can. */
	UPROPERTY(EditAnywhere, Category = "Dodge") float InputBufferSeconds = 0.25f;

protected:
	virtual void BeginPlay() override;

private:
	bool TryRoll(bool bIgnoreCooldown);
	bool CanRoll(bool bIgnoreCooldown) const;
	ERollDirection ResolveDirection(bool& bOutUseBackStep);
	void StartRoll(UAnimMontage* Montage);
	void OnRollEnded(UAnimMontage* Montage, bool bInterrupted);

	UPROPERTY(Transient) TObjectPtr<UAnimMontage> ActiveMontage;
	bool bRolling = false;
	bool bSavedOrient = true;
	float LastRollEndTime = -100.f;
	float BufferedAt = -100.f;
};
