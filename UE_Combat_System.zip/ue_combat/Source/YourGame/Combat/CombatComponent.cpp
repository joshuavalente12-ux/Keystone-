#include "CombatComponent.h"
#include "HitReactionComponent.h"
#include "HitStopSubsystem.h"
#include "LockOnComponent.h"
#include "Animation/AnimInstance.h"
#include "Camera/CameraShakeBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "MotionWarpingComponent.h"

UCombatComponent::UCombatComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UCombatComponent::BeginPlay()
{
	Super::BeginPlay();
	if (UAnimInstance* A = GetAnim()) A->SetRootMotionMode(ERootMotionMode::RootMotionFromMontagesOnly);
}

UAnimInstance* UCombatComponent::GetAnim() const
{
	const ACharacter* C = Cast<ACharacter>(GetOwner());
	return (C && C->GetMesh()) ? C->GetMesh()->GetAnimInstance() : nullptr;
}

UMeshComponent* UCombatComponent::GetTraceMesh() const
{
	if (UMeshComponent* W = GetOwner()->FindComponentByTag<UMeshComponent>(TEXT("Weapon"))) return W;
	const ACharacter* C = Cast<ACharacter>(GetOwner());
	return C ? C->GetMesh() : nullptr;
}

AActor* UCombatComponent::GetLockedTarget() const
{
	const ULockOnComponent* L = GetOwner()->FindComponentByClass<ULockOnComponent>();
	return L ? L->GetTarget() : nullptr;
}

// ---------------------------------------------------------------------------------------------
// Attacking
// ---------------------------------------------------------------------------------------------

bool UCombatComponent::RequestAttack()
{
	if (LightCombo.Num() == 0) return false;

	// Pillar 2: the attack press is what finds your target.
	if (ULockOnComponent* Lock = GetOwner()->FindComponentByClass<ULockOnComponent>())
	{
		if (!Lock->HasTarget()) Lock->TryAcquireTarget();
	}

	if (bAttackActive)
	{
		if (bComboWindowOpen) AdvanceCombo();
		else bAttackBuffered = true; // pressed early: fires the instant the combo window opens
		return true;
	}
	ComboIndex = 0;
	StartAttack(LightCombo[0], GetLockedTarget());
	return bAttackActive;
}

bool UCombatComponent::PlayAttack(const FAttackData& Attack, AActor* Target)
{
	if (bAttackActive) return false;
	StartAttack(Attack, Target);
	return bAttackActive;
}

void UCombatComponent::AdvanceCombo()
{
	bAttackBuffered = false;
	bComboWindowOpen = false;
	if (ComboIndex + 1 >= LightCombo.Num()) return; // end of the chain
	++ComboIndex;
	StartAttack(LightCombo[ComboIndex], GetLockedTarget());
}

void UCombatComponent::StartAttack(const FAttackData& Attack, AActor* Target)
{
	UAnimInstance* Anim = GetAnim();
	if (!Anim || !Attack.Montage) return;

	EndMeleeTrace();
	CurrentAttack = Attack;
	AttackTarget = Target;
	FaceTarget(Target);
	UpdateWarp(Attack, Target);

	if (Anim->Montage_Play(Attack.Montage, Attack.PlayRate) <= 0.f) return;
	ActiveMontage = Attack.Montage;
	bAttackActive = true;
	bComboWindowOpen = false;
	bAttackBuffered = false;

	FOnMontageEnded End;
	End.BindUObject(this, &UCombatComponent::OnAttackMontageEnded);
	Anim->Montage_SetEndDelegate(End, Attack.Montage);
}

void UCombatComponent::FaceTarget(AActor* Target)
{
	AActor* Owner = GetOwner();
	if (Target)
	{
		FRotator R = (Target->GetActorLocation() - Owner->GetActorLocation()).Rotation();
		R.Pitch = 0.f; R.Roll = 0.f;
		Owner->SetActorRotation(R);
		return;
	}
	// No target: swing where the stick points, so the attack goes where you meant it to.
	if (const ACharacter* C = Cast<ACharacter>(Owner))
	{
		const FVector Input = C->GetLastMovementInputVector();
		if (!Input.IsNearlyZero(0.1f)) Owner->SetActorRotation(FRotator(0.f, Input.Rotation().Yaw, 0.f));
	}
}

void UCombatComponent::UpdateWarp(const FAttackData& Attack, AActor* Target)
{
	if (Attack.WarpTargetName.IsNone()) return;
	UMotionWarpingComponent* Warp = GetOwner()->FindComponentByClass<UMotionWarpingComponent>();
	if (!Warp) return;
	if (!Target)
	{
		Warp->RemoveWarpTarget(Attack.WarpTargetName);
		return;
	}
	const FVector Me = GetOwner()->GetActorLocation();
	const FVector To = Target->GetActorLocation() - Me;
	const float Dist = To.Size2D();
	if (Dist > Attack.MaxWarpDistance)
	{
		Warp->RemoveWarpTarget(Attack.WarpTargetName);
		return;
	}
	const FVector Dir = To.GetSafeNormal2D();
	const FVector Goal = Target->GetActorLocation() - Dir * Attack.WarpStopDistance;
	Warp->AddOrUpdateWarpTargetFromLocationAndRotation(Attack.WarpTargetName, FVector(Goal.X, Goal.Y, Me.Z), Dir.Rotation());
}

void UCombatComponent::CancelAttack()
{
	if (!bAttackActive) return;
	if (UAnimInstance* A = GetAnim())
	{
		if (ActiveMontage) A->Montage_Stop(0.1f, ActiveMontage);
	}
	// OnAttackMontageEnded finishes the cleanup.
}

void UCombatComponent::OnAttackMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage != ActiveMontage) return; // an older montage ending because a chained attack replaced it
	ActiveMontage = nullptr;
	bAttackActive = false;
	bComboWindowOpen = false;
	bAttackBuffered = false;
	ComboIndex = 0;
	EndMeleeTrace();
	OnAttackFinished.Broadcast(bInterrupted);
}

void UCombatComponent::SetComboWindow(bool bOpen)
{
	bComboWindowOpen = bOpen;
	if (bOpen && bAttackBuffered && bAttackActive) AdvanceCombo();
}

// ---------------------------------------------------------------------------------------------
// The frame-accurate melee trace
// ---------------------------------------------------------------------------------------------

void UCombatComponent::BeginMeleeTrace(const FMeleeTraceParams& Params)
{
	HitThisSwing.Reset();
	bHavePrev = false;
}

void UCombatComponent::EndMeleeTrace()
{
	HitThisSwing.Reset();
	bHavePrev = false;
}

void UCombatComponent::TickMeleeTrace(const FMeleeTraceParams& P)
{
	UMeshComponent* Mesh = GetTraceMesh();
	if (!Mesh || !GetWorld()) return;

	const FVector Base = Mesh->GetSocketLocation(P.StartSocket);
	const FVector Tip = Mesh->GetSocketLocation(P.EndSocket);
	if (!bHavePrev)
	{
		PrevBase = Base;
		PrevTip = Tip;
		bHavePrev = true;
	}

	FCollisionQueryParams Q(SCENE_QUERY_STAT(MeleeTrace), false, GetOwner());
	const FCollisionShape Sphere = FCollisionShape::MakeSphere(P.Radius);
	const int32 N = FMath::Max(2, P.SamplePoints);

	// Sweep several points along the blade from where each WAS last update to where it IS now.
	// That covers the whole area the blade cut through, so a fast swing cannot tunnel past an enemy.
	for (int32 i = 0; i < N; ++i)
	{
		const float A = static_cast<float>(i) / static_cast<float>(N - 1);
		const FVector From = FMath::Lerp(PrevBase, PrevTip, A);
		const FVector To = FMath::Lerp(Base, Tip, A);
		TArray<FHitResult> Hits;
		GetWorld()->SweepMultiByChannel(Hits, From, To, FQuat::Identity, TraceChannel, Sphere, Q);
		for (const FHitResult& H : Hits)
		{
			AActor* V = H.GetActor();
			if (!V || HitThisSwing.Contains(V)) continue;
			if (ProcessHit(V, H, P)) HitThisSwing.Add(V);
		}
		if (bDrawDebugTrace) DrawDebugLine(GetWorld(), From, To, FColor::Red, false, 0.5f, 0, 1.5f);
	}
	if (bDrawDebugTrace) DrawDebugLine(GetWorld(), Base, Tip, FColor::Yellow, false, 0.f, 0, 2.f);

	PrevBase = Base;
	PrevTip = Tip;
}

bool UCombatComponent::ProcessHit(AActor* Victim, const FHitResult& Hit, const FMeleeTraceParams& P)
{
	if (Victim == GetOwner()) return false;
	if (HittableTags.Num() > 0)
	{
		bool bOk = false;
		for (const FName& T : HittableTags) bOk |= Victim->ActorHasTag(T);
		if (!bOk) return false;
	}
	UHitReactionComponent* Reaction = Victim->FindComponentByClass<UHitReactionComponent>();
	if (!Reaction) return false;

	FHitData Data = P.bOverrideHit ? P.Hit : CurrentAttack.Hit;
	Data.Damage *= P.DamageScale;
	if (!Reaction->ReceiveHit(GetOwner(), Data, Hit)) return false;

	// Attacker-side feedback: the freeze, the shake, and a hook for VFX / SFX in Blueprint.
	if (UHitStopSubsystem* Stop = GetWorld()->GetSubsystem<UHitStopSubsystem>())
	{
		Stop->RequestHitStop(GetOwner(), Data.HitStopDuration, Data.HitStopDilation);
		Stop->RequestHitStop(Victim, Data.HitStopDuration, Data.HitStopDilation);
	}
	if (const ACharacter* C = Cast<ACharacter>(GetOwner()))
	{
		if (APlayerController* PC = Cast<APlayerController>(C->GetController()))
		{
			if (LandHitShake) PC->ClientStartCameraShake(LandHitShake, Data.LandShakeScale);
		}
	}
	OnHitLanded.Broadcast(Victim, Hit, Data);
	return true;
}
