#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "CombatTypes.h"
#include "AnimNotifyState_MeleeTrace.generated.h"

/**
 * Drop this on an attack montage across the frames where the blade is actually dangerous.
 * Damage can only happen while it is active, and only where the weapon physically sweeps.
 * Set the notify's "Montage Tick Type" to Branching Point so it fires on the exact frame.
 */
UCLASS(meta = (DisplayName = "Melee Trace"))
class YOURGAME_API UAnimNotifyState_MeleeTrace : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Trace") FName StartSocket = TEXT("weapon_base");
	UPROPERTY(EditAnywhere, Category = "Trace") FName EndSocket = TEXT("weapon_tip");
	UPROPERTY(EditAnywhere, Category = "Trace") float Radius = 14.f;
	/** Points along the blade that get swept. 4 is plenty for a sword, 6+ for a long polearm. */
	UPROPERTY(EditAnywhere, Category = "Trace", meta = (ClampMin = "2")) int32 SamplePoints = 4;
	UPROPERTY(EditAnywhere, Category = "Hit") float DamageScale = 1.f;
	/** Off = use the FHitData of the attack (FAttackData.Hit). On = use HitData below for this one swing. */
	UPROPERTY(EditAnywhere, Category = "Hit") bool bOverrideHit = false;
	UPROPERTY(EditAnywhere, Category = "Hit", meta = (EditCondition = "bOverrideHit")) FHitData HitData;

	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
	virtual FString GetNotifyName_Implementation() const override { return TEXT("Melee Trace"); }

private:
	FMeleeTraceParams MakeParams() const;
};
