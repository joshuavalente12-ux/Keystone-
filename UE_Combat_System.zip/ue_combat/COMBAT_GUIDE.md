# Weighty Combat for UE 5.5: C++ architecture + Blueprint/AnimBP guide

Everything here is written for **Unreal Engine 5.5.x** and split into small components you can drop onto the player *and* the monsters, so both share one combat pipeline.

> I could not compile this against your project. The API calls follow the UE 5.5 signatures as I know them, but expect to fix a small thing or two on first build. Send me the compiler output and I will sort it.

---

## 0. Setup (10 minutes)

**Files.** Copy `Source/YourGame/Combat/*` into your module. Find-and-replace `YOURGAME_API` with your module's macro (e.g. `KEYSTONE_API`).

**Build.cs.** Add the modules from `YourGame.Build.cs.snippet` (`AnimGraphRuntime`, `MotionWarping`, `EnhancedInput`).

**Plugins** (Edit > Plugins): enable **Motion Warping**. For the monster section also enable **Animation Warping** and keep **IK Rig** on.

**Collision.** Project Settings > Collision > New Trace Channel:
- `Weapon` (default response: Ignore)
- `LockOn` (default response: Ignore)

On every **enemy** and on the **player**:
- Capsule: Weapon = **Ignore**, LockOn = **Overlap**.
- Skeletal Mesh: Collision Enabled = *Query and Physics*, Weapon = **Overlap**. The Physics Asset bodies then act as per-bone hitboxes, so a sword through a shoulder hits the shoulder and `Hit.BoneName` is correct.

Set `CombatComponent.TraceChannel = Weapon` and `LockOnComponent.TargetChannel = LockOn` in the component defaults.

**Tags.** Player character: tag `Player`. Enemies: tag `Enemy` (`AEnemyCharacterBase` adds it for you). Player's `CombatComponent.HittableTags = [Enemy]`.

**Anim slots.** In any Animation Editor: Window > Anim Slot Manager. Create a slot group `Combat` with slots: `UpperBody`, `FullBody`, `HitReact`.

**Skeleton sockets.** Add `weapon_base` and `weapon_tip` sockets on the sword (or on the hand bone if the sword is baked in). The tip socket must sit on the blade tip.

**Player Blueprint wiring** (or do it in C++):
1. Add components: `CombatComponent`, `HitReactionComponent`, `LockOnComponent`, `DodgeRollComponent`, `MotionWarpingComponent`.
2. Character Movement: `Orient Rotation to Movement = true`, `Use Controller Rotation Yaw = false` by default (the lock-on flips them and restores them on release). Spring Arm: `Use Pawn Control Rotation = true`.
3. Enhanced Input: `IA_Attack` > `CombatComponent::RequestAttack`, `IA_Dodge` > `DodgeRollComponent::RequestRoll`, `IA_LookX` while locked > `LockOnComponent::SwitchTarget` (flick past 0.8, with a 0.3 s cooldown), `IA_LockToggle` > `ReleaseTarget`.
4. Mesh AnimBP parent class: `CombatAnimInstance`.

---

## 1. Combat feel and animation overhaul

### 1.1 AnimBP: legs run, upper body swings

**Goal:** lower body keeps the locomotion pose, upper body plays the sword swing.

1. Create the AnimBP with **Parent Class = `CombatAnimInstance`**. Its variables (`GroundSpeed`, `Direction`, `bIsLockedOn`, `Lean`, `AimYaw`, `AimPitch`, ...) appear in the AnimGraph with no Event Graph work.
2. **AnimGraph, from left to right:**
   - `Locomotion` state machine (see 2.3) > **Save Cached Pose** `LocoCache`.
   - Add **Layered blend per bone**:
     - *Base Pose* = `Use cached pose LocoCache`.
     - *Blend Poses 0* = **Slot `UpperBody`** (source: `Use cached pose LocoCache` so the slot falls back to locomotion when idle).
     - *Layer Setup 0 > Branch Filters*: add `spine_01`, **Blend Depth = 1** (a one-bone blend so the waist does not snap).
     - Tick **Mesh Space Rotation Blend** (keeps the upper body pointing where the animation says while the hips rotate with the run).
     - Tick **Blend Root Motion Based on Root Bone**.
     - *Blend Weights 0* = 1.0.
   - Output of the blend > **Slot `FullBody`** (staggers, rolls, heavy root-motion attacks: these replace the whole body).
   - > **Slot `HitReact`** with an additive flinch (see 1.4).
   - > **Aim Offset** (head/torso look toward `AimYaw`/`AimPitch`) > *optional* additive lean using `Lean`.
   - > **Control Rig / Leg IK** (foot planting) > **Output Pose**.
3. **Class Defaults > Root Motion Mode = Root Motion from Montages Only.** (The components also set it at BeginPlay as a safety net.)

**Rule of thumb for which slot to use**
| Attack type | Slot | Root motion? |
|---|---|---|
| Light / mobile swings (can move while swinging) | `UpperBody` | **Off** (untick *Enable Root Motion* on the sequence) |
| Heavy grounded swings, lunges | `FullBody` | On, plus Motion Warping toward the target |
| Staggers, knockdowns, rolls | `FullBody` | On |
| Flinches | `HitReact` | Off, **additive** |

Root motion in a layered upper-body slot fights with the run cycle; that is the usual cause of "sliding while swinging".

### 1.2 Authoring an attack montage (this is what makes it feel weighty)

Make each attack its own montage with these sections. Times are for a **heavy** swing at 30 fps; a light swing is about 60% of this.

| Phase | Frames | What you place |
|---|---|---|
| Anticipation (wind-up) | 0-12 | Slow, exaggerated pull-back. *Combat Window: Super Armor* on monsters. Telegraph SFX/glow here. |
| **Active** | 12-19 | **Melee Trace** notify state, *Montage Tick Type = Branching Point*. Only these frames can deal damage. |
| Follow-through | 19-28 | Blade decelerates *past* the target. The overshoot sells the mass. |
| Recovery | 28-48 | **Combat Window: Combo Window** on frames 30-42 (light combos). Vulnerable. |

Weight is mostly **timing**: a short, fast active window between a long wind-up and a long recovery. Do not make the whole animation fast.

Set in the montage: Blend In 0.06-0.1 s, Blend Out 0.15-0.25 s, and **Enable Auto Blend Out = true**.

### 1.3 Frame-perfect damage (replaces proximity damage)

`AnimNotifyState_Melee Trace` calls into `UCombatComponent`. Each animation update while the notify is active:

1. Read the blade's `weapon_base` and `weapon_tip` socket positions **now**, and remember where they were **last update**.
2. Sweep a sphere for 4 points along the blade from *last position* to *current position*. That covers the full area the sword cut through, so a fast swing cannot skip past an enemy between frames.
3. Each victim can only be hit **once per swing** (`HitThisSwing`).
4. Only actors with a `HitReactionComponent` and a matching tag can be hit. Nothing here checks distance.

**Two gotchas already handled in the code:**
- A notify asset is **shared by every character using that animation**. Per-swing state (previous positions, who was hit) must live on the component, never on the notify. It does.
- The notify does nothing in the Animation Editor preview (`IsGameWorld()` check).

Turn on `CombatComponent > Draw Debug Trace` to see the swept lines in-game. If hits feel late, check the notify's *Montage Tick Type* is **Branching Point**.

Per-attack numbers live in `FAttackData.Hit` (damage, poise damage, knockback, hit stop, shake). A single swing can override them with `Override Hit` on the notify (for the last hit of a combo).

### 1.4 Hit stop (hit pause)

`HitStopSubsystem` freezes **only the attacker and the victim** using `Actor::CustomTimeDilation`. Both stop dead for ~0.07 s on the frame the trace connects, then resume.

Why not `SetGlobalTimeDilation`?
- It also freezes the camera lag, VFX, HUD and every other enemy, which feels like the game hitched.
- **World timers run on dilated time**: a 0.07 s timer at 0.02x speed lasts 3.5 s. The subsystem compares world time (which per-actor dilation does not touch), so the freeze lasts exactly what you set.

Values that feel right (`FHitData`):
| Hit | Duration | Dilation |
|---|---|---|
| Light | 0.05-0.07 | 0.03 |
| Heavy | 0.09-0.14 | 0.02 |
| Killing blow | 0.16-0.22 | 0.01 |

Never use 0.0: some systems divide by the time step. Overlapping requests extend the freeze, they never shorten it.

### 1.5 Hit reactions

`HitReactionComponent` gives every character:
- **Directional flinch**: the hit direction is worked out relative to *the victim's* facing (Front / Back / Left / Right) and a random montage from that list is played in the `HitReact` slot (additive, so they keep walking or attacking and the body just reacts).
- **Poise + stagger**: each hit chips poise. At 0 the victim staggers: all montages stop and a full-body stagger montage plays. Poise regenerates after 2 s untouched. *Super Armor* windows stop light hits from flinching a monster mid wind-up.
- **Colour flash**: create the parameters `HitFlashAmount` (scalar) and `HitFlashColor` (vector) in the character materials and hook them up like this:
  - Base Color: `Lerp(BaseColor, HitFlashColor, HitFlashAmount)`
  - Emissive Color: `HitFlashColor * HitFlashAmount * 3`
  The component makes dynamic material instances for you and decays the flash in ~0.16 s. Use **white** for enemies, **red** for the player (`FlashColor` on the component).
- **Physical reaction** (`bUsePhysicalReaction`, on by default for monsters): the bones below `spine_01` briefly simulate physics, take an impulse at the exact hit bone, and blend back over 0.35 s. This is what makes a big monster's torso *recoil* rather than play a canned animation. Needs a Physics Asset with good constraints.
- **Death**: ragdoll with an impulse along the killing blow (`bRagdollOnDeath`).

Flinch montages should be **additive** animations (Asset Details > Additive Anim Type = Mesh Space, Base Pose Type = Selected Animation Frame) put in slot `HitReact`. Make 2-3 per direction: variety is what stops it looking canned.

### 1.6 Camera shake and knockback

**Camera shakes** (Content Browser > Blueprint Class > `CameraShakeBase`; in Class Defaults set **Root Shake Pattern = WaveOscillatorCameraShakePattern**):

| Asset | Duration | Blend in/out | Rotation Pitch | Rotation Roll | Location Z | Assign to |
|---|---|---|---|---|---|---|
| `CS_LandHit` (subtle) | 0.15 | 0.02 / 0.08 | amp 0.6, freq 22 | amp 0.4, freq 18 | amp 1.5, freq 25 | `CombatComponent.LandHitShake` |
| `CS_TakeHit` (heavy) | 0.40 | 0.02 / 0.20 | amp 2.5, freq 14 | amp 3.0, freq 12 | amp 4.0, freq 16 | `HitReactionComponent.TakeHitShake` (player) |

Scale each per hit with `FHitData.LandShakeScale` / `TakeShakeScale` (heavy attack: 1.0; light: 0.5).

**Knockback** uses `LaunchCharacter` along the attacker-to-victim direction:
`Velocity = Dir * KnockbackStrength * (1 - KnockbackResistance) + Up * KnockbackUpward`. Bosses: `KnockbackResistance = 1`. It is skipped while the victim is in root motion (a roll or a warped attack), so hits never fight a montage.

---

## 2. Auto lock-on and strafing

### 2.1 Target detection
`CombatComponent::RequestAttack()` calls `LockOnComponent::TryAcquireTarget()` when no target is held. That:
1. Sweeps a sphere (radius 140, distance 900) forward along the **camera yaw** on the `LockOn` channel.
2. Takes the nearest valid enemy (tagged `Enemy`, not dead) and stores it as `CurrentTarget`.
3. If the sweep found nothing, falls back to an overlap sphere and picks the enemy closest to where you are facing inside a 55 degree cone (the "aim assist" that makes it forgiving).

### 2.2 Camera orbit + strafe
While `CurrentTarget` is valid, the component ticks:
- `FindLookAtRotation(eye, targetFocusPoint)` then `RInterpTo(controllerRotation, want, dt, 8)` then `SetControlRotation`. Pitch is clamped to -35..15 with an offset so you see over your own shoulder.
- On lock: `Orient Rotation to Movement = false`, `Use Controller Rotation Yaw = true`, walk speed drops to 320. On release, all three are **restored to what they were**.
- The lock breaks on: target death, distance > 1600, or no line of sight for 2.5 s.

### 2.3 The 2D strafe Blend Space
Create **Blend Space** `BS_Strafe`:
- Horizontal axis **Direction**, -180 to 180, 5 grid divisions.
- Vertical axis **Speed**, 0 to 600, 3 divisions.

| Direction \ Speed | 0 | ~150 (walk) | ~320 (strafe max) |
|---|---|---|---|
| 0 | Idle | Walk_F | Jog_F |
| 90 | Idle | Strafe_R | Strafe_R |
| -90 | Idle | Strafe_L | Strafe_L |
| 180 | Idle | Walk_B | Jog_B |
| -180 | Idle | Walk_B | Jog_B |

Put the backward animation on **both** -180 and +180 so the blend has no seam behind you. Give every cycle the same **Sync Group + sync markers** (left-foot / right-foot) so feet stay in step while blending sideways to forward.

State machine `Locomotion`: `Idle/Walk/Run` (1D blend space on `GroundSpeed`) and `Strafe` (`BS_Strafe`, X = `Direction`, Y = `GroundSpeed`). Transition to Strafe when `bIsLockedOn`, back when not, 0.2 s blend. Because the body faces the target, `Direction` is already relative to the enemy.

---

## 3. Directional dodge roll

`DodgeRollComponent::RequestRoll()`:
1. **Input**: `GetLastMovementInputVector()`, falling back to `CharacterMovement->GetCurrentAcceleration()` when the stick is neutral this frame.
2. **Direction**:
   - No input: play `BackStep`.
   - **Locked on**: `CalculateDirection(input, actorRotation)` gives -180..180 relative to where you face. Buckets: |a| <= 45 Forward, 45-135 Right, -135 to -45 Left, otherwise Backward.
   - **Free roam**: the character snaps to the stick direction and plays `RollForward` (reads far better than a sideways roll with no enemy to face).
3. **Play** the montage. Because Root Motion Mode is *from montages*, the animation physically moves the capsule (collision, slopes and walls all still work).
4. Movement input is ignored for the roll; `bOrientRotationToMovement` is turned off during it and restored after. A dodge pressed within 0.25 s of the end of a roll or attack is buffered and fires the moment it can.

**Roll montages (4 + back-step):** author each in `FullBody`, with **Enable Root Motion** on the sequences and *Root Motion Root Lock = Anim First Frame*.
- Forward roll: about 1.0 s, travels ~350 cm.
- Side rolls: about 0.9 s, ~300 cm. Back roll: 0.9 s, ~280 cm.
- Add **Combat Window: I-Frames** from about 15% to 60% of the roll. Recovery after that is the vulnerable part; it is what gives dodging risk.
- Blend In 0.05 s, Blend Out 0.2 s.

Stamina: override `ConsumeStamina` in Blueprint.

---

## 4. Monster animation overhaul

`AEnemyCharacterBase` gives every monster the same pipeline as the player. Subclass it in Blueprint per monster.

### 4.1 Make attacks readable and dangerous
Fill `Attacks` (an array of `FEnemyAttack`): montage, hit data, min/max range, weight, cooldown. `TryAttack(Target)` (call from your Behavior Tree task or State Tree) filters by distance and cooldown and picks a weighted random attack, so monsters stop repeating themselves.

Every monster attack montage follows the same three beats:

| Beat | What players read | Notify |
|---|---|---|
| **Telegraph** (0.4-0.8 s) | Body coils, weapon draws back, eyes/weapon glow, a growl | *Combat Window: Super Armor*, SFX, glow VFX |
| **Strike** (0.15-0.25 s) | The blow itself | *Melee Trace* with the claw/weapon sockets, *Motion Warping* |
| **Recovery** (0.4-1.0 s) | Long, heavy, obviously open | none: this is your damage window |

Heavier monster = **longer** telegraph and recovery, not faster swings.

### 4.2 Motion Warping (attacks that actually connect)
`CombatComponent` updates a warp target each time an attack starts (`FAttackData.WarpTargetName`, stop distance, max distance). In the montage, add the built-in **Motion Warping** notify state over the lunge frames with the same name, *Warp Translation + Rotation*, *Skew Warp*. The monster steps to the right distance and turns to you during the swing instead of swinging at where you *were*. Stop warping before the Strike beat so the blow itself is committed and you can dodge it.

### 4.3 Locomotion that looks real
In the monster's AnimBP (parent `CombatAnimInstance`):
- **Stride Warping + Orientation Warping** nodes (Animation Warping plugin) after the locomotion state machine, so feet stop sliding when the speed does not match the cycle.
- **Start / Stop / Turn-in-place** states (use a distance/angle check in the state machine; monsters with a low `RotationRate` look far more real when they plant and pivot).
- **Leg IK / Foot Placement** so feet sit on slopes and stairs.
- **Aim Offset** using `AimYaw/AimPitch`: the head and torso track the player. Set the AI Controller's **Focus** on the target and `BaseAimRotation` follows it.
- **Idle variety**: a *Random Sequence Player* over 3-4 idle loops, plus a low-amplitude additive **breathing** layer.
- **Lean** additive from `Lean` when it turns.
- **Reused human animations**: the **IK Retargeter** (5.5) copies your player sword set to any humanoid monster rig; then tweak, do not start from scratch.

### 4.4 Reactions that change with the hit
Same component as the player, tuned per monster:
- Small monsters: low `MaxPoise` (flinch and stagger easily).
- Big monsters: high `MaxPoise`, `KnockbackResistance` 0.6-1.0, super armor windows on wind-ups, physical reaction on (torso recoils, feet stay).
- Stagger montage variants per direction (front hit knocks it back, back hit makes it stumble forward).
- Death: `bRagdollOnDeath` with the impulse from the killing blow, or a death montage first that transitions to ragdoll on a notify (call `Die` from a notify if you want that).

### 4.5 Aggro and life
Give each monster an **aggro montage** (a roar in `FullBody`, played once on first sight) and a **hurt vocalization** on `OnHitTaken`. It costs almost nothing and makes them feel alive.

---

## 5. Tuning cheat sheet

| What | Value | If it feels wrong |
|---|---|---|
| Hit stop, light | 0.06 s @ 0.03 | Too floaty: raise duration to 0.09. Too stuttery: cut to 0.04. |
| Melee trace radius | 14 cm | Missing thin limbs: 18-20. |
| Sample points | 4 | Long weapons: 6. |
| Lock-on interp speed | 8 | Camera too snappy: 5. Too lazy: 12. |
| Roll i-frames | 15-60% of roll | Too safe: shorten. Too punishing: widen slightly. |
| Knockback, light | 250-350 | Bosses: use resistance, not smaller numbers. |
| Poise | player 80, imp 30, brute 150 | Monster never staggers: lower poise or raise `PoiseDamage`. |

## 6. Debug and pitfalls
- `showdebug animation` shows the active montage, slot weights and root motion.
- **No damage at all:** the notify fires only if the montage's *slot* is in the AnimBP, and the victim needs a `HitReactionComponent` and the right tag.
- **Damage on the wrong frames:** set the notify's *Montage Tick Type* to Branching Point; keep the notify *inside* the montage, not the sequence.
- **Character slides while swinging:** you left *Enable Root Motion* on for an upper-body slot montage.
- **Roll goes nowhere:** Root Motion Mode is not *from montages*, or the sequence has *Enable Root Motion* off.
- **Hit stop lasts too long:** something else is using `SetGlobalTimeDilation`; use the subsystem only.
- **Stuck invulnerable / super armor:** a montage was cut before its notify end ran. The counters live on `HitReactionComponent`; reset them in `Die` or on montage end if you see it.
