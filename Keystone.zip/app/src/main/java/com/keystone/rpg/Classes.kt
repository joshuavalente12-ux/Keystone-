package com.keystone.rpg

/**
 * The three paths a hero can start on. Chosen once, at the very start of a run (regular or
 * hardcore), right after you set your look. Each class is locked to its own family of weapons:
 * a Warrior never picks up a bow, a Mage never swings a sword.
 */
object HeroClass {
    const val WARRIOR = 0
    const val ARCHER = 1
    const val MAGE = 2
    const val COUNT = 3
}

/** Everything the class-pick screen (and the rest of the game) needs to know about one class. */
class ClassDef(
    val name: String,
    val icon: String,
    val blurb: String,
    val style: String,
    /** The weapon kind (see [WeaponClass]) and name you start the game holding. 5 damage flat. */
    val startKind: Int,
    val startName: String,
    /** Every weapon kind this class is ever allowed to equip. */
    val kinds: IntArray,
    /** For the comparison screen: 0..1 bars, not real game units. */
    val power: Float,
    val speed: Float,
    val range: Float,
    val color: Long,
)

val HERO_CLASSES = arrayOf(
    ClassDef(
        "Warrior", "\u2694\uFE0F",
        "Stands and trades blows up close. The most health, the hardest hits, the shortest reach.",
        "Melee \u00B7 swords & axes",
        WeaponClass.SWORD, "Rusty Sword",
        intArrayOf(WeaponClass.SWORD, WeaponClass.AXE, WeaponClass.HALBERD),
        0.9f, 0.45f, 0.2f, 0xFFD2323A,
    ),
    ClassDef(
        "Archer", "\uD83C\uDFF9",
        "Keeps its distance and peppers you with arrows. Light on its feet, light on defence.",
        "Ranged \u00B7 bows & crossbows",
        WeaponClass.BOW, "Stick-and-String Bow",
        intArrayOf(WeaponClass.BOW, WeaponClass.KUNAI),
        0.55f, 0.9f, 1f, 0xFF6CCB5F,
    ),
    ClassDef(
        "Mage", "\uD83D\uDD2E",
        "Hurls bolts of raw magic from a staff or a wand. Later staffs carry real elemental power.",
        "Ranged \u00B7 staffs & wands",
        WeaponClass.STAFF, "Worn Staff",
        intArrayOf(WeaponClass.STAFF, WeaponClass.WAND),
        0.65f, 0.7f, 0.85f, 0xFF4A9CFF,
    ),
)

/** Whether [heroClass] is allowed to equip a weapon of this [kind]. Unset saves (-1) allow anything. */
fun classAllows(heroClass: Int, kind: Int): Boolean {
    if (heroClass < 0) return true
    return HERO_CLASSES.getOrNull(heroClass)?.kinds?.contains(kind) ?: true
}
