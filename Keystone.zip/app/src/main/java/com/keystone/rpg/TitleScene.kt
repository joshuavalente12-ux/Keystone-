package com.keystone.rpg

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate

/**
 * The title screen's still shot: the hero in the foreground holding his sword, and a
 * Grain Rot monster towering behind him through the green murk. Drawn as one frozen frame.
 */
@Composable
fun TitleScene(modifier: Modifier = Modifier.fillMaxSize()) {
    Canvas(modifier = modifier) {
        val fw = size.width
        val h = size.height
        // The figures are drawn in a box sized for their proportions and centred, so a wide landscape screen doesn't stretch them.
        val w = minOf(fw, h * 1.15f)
        val ink = Color(0xFF050807)
        val glow = Color(0xFF9BD84A)

        // Sickly sky.
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFF07120C), Color(0xFF1F3A1C), Color(0xFF34531F), Color(0xFF0B140C)),
            ),
        )
        // Light bleeding through the rot, right behind the monster.
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(glow.copy(alpha = 0.45f), glow.copy(alpha = 0.12f), Color.Transparent),
                center = Offset(fw * 0.5f + (w * 0.12f), h * 0.34f),
                radius = h * 1.1f,
            ),
        )

        translate(left = (fw - w) / 2f, top = 0f) {
            // ----- The monster: a hunched, rotted reaper, taller than the frame. -----
            // Scythe pole and blade, held up on the right.
            val pole = Path().apply {
                moveTo(w * 0.84f, h * 0.66f)
                lineTo(w * 0.87f, h * 0.66f)
                lineTo(w * 0.81f, h * 0.08f)
                lineTo(w * 0.78f, h * 0.08f)
                close()
            }
            drawPath(pole, ink)
            val blade = Path().apply {
                moveTo(w * 0.79f, h * 0.085f)
                quadraticBezierTo(w * 0.55f, h * 0.02f, w * 0.40f, h * 0.15f)
                quadraticBezierTo(w * 0.58f, h * 0.085f, w * 0.79f, h * 0.12f)
                close()
            }
            drawPath(blade, ink)
            drawPath(blade, glow.copy(alpha = 0.5f), style = Stroke(width = 2.5f))
            // Great hunched shoulders and torso.
            drawOval(ink, topLeft = Offset(w * 0.26f, h * 0.27f), size = Size(w * 0.72f, h * 0.36f))
            drawOval(ink, topLeft = Offset(w * 0.34f, h * 0.44f), size = Size(w * 0.56f, h * 0.40f))
            // Head, sunk low between the shoulders.
            drawCircle(ink, radius = w * 0.115f, center = Offset(w * 0.60f, h * 0.245f))
            // Long arm hanging on the left, ending in claws.
            val arm = Path().apply {
                moveTo(w * 0.30f, h * 0.36f)
                quadraticBezierTo(w * 0.16f, h * 0.55f, w * 0.20f, h * 0.70f)
                lineTo(w * 0.25f, h * 0.70f)
                quadraticBezierTo(w * 0.27f, h * 0.55f, w * 0.40f, h * 0.44f)
                close()
            }
            drawPath(arm, ink)
            for (k in 0 until 3) {
                val cx = w * (0.19f + k * 0.03f)
                val claw = Path().apply {
                    moveTo(cx, h * 0.70f)
                    lineTo(cx + w * 0.012f, h * 0.70f)
                    lineTo(cx + w * 0.004f, h * 0.76f)
                    close()
                }
                drawPath(claw, ink)
            }
            // Fungal caps sprouting from its shoulders and back.
            val capCol = Color(0xFF243A16)
            drawOval(capCol, topLeft = Offset(w * 0.36f, h * 0.245f), size = Size(w * 0.14f, h * 0.05f))
            drawOval(capCol, topLeft = Offset(w * 0.74f, h * 0.27f), size = Size(w * 0.16f, h * 0.055f))
            drawOval(capCol, topLeft = Offset(w * 0.80f, h * 0.36f), size = Size(w * 0.11f, h * 0.04f))
            drawOval(glow.copy(alpha = 0.35f), topLeft = Offset(w * 0.74f, h * 0.27f), size = Size(w * 0.16f, h * 0.055f), style = Stroke(width = 2f))
            // Eyes, burning through the dark.
            for (ex in floatArrayOf(0.555f, 0.645f)) {
                drawCircle(glow.copy(alpha = 0.25f), radius = w * 0.05f, center = Offset(w * ex, h * 0.24f))
                drawCircle(glow, radius = w * 0.017f, center = Offset(w * ex, h * 0.24f))
            }
        }
        // Mist swallowing the monster's legs.
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color(0xCC1B2E17), Color(0xEE0A120B)),
                startY = h * 0.55f,
                endY = h * 0.86f,
            ),
            topLeft = Offset(0f, h * 0.55f),
            size = Size(fw, h * 0.45f),
        )

        translate(left = (fw - w) / 2f, top = 0f) {
            // ----- The hero: low camera, sword held up, back to us. -----
            val hx = w * 0.34f
            val hero = Color(0xFF020403)
            // Cloak streaming behind him.
            val cloak = Path().apply {
                moveTo(hx - w * 0.08f, h * 0.56f)
                quadraticBezierTo(hx - w * 0.24f, h * 0.76f, hx - w * 0.20f, h * 0.95f)
                lineTo(hx + w * 0.06f, h * 0.95f)
                lineTo(hx + w * 0.05f, h * 0.60f)
                close()
            }
            drawPath(cloak, hero)
            // Legs planted wide.
            drawRect(hero, topLeft = Offset(hx - w * 0.075f, h * 0.78f), size = Size(w * 0.06f, h * 0.17f))
            drawRect(hero, topLeft = Offset(hx + w * 0.005f, h * 0.78f), size = Size(w * 0.06f, h * 0.17f))
            // Torso, broad shoulders, and a helmed head.
            drawOval(hero, topLeft = Offset(hx - w * 0.11f, h * 0.55f), size = Size(w * 0.22f, h * 0.27f))
            drawCircle(hero, radius = w * 0.052f, center = Offset(hx, h * 0.515f))
            val crest = Path().apply {
                moveTo(hx - w * 0.008f, h * 0.465f)
                lineTo(hx + w * 0.008f, h * 0.465f)
                lineTo(hx + w * 0.02f, h * 0.43f)
                lineTo(hx - w * 0.004f, h * 0.44f)
                close()
            }
            drawPath(crest, hero)
            // Sword arm raised to the right, blade pointing up toward the monster.
            val armUp = Path().apply {
                moveTo(hx + w * 0.07f, h * 0.575f)
                lineTo(hx + w * 0.15f, h * 0.50f)
                lineTo(hx + w * 0.175f, h * 0.53f)
                lineTo(hx + w * 0.09f, h * 0.62f)
                close()
            }
            drawPath(armUp, hero)
            // The sword: steel blade catching the green light.
            val sx = hx + w * 0.165f
            val sy = h * 0.505f
            val steel = Path().apply {
                moveTo(sx - w * 0.012f, sy)
                lineTo(sx + w * 0.012f, sy)
                lineTo(sx + w * 0.006f, h * 0.17f)
                lineTo(sx, h * 0.135f)
                lineTo(sx - w * 0.006f, h * 0.17f)
                close()
            }
            drawPath(
                steel,
                Brush.horizontalGradient(
                    listOf(Color(0xFF8FA0A8), Color(0xFFEAF2F4), Color(0xFF5E6E76)),
                    startX = sx - w * 0.012f,
                    endX = sx + w * 0.012f,
                ),
            )
            drawLine(Color.White.copy(alpha = 0.85f), Offset(sx, sy - h * 0.01f), Offset(sx, h * 0.15f), strokeWidth = 1.5f)
            // Crossguard and grip.
            drawRect(Color(0xFFB89A4A), topLeft = Offset(sx - w * 0.04f, sy - h * 0.006f), size = Size(w * 0.08f, h * 0.012f))
            drawRect(hero, topLeft = Offset(sx - w * 0.008f, sy + h * 0.006f), size = Size(w * 0.016f, h * 0.035f))
            // Green rim light on his shoulder and blade side, from the monster's glow.
            drawOval(
                glow.copy(alpha = 0.4f),
                topLeft = Offset(hx - w * 0.11f, h * 0.55f),
                size = Size(w * 0.22f, h * 0.27f),
                style = Stroke(width = 2f),
            )
        }
        // Spores drifting through the frame.
        for (i in 0 until 36) {
            val fx = ((i * 37) % 100) / 100f
            val fy = ((i * 53) % 100) / 100f
            val r = 1.5f + ((i * 7) % 4)
            drawCircle(glow.copy(alpha = 0.15f + ((i * 11) % 5) * 0.09f), radius = r, center = Offset(fw * fx, h * fy))
        }

        // Dark edges, and room for the title and the button.
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color(0xAA000000)),
                center = Offset(fw * 0.5f, h * 0.5f),
                radius = fw * 0.6f,
            ),
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xCC000000), Color.Transparent),
                startY = 0f,
                endY = h * 0.22f,
            ),
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color(0xEE000000)),
                startY = h * 0.68f,
                endY = h,
            ),
        )
    }
}
