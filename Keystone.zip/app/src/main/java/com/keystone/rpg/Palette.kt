package com.keystone.rpg

import androidx.compose.ui.graphics.Color

/** Colours for the screen overlay. The 3D world picks its own colours as it's built. */
object Palette {
    val gold = Color(0xFFFFC940)
    val night = Color(0xFF15131C)
}
