package com.keystone.rpg

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

object Palette {
    val gold = Color(0xFFFFC940)
    val night = Color(0xFF15131C)
    val shadow = Color(0x33000000)

    // Meadow
    val grass = Color(0xFF7BC96F)
    val meadowPath = Color(0xFFE2CC94)
    val flowerYellow = Color(0xFFFFE66D)
    val flowerPink = Color(0xFFFF8FA3)
    val flowerWhite = Color(0xFFFFFFFF)
    val tree = Color(0xFF3E8E41)
    val treeHi = Color(0xFF5BAF5E)
    val trunk = Color(0xFF8B5E3C)

    // Forest
    val forestFloor = Color(0xFF5A9A55)
    val forestPath = Color(0xFFA38B5F)
    val treeDark = Color(0xFF2F6B35)
    val treeDarkHi = Color(0xFF468A4A)

    // Water
    val water = Color(0xFF4FA3E0)
    val waterLight = Color(0xFFA9D8F7)

    // Desert
    val sand = Color(0xFFF1D48E)
    val desertPath = Color(0xFFDDB46A)
    val cactus = Color(0xFF5DAA68)
    val boulder = Color(0xFFB08D63)
    val boulderHi = Color(0xFFC9A67A)

    // Snow
    val snow = Color(0xFFEAF2F8)
    val snowPath = Color(0xFFC9D6E3)
    val ice = Color(0xFFB9E0F2)
    val pine = Color(0xFF2C5E52)

    // Caves
    val caveFloor = Color(0xFF4B4459)
    val cavePath = Color(0xFF645B76)
    val caveTop = Color(0xFF3A3446)
    val caveSide = Color(0xFF221E2A)
    val crystal = Color(0xFFB482FF)
    val crystalHi = Color(0xFFE2CCFF)

    // Mountains
    val mountainTop = Color(0xFF979CA6)
    val mountainSide = Color(0xFF686D78)
    val mountainSnowTop = Color(0xFFDDE6EE)

    // Hero
    val hero = Color(0xFF3B6FF5)
    val heroEye = Color(0xFF1B1F2E)

    fun path(zone: Int): Color = when (zone) {
        Zone.FOREST.ordinal -> forestPath
        Zone.DESERT.ordinal -> desertPath
        Zone.SNOW.ordinal -> snowPath
        Zone.CAVES.ordinal -> cavePath
        else -> meadowPath
    }

    fun ground(t: Int, zone: Int): Color = when (t) {
        T.GRASS, T.FLOWERS -> if (zone == Zone.FOREST.ordinal) forestFloor else grass
        T.TREE -> if (zone == Zone.FOREST.ordinal) forestFloor else grass
        T.FOREST_FLOOR -> forestFloor
        T.WATER -> water
        T.SAND, T.CACTUS, T.BOULDER -> sand
        T.SNOW, T.PINE -> snow
        T.ICE -> ice
        T.CAVE_FLOOR, T.CRYSTAL -> caveFloor
        T.CAVE_WALL -> caveTop
        T.MOUNTAIN -> mountainTop
        T.PATH, T.GATE -> path(zone)
        else -> grass
    }

    fun mapColor(t: Int, zone: Int): Int = when (t) {
        T.TREE -> treeDark
        T.PINE -> pine
        T.CACTUS -> cactus
        T.BOULDER -> boulder
        T.CAVE_WALL -> caveSide
        T.CRYSTAL -> crystal
        T.GATE -> gold
        else -> ground(t, zone)
    }.toArgb()
}
