package com.keystone.rpg

/**
 * One region's boss: a huge, named version of one of that region's monsters, waiting
 * in its lair. Beat it and the next region's seal breaks.
 */
class BossDef(
    val name: String,
    /** Which monster it's a giant version of (by species name). */
    val base: String,
    val zone: Zone,
    val level: Int,
    /** How much bigger than the biggest ordinary one. */
    val scale: Float,
    val health: Float,
    /** How much harder it hits than an ordinary one. */
    val hitMul: Float,
    /** Roughly where its lair is; the exact spot is found on open ground nearby. */
    val prefX: Float,
    val prefZ: Float,
)

/** The regions in the order you have to clear them. */
val ZONE_ORDER = arrayOf(Zone.MEADOW, Zone.FOREST, Zone.SNOW, Zone.DESERT, Zone.CAVES)

/** 0 for Greenhollow, 1 for Whisperwood, and so on down [ZONE_ORDER]. */
fun zoneRank(z: Zone): Int = ZONE_ORDER.indexOf(z)

/** One boss per region, in [ZONE_ORDER]. */
val BOSSES = listOf(
    BossDef("Gorvak the Moss King", "Mossgolem", Zone.MEADOW, 22, 2.3f, 70f, 1.5f, 950f, 2450f),
    BossDef("The Hollow Elder", "Shadow Treant", Zone.FOREST, 42, 2.0f, 90f, 1.5f, 880f, 560f),
    BossDef("Grimtusk the Frost Tyrant", "Ice Troll", Zone.SNOW, 72, 2.1f, 110f, 1.5f, 1520f, 1220f),
    BossDef("Khepri the Sun Devourer", "Scarab Titan", Zone.DESERT, 102, 2.1f, 130f, 1.5f, 2460f, 1120f),
    BossDef("The Keystone Warden", "Hollow Titan", Zone.CAVES, 150, 1.5f, 160f, 1.4f, 2380f, 2360f),
)
