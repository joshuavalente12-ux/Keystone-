package com.keystone.rpg

import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Everything the sky, fog and lights need each frame, as one list of numbers so the
 * renderer can ease smoothly from one region's weather to the next:
 *  0-2 horizon and fog colour, 3 fog start, 4 fog end, 5-7 sky colour straight up,
 *  8 sun glow in the sky, 9 snowfall, 10 clouds, 11-13 direction light comes from,
 *  14-16 light colour, 17 stars and moon, 18 rain, 19 exposure, 20 blowing dust,
 *  21 wind, 22 low mist.
 */
const val ATM = 23

/** One full day and night, in real seconds. */
const val DAY_SECONDS = 1200f

private const val TWO_PI = 6.2831855f

/**
 * Time of day and weather. Greenhollow, Frostpeak and Sunscar follow the day,
 * Whisperwood is always a rainy night, the Hollow Deep keeps its gloom with fog and rain.
 * Frostpeak gets a rare blizzard, Sunscar gets dust storms with dust devils and a wind
 * that picks up after dark, and Whisperwood has lightning.
 */
class Weather {
    /** Seconds into the current day. Starts just after sunrise. */
    var clock = DAY_SECONDS * 0.3f
        private set

    /** Unit direction towards the sun and the moon (always opposite each other). */
    val sun = FloatArray(3)
    val moon = FloatArray(3)

    /** 0..1: how much of a Frostpeak blizzard / Sunscar dust storm is blowing. */
    var blizzard = 0f
        private set
    var dustStorm = 0f
        private set

    /** 0..1: a lightning flash lighting up Whisperwood. */
    var flash = 0f
        private set

    private val rng = Random(20260926)
    private var blizzardOn = false
    private var blizzardLeft = 0f
    private var blizzardRoll = 240f
    private var dustOn = false
    private var dustLeft = 0f
    private var dustRoll = 90f
    private var nextBolt = 5f
    private var reflash = -1f

    // Where the noon sun sits, and east at right angles to it along the ground.
    private val noonX: Float
    private val noonY: Float
    private val noonZ: Float
    private val eastX: Float
    private val eastZ: Float

    init {
        val l = sqrt(SUN_X * SUN_X + SUN_Y * SUN_Y + SUN_Z * SUN_Z)
        noonX = SUN_X / l
        noonY = SUN_Y / l
        noonZ = SUN_Z / l
        val h = sqrt(noonX * noonX + noonZ * noonZ)
        eastX = -noonZ / h
        eastZ = noonX / h
        place()
    }

    fun update(dt: Float, zone: Zone) {
        clock = (clock + dt) % DAY_SECONDS
        place()

        // Frostpeak blizzard: once in a blue moon.
        if (blizzardOn) {
            blizzardLeft -= dt
            if (blizzardLeft <= 0f) blizzardOn = false
        } else {
            blizzardRoll -= dt
            if (blizzardRoll <= 0f) {
                blizzardRoll = 180f
                if (rng.nextFloat() < 0.12f) {
                    blizzardOn = true
                    blizzardLeft = 150f + rng.nextFloat() * 110f
                }
            }
        }
        blizzard += ((if (blizzardOn) 1f else 0f) - blizzard) * min(1f, dt / 12f)

        // Sunscar dust storms: fairly common.
        if (dustOn) {
            dustLeft -= dt
            if (dustLeft <= 0f) dustOn = false
        } else {
            dustRoll -= dt
            if (dustRoll <= 0f) {
                dustRoll = 150f
                if (rng.nextFloat() < 0.3f) {
                    dustOn = true
                    dustLeft = 120f + rng.nextFloat() * 90f
                }
            }
        }
        dustStorm += ((if (dustOn) 1f else 0f) - dustStorm) * min(1f, dt / 10f)

        // Lightning over Whisperwood, with thunder rolling in after it.
        flash *= exp(-dt * 7f)
        if (zone == Zone.FOREST) {
            nextBolt -= dt
            if (nextBolt <= 0f) {
                flash = 1f
                reflash = 0.12f + rng.nextFloat() * 0.15f
                nextBolt = 7f + rng.nextFloat() * 16f
                val delay = 0.3f + rng.nextFloat() * 2.4f
                Sound.thunder(delay, 1.1f - delay * 0.25f)
            }
            if (reflash > 0f) {
                reflash -= dt
                if (reflash <= 0f) flash = max(flash, 0.75f)
            }
        } else {
            nextBolt = max(nextBolt, 4f)
        }
    }

    /** 0 in daylight, 1 in the dead of night (for the regions that have a day). */
    val night: Float get() = 1f - smooth(-0.25f, 0.02f, sun[1])

    fun windFor(zone: Zone): Float {
        val n = night
        return when (zone) {
            Zone.MEADOW -> 0.2f + 0.15f * n
            Zone.SNOW -> 0.35f + 0.1f * n + 0.95f * blizzard
            Zone.DESERT -> 0.25f + 0.55f * n + 0.9f * dustStorm
            Zone.FOREST -> 0.55f
            Zone.CAVES -> 0.3f
        }
    }

    fun rainFor(zone: Zone): Float = when (zone) {
        Zone.FOREST -> 1f
        Zone.CAVES -> 0.6f
        else -> 0f
    }

    /** Fills [out] (size [ATM]) with how the sky should look in [zone] right now. [base] is its daytime look. */
    fun target(zone: Zone, base: FloatArray, out: FloatArray) {
        for (i in 0 until 11) out[i] = base[i]
        for (i in 11 until ATM) out[i] = 0f
        out[21] = windFor(zone)
        out[18] = rainFor(zone)
        when (zone) {
            Zone.FOREST -> {
                // Always night, heavy rain, low cloud: no moon or stars get through.
                setRgb(out, 0, 0.075f, 0.095f, 0.115f)
                out[3] = 25f
                out[4] = 230f
                setRgb(out, 5, 0.03f, 0.04f, 0.06f)
                out[8] = 0f
                out[9] = 0f
                out[10] = 0f
                setDir(out, 0.25f, 0.92f, 0.3f)
                setRgb(out, 14, 0.14f, 0.17f, 0.24f)
                out[19] = 1.05f
                out[22] = 0.25f
            }
            Zone.CAVES -> {
                // The same gloom as before, with rain and a thick drifting fog.
                out[0] = base[0] + (0.24f - base[0]) * 0.45f
                out[1] = base[1] + (0.22f - base[1]) * 0.45f
                out[2] = base[2] + (0.30f - base[2]) * 0.45f
                out[3] = 8f
                out[4] = 125f
                setDir(out, SUN_X, SUN_Y, SUN_Z)
                setRgb(out, 14, 0.75f, 0.71f, 0.65f)
                out[19] = 0.65f
                out[22] = 0.7f
            }
            else -> dayAndNight(zone, base, out)
        }
    }

    private fun dayAndNight(zone: Zone, base: FloatArray, out: FloatArray) {
        val s = sun[1]
        val day = smooth(-0.05f, 0.25f, s)
        val night = 1f - smooth(-0.25f, 0.02f, s)
        val dusk = (1f - day) * (1f - night)
        val sum = day + dusk + night
        val wd = day / sum
        val wk = dusk / sum
        val wn = night / sum
        // Moonlit snow glows; the desert night has a faint purple.
        val nb = when (zone) {
            Zone.SNOW -> 1.35f
            Zone.DESERT -> 1.1f
            else -> 1f
        }
        val duskH = if (zone == Zone.DESERT) DUSK_DESERT else DUSK_H
        for (c in 0 until 3) {
            out[c] = base[c] * wd + duskH[c] * wk + NIGHT_H[c] * nb * wn
            out[5 + c] = base[5 + c] * wd + DUSK_Z[c] * wk + NIGHT_Z[c] * nb * wn
        }
        out[3] = base[3] * (1f - 0.3f * night)
        out[4] = base[4] * (1f - 0.2f * night)
        out[8] = base[8] * smooth(-0.08f, 0.15f, s)

        // Sunlight turns orange near the horizon; after dark a pale blue moon takes over.
        val sunAmt = smooth(-0.03f, 0.18f, s)
        val moonAmt = smooth(-0.03f, 0.18f, -s)
        val warm = smooth(0.03f, 0.4f, s)
        val sunI = (0.75f + 0.45f * base[8]) * sunAmt
        out[14] = 1.0f * sunI + 0.16f * nb * moonAmt
        out[15] = (0.5f + 0.45f * warm) * sunI + 0.2f * nb * moonAmt
        out[16] = (0.28f + 0.58f * warm) * sunI + 0.32f * nb * moonAmt
        if (s > -0.03f) setDir(out, sun[0], sun[1], sun[2]) else setDir(out, moon[0], moon[1], moon[2])
        out[17] = night
        out[19] = 0.65f + 0.4f * night
        if (zone == Zone.DESERT) out[20] = 0.35f * night

        if (zone == Zone.SNOW && blizzard > 0.001f) {
            val b = blizzard
            val bright = 0.2f + 0.8f * (1f - night)
            mixRgbInto(out, 0, 0.74f * bright, 0.77f * bright, 0.82f * bright, b)
            mixRgbInto(out, 5, 0.62f * bright, 0.66f * bright, 0.72f * bright, b)
            out[3] += (6f - out[3]) * b
            out[4] += (95f - out[4]) * b
            out[9] = 1f + 0.6f * b
            fadeSky(out, b, 0.55f)
        }
        if (zone == Zone.DESERT && dustStorm > 0.001f) {
            val d = dustStorm
            val bright = 0.2f + 0.8f * (1f - night)
            mixRgbInto(out, 0, 0.80f * bright, 0.60f * bright, 0.38f * bright, d)
            mixRgbInto(out, 5, 0.66f * bright, 0.50f * bright, 0.32f * bright, d)
            out[3] += (8f - out[3]) * d
            out[4] += (120f - out[4]) * d
            out[20] = max(out[20], d)
            fadeSky(out, d, 0.5f)
        }
    }

    /** A storm hides the stars, clouds and sun glow, and dims the light. */
    private fun fadeSky(out: FloatArray, k: Float, dim: Float) {
        out[8] *= 1f - k
        out[10] *= 1f - k
        out[17] *= 1f - k
        for (c in 14..16) out[c] *= 1f - dim * k
    }

    private fun place() {
        val a = (clock / DAY_SECONDS - 0.25f) * TWO_PI
        val ca = cos(a)
        val sa = sin(a)
        sun[0] = eastX * ca + noonX * sa
        sun[1] = noonY * sa
        sun[2] = eastZ * ca + noonZ * sa
        for (i in 0 until 3) moon[i] = -sun[i]
    }

    private fun setRgb(out: FloatArray, at: Int, r: Float, g: Float, b: Float) {
        out[at] = r
        out[at + 1] = g
        out[at + 2] = b
    }

    private fun setDir(out: FloatArray, x: Float, y: Float, z: Float) {
        val l = sqrt(x * x + y * y + z * z).coerceAtLeast(1e-4f)
        setRgb(out, 11, x / l, y / l, z / l)
    }

    private fun mixRgbInto(out: FloatArray, at: Int, r: Float, g: Float, b: Float, k: Float) {
        out[at] += (r - out[at]) * k
        out[at + 1] += (g - out[at + 1]) * k
        out[at + 2] += (b - out[at + 2]) * k
    }

    companion object {
        private val NIGHT_H = floatArrayOf(0.10f, 0.13f, 0.21f)
        private val NIGHT_Z = floatArrayOf(0.03f, 0.05f, 0.12f)
        private val DUSK_H = floatArrayOf(0.98f, 0.60f, 0.38f)
        private val DUSK_DESERT = floatArrayOf(1.0f, 0.55f, 0.30f)
        private val DUSK_Z = floatArrayOf(0.30f, 0.34f, 0.58f)
    }
}
