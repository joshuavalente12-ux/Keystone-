package com.keystone.rpg

import kotlin.math.hypot

/**
 * A world boss: a colossal version of one of a region's monsters that turns up somewhere in that
 * region for a short while every few hours, and carries a set of gear found nowhere else.
 */
class WorldBossDef(
    val name: String,
    /** Which monster it's a giant version of (by species name). */
    val base: String,
    val zone: Zone,
    /** How much bigger than the biggest ordinary one. */
    val scale: Float,
    /** How much harder it hits than an ordinary one. */
    val hitMul: Float,
    /** The word every piece of its gear is named after ("Ironhide Helm", "Ironhide Sword"...). */
    val setName: String,
)

/** Nullfang as he waits in the Grain Rot realm: the same beast, far larger and crueller. */
const val ROT_LORD_NAME = "Nullfang, Servant of the Grain Rot"

/** One per region, in [ZONE_ORDER]. */
val WORLD_BOSSES = listOf(
    WorldBossDef("Ironhide the Boar Lord", "Barkbiter Boar", Zone.MEADOW, 3.2f, 1.7f, "Ironhide"),
    WorldBossDef("Mournhorn the Rot Stag", "Rotstag", Zone.FOREST, 2.7f, 1.7f, "Mournhorn"),
    WorldBossDef("Hoarfang the Yeti King", "Frost Yeti", Zone.SNOW, 2.6f, 1.7f, "Hoarfang"),
    WorldBossDef("Sandmaw the World Eater", "Duneworm", Zone.DESERT, 2.3f, 1.7f, "Sandmaw"),
    WorldBossDef("Nullfang the Void Stalker", "Void Stalker", Zone.CAVES, 2.5f, 1.6f, "Nullfang"),
)

/**
 * When world bosses appear. Everything runs off the clock (UTC), so every phone agrees on when one
 * is out: a new one every 6 hours, staying for 30 minutes. That's what lets them go online later.
 */
object WorldSchedule {
    const val EVERY_MS = 6L * 60L * 60L * 1000L
    const val STAYS_MS = 30L * 60L * 1000L
    /** How long before it appears you get a warning. */
    const val WARN_MS = 10L * 60L * 1000L

    /** Which 6-hour stretch [now] falls in. */
    fun slot(now: Long): Long = now / EVERY_MS

    /** Milliseconds a boss has left in this stretch, or 0 if its time is up. */
    fun timeLeft(now: Long): Long = (STAYS_MS - (now - slot(now) * EVERY_MS)).coerceAtLeast(0L)

    /** Milliseconds until the next one appears. */
    fun untilNext(now: Long): Long = (slot(now) + 1) * EVERY_MS - now

    /** "3h 12m", "8m 05s". */
    fun clock(ms: Long): String {
        val s = (ms / 1000L).coerceAtLeast(0L)
        val h = s / 3600L
        val m = (s / 60L) % 60L
        val sec = s % 60L
        return if (h > 0) "${h}h ${m}m" else "${m}m ${sec.toString().padStart(2, '0')}s"
    }

    /** Which region's boss comes out in [slot], out of the regions you've opened up so far. */
    fun bossFor(slot: Long, unlockedRank: Int): Int {
        val n = (unlockedRank + 1).coerceIn(1, WORLD_BOSSES.size)
        val h = ((slot * 2654435761L) ushr 7) and 0x7FFFFFFFL
        return (h % n).toInt()
    }

    /**
     * A spot in [zone] for the boss to stand: open, fairly flat ground, away from towns, lairs and
     * thick woods. The same [seed] always gives the same spot. Null if nowhere suitable turned up.
     */
    fun findSpot(world: World, zone: Zone, seed: Long, lairX: FloatArray, lairZ: FloatArray): FloatArray? {
        val rnd = java.util.Random(seed * 31L + zone.ordinal)
        val probe = Probe()
        val tmp = Placed()
        for (tries in 0 until 900) {
            val x = 120f + rnd.nextFloat() * (WORLD_SIZE - 240f)
            val z = 120f + rnd.nextFloat() * (WORLD_SIZE - 240f)
            world.probe(x, z, probe)
            if (probe.zone != zone || probe.site < 80f || probe.mountain > 0.3f) continue
            if (world.terrainAt(x, z) < 1.5f) continue
            var nearLair = false
            for (i in lairX.indices) if (hypot(x - lairX[i], z - lairZ[i]) < 90f) nearLair = true
            if (nearLair) continue
            if (!world.clearForBuilding(x, z, 8f, tmp, probe)) continue
            return floatArrayOf(x, z)
        }
        return null
    }

    /** A spot near (px, pz) in whatever region you're in, for calling one up to test it. */
    fun spotNear(world: World, px: Float, pz: Float): FloatArray? {
        val rnd = java.util.Random(System.nanoTime())
        val probe = Probe()
        val tmp = Placed()
        for (tries in 0 until 300) {
            val a = rnd.nextFloat() * 6.2831855f
            val r = 45f + rnd.nextFloat() * 40f
            val x = px + kotlin.math.cos(a) * r
            val z = pz + kotlin.math.sin(a) * r
            if (x < 60f || z < 60f || x > WORLD_SIZE - 60f || z > WORLD_SIZE - 60f) continue
            world.probe(x, z, probe)
            if (probe.site < 40f || probe.mountain > 0.4f || world.terrainAt(x, z) < 1f) continue
            if (!world.clearForBuilding(x, z, 6f, tmp, probe)) continue
            return floatArrayOf(x, z)
        }
        return null
    }
}
