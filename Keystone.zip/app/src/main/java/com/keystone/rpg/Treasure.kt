package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Cave interiors are built this far below the world, so the surface never gets in the way. */
const val CAVE_Y = -300f

/** A treasure chest, out in the wild ([cave] = -1) or inside cave number [cave]. */
class Chest(
    val id: Int, val x: Float, val y: Float, val z: Float, val yaw: Float,
    val cave: Int, val tier: Int, val rich: Boolean,
) {
    @Volatile var opened = false
    /** Lid: 0 shut, 1 thrown open. */
    @Volatile var openT = 0f
}

/**
 * A hidden cave: a rocky mound with a dark mouth out in the world, and a
 * winding interior of chambers and tunnels (in its own space far below).
 */
class Cave(
    val id: Int, val name: String, val zone: Zone, val x: Float, val y: Float, val z: Float, val yaw: Float,
    private val seed: Int,
) {
    // Inside, in metres from the entrance chamber: chambers (x, z, radius) joined by tunnels (ax, az, bx, bz, radius).
    val chambers = ArrayList<FloatArray>()
    val tunnels = ArrayList<FloatArray>()
    /** Stalagmites you bump into: x, z, radius. */
    val pillars = ArrayList<FloatArray>()

    /** The mouth, where you go in (just in front of the mound). */
    val mouthX: Float get() = x + sin(yaw) * 0.3f
    val mouthZ: Float get() = z + cos(yaw) * 0.3f
    /** Centre of the solid rock mound behind the mouth. */
    val moundX: Float get() = x - sin(yaw) * 2.2f
    val moundZ: Float get() = z - cos(yaw) * 2.2f

    init {
        val rnd = java.util.Random(seed.toLong())
        chambers.add(floatArrayOf(0f, 0f, 6.5f + rnd.nextFloat() * 1.5f))
        val want = 3 + rnd.nextInt(3)
        var ang = rnd.nextFloat() * 6.2831855f
        var tries = 0
        while (chambers.size < want + 1 && tries < 80) {
            tries++
            val from = chambers[if (chambers.size > 1 && rnd.nextFloat() < 0.35f) rnd.nextInt(chambers.size) else chambers.size - 1]
            ang += (rnd.nextFloat() - 0.5f) * 2.2f
            val r = 5f + rnd.nextFloat() * 4f
            val dist = from[2] + r + 5f + rnd.nextFloat() * 6f
            val cx = from[0] + cos(ang) * dist
            val cz = from[1] + sin(ang) * dist
            var clash = false
            for (c in chambers) if (hypot(c[0] - cx, c[1] - cz) < c[2] + r + 3f) clash = true
            if (clash) continue
            chambers.add(floatArrayOf(cx, cz, r))
            tunnels.add(floatArrayOf(from[0], from[1], cx, cz, 1.8f + rnd.nextFloat() * 0.5f))
        }
    }

    /** How far inside the cave (x, z) is, in metres: positive inside, negative in the rock. */
    fun inside(lx: Float, lz: Float): Float {
        var d = -1e9f
        for (c in chambers) d = max(d, c[2] - hypot(lx - c[0], lz - c[1]))
        for (t in tunnels) d = max(d, t[4] - segDist(lx, lz, t[0], t[1], t[2], t[3]))
        return d + (valueNoise(lx * 0.22f, lz * 0.22f, seed + 5) - 0.5f) * 1.6f
    }

    /** Floor height inside; it curls up to meet the ceiling at the walls. */
    fun floorAt(lx: Float, lz: Float): Float = floorFrom(lx, lz, inside(lx, lz))

    fun floorFrom(lx: Float, lz: Float, d: Float): Float {
        val rim = smooth(0f, 2.2f, d)
        val n = (valueNoise(lx * 0.35f, lz * 0.35f, seed + 1) - 0.5f) * 0.5f
        return CAVE_Y + n * rim + (1f - rim) * 1.6f
    }

    fun ceilFrom(lx: Float, lz: Float, d: Float): Float {
        val rim = smooth(0f, 2.2f, d)
        val h = 3.4f + min(d, 7f) * 0.45f + (valueNoise(lx * 0.2f, lz * 0.2f, seed + 2) - 0.5f) * 1.4f
        return CAVE_Y + 1.6f + rim * (h - 1.6f)
    }

    /** Whether a body of radius [r] can stand at (lx, lz). */
    fun walkable(lx: Float, lz: Float, r: Float): Boolean {
        if (inside(lx, lz) < 0.9f + r) return false
        for (p in pillars) {
            val rr = p[2] + r
            val dx = lx - p[0]
            val dz = lz - p[1]
            if (dx * dx + dz * dz < rr * rr) return false
        }
        return true
    }

    /**
     * The whole interior as one mesh: a floor and a ceiling that meet at the walls,
     * with stalagmites, stalactites, glowing crystals, torches and the way out.
     */
    fun buildMesh(): MeshBuilder {
        pillars.clear()
        val look = CAVE_LOOK[zone.ordinal]
        val floorCol = look[0]
        val rockCol = look[1]
        val glow = look[2]
        val glow2 = look[3]
        var minX = 0f
        var maxX = 0f
        var minZ = 0f
        var maxZ = 0f
        for (c in chambers) {
            minX = min(minX, c[0] - c[2])
            maxX = max(maxX, c[0] + c[2])
            minZ = min(minZ, c[1] - c[2])
            maxZ = max(maxZ, c[1] + c[2])
        }
        minX -= 3f
        maxX += 3f
        minZ -= 3f
        maxZ += 3f
        val cell = 0.9f
        val nx = ((maxX - minX) / cell).toInt() + 2
        val nz = ((maxZ - minZ) / cell).toInt() + 2
        val d = FloatArray(nx * nz)
        val fl = FloatArray(nx * nz)
        val ce = FloatArray(nx * nz)
        for (j in 0 until nz) for (i in 0 until nx) {
            val lx = minX + i * cell
            val lz = minZ + j * cell
            val k = j * nx + i
            d[k] = inside(lx, lz)
            fl[k] = floorFrom(lx, lz, d[k])
            ce[k] = ceilFrom(lx, lz, d[k])
        }
        val m = MeshBuilder(65536)
        fun nrm(h: FloatArray, i: Int, j: Int, out: FloatArray) {
            val i0 = max(0, i - 1)
            val i1 = min(nx - 1, i + 1)
            val j0 = max(0, j - 1)
            val j1 = min(nz - 1, j + 1)
            out[0] = -(h[j * nx + i1] - h[j * nx + i0]) / ((i1 - i0) * cell)
            out[1] = 1f
            out[2] = -(h[j1 * nx + i] - h[j0 * nx + i]) / ((j1 - j0) * cell)
        }
        val na = FloatArray(3)
        val nb = FloatArray(3)
        val nc = FloatArray(3)
        val ne = FloatArray(3)
        for (j in 0 until nz - 1) for (i in 0 until nx - 1) {
            val a = j * nx + i
            val b = a + 1
            val c = a + nx + 1
            val e = a + nx
            if (d[a] < -0.6f && d[b] < -0.6f && d[c] < -0.6f && d[e] < -0.6f) continue
            val xa = x + minX + i * cell
            val xb = xa + cell
            val za = z + minZ + j * cell
            val ze = za + cell
            val lowest = min(min(d[a], d[b]), min(d[c], d[e]))
            // Floor.
            nrm(fl, i, j, na)
            nrm(fl, i + 1, j, nb)
            nrm(fl, i + 1, j + 1, nc)
            nrm(fl, i, j + 1, ne)
            val fflag = if (lowest > 1.8f) FLAG_DIRT else FLAG_ROCK
            val fc = if (lowest > 1.8f) floorCol else mixRgb(floorCol, rockCol, 0.6f)
            val tone = 0.92f + 0.16f * hash(i, j, seed)
            val col = shadeRgb(fc, tone)
            m.triNC(xa, fl[a], za, na[0], na[1], na[2], col, xb, fl[b], za, nb[0], nb[1], nb[2], col, xb, fl[c], ze, nc[0], nc[1], nc[2], col, fflag)
            m.triNC(xa, fl[a], za, na[0], na[1], na[2], col, xb, fl[c], ze, nc[0], nc[1], nc[2], col, xa, fl[e], ze, ne[0], ne[1], ne[2], col, fflag)
            // Ceiling (normals point down, into the cave).
            nrm(ce, i, j, na)
            nrm(ce, i + 1, j, nb)
            nrm(ce, i + 1, j + 1, nc)
            nrm(ce, i, j + 1, ne)
            val rc = shadeRgb(rockCol, 0.85f + 0.2f * hash(i, j, seed + 9))
            m.triNC(
                xa, ce[a], za, -na[0], -na[1], -na[2], rc, xb, ce[b], za, -nb[0], -nb[1], -nb[2], rc,
                xb, ce[c], ze, -nc[0], -nc[1], -nc[2], rc, FLAG_ROCK,
            )
            m.triNC(
                xa, ce[a], za, -na[0], -na[1], -na[2], rc, xb, ce[c], ze, -nc[0], -nc[1], -nc[2], rc,
                xa, ce[e], ze, -ne[0], -ne[1], -ne[2], rc, FLAG_ROCK,
            )
        }

        val rnd = java.util.Random(seed * 31L + 7L)
        for ((ci, c) in chambers.withIndex()) {
            // Stalagmites (solid) and stalactites.
            val spikes = if (ci == 0) 2 else 3 + rnd.nextInt(4)
            for (s in 0 until spikes) {
                val a = rnd.nextFloat() * 6.2831855f
                val rr = c[2] * (0.35f + rnd.nextFloat() * 0.5f)
                val px = c[0] + cos(a) * rr
                val pz = c[1] + sin(a) * rr
                if (inside(px, pz) < 2.4f || hypot(px, pz) < 3.5f) continue
                val r = 0.3f + rnd.nextFloat() * 0.35f
                val h = 1.0f + rnd.nextFloat() * 1.8f
                m.cone(x + px, floorAt(px, pz) - 0.2f, z + pz, r, h, 7, shadeRgb(rockCol, 1.05f), a, FLAG_ROCK)
                pillars.add(floatArrayOf(px, pz, r * 0.9f))
            }
            for (s in 0 until 7) {
                val a = rnd.nextFloat() * 6.2831855f
                val rr = c[2] * rnd.nextFloat() * 0.85f
                val px = c[0] + cos(a) * rr
                val pz = c[1] + sin(a) * rr
                val dd = inside(px, pz)
                if (dd < 1.6f) continue
                m.cone(x + px, ceilFrom(px, pz, dd) + 0.2f, z + pz, 0.18f + rnd.nextFloat() * 0.2f, -(0.7f + rnd.nextFloat() * 1.3f), 6, rockCol, a, FLAG_ROCK)
            }
            // Glowing crystal clusters round the walls.
            for (s in 0 until 6) {
                val a = rnd.nextFloat() * 6.2831855f
                var px = c[0] + cos(a) * c[2]
                var pz = c[1] + sin(a) * c[2]
                // Walk inwards until we're just off the wall.
                var guard = 0
                while (inside(px, pz) < 1.0f && guard < 12) {
                    px += (c[0] - px) * 0.12f
                    pz += (c[1] - pz) * 0.12f
                    guard++
                }
                val fy = floorAt(px, pz)
                val n = 3 + rnd.nextInt(3)
                for (q in 0 until n) {
                    val qa = rnd.nextFloat() * 6.2831855f
                    m.spike(
                        x + px + cos(qa) * 0.15f, fy - 0.1f, z + pz + sin(qa) * 0.15f,
                        0.05f + rnd.nextFloat() * 0.06f, 0.35f + rnd.nextFloat() * 0.6f,
                        cos(qa) * 0.35f, sin(qa) * 0.35f, if (q % 2 == 0) glow else glow2, FLAG_GLOW,
                    )
                }
            }
        }
        // The way out: a shaft of daylight falling on a ring of pale stones.
        val fy0 = floorAt(0f, 0f)
        for (q in 0 until 14) {
            val a = q * 0.4488f
            m.blob(x + cos(a) * 1.2f, fy0 + 0.02f, z + sin(a) * 1.2f, 0.12f, 0.05f, 0.12f, 0xFFF0C8, q, 0f, FLAG_GLOW)
        }
        m.limb(x, fy0, z, x, ceilFrom(0f, 0f, inside(0f, 0f)) + 0.5f, z, 0.32f, 0.5f, 0xFFF6DA, FLAG_GLOW)
        // Two torches on the walls of the first chamber.
        val c0 = chambers[0]
        for (t in 0 until 2) {
            val a = 0.9f + t * 2.6f
            var px = cos(a) * c0[2]
            var pz = sin(a) * c0[2]
            var guard = 0
            while (inside(px, pz) < 0.9f && guard < 12) {
                px *= 0.9f
                pz *= 0.9f
                guard++
            }
            val fy = floorAt(px, pz)
            m.limb(x + px, fy, z + pz, x + px, fy + 1.3f, z + pz, 0.05f, 0.04f, 0x4A3422, FLAG_WOOD)
            m.flame(x + px, fy + 1.3f, z + pz, 0.09f, 0.4f, 0f, 0xFF7A1A, 0xFFE070)
            m.flame(x + px, fy + 1.3f, z + pz, 0.07f, 0.3f, 1.2f, 0xFF7A1A, 0xFFE070)
        }
        return m
    }

    companion object {
        /** Distance from (px, pz) to the segment (ax, az)-(bx, bz). */
        fun segDist(px: Float, pz: Float, ax: Float, az: Float, bx: Float, bz: Float): Float {
            val vx = bx - ax
            val vz = bz - az
            val l2 = vx * vx + vz * vz
            val t = if (l2 > 1e-6f) (((px - ax) * vx + (pz - az) * vz) / l2).coerceIn(0f, 1f) else 0f
            return hypot(px - (ax + vx * t), pz - (az + vz * t))
        }
    }
}

// Per region: floor, rock, crystal glow, second glow.
private val CAVE_LOOK = arrayOf(
    intArrayOf(0x5A4A38, 0x6A625A, 0x8AFF6A, 0xE8FF8A),   // Greenhollow: glowing moss and shrooms
    intArrayOf(0x3A3428, 0x4A4640, 0x5AC8FF, 0x9ADCFF),   // Whisperwood: cold blue
    intArrayOf(0x3A2E22, 0xA88458, 0xFFB040, 0xFF7A2A),   // Sunscar: amber
    intArrayOf(0xA8B8C8, 0x8AA0B8, 0xBEF0FF, 0xFFFFFF),   // Frostpeak: ice
    intArrayOf(0x2A2436, 0x3A3048, 0xC8A0FF, 0x8ADCFF),   // Hollow Deep: amethyst
)

private val CAVE_NAMES = mapOf(
    Zone.MEADOW to arrayOf("Mossy Hollow", "Fox Burrow", "Dripstone Den", "Old Miner's Hole", "Glowcap Grotto", "Hidden Spring Cave"),
    Zone.FOREST to arrayOf("Whispering Hollow", "Spider's Nest", "Rootbound Cavern", "Moonwell Grotto", "Gloom Den", "The Sunken Barrow"),
    Zone.SNOW to arrayOf("Frozen Grotto", "Icicle Vault", "Yeti's Lair", "Crystalfrost Cave", "Howling Hollow", "Rimeglass Cavern"),
    Zone.DESERT to arrayOf("Sunken Tomb", "Scorpion Burrow", "Sandglass Cavern", "Forgotten Cistern", "Ember Hollow", "Duneworm's Den"),
    Zone.CAVES to arrayOf("Voidheart Chasm", "Amethyst Deep", "Whispering Abyss", "Shadowroot Vault", "Crystal Throne", "Echoing Rift"),
)

/** How good the loot is in each region. */
fun tierOf(zone: Zone): Int = when (zone) {
    Zone.MEADOW -> 1
    Zone.FOREST -> 2
    Zone.SNOW -> 3
    Zone.DESERT -> 4
    Zone.CAVES -> 5
}

/**
 * Where all the treasure is: 50 chests tucked away around the world (ten in each region)
 * and 30 hidden caves (six in each), each with a chest or three inside. Always the same
 * places, so a chest you've opened stays opened.
 */
class Treasure(private val world: World) {
    val chests = ArrayList<Chest>()
    val caves = ArrayList<Cave>()

    // Meshes shared by every chest and every cave mouth.
    val chestBody = mesh { buildChestBody(it, false) }
    val chestLid = mesh { buildChestLid(it, false) }
    val richBody = mesh { buildChestBody(it, true) }
    val richLid = mesh { buildChestLid(it, true) }
    val entrances = Array(Zone.entries.size) { z -> mesh { buildEntrance(it, Zone.entries[z]) } }

    /** Things monsters drop: a small bag with a glowing gem, one for each rarity colour. */
    val drops = Array(5) { r -> mesh { buildDrop(it, (Rarity.COLORS[r] and 0xFFFFFFL).toInt()) } }

    /** Every mesh above, for uploading to the graphics card. */
    val meshes: List<CreaturePart> get() = listOf(chestBody, chestLid, richBody, richLid) + entrances.toList() + drops.toList()

    private fun buildDrop(m: MeshBuilder, gem: Int) {
        m.hd = true
        m.blob(0f, 0.16f, 0f, 0.17f, 0.16f, 0.15f, 0x8A6A40, 1, 0.1f, FLAG_FUR)
        m.blob(0f, 0.31f, 0f, 0.07f, 0.04f, 0.07f, 0x6A4A2A, 2, 0f, FLAG_FUR)
        m.limb(0f, 0.3f, 0f, 0f, 0.36f, 0f, 0.05f, 0.03f, 0x5A3A22, FLAG_FUR)
        m.hd = false
        m.spike(0f, 0.42f, 0f, 0.09f, 0.2f, 0f, 0f, gem, FLAG_GLOW)
        m.spike(0f, 0.42f, 0f, 0.09f, -0.12f, 0f, 0f, gem, FLAG_GLOW)
    }

    private fun mesh(build: (MeshBuilder) -> Unit): CreaturePart {
        val m = MeshBuilder(4096)
        build(m)
        return CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
    }

    init {
        place()
    }

    private fun place() {
        val rnd = java.util.Random(24680)
        val p = Probe()
        val tmp = Placed()
        // Caves first, so chests keep clear of them.
        for (zone in Zone.entries) {
            val names = CAVE_NAMES.getValue(zone)
            var made = 0
            var tries = 0
            while (made < 6 && tries < 6000) {
                tries++
                val x = 70f + rnd.nextFloat() * (WORLD_SIZE - 140f)
                val z = 70f + rnd.nextFloat() * (WORLD_SIZE - 140f)
                world.probe(x, z, p)
                if (p.zone != zone || p.trail < 18f || p.site < 45f || p.mountain > 0.35f || p.river < 20f) continue
                if (world.terrainAt(x, z) < 1.2f || world.isBlocked(x, z, p)) continue
                var near = false
                for (c in caves) if (hypot(c.x - x, c.z - z) < 160f) near = true
                if (near) continue
                val yaw = rnd.nextFloat() * 6.2831855f
                val mx = x - sin(yaw) * 2.2f
                val mz = z - cos(yaw) * 2.2f
                if (world.hitsObstacle(mx, mz, 3.2f, tmp, p)) continue
                val fx = x + sin(yaw) * 2.5f
                val fz = z + cos(yaw) * 2.5f
                if (world.isBlocked(fx, fz, p) || world.hitsObstacle(fx, fz, 1.2f, tmp, p)) continue
                val id = caves.size
                val cave = Cave(id, names[made], zone, x, world.terrainAt(x, z), z, yaw, 5000 + id * 97)
                caves.add(cave)
                // Chests in the chambers past the first.
                val n = min(cave.chambers.size - 1, 1 + rnd.nextInt(3))
                for (k in 0 until n) {
                    val c = cave.chambers[k + 1]
                    val a = rnd.nextFloat() * 6.2831855f
                    val cx = c[0] + cos(a) * c[2] * 0.3f
                    val cz = c[1] + sin(a) * c[2] * 0.3f
                    val face = kotlin.math.atan2(c[0] - cx, c[1] - cz) + 3.1415927f
                    chests.add(Chest(100 + id * 4 + k, x + cx, cave.floorAt(cx, cz), z + cz, face, id, tierOf(zone), true))
                }
                made++
            }
        }
        // Chests out in the wild: tucked beside rocks, trees and bushes, away from roads and villages.
        for (zone in Zone.entries) {
            var made = 0
            var tries = 0
            while (made < 10 && tries < 8000) {
                tries++
                val x = 50f + rnd.nextFloat() * (WORLD_SIZE - 100f)
                val z = 50f + rnd.nextFloat() * (WORLD_SIZE - 100f)
                world.probe(x, z, p)
                if (p.zone != zone || p.trail < 12f || p.site < 30f || p.mountain > 0.5f || p.river < 8f) continue
                if (world.terrainAt(x, z) < 1.0f || world.isBlocked(x, z, p)) continue
                if (world.hitsObstacle(x, z, 1.0f, tmp, p)) continue
                // Hidden: something must be close by (unless we're struggling to find spots).
                if (tries < 6000 && !world.hitsObstacle(x, z, 2.8f, tmp, p)) continue
                var near = false
                for (c in chests) if (c.cave < 0 && hypot(c.x - x, c.z - z) < 90f) near = true
                for (c in caves) if (hypot(c.x - x, c.z - z) < 12f) near = true
                if (near) continue
                chests.add(Chest(chests.count { it.cave < 0 }, x, world.terrainAt(x, z), z, rnd.nextFloat() * 6.2831855f, -1, tierOf(zone), false))
                made++
            }
        }
    }

    /** The cave whose mouth is within [range] metres, or null. */
    fun caveMouthNear(px: Float, pz: Float, range: Float): Cave? {
        for (c in caves) if (hypot(c.mouthX - px, c.mouthZ - pz) < range) return c
        return null
    }

    /** True if a body of [r] at (px, pz) would bump into a chest or a cave mound out in the world. */
    fun blocksOutside(px: Float, pz: Float, r: Float): Boolean {
        for (c in caves) {
            val rr = 2.6f + r
            val dx = px - c.moundX
            val dz = pz - c.moundZ
            if (dx * dx + dz * dz < rr * rr) return true
        }
        for (c in chests) {
            if (c.cave >= 0) continue
            val rr = 0.55f + r
            val dx = px - c.x
            val dz = pz - c.z
            if (dx * dx + dz * dz < rr * rr) return true
        }
        return false
    }

    // ---------- Meshes ----------

    /** Chest body: bottom centre at the origin, front facing +z. */
    private fun buildChestBody(m: MeshBuilder, rich: Boolean) {
        val wood = if (rich) 0x5A3420 else 0x7A5230
        val band = if (rich) 0xD8B048 else 0x5A5A60
        m.box(0f, 0.28f, 0f, 0.5f, 0.28f, 0.31f, 0f, wood, FLAG_WOOD)
        m.box(-0.35f, 0.28f, 0f, 0.04f, 0.29f, 0.32f, 0f, band, FLAG_METAL_T)
        m.box(0.35f, 0.28f, 0f, 0.04f, 0.29f, 0.32f, 0f, band, FLAG_METAL_T)
        m.box(0f, 0.03f, 0f, 0.52f, 0.03f, 0.33f, 0f, band, FLAG_METAL_T)
        m.box(0f, 0.46f, 0.318f, 0.075f, 0.085f, 0.014f, 0f, 0xC8A040, FLAG_METAL_T)
        m.blob(0f, 0.46f, 0.336f, 0.028f, 0.028f, 0.014f, if (rich) 0xFF5AD8 else 0x6AE0FF, 7, 0f, FLAG_GLOW)
    }

    /** Chest lid: its hinge (back top edge) at the origin, curving forward along +z. */
    private fun buildChestLid(m: MeshBuilder, rich: Boolean) {
        val wood = if (rich) 0x5A3420 else 0x7A5230
        val band = if (rich) 0xD8B048 else 0x5A5A60
        arc(m, -0.5f, 0.5f, 0.31f, 0f, wood, FLAG_WOOD, true)
        arc(m, -0.39f, -0.31f, 0.325f, 0.004f, band, FLAG_METAL_T, false)
        arc(m, 0.31f, 0.39f, 0.325f, 0.004f, band, FLAG_METAL_T, false)
    }

    /** A half-barrel from x0 to x1, radius [r], spanning z 0..2r, standing on y = 0. */
    private fun arc(m: MeshBuilder, x0: Float, x1: Float, r: Float, lift: Float, rgb: Int, flag: Int, caps: Boolean) {
        val n = 8
        val cz = 0.31f
        for (k in 0 until n) {
            val a0 = k * 3.1415927f / n
            val a1 = (k + 1) * 3.1415927f / n
            val z0 = cz - cos(a0) * r
            val y0 = sin(a0) * r * 0.8f + lift
            val z1 = cz - cos(a1) * r
            val y1 = sin(a1) * r * 0.8f + lift
            m.quad(x0, y0, z0, x1, y0, z0, x1, y1, z1, x0, y1, z1, rgb, flag, (x0 + x1) * 0.5f, lift, cz)
            if (caps) {
                m.tri(x0, lift, cz, x0, y0, z0, x0, y1, z1, rgb, flag, 0f, 0.1f, cz)
                m.tri(x1, lift, cz, x1, y0, z0, x1, y1, z1, rgb, flag, 0f, 0.1f, cz)
            }
        }
    }

    /** A cave mouth: a horseshoe of boulders round a dark opening facing +z, dressed for its region. */
    private fun buildEntrance(m: MeshBuilder, zone: Zone) {
        val rock = when (zone) {
            Zone.MEADOW -> 0x7A746A
            Zone.FOREST -> 0x55524C
            Zone.SNOW -> 0x8A94A0
            Zone.DESERT -> 0xB08A5A
            Zone.CAVES -> 0x4A4058
        }
        val rnd = java.util.Random(zone.ordinal * 13L + 5L)
        // The dark inside, seen through the gap.
        m.blob(0f, 0.9f, -1.3f, 1.3f, 1.4f, 1.4f, 0x040405, 1, 0f, FLAG_SOLID)
        m.blob(0f, 0.2f, -0.6f, 1.0f, 0.3f, 0.8f, 0x0A0908, 2, 0f, FLAG_SOLID)
        // Boulders round the back and sides, leaving the front open.
        var a = 0.75f
        var k = 0
        while (a < 6.2831855f - 0.75f) {
            val rr = 2.2f + rnd.nextFloat() * 0.3f
            val px = sin(a) * rr
            val pz = -2.2f + cos(a) * rr
            m.rock(px, 0.7f + rnd.nextFloat() * 0.4f, pz, 1.3f + rnd.nextFloat() * 0.4f, 1.5f + rnd.nextFloat() * 0.7f, 1.3f + rnd.nextFloat() * 0.3f,
                shadeRgb(rock, 0.9f + rnd.nextFloat() * 0.2f), 40 + k, FLAG_BOULDER)
            a += 0.7f
            k++
        }
        // Lintel and top.
        m.rock(0f, 2.55f, -0.9f, 1.8f, 0.75f, 1.1f, rock, 60, FLAG_BOULDER)
        m.rock(-0.6f, 2.9f, -2.4f, 1.6f, 1.0f, 1.5f, shadeRgb(rock, 0.95f), 61, FLAG_BOULDER)
        m.rock(0.8f, 2.7f, -2.8f, 1.4f, 0.9f, 1.4f, shadeRgb(rock, 1.05f), 62, FLAG_BOULDER)
        // Scattered stones in front.
        for (s in 0 until 4) {
            m.rock(-1.8f + s * 1.2f, 0.1f, 0.6f + (s % 2) * 0.5f, 0.3f, 0.22f, 0.28f, rock, 70 + s, FLAG_BOULDER)
        }
        when (zone) {
            Zone.MEADOW -> for (s in 0 until 6) {
                m.blob(-1.2f + s * 0.5f, 3.2f - (s % 3) * 0.3f, -1.5f - (s % 2) * 0.8f, 0.5f, 0.18f, 0.5f, 0x5A8A3A, 80 + s, 0.2f, FLAG_GRASS)
            }
            Zone.FOREST -> {
                for (s in 0 until 7) {
                    val vx = -1.1f + s * 0.36f
                    m.limb(vx, 3.0f, -0.4f, vx + 0.05f, 1.6f + (s % 3) * 0.3f, -0.25f, 0.025f, 0.015f, 0x3A6A2A, FLAG_LEAF)
                }
                for (s in 0 until 4) m.blob(-1.6f + s * 1.1f, 0.15f, 0.2f + (s % 2) * 0.3f, 0.08f, 0.06f, 0.08f, 0x5AC8FF, 90 + s, 0f, FLAG_GLOW)
            }
            Zone.SNOW -> for (s in 0 until 5) {
                m.blob(-1.4f + s * 0.7f, 3.3f - (s % 2) * 0.3f, -1.8f - (s % 3) * 0.5f, 0.8f, 0.25f, 0.7f, 0xF2F6FA, 80 + s, 0.15f, FLAG_SNOW)
            }
            Zone.DESERT -> for (s in 0 until 5) {
                m.blob(-2.2f + s * 1.1f, 0.1f, -0.3f - (s % 2) * 1.5f, 1.0f, 0.35f, 0.9f, 0xE0C08A, 80 + s, 0.1f, FLAG_SAND)
            }
            Zone.CAVES -> for (s in 0 until 7) {
                m.spike(-1.8f + s * 0.6f, 0.5f + (s % 3) * 0.7f, -1.2f - (s % 2) * 1.6f, 0.1f, 0.6f + (s % 3) * 0.3f, (s - 3) * 0.1f, 0.2f,
                    if (s % 2 == 0) 0xC8A0FF else 0x8ADCFF, FLAG_GLOW)
            }
        }
    }
}

/** Something a monster dropped, lying on the ground until you walk over it. */
class Drop(val x: Float, val y: Float, val z: Float, val item: Item) {
    var age = 0f
}

/** Highest level you can reach. */
const val MAX_LEVEL = 150

/** Brushed metal (bands and locks). */
private const val FLAG_METAL_T = 254

// ---------- Items ----------

/** Where a piece of equipment is worn. POTION items are drunk, not worn. */
object Slot {
    const val HEAD = 0
    const val BODY = 1
    const val HANDS = 2
    const val FEET = 3
    const val RING = 4
    const val AMULET = 5
    const val POTION = 6
    const val WORN = 6
    val NAMES = arrayOf("Head", "Body", "Hands", "Feet", "Ring", "Amulet", "Potion")
    val ICONS = arrayOf("\u26D1\uFE0F", "\uD83D\uDEE1\uFE0F", "\uD83E\uDDE4", "\uD83E\uDD7E", "\uD83D\uDC8D", "\uD83D\uDCFF", "\uD83E\uDDEA")
}

/** Common to Legendary, with the colour each name is shown in. */
object Rarity {
    val NAMES = arrayOf("Common", "Uncommon", "Rare", "Epic", "Legendary")
    val COLORS = longArrayOf(0xFFD8D8D8, 0xFF6ADB5A, 0xFF4A9CFF, 0xFFB86AFF, 0xFFFFA630)
    val POWER = floatArrayOf(1f, 1.35f, 1.8f, 2.4f, 3.2f)
}

/**
 * One item. [def] cuts the damage monsters do, [pow] makes your hits harder, [vit] adds
 * to your health (for potions: how much they heal), [spd] makes you faster (percent).
 */
class Item(
    val slot: Int, val tier: Int, val rarity: Int, val name: String,
    val def: Int, val pow: Int, val vit: Int, val spd: Int,
) {
    fun encode(): String = "$slot|$tier|$rarity|$name|$def|$pow|$vit|$spd"

    /** Short description of what it does. */
    fun stats(): String {
        if (slot == Slot.POTION) return "Heals $vit health"
        val parts = ArrayList<String>()
        if (def > 0) parts.add("+$def Defense")
        if (pow > 0) parts.add("+$pow Power")
        if (vit > 0) parts.add("+$vit Health")
        if (spd > 0) parts.add("+$spd% Speed")
        return parts.joinToString("   ")
    }

    companion object {
        fun decode(s: String): Item? {
            val f = s.split('|')
            if (f.size != 8) return null
            return try {
                Item(f[0].toInt(), f[1].toInt(), f[2].toInt(), f[3], f[4].toInt(), f[5].toInt(), f[6].toInt(), f[7].toInt())
            } catch (ignored: NumberFormatException) {
                null
            }
        }
    }
}

private val ARMOUR_MATERIAL = arrayOf("Leather", "Oakguard", "Frostforged", "Sunforged", "Voidcrystal")
private val JEWEL_MATERIAL = arrayOf("Copper", "Silver", "Moonstone", "Golden", "Amethyst")
private val BASE_NAMES = arrayOf(
    arrayOf("Cap", "Helm", "Crown"),
    arrayOf("Vest", "Mail", "Plate"),
    arrayOf("Gloves", "Bracers", "Gauntlets"),
    arrayOf("Boots", "Treads", "Greaves"),
    arrayOf("Band", "Ring", "Signet"),
    arrayOf("Charm", "Pendant", "Talisman"),
)
private val LEGENDS = arrayOf(
    arrayOf("Crown of the Moss Gate", "Helm of the Hollow Titan", "Mask of the Wraithwolf"),
    arrayOf("Heart of Whisperwood", "Frostmane Mantle", "Plate of the Sunspire"),
    arrayOf("Gauntlets of the Rotroot", "Grips of the Bloodsworn", "Emberwing Bracers"),
    arrayOf("Duneskimmer Boots", "Treads of the Nightwisp", "Greaves of Frosthold"),
    arrayOf("Band of the Bloodsworn", "Ring of the Abyss Eye", "Signet of Greenhollow Keep"),
    arrayOf("Eye of Mind, Body & Soul", "Glimmerhorn Talisman", "Amulet of the Deep"),
)
private val POTION_NAMES = arrayOf("Minor Health Potion", "Health Potion", "Greater Health Potion", "Superior Health Potion", "Elixir of Life")
private val SUFFIX = arrayOf("of Stone", "of Fury", "of the Bear", "of the Wind")

/**
 * What you're carrying: your bag, what you're wearing, your gold, and which chests
 * you've opened. Saved on the phone so it's all still there next time you play.
 * Touched from the game thread (opening chests) and the screen (equipping), so
 * everything goes through one lock.
 */
class Loot {
    private val lock = Any()
    private val bag = ArrayList<Item>()
    private val worn = arrayOfNulls<Item>(Slot.WORN)
    private val opened = HashSet<Int>()
    private var appCtx: Context? = null

    @Volatile var gold = 0
        private set
    /** Your character level (1-150) and experience towards the next one. */
    @Volatile var level = 1
        private set
    @Volatile var xp = 0
        private set
    @Volatile var defense = 0
        private set
    @Volatile var power = 0
        private set
    @Volatile var vitality = 0
        private set
    @Volatile var speed = 0
        private set

    /** Changes whenever anything in here changes, so the screen redraws. */
    var version by mutableIntStateOf(0)
        private set

    fun isOpened(id: Int): Boolean = synchronized(lock) { id in opened }

    /** Experience needed to go from [lv] to the next level. */
    fun xpNeeded(lv: Int): Int = (25f + lv * lv * 1.2f).toInt()

    /** Adds experience; returns how many levels you went up. */
    fun addXp(amount: Int): Int {
        var gained = 0
        synchronized(lock) {
            if (level >= MAX_LEVEL) return 0
            xp += amount
            while (level < MAX_LEVEL && xp >= xpNeeded(level)) {
                xp -= xpNeeded(level)
                level++
                gained++
            }
            if (level >= MAX_LEVEL) xp = 0
            version++
        }
        save()
        return gained
    }

    /** Puts something a monster dropped into your bag. */
    fun addItem(item: Item) {
        synchronized(lock) {
            bag.add(item)
            version++
        }
        save()
    }

    fun addGold(amount: Int) {
        synchronized(lock) {
            gold += amount
            version++
        }
        save()
    }

    /** A random thing a monster from a region of [tier] might drop. */
    fun rollDrop(tier: Int): Item {
        val rnd = java.util.Random(System.nanoTime())
        return if (rnd.nextFloat() < 0.35f) potion(tier) else gear(tier, false, rnd)
    }

    /** Copies for the screen to show. */
    fun bagItems(): List<Item> = synchronized(lock) { ArrayList(bag) }
    fun wornItems(): Array<Item?> = synchronized(lock) { worn.copyOf() }

    /** Opens chest [id] and fills your bag with random things for its [tier]. Returns what you found. */
    fun openChest(id: Int, tier: Int, rich: Boolean): List<Item> {
        val rnd = java.util.Random(System.nanoTime() xor (id * 7919L))
        val found = ArrayList<Item>()
        val count = 1 + rnd.nextInt(if (rich) 3 else 2)
        for (i in 0 until count) found.add(if (rnd.nextFloat() < 0.22f) potion(tier) else gear(tier, rich, rnd))
        val coins = (8 + rnd.nextInt(18)) * tier * (if (rich) 2 else 1)
        synchronized(lock) {
            opened.add(id)
            bag.addAll(found)
            gold += coins
            recompute()
        }
        found.add(0, Item(Slot.POTION, 0, 4, "$coins gold", 0, 0, -1, 0))
        save()
        return found
    }

    /** Wears the bag item at [index] (swapping out whatever was there). Potions can't be worn. */
    fun equip(index: Int) {
        synchronized(lock) {
            if (index !in bag.indices) return
            val item = bag[index]
            if (item.slot >= Slot.WORN) return
            bag.removeAt(index)
            worn[item.slot]?.let { bag.add(it) }
            worn[item.slot] = item
            recompute()
        }
        save()
    }

    /** Takes off whatever is worn in [slot] and puts it back in the bag. */
    fun unequip(slot: Int) {
        synchronized(lock) {
            val item = worn.getOrNull(slot) ?: return
            worn[slot] = null
            bag.add(item)
            recompute()
        }
        save()
    }

    /** Removes the potion at [index] and says how much it heals (0 if it isn't a potion). */
    fun drink(index: Int): Int {
        var heal = 0
        synchronized(lock) {
            if (index !in bag.indices || bag[index].slot != Slot.POTION) return 0
            heal = bag[index].vit
            bag.removeAt(index)
            recompute()
        }
        save()
        return heal
    }

    private fun recompute() {
        var d = 0
        var p = 0
        var v = 0
        var s = 0
        for (item in worn) {
            if (item == null) continue
            d += item.def
            p += item.pow
            v += item.vit
            s += item.spd
        }
        defense = d
        power = p
        vitality = v
        speed = min(s, 40)
        version++
    }

    private fun potion(tier: Int): Item {
        val t = tier.coerceIn(1, 5)
        return Item(Slot.POTION, t, min(4, t - 1), POTION_NAMES[t - 1], 0, 0, 30 + t * 20, 0)
    }

    private fun gear(tier: Int, rich: Boolean, rnd: java.util.Random): Item {
        val t = tier.coerceIn(1, 5)
        val roll = rnd.nextFloat() * (if (rich) 0.7f else 1f)
        val rarity = when {
            roll < 0.025f -> 4
            roll < 0.09f -> 3
            roll < 0.24f -> 2
            roll < 0.52f -> 1
            else -> 0
        }
        val slot = rnd.nextInt(Slot.WORN)
        val k = Rarity.POWER[rarity] * (0.85f + rnd.nextFloat() * 0.3f)
        val base = t * 4f * k
        var def = 0
        var pow = 0
        var vit = 0
        var spd = 0
        when (slot) {
            Slot.HEAD -> def = base.toInt().coerceAtLeast(1)
            Slot.BODY -> def = (base * 1.6f).toInt().coerceAtLeast(1)
            Slot.HANDS -> pow = (base * 0.8f).toInt().coerceAtLeast(1)
            Slot.FEET -> {
                spd = (2f + t * 1.5f * k).toInt()
                def = (base * 0.5f).toInt()
            }
            Slot.RING -> pow = base.toInt().coerceAtLeast(1)
            else -> vit = (base * 3f).toInt().coerceAtLeast(3)
        }
        // Rare and better pieces get a bonus, and a name that says so.
        var suffix = -1
        if (rarity >= 2) {
            suffix = rnd.nextInt(4)
            val extra = (base * 0.6f).toInt().coerceAtLeast(1)
            when (suffix) {
                0 -> def += extra
                1 -> pow += (extra * 0.8f).toInt().coerceAtLeast(1)
                2 -> vit += extra * 3
                else -> spd += (extra / 2).coerceAtLeast(2)
            }
        }
        val name = if (rarity == 4) {
            LEGENDS[slot][rnd.nextInt(LEGENDS[slot].size)]
        } else {
            val material = if (slot >= Slot.RING) JEWEL_MATERIAL[t - 1] else ARMOUR_MATERIAL[t - 1]
            val baseName = BASE_NAMES[slot][min(2, rarity / 2 + rnd.nextInt(2))]
            val front = if (rarity == 3) "Grand $material $baseName" else "$material $baseName"
            if (suffix >= 0) "$front ${SUFFIX[suffix]}" else front
        }
        return Item(slot, t, rarity, name, def, pow, vit, spd)
    }

    // ---------- Saving ----------

    fun load(ctx: Context) {
        appCtx = ctx.applicationContext
        val prefs = ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE)
        synchronized(lock) {
            bag.clear()
            opened.clear()
            for (i in worn.indices) worn[i] = null
            gold = prefs.getInt("gold", 0)
            level = prefs.getInt("level", 1).coerceIn(1, MAX_LEVEL)
            xp = prefs.getInt("xp", 0)
            prefs.getString("bag", "")?.split(';')?.forEach { s -> Item.decode(s)?.let { bag.add(it) } }
            val w = prefs.getString("worn", "")?.split(';') ?: emptyList()
            for (s in w) {
                val item = Item.decode(s) ?: continue
                if (item.slot < Slot.WORN) worn[item.slot] = item
            }
            prefs.getString("opened", "")?.split(',')?.forEach { s -> s.toIntOrNull()?.let { opened.add(it) } }
            recompute()
        }
    }

    private fun save() {
        val ctx = appCtx ?: return
        var bagS = ""
        var wornS = ""
        var openS = ""
        var g = 0
        var lv = 1
        var x = 0
        synchronized(lock) {
            lv = level
            x = xp
            bagS = bag.joinToString(";") { it.encode() }
            wornS = worn.filterNotNull().joinToString(";") { it.encode() }
            openS = opened.joinToString(",")
            g = gold
        }
        ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit()
            .putInt("gold", g)
            .putInt("level", lv)
            .putInt("xp", x)
            .putString("bag", bagS)
            .putString("worn", wornS)
            .putString("opened", openS)
            .apply()
    }
}

