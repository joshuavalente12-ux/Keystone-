package com.keystone.rpg

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Material id for falling water: anything from 46 to 49 is streaked downhill by the shader. */
const val FLAG_FALL = 47

/**
 * A big waterfall on the great mountain wall behind Greenhollow. The land itself carves out the pool
 * at the foot (see [World.fallsX]); this adds the water sheet draped down the face, the foam where it
 * lands, a ring of rocks round the pool and reeds along the bank. All of it is built straight into
 * world coordinates, once, and drawn as one piece.
 */
class Waterfall(private val world: World) {
    val meshes = ArrayList<CreaturePart>()
    val x: Float = world.fallsX
    val z: Float = world.fallsZ
    val mesh: CreaturePart? = if (world.fallsX > 0f) build() else null

    private fun build(): CreaturePart {
        val m = MeshBuilder(16384)
        val fx = world.fallsX
        val fz = world.fallsZ
        val foot = world.fallsFootX
        val rnd = kotlin.random.Random(4242)

        // The crest: the highest ground along the middle of the fall.
        var topX = foot
        var topH = -1e9f
        var sx = foot
        val limit = max(foot - 75f, 14f)
        while (sx > limit) {
            val h = world.terrainAt(sx, fz)
            if (h > topH) {
                topH = h
                topX = sx
            }
            sx -= 2f
        }
        val startX = fx - 6f
        val step = 2.2f
        val rows = max(2, ((startX - topX) / step).toInt())

        // The great sheet, with a thin trickle down each side.
        strip(m, fz, startX, step, topX, rows, 0f, 7.0f, 4.5f, 9)
        strip(m, fz, startX, step, topX, rows, -15f, 1.5f, 1.0f, 2)
        strip(m, fz, startX, step, topX, rows, 16.5f, 1.7f, 1.1f, 2)

        // Foam where it crashes into the pool, and along the lip at the top.
        for (k in 0 until 11) {
            val off = (k - 5) * 1.6f + (rnd.nextFloat() - 0.5f)
            val bx = foot - 2f + rnd.nextFloat() * 4f
            val s = 1.3f + rnd.nextFloat() * 1.1f
            m.blob(bx, 0.3f, fz + off, s, 0.55f, s, 0xF4FBFF, 600 + k, 0.45f, FLAG_SOLID)
        }
        for (k in 0 until 6) {
            val off = (k - 2.5f) * 1.9f
            val tx = topX + 0.9f
            val ty = world.terrainAt(topX, fz + off) + 0.5f
            m.blob(tx, ty, fz + off, 1.2f, 0.45f, 1.2f, 0xF4FBFF, 700 + k, 0.4f, FLAG_SOLID)
        }

        // A ring of rocks round the pool, right at the water's edge: big ones at the foot of the
        // cliff, smaller worn ones along the bank.
        val greys = intArrayOf(0x7B7A76, 0x6E6D6A, 0x8A8884, 0x66665F, 0x5F5E5B)
        var a = 0f
        while (a < 6.2831855f) {
            val ca = cos(a)
            val sa = sin(a)
            var r = 5f
            while (r < 34f && world.terrainAt(fx + ca * r, fz + sa * r) < 0.1f) r += 0.5f
            val edgeX = fx + ca * (r + 0.4f)
            val edgeZ = fz + sa * (r + 0.4f)
            val west = -ca   // 1 on the cliff side, -1 on the far bank
            val size = if (west > 0.3f) 1.6f + rnd.nextFloat() * 1.9f else 0.7f + rnd.nextFloat() * 1.0f
            val grey = greys[rnd.nextInt(greys.size)]
            val col = when {
                rnd.nextFloat() < 0.22f -> mixRgb(grey, 0x66803F, 0.45f)    // mossy
                rnd.nextFloat() < 0.3f -> shadeRgb(grey, 0.7f)              // wet and dark
                else -> grey
            }
            val gy = world.terrainAt(edgeX, edgeZ)
            m.rock(edgeX, gy + size * 0.25f, edgeZ, size * 1.15f, size * 0.8f, size, col, 800 + (a * 40f).toInt())
            if (rnd.nextFloat() < 0.5f) {
                val ox = edgeX + (rnd.nextFloat() - 0.5f) * 2.4f
                val oz = edgeZ + (rnd.nextFloat() - 0.5f) * 2.4f
                val s2 = size * (0.45f + rnd.nextFloat() * 0.3f)
                m.rock(ox, world.terrainAt(ox, oz) + s2 * 0.2f, oz, s2, s2 * 0.8f, s2 * 0.9f, shadeRgb(col, 0.9f), 900 + (a * 30f).toInt())
            }
            a += 0.2f + rnd.nextFloat() * 0.1f
        }
        // A few stepping stones sticking out of the water.
        for (k in 0 until 4) {
            val ang = rnd.nextFloat() * 6.2831855f
            val rr = 4f + rnd.nextFloat() * 5f
            val sx2 = fx + cos(ang) * rr
            val sz2 = fz + sin(ang) * rr
            if (world.terrainAt(sx2, sz2) > -0.2f) continue
            m.rock(sx2, 0.0f, sz2, 0.8f, 0.55f, 0.75f, 0x6A6B68, 1000 + k)
        }

        // Reeds along the bank, a few blades to a clump, with a brown tip on some.
        for (k in 0 until 16) {
            val ang = 0.3f + rnd.nextFloat() * 5.6f
            val ca = cos(ang)
            val sa = sin(ang)
            if (-ca > 0.4f) continue   // the cliff side is all rock
            var r = 5f
            while (r < 34f && world.terrainAt(fx + ca * r, fz + sa * r) < 0.0f) r += 0.5f
            val bx = fx + ca * (r + 0.2f)
            val bz = fz + sa * (r + 0.2f)
            for (j in 0 until 4) {
                val ox = bx + (rnd.nextFloat() - 0.5f) * 1.2f
                val oz = bz + (rnd.nextFloat() - 0.5f) * 1.2f
                val gy = world.terrainAt(ox, oz)
                if (gy < -0.3f) continue
                val hgt = 1.0f + rnd.nextFloat() * 0.9f
                m.limb(ox, gy, oz, ox + 0.12f, gy + hgt, oz + 0.08f, 0.035f, 0.012f, 0x6C8A3A, 150)
                if (rnd.nextFloat() < 0.4f) m.limb(ox + 0.12f, gy + hgt - 0.35f, oz + 0.08f, ox + 0.12f, gy + hgt, oz + 0.08f, 0.05f, 0.05f, 0x5A3E24, 150)
            }
        }

        val cp = CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
        meshes.add(cp)
        return cp
    }

    /** A point on the water sheet in row [r], [off] metres to the side of the fall's line. */
    private fun pt(fz: Float, startX: Float, step: Float, topX: Float, r: Int, off: Float, out: FloatArray) {
        val xr = max(startX - r * step, topX)
        val zr = fz + off + sin(xr * 0.09f + off) * 1.4f
        val ground = world.terrainAt(xr, zr)
        // Held a little way off the rock (outwards, and up) so the face never pokes through.
        out[0] = xr + 0.7f
        out[1] = max(ground, 0f) + 0.4f
        out[2] = zr
    }

    /** One ribbon of falling water, [cols] wide, hugging the ground from the pool up to the crest. */
    private fun strip(
        m: MeshBuilder, fz: Float, startX: Float, step: Float, topX: Float, rows: Int,
        centre: Float, hwBottom: Float, hwTop: Float, cols: Int,
    ) {
        val p0 = FloatArray(3)
        val p1 = FloatArray(3)
        val p2 = FloatArray(3)
        val p3 = FloatArray(3)
        for (r in 0 until rows) {
            val t0 = r / rows.toFloat()
            val t1 = (r + 1) / rows.toFloat()
            val hw0 = hwBottom + (hwTop - hwBottom) * t0
            val hw1 = hwBottom + (hwTop - hwBottom) * t1
            for (c in 0 until cols) {
                val u0 = -1f + 2f * c / cols
                val u1 = -1f + 2f * (c + 1) / cols
                pt(fz, startX, step, topX, r, centre + u0 * hw0, p0)
                pt(fz, startX, step, topX, r, centre + u1 * hw0, p1)
                pt(fz, startX, step, topX, r + 1, centre + u1 * hw1, p2)
                pt(fz, startX, step, topX, r + 1, centre + u0 * hw1, p3)
                val col = mixRgb(0x8FD0E6, 0xEEF9FF, hash(r, c + (centre * 7f).toInt(), 91))
                val mx = (p0[0] + p1[0] + p2[0] + p3[0]) * 0.25f
                val my = (p0[1] + p1[1] + p2[1] + p3[1]) * 0.25f
                val mz = (p0[2] + p1[2] + p2[2] + p3[2]) * 0.25f
                // Faces away from a point behind and below it, i.e. out and up from the wall.
                m.quad(
                    p0[0], p0[1], p0[2], p1[0], p1[1], p1[2],
                    p2[0], p2[1], p2[2], p3[0], p3[1], p3[2],
                    col, FLAG_FALL, mx - 8f, my - 4f, mz,
                )
            }
        }
    }
}
