package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The opening cinematic, played once at the start of a new game, before you choose a class.
 *
 * Deep in the Grain Rot, the hero is losing a fight with Nullfang. The beast beats him down,
 * picks him up, tears open a portal and hurls him through it. He comes tumbling out of the sky
 * in Greenhollow, rolls to a stop right where every new hero begins, and the villagers gather
 * round. He remembers nothing, not even his name, which is why you then choose who he is.
 *
 * This class only works out where everything should be at each moment ([update]); [Game] puts
 * the hero there, and [WorldRenderer] draws the boss and the portal from the fields here.
 */
class Intro {
    /** Seconds since the cinematic began. */
    var t = 0f
        private set
    /** Finished (or skipped): the app moves on to choosing a class. */
    @Volatile var done = false
    /** Asked to skip by tapping SKIP. */
    @Volatile var skipAsked = false

    // ---- The hero ----
    var heroX = 0f
    var heroZ = 0f
    var heroFeet = 0f
    var heroYaw = 0f
    /** Attack animation 0..1, or -1. */
    var heroAttack = -1f
    /** Somersault 0..1 (the dodge roll's tumble), or -1. */
    var heroTumble = -1f
    /** 0 standing, 1 flat on his back. */
    var heroLie = 0f
    var heroAir = 0f

    // ---- The camera ----
    val cam = FloatArray(6)
    var camYaw = 0f

    // ---- Nullfang (a creature of our own, not one of the cave's) ----
    val boss = Creature()
    var bossVisible = false

    // ---- The portal he tears open (and the one the hero falls out of) ----
    var portalX = 0f
    var portalY = 0f
    var portalZ = 0f
    var portalYaw = 0f
    /** 0 shut, 1 fully open. */
    var portalOpen = 0f

    // ---- The pulse of rot-power Nullfang charges and hurls (a spinning swirl, like the portal's) ----
    var blastOn = false
    var blastX = 0f
    var blastY = 0f
    var blastZ = 0f
    var blastScale = 0f
    /** Nullfang's health bar, nicked down a little by each of the hero's blows. */
    @Volatile var bossHp = 1f
    private var blastFlash = 0f
    private var shake = 0f
    private var prevBX = Float.NaN
    private var prevBZ = 0f

    /** True while the scene is inside the Grain Rot; false once he's been thrown back to Greenhollow. */
    var inRealm = true
        private set
    /** The cave index of the Grain Rot, or -1 if it couldn't be found (then the cinematic is skipped). */
    var realmCave = -1
        private set
    /** Why [setup] returned false, for diagnosing on a real device. Blank if it worked. */
    var failReason = ""
        private set

    /** Same as [failReason], for callers outside this file. */
    fun failReasonPublic(): String = failReason

    // ---- What the screen shows over the picture ----
    @Volatile var speaker = ""
    @Volatile var caption = ""
    @Volatile var title = ""
    @Volatile var subtitle = ""
    /** Black and white fades, 0..1. */
    @Volatile var black = 1f
    @Volatile var white = 0f
    /** Health bars during the fight. */
    @Volatile var showBars = false
    @Volatile var heroHp = 1f
    @Volatile var hurtFlash = 0f

    // ---- The two scenes, worked out once in [setup] ----
    private var cave: Cave? = null
    private var mx = 0f        // middle of the fight
    private var mz = 0f
    private var floorY = 0f
    private var dirX = 0f      // from the hero towards Nullfang
    private var dirZ = 1f
    private var bossX0 = 0f
    private var bossZ0 = 0f
    private var heroX0 = 0f
    private var heroZ0 = 0f
    private var bossFront = 3f // how far its snout reaches in front of its middle
    private var bossTop = 2f   // how high its back is
    private var gap = 3f

    private var sx = 0f        // where he lands (the spawn point)
    private var sz = 0f
    private var ground = 0f
    private var fX = 0f        // from the spawn point out away from the village
    private var fZ = 1f
    private val gather = ArrayList<Npc>()
    /** Where each of [gather] goes to stand round him. */
    private val spotX = FloatArray(4)
    private val spotZ = FloatArray(4)
    private val names = arrayOf("Villager", "Villager", "Villager")
    private var placeName = "Greenhollow"

    private val sounded = HashSet<Int>()
    /** Nullfang's growl (see [Sound.call]). */
    private var growl = 14

    /** Works out both scenes from the world. Returns false if there's nothing to show. */
    fun setup(g: Game): Boolean {
        val tr = g.treasure
        val ci = tr.rotCave
        val cv = tr.caves.getOrNull(ci)
        if (cv == null) {
            failReason = "no Grain Rot cave (rotCave=$ci, caves=${tr.caves.size})"
            return false
        }
        val si = g.fauna.rotLordSpecies()
        if (si < 0) {
            failReason = "no Nullfang species (index=$si)"
            return false
        }
        if (cv.chambers.isEmpty()) {
            failReason = "Grain Rot cave has no chambers"
            return false
        }
        realmCave = ci
        cave = cv
        val sp = g.fauna.species[si]
        growl = sp.growl

        // Nullfang, as big as he is when you finally face him for real.
        boss.active = true
        boss.sp = si
        boss.rotLord = true
        boss.boss = -1
        boss.wb = -1
        boss.level = 150
        boss.dying = -1f
        boss.hurt = 0f
        boss.strike = 0f
        boss.speed = 0f
        boss.flap = 1f
        boss.scale = sp.maxScale * WORLD_BOSSES[WORLD_BOSSES.size - 1].scale * 1.2f
        val s = boss.scale
        bossFront = (sp.colZ + sp.colHalf + sp.colR) * s
        // How high its back is: the top of its body mesh.
        var top = 0f
        for (pt in sp.parts) {
            if (pt.kind != PartKind.BODY) continue
            for (v in 0 until pt.count) top = max(top, pt.data.getFloat(v * STRIDE + 4) + pt.py)
        }
        bossTop = (if (top > 0.2f) top else 1.2f) * s

        // The fight is in the deepest chamber, across its middle.
        val ch = cv.chambers[cv.chambers.size - 1]
        mx = cv.x + ch[0]
        mz = cv.z + ch[1]
        val a = 0.7f
        dirX = sin(a)
        dirZ = cos(a)
        gap = bossFront + 2.4f
        bossX0 = mx + dirX * gap * 0.5f
        bossZ0 = mz + dirZ * gap * 0.5f
        heroX0 = mx - dirX * gap * 0.5f
        heroZ0 = mz - dirZ * gap * 0.5f
        floorY = cv.floorAt(mx - cv.x, mz - cv.z)
        boss.x = bossX0
        boss.z = bossZ0
        boss.y = cv.floorAt(bossX0 - cv.x, bossZ0 - cv.z)
        boss.yaw = atan2(-dirX, -dirZ)
        boss.wantYaw = boss.yaw

        // Where he lands: right where every new hero starts, in Greenhollow.
        val w = g.world
        sx = w.spawnX
        sz = w.spawnZ
        ground = w.groundAt(sx, sz)
        // Out away from the village centre, so the villagers come from behind him.
        val p0 = PLACES[0]
        val ox = sx - p0.x
        val oz = sz - p0.z
        val ol = hypot(ox, oz)
        if (ol > 0.5f) {
            fX = ox / ol
            fZ = oz / ol
        } else {
            fX = sin(w.spawnYaw)
            fZ = cos(w.spawnYaw)
        }
        placeName = p0.name

        // The nearest few people come over to see what's happened.
        val near = g.people.npcs
            .filter { !it.sitting && hypot(it.x - sx, it.z - sz) < 120f }
            .sortedBy { hypot(it.x - sx, it.z - sz) }
        gather.clear()
        for (n in near) {
            if (gather.size >= 4) break
            gather.add(n)
        }
        // Speaking order: an elder gets the last (and kindest) word if one came.
        val elder = gather.firstOrNull { it.role == NpcRole.QUEST }
        val talkers = (gather.filter { it !== elder } + listOfNotNull(elder)).toMutableList()
        for (i in names.indices) {
            val n = talkers.getOrNull(if (i == 2) talkers.size - 1 else i)
            names[i] = n?.title ?: "Villager"
        }
        if (talkers.size == 1) {
            names[0] = talkers[0].title
            names[1] = talkers[0].title
        }
        update(0f, g)
        return true
    }

    /** Moves everything on to this moment. Tells [g] when the scene changes from the realm to Greenhollow. */
    fun update(dt: Float, g: Game) {
        if (done) return
        if (skipAsked) {
            finish()
            return
        }
        t += dt
        if (t >= LENGTH) {
            finish()
            return
        }
        if (inRealm && t >= SWITCH) {
            inRealm = false
            g.introLeaveRealm()
            startGathering()
        }
        hurtFlash = max(0f, hurtFlash - dt * 2f)
        if (inRealm) realm(dt) else landing(dt)
        overlay()
    }

    private fun finish() {
        if (done) return
        done = true
        Sound.stopVoice()
        for (n in gather) n.gather = false
        caption = ""
        speaker = ""
        title = ""
        black = 1f
    }

    // ===================================================================================
    // Scene 1: the Grain Rot
    // ===================================================================================

    private fun bump(x: Float, t0: Float, up: Float, down: Float): Float =
        smooth((x - t0) / up) * (1f - smooth((x - t0 - up) / down))

    private fun angDiff(from: Float, to: Float): Float {
        var d = to - from
        while (d > PI) d -= 2f * PI
        while (d < -PI) d += 2f * PI
        return d
    }

    private class Shot(val t0: Float, val a: Float, val rate: Float, val r: Float, val h: Float, val th: Float, val focus: Int)

    /**
     * The camera cuts. [a] is the angle round the fight (0 = off to his right, 90 degrees = behind
     * Nullfang looking at him, minus 90 = behind the hero looking at the beast), [rate] a slow drift,
     * [r] how far out (on top of Nullfang's own size), [h] how high, [th] how high up Nullfang to look,
     * and [focus] what to centre on: 0 the middle of the fight, 1 the hero, 2 Nullfang.
     */
    private val shots = listOf(
        Shot(0.0f, 0.60f, 0.025f, 22f, 8.5f, 0.30f, 0),   // high establishing orbit
        Shot(9.0f, -1.25f, 0.0f, 12f, 2.4f, 0.50f, 0),    // behind him, low: the size of it
        Shot(13.5f, 0.15f, 0.015f, 17f, 3.0f, 0.40f, 0),  // profile, first blows
        Shot(24.0f, 2.70f, -0.02f, 18f, 3.4f, 0.40f, 0),
        Shot(30.0f, -0.50f, 0.02f, 16f, 2.0f, 0.45f, 0),
        Shot(38.0f, 0.90f, 0.0f, 24f, 7.0f, 0.30f, 0),    // high and wide
        Shot(46.0f, -2.50f, 0.03f, 17f, 2.8f, 0.40f, 0),
        Shot(54.0f, 0.30f, -0.02f, 20f, 3.0f, 0.45f, 0),
        Shot(61.0f, 2.30f, 0.0f, 15f, 1.6f, 0.50f, 0),
        Shot(67.5f, 1.40f, 0.0f, 22f, 6.0f, 0.30f, 0),
        Shot(70.6f, 0.20f, 0.0f, 17f, 1.2f, 0.35f, 0),    // he is knocked down
        Shot(74.0f, -1.80f, 0.0f, 14f, 1.0f, 0.50f, 2),   // Nullfang looms over him
        Shot(79.0f, 0.00f, 0.03f, 20f, 3.0f, 0.40f, 0),
        Shot(88.0f, 2.90f, 0.0f, 17f, 2.2f, 0.40f, 0),
        Shot(95.0f, -0.80f, 0.02f, 24f, 7.5f, 0.30f, 0),
        Shot(104.0f, 0.50f, 0.0f, 15f, 1.4f, 0.45f, 0),
        Shot(106.6f, 2.00f, 0.0f, 18f, 1.1f, 0.35f, 0),   // knocked down again
        Shot(113.0f, -1.10f, 0.0f, 16f, 1.6f, 0.50f, 1),  // struggling to rise
        Shot(118.0f, 0.40f, 0.02f, 20f, 3.5f, 0.55f, 2),  // it gathers its power
        Shot(126.2f, 1.35f, 0.0f, 12f, 3.0f, 0.40f, 0),   // over its shoulder as the blast leaves
        Shot(128.4f, 0.10f, 0.0f, 22f, 3.2f, 0.40f, 1),   // the blast hits
        Shot(131.2f, -1.15f, 0.0f, 12f, 1.0f, 0.55f, 0),  // low, as it walks over to him
        Shot(137.0f, 3.10f, 0.01f, 22f, 3.5f, 0.45f, 0),  // the portal opens beyond them
        Shot(142.2f, 0.00f, 0.0f, 16f, 2.6f, 0.55f, 2),   // the grab
        Shot(146.4f, -1.00f, 0.0f, 22f, 4.2f, 0.60f, 0),  // wide, for the throw
    )

    private fun realm(dt: Float) {
        val cv = cave ?: return
        bossVisible = true
        val sideX = dirZ
        val sideZ = -dirX
        shake = max(0f, shake - dt * 1.4f)
        blastFlash = 0f

        // ================= The hero =================
        var hf = 0f        // metres towards Nullfang (negative: driven back)
        var hl = 0f        // metres off to the side (his dodge rolls)
        var lean = 0f      // staggering backwards, 0 upright
        var kdLie = 0f     // knocked down, up to 0.85 (flat on his back)
        var hp = 1f
        var rollSign = 0f
        var rollMix = 0f
        var bfw = 0f       // Nullfang's own lunges and recoil along the fight line (negative: towards him)
        var bHurt = 0f
        var landed = 0
        heroAttack = -1f
        heroTumble = -1f
        heroAir = 0f
        boss.strike = 0f

        // His own swings: a step in and a cut, and where each lands the beast flinches.
        for (sw in SWINGS) {
            val u = (t - sw) / SWING_LEN
            if (u in 0f..1f) {
                heroAttack = u
                hf += 0.9f * sin(u * PI)
            }
            val hitAt = sw + SWING_LEN * 0.55f
            if (t >= hitAt) {
                landed++
                bHurt = max(bHurt, bump(t, hitAt, 0.05f, 0.5f))
                bfw += 0.35f * bump(t, hitAt, 0.1f, 0.7f)
                if (sounded.add(500 + (sw * 10f).toInt())) {
                    Sound.step(Surface.ROCK, 1.3f)
                    shake = max(shake, 0.35f)
                }
            }
        }

        // Its blows: some he rolls clear of, some drive him back, two put him on the ground.
        var dodgeN = 0
        var hitN = 0
        for (i in BSTRIKE_T.indices) {
            val st = BSTRIKE_T[i]
            val kind = BSTRIKE_K[i]
            val u = (t - st) / STRIKE_LEN
            if (u in 0f..1f) {
                boss.strike = 1f - u
                bfw -= 0.9f * sin(u * PI)
            }
            if (t >= st && sounded.add(200 + i)) Sound.call(growl, 1f)
            val imp = st + 0.5f
            if (kind == 0) {
                val sign = if (dodgeN % 2 == 0) 1f else -1f
                dodgeN++
                val rs = st - 0.35f
                val ru = (t - rs) / ROLL_LEN
                if (ru in 0f..1f) {
                    heroTumble = ru
                    rollSign = sign
                    rollMix = smooth(ru / 0.15f) * (1f - smooth((ru - 0.85f) / 0.15f))
                }
                hl += sign * 3.6f * (smooth((t - rs) / ROLL_LEN) - smooth((t - rs - 2.4f) / 1.6f))
                if (t >= imp && sounded.add(300 + i)) {
                    Sound.step(Surface.ROCK, 1.1f)   // the claws bite empty rock
                    shake = max(shake, 0.3f)
                }
            } else {
                val heavy = kind == 2
                val prevHp = if (hitN == 0) 1f else HP_AFTER[hitN - 1]
                val hold = if (heavy) LIE_FOR[hitN] else 1.6f
                val rec = if (heavy) 0.7f else 0.85f
                val push = if (heavy) 5.5f else 3.0f
                hf -= push * (smooth((t - imp) / 0.25f) - rec * smooth((t - imp - hold) / 1.6f))
                if (t >= imp) {
                    hp = prevHp + (HP_AFTER[hitN] - prevHp) * smooth((t - imp) / 0.5f)
                    if (sounded.add(300 + i)) {
                        hurtFlash = 1f
                        shake = max(shake, if (heavy) 1.0f else 0.6f)
                        Sound.step(Surface.ROCK, if (heavy) 2f else 1.5f)
                    }
                }
                if (heavy) {
                    kdLie += 0.85f * smooth((t - imp) / 0.45f) *
                        (1f - RESID[hitN] * smooth((t - imp - LIE_FOR[hitN]) / RISE_FOR[hitN]))
                } else {
                    lean += 0.32f * bump(t, imp, 0.12f, 1.0f)
                }
                hitN++
            }
        }
        // Worn down: swaying on his feet from here on.
        if (t < BLAST_HIT) lean += 0.05f * sin(t * 2.7f) * smooth((t - 80f) / 10f)
        // One last, feeble swing at nothing, after the second fall.
        val du = (t - 120.0f) / 1.6f
        if (du in 0f..1f) {
            heroAttack = du
            hf += 0.5f * sin(du * PI)
        }

        // ---- The pulse of power: it hits him and blows him across the cavern ----
        val bu = (t - BLAST_HIT) / 1.3f
        hf -= 7.5f * smooth(bu)
        val flying = t >= BLAST_HIT && t < BLAST_HIT + 1.3f
        if (flying) {
            heroAir = 1f
            heroTumble = ((t - BLAST_HIT) * 1.6f) % 1f
            rollSign = 0f
            rollMix = 0f
        }
        var lie = min(0.9f, lean + kdLie)
        if (t >= BLAST_HIT) {
            lie = 0.85f * smooth((t - BLAST_HIT - 1.1f) / 0.35f)
            val last = HP_AFTER[HP_AFTER.size - 1]
            hp = last + (0.03f - last) * smooth((t - BLAST_HIT) / 0.3f)
            if (sounded.add(600)) {
                hurtFlash = 1f
                shake = 1.7f
                Sound.step(Surface.ROCK, 2.2f)
            }
            blastFlash = smooth((t - BLAST_HIT) / 0.12f) * (1f - smooth((t - BLAST_HIT - 1.0f) / 3.5f))
        }
        heroLie = lie
        heroHp = hp
        bossHp = 1f - 0.011f * landed

        val hgx = heroX0 + dirX * hf + sideX * hl
        val hgz = heroZ0 + dirZ * hf + sideZ * hl

        // ================= Nullfang =================
        // After the blast it stalks over to where he lies.
        val walkK = smooth((t - 131.5f) / 9.0f)
        var bgx = bossX0 + dirX * bfw + sideX * hl * 0.4f
        var bgz = bossZ0 + dirZ * bfw + sideZ * hl * 0.4f
        bgx += (hgx + dirX * bossFront * 0.95f - bgx) * walkK
        bgz += (hgz + dirZ * bossFront * 0.95f - bgz) * walkK
        boss.x = bgx
        boss.z = bgz
        boss.y = cv.floorAt(bgx - cv.x, bgz - cv.z)
        boss.hurt = bHurt

        // The portal it rips open, off to one side of where he lies.
        val pX = hgx + sideX * 10f
        val pZ = hgz + sideZ * 10f
        portalX = pX
        portalZ = pZ
        portalY = cv.floorAt(pX - cv.x, pZ - cv.z) + 2.6f
        portalOpen = smooth((t - 136.0f) / 1.4f)

        // It watches him; turns to the portal as it holds him over it.
        val face = atan2(hgx - boss.x, hgz - boss.z)
        val toPortal = atan2(pX - boss.x, pZ - boss.z)
        val want = face + angDiff(face, toPortal) * smooth((t - 143.9f) / 2.2f)
        boss.yaw += angDiff(boss.yaw, want) * min(1f, dt * 5f)
        boss.wantYaw = boss.yaw

        // Its legs follow how fast it's actually moving, so lunges and the slow stalk both look right.
        if (prevBX.isNaN()) {
            prevBX = boss.x
            prevBZ = boss.z
        }
        if (dt > 0f) {
            val sp = hypot(boss.x - prevBX, boss.z - prevBZ) / dt
            boss.speed += (min(1.6f, sp * 0.8f) - boss.speed) * min(1f, dt * 8f)
        }
        prevBX = boss.x
        prevBZ = boss.z
        boss.phase += dt * boss.speed * 3f

        // The cast, the bite that snatches him up, and the heave that throws him.
        for ((i, st) in SPECIAL.withIndex()) {
            val u = (t - st) / STRIKE_LEN
            if (u in 0f..1f) boss.strike = 1f - u
            if (t >= st && sounded.add(250 + i)) Sound.call(growl, 1f)
        }
        if (t >= CHARGE && sounded.add(260)) Sound.call(growl, 1.3f)
        if (t >= 131.5f && sounded.add(261)) Sound.call(growl, 1f)

        val fx = sin(boss.yaw)
        val fz = cos(boss.yaw)
        // Its jaws: just in front of its snout, up at the height of its back.
        val jawX = boss.x + fx * bossFront * 0.95f
        val jawZ = boss.z + fz * bossFront * 0.95f
        val jawY = boss.y + bossTop * 0.85f - 1.2f
        portalYaw = atan2(jawX - pX, jawZ - pZ)

        // ---- The power it gathers, hurls, and that bursts on him ----
        blastOn = false
        if (t >= CHARGE && t < BLAST_HIT + 0.9f) {
            val oy = boss.y + bossTop * 0.62f
            if (t < FIRE) {
                blastOn = true
                blastX = boss.x + fx * (bossFront + 0.8f)
                blastZ = boss.z + fz * (bossFront + 0.8f)
                blastY = oy
                blastScale = (0.1f + 0.55f * smooth((t - CHARGE) / 8.5f)) * (1f + 0.08f * sin(t * 14f))
            } else if (t < BLAST_HIT) {
                val k = smooth((t - FIRE) / (BLAST_HIT - FIRE))
                val ox = boss.x + fx * (bossFront + 0.8f)
                val oz = boss.z + fz * (bossFront + 0.8f)
                blastOn = true
                blastX = ox + (hgx - ox) * k
                blastZ = oz + (hgz - oz) * k
                blastY = oy + (cv.floorAt(hgx - cv.x, hgz - cv.z) + 1.1f - oy) * k
                blastScale = 0.65f
            } else {
                blastOn = true
                blastX = hgx
                blastZ = hgz
                blastY = cv.floorAt(hgx - cv.x, hgz - cv.z) + 1.1f
                blastScale = (0.65f + 2.8f * smooth((t - BLAST_HIT) / 0.35f)) *
                    (1f - smooth((t - BLAST_HIT - 0.3f) / 0.6f))
            }
        }

        // ================= Lifted, held, and thrown =================
        var hx = hgx
        var hz = hgz
        var hy = cv.floorAt(hx - cv.x, hz - cv.z)
        if (flying) hy += 3.2f * sin(bu.coerceIn(0f, 1f) * PI)
        if (t >= GRAB) {
            val k = smooth((t - GRAB) / 0.8f)
            val sway = sin(t * 5f) * 0.12f * k
            hx += (jawX - hx) * k + sideX * sway
            hz += (jawZ - hz) * k + sideZ * sway
            hy += (jawY - hy) * k
            heroLie = 0.85f * (1f - k)
            heroAir = k
        }
        if (t >= THROW) {
            // Hurled through the portal, tumbling end over end.
            val u = ((t - THROW) / 1.0f).coerceIn(0f, 1f)
            hx = jawX + (pX - jawX) * u
            hz = jawZ + (pZ - jawZ) * u
            hy = jawY + (portalY - 0.8f - jawY) * u + sin(u * PI) * 1.6f
            heroTumble = ((t - THROW) * 2.4f) % 1f
            heroLie = 0f
            heroAir = 1f
            if (sounded.add(700)) Sound.step(Surface.ROCK, 1.8f)
        }
        heroX = hx
        heroZ = hz
        heroFeet = hy
        var yaw = atan2(boss.x - hx, boss.z - hz)
        if (rollMix > 0f) {
            val ry = atan2(rollSign * sideX, rollSign * sideZ)
            yaw += angDiff(yaw, ry) * rollMix
        }
        heroYaw = yaw

        // ================= Camera =================
        var si = 0
        for (i in shots.indices) if (t >= shots[i].t0) si = i
        val sh = shots[si]
        val ang = sh.a + sh.rate * (t - sh.t0)
        val cxF: Float
        val czF: Float
        val cty: Float
        when (sh.focus) {
            1 -> {
                cxF = hx
                czF = hz
                cty = hy + 1.0f
            }
            2 -> {
                cxF = boss.x
                czF = boss.z
                cty = floorY + bossTop * sh.th
            }
            else -> {
                cxF = (hx + boss.x) * 0.5f
                czF = (hz + boss.z) * 0.5f
                cty = floorY + bossTop * sh.th
            }
        }
        val rr = sh.r + bossFront * 0.9f
        var ex = cxF + (sideX * cos(ang) + dirX * sin(ang)) * rr
        var ez = czF + (sideZ * cos(ang) + dirZ * sin(ang)) * rr
        var ey = floorY + sh.h
        var tx = cxF
        var tz = czF
        var ty = cty
        if (shake > 0f) {
            ex += sin(t * 53f) * 0.22f * shake
            ey += cos(t * 47f) * 0.16f * shake
            ez += sin(t * 41f + 1f) * 0.22f * shake
            tx += cos(t * 59f) * 0.12f * shake
            ty += sin(t * 43f) * 0.1f * shake
            tz += cos(t * 37f) * 0.12f * shake
        }
        look(ex, ey, ez, tx, ty, tz)
        keepInCave(cv)
    }

    /** Keeps the camera between the cave's floor and roof. */
    private fun keepInCave(cv: Cave) {
        // Sideways first: if the lens has drifted into solid rock, slide it back towards the action.
        var guard = 0
        while (guard < 14 && cv.inside(cam[0] - cv.x, cam[2] - cv.z) < 2.5f) {
            cam[0] += (cam[3] - cam[0]) * 0.15f
            cam[2] += (cam[5] - cam[2]) * 0.15f
            guard++
        }
        val lx = cam[0] - cv.x
        val lz = cam[2] - cv.z
        val d = cv.inside(lx, lz)
        val lo = cv.floorFrom(lx, lz, d) + 0.5f
        val hi = cv.ceilFrom(lx, lz, d) - 0.6f
        cam[1] = cam[1].coerceIn(lo, max(lo, hi))
    }

    // ===================================================================================
    // Scene 2: Greenhollow
    // ===================================================================================

    private fun startGathering() {
        bossVisible = false
        // Where each of them stands round him: on the village side, in an arc.
        val baseAng = atan2(-fX, -fZ)
        val spread = floatArrayOf(-1.15f, -0.4f, 0.4f, 1.15f)
        for (i in gather.indices) {
            val a = baseAng + spread[i % spread.size]
            spotX[i] = sx + sin(a) * 2.5f
            spotZ[i] = sz + cos(a) * 2.5f
        }
    }

    private fun landing(dt: Float) {
        bossVisible = false
        val sideX = fZ
        val sideZ = -fX
        // The portal hangs in the air just outside the village.
        val pX = sx + fX * 9f
        val pZ = sz + fZ * 9f
        portalX = pX
        portalZ = pZ
        portalY = ground + 3.4f
        portalYaw = atan2(-fX, -fZ)
        portalOpen = smooth((t - SWITCH) / 0.4f) * (1f - smooth((t - (SWITCH + 3.4f)) / 1.0f))

        // Shot out of it, he hits the ground, rolls and lies still right on the spawn point.
        val outAt = SWITCH + 0.9f
        val landAt = outAt + 0.9f
        val stopAt = landAt + 1.3f
        val lx = sx + fX * 2.6f
        val lz = sz + fZ * 2.6f
        heroYaw = atan2(-fX, -fZ)
        heroAttack = -1f
        when {
            t < outAt -> {
                // Still inside: nothing to see but the portal.
                heroX = pX
                heroZ = pZ
                heroFeet = portalY - 0.8f
                heroTumble = ((t - SWITCH) * 2.4f) % 1f
                heroAir = 1f
                heroLie = 0f
            }
            t < landAt -> {
                val u = (t - outAt) / (landAt - outAt)
                heroX = pX + (lx - pX) * u
                heroZ = pZ + (lz - pZ) * u
                heroFeet = (portalY - 0.8f) + (ground - (portalY - 0.8f)) * u * u + sin(u * PI) * 0.8f
                heroTumble = ((t - outAt) * 2.4f) % 1f
                heroAir = 1f
                heroLie = 0f
            }
            t < stopAt -> {
                if (sounded.add(400)) Sound.step(Surface.GRASS, 1.8f)
                // Rolling along the ground, slowing down.
                val u = (t - landAt) / (stopAt - landAt)
                val e = 1f - (1f - u) * (1f - u)
                heroX = lx + (sx - lx) * e
                heroZ = lz + (sz - lz) * e
                heroFeet = ground
                heroTumble = (e * 2f) % 1f
                heroAir = 0f
                heroLie = smooth((u - 0.75f) / 0.25f)
                if (u > 0.5f && sounded.add(401)) Sound.step(Surface.GRASS, 1.2f)
            }
            else -> {
                heroX = sx
                heroZ = sz
                heroFeet = ground
                heroTumble = -1f
                heroAir = 0f
                // Flat out, then propped up on his elbows when he comes round.
                heroLie = 1f - 0.45f * smooth((t - (SWITCH + 12.0f)) / 1.2f)
            }
        }

        // The villagers come over once he's still.
        if (t >= SWITCH + 3.6f) {
            for ((i, n) in gather.withIndex()) {
                if (n.gather) continue
                n.goX = spotX[i]
                n.goZ = spotZ[i]
                n.gather = true
            }
        }

        // ---- Camera ----
        when {
            t < SWITCH + 3.8f -> {
                // From the side: out of the portal, onto the grass.
                val cx = (sx + pX) * 0.5f
                val cz = (sz + pZ) * 0.5f
                look(cx + sideX * 8f - fX * 1f, ground + 2.2f, cz + sideZ * 8f - fZ * 1f, cx, ground + 1.3f, cz)
            }
            t < SWITCH + 10.0f -> {
                // From beyond him: he lies in front of us and the village comes running.
                look(sx + fX * 5.2f + sideX * 1.6f, ground + 2.6f, sz + fZ * 5.2f + sideZ * 1.6f, sx - fX * 1.5f, ground + 0.8f, sz - fZ * 1.5f)
            }
            else -> {
                // What he sees as he comes round: faces looking down at him.
                val headX = sx + fX * 1.4f
                val headZ = sz + fZ * 1.4f
                var tx = sx - fX * 2f
                var tz = sz - fZ * 2f
                if (gather.isNotEmpty()) {
                    tx = gather.sumOf { it.x.toDouble() }.toFloat() / gather.size
                    tz = gather.sumOf { it.z.toDouble() }.toFloat() / gather.size
                }
                val rise = 0.35f + 0.5f * smooth((t - (SWITCH + 12.0f)) / 1.2f)
                look(headX, ground + rise, headZ, tx, ground + 1.55f, tz)
            }
        }
    }

    // ===================================================================================

    /** Captions, titles, fades and health bars for this moment. */
    private fun overlay() {
        black = when {
            t < 2.0f -> 1f - smooth(t / 2.0f)
            t > LENGTH - 1.5f -> smooth((t - (LENGTH - 1.5f)) / 1.3f)
            else -> 0f
        }
        white = when {
            t < THROW + 0.7f -> 0f
            t < SWITCH -> smooth((t - (THROW + 0.7f)) / (SWITCH - THROW - 0.7f))
            t < SWITCH + 1.1f -> 1f - smooth((t - SWITCH - 0.1f) / 1.0f)
            else -> 0f
        }
        white = max(white, blastFlash)
        showBars = t in 12f..BLAST_HIT
        title = ""
        subtitle = ""
        if (t in 0.8f..5.5f) {
            title = "THE GRAIN ROT"
            subtitle = "The far side of the gate"
        } else if (t in SWITCH + 1.0f..(SWITCH + 3.6f)) {
            title = Zone.MEADOW.title.uppercase()
            subtitle = placeName
        }
        speaker = ""
        caption = ""
        var active: Line? = null
        for (ln in lines()) {
            if (t >= ln.from && t < ln.to) {
                speaker = ln.who
                caption = ln.text
                active = ln
            }
        }
        // Starts this line's recorded voice clip the moment it becomes current (res/raw/voice_<id>).
        // Until that file exists it's a no-op and the caption keeps the timing above, so this is
        // safe to leave wired in before any audio has been recorded.
        if (active != null && active.id != voicingId) {
            voicingId = active.id
            Sound.playVoice(active.id) {}
        } else if (active == null && voicingId.isNotEmpty()) {
            voicingId = ""
        }
    }

    /** The [Line.id] whose voice clip we last started, so each line only triggers once. */
    private var voicingId = ""

    private class Line(val from: Float, val to: Float, val who: String, val text: String, val id: String)

    private var cachedLines: List<Line>? = null

    private fun lines(): List<Line> = cachedLines ?: listOf(
        Line(9.0f, 12.4f, "Nullfang", "Another little hero, crawling into my realm.", "nullfang_1"),
        Line(73.0f, 76.0f, "Nullfang", "You don't belong here. You never did.", "nullfang_2"),
        Line(91.5f, 94.3f, "Nullfang", "Is that all you have, little hero?", "nullfang_5"),
        Line(123.6f, 126.8f, "Nullfang", "Everything you were\u2026 forget it.", "nullfang_4"),
        Line(144.0f, 147.4f, "Nullfang", "Go back where you came from\u2026 and forget.", "nullfang_3"),
        Line(SWITCH + 4.3f, SWITCH + 6.7f, names[0], "Did you see that?! He fell right out of the sky!", "villager_1"),
        Line(SWITCH + 6.9f, SWITCH + 9.2f, names[1], "He's breathing\u2026 barely. Look at those wounds.", "villager_2"),
        Line(SWITCH + 9.4f, SWITCH + 11.8f, names[2], "Stranger? Can you hear me? What's your name?", "villager_3"),
        Line(SWITCH + 12.2f, SWITCH + 14.6f, "???", "I\u2026 I don't know. I can't remember anything.", "hero_1"),
        Line(SWITCH + 14.8f, SWITCH + 17.3f, names[2], "Then start with your hands. What were they made to hold?", "villager_4"),
    ).also { cachedLines = it }

    private fun look(ex: Float, ey: Float, ez: Float, tx: Float, ty: Float, tz: Float) {
        cam[0] = ex
        cam[1] = ey
        cam[2] = ez
        cam[3] = tx
        cam[4] = ty
        cam[5] = tz
        camYaw = atan2(tx - ex, tz - ez)
    }

    private fun smooth(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    companion object {
        /** The whole thing, in seconds: about three minutes. */
        const val LENGTH = 173.4f
        /** When the white flash is fullest and the scene jumps to Greenhollow. */
        const val SWITCH = 150.0f
        private const val GRAB = 142.6f
        private const val THROW = 148.6f
        /** He starts gathering its power; fires it; and it hits him. */
        private const val CHARGE = 118.0f
        private const val FIRE = 127.4f
        private const val BLAST_HIT = 128.4f
        private const val STRIKE_LEN = 1.0f
        private const val SWING_LEN = 1.3f
        private const val ROLL_LEN = 0.9f
        private const val PI = 3.1415927f
        /** When he swings at it (each lands about half way through). */
        private val SWINGS = floatArrayOf(14.5f, 21.0f, 27.5f, 36.0f, 43.0f, 52.0f, 58.5f, 66.0f, 85.5f, 96.0f, 103.5f)
        /** When its blows start (they land half a second later), and how each ends: 0 he rolls clear, 1 it hits, 2 it knocks him down. */
        private val BSTRIKE_T = floatArrayOf(19.2f, 25.0f, 31.5f, 40.0f, 47.6f, 55.5f, 62.0f, 70.5f, 83.0f, 90.0f, 100.0f, 106.0f)
        private val BSTRIKE_K = intArrayOf(0, 0, 1, 0, 1, 0, 1, 2, 0, 1, 0, 2)
        /** His health after each blow that lands, in order. */
        private val HP_AFTER = floatArrayOf(0.88f, 0.78f, 0.66f, 0.45f, 0.33f, 0.18f)
        /** For the two knock-downs (the 4th and 6th blows to land): seconds on the ground, seconds to get up, and how far up he gets. */
        private val LIE_FOR = floatArrayOf(0f, 0f, 0f, 5.0f, 0f, 6.5f)
        private val RISE_FOR = floatArrayOf(1f, 1f, 1f, 4.5f, 1f, 5.5f)
        private val RESID = floatArrayOf(1f, 1f, 1f, 1.0f, 1f, 0.75f)
        /** The cast, the bite and the heave: strike animations with no damage to show. */
        private val SPECIAL = floatArrayOf(126.8f, GRAB - 0.6f, THROW - 0.6f)
    }
}
