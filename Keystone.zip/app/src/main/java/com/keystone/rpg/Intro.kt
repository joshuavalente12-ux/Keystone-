package com.keystone.rpg

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * The opening cinematic, played once at the start of a new game, before you choose a class.
 *
 * Deep in the Grain Rot, the hero is losing a fight with Nullfang. The beast beats him down,
 * picks him up, tears open a portal and hurls him through it. He comes tumbling out of the sky
 * in Greenhollow, rolls to a stop right where every new hero begins, and the villagers gather
 * round. He remembers nothing, not even his name, which is why you then choose who he is.
 *
 * This class only works out where everything should be at each moment ([update]); [Game] puts
 * the hero there, and [WorldRenderer] draws the boss and the portal from the fields here.
 */
class Intro {
    /** Seconds since the cinematic began. */
    var t = 0f
        private set
    /** Finished (or skipped): the app moves on to choosing a class. */
    @Volatile var done = false
    /** Asked to skip by tapping SKIP. */
    @Volatile var skipAsked = false

    // ---- The hero ----
    var heroX = 0f
    var heroZ = 0f
    var heroFeet = 0f
    var heroYaw = 0f
    /** Attack animation 0..1, or -1. */
    var heroAttack = -1f
    /** Somersault 0..1 (the dodge roll's tumble), or -1. */
    var heroTumble = -1f
    /** 0 standing, 1 flat on his back. */
    var heroLie = 0f
    var heroAir = 0f

    // ---- The camera ----
    val cam = FloatArray(6)
    var camYaw = 0f

    // ---- Nullfang (a creature of our own, not one of the cave's) ----
    val boss = Creature()
    var bossVisible = false

    // ---- The portal he tears open (and the one the hero falls out of) ----
    var portalX = 0f
    var portalY = 0f
    var portalZ = 0f
    var portalYaw = 0f
    /** 0 shut, 1 fully open. */
    var portalOpen = 0f

    /** True while the scene is inside the Grain Rot; false once he's been thrown back to Greenhollow. */
    var inRealm = true
        private set
    /** The cave index of the Grain Rot, or -1 if it couldn't be found (then the cinematic is skipped). */
    var realmCave = -1
        private set
    /** Why [setup] returned false, for diagnosing on a real device. Blank if it worked. */
    var failReason = ""
        private set

    /** Same as [failReason], for callers outside this file. */
    fun failReasonPublic(): String = failReason

    // ---- What the screen shows over the picture ----
    @Volatile var speaker = ""
    @Volatile var caption = ""
    @Volatile var title = ""
    @Volatile var subtitle = ""
    /** Black and white fades, 0..1. */
    @Volatile var black = 1f
    @Volatile var white = 0f
    /** Health bars during the fight. */
    @Volatile var showBars = false
    @Volatile var heroHp = 1f
    @Volatile var hurtFlash = 0f

    // ---- The two scenes, worked out once in [setup] ----
    private var cave: Cave? = null
    private var mx = 0f        // middle of the fight
    private var mz = 0f
    private var floorY = 0f
    private var dirX = 0f      // from the hero towards Nullfang
    private var dirZ = 1f
    private var bossX0 = 0f
    private var bossZ0 = 0f
    private var heroX0 = 0f
    private var heroZ0 = 0f
    private var bossFront = 3f // how far its snout reaches in front of its middle
    private var bossTop = 2f   // how high its back is
    private var gap = 3f

    private var sx = 0f        // where he lands (the spawn point)
    private var sz = 0f
    private var ground = 0f
    private var fX = 0f        // from the spawn point out away from the village
    private var fZ = 1f
    private val gather = ArrayList<Npc>()
    /** Where each of [gather] goes to stand round him. */
    private val spotX = FloatArray(4)
    private val spotZ = FloatArray(4)
    private val names = arrayOf("Villager", "Villager", "Villager")
    private var placeName = "Greenhollow"

    private val sounded = HashSet<Int>()
    /** Nullfang's growl (see [Sound.call]). */
    private var growl = 14

    /** Works out both scenes from the world. Returns false if there's nothing to show. */
    fun setup(g: Game): Boolean {
        val tr = g.treasure
        val ci = tr.rotCave
        val cv = tr.caves.getOrNull(ci)
        if (cv == null) {
            failReason = "no Grain Rot cave (rotCave=$ci, caves=${tr.caves.size})"
            return false
        }
        val si = g.fauna.rotLordSpecies()
        if (si < 0) {
            failReason = "no Nullfang species (index=$si)"
            return false
        }
        if (cv.chambers.isEmpty()) {
            failReason = "Grain Rot cave has no chambers"
            return false
        }
        realmCave = ci
        cave = cv
        val sp = g.fauna.species[si]
        growl = sp.growl

        // Nullfang, as big as he is when you finally face him for real.
        boss.active = true
        boss.sp = si
        boss.rotLord = true
        boss.boss = -1
        boss.wb = -1
        boss.level = 150
        boss.dying = -1f
        boss.hurt = 0f
        boss.strike = 0f
        boss.speed = 0f
        boss.flap = 1f
        boss.scale = sp.maxScale * WORLD_BOSSES[WORLD_BOSSES.size - 1].scale * 1.2f
        val s = boss.scale
        bossFront = (sp.colZ + sp.colHalf + sp.colR) * s
        // How high its back is: the top of its body mesh.
        var top = 0f
        for (pt in sp.parts) {
            if (pt.kind != PartKind.BODY) continue
            for (v in 0 until pt.count) top = max(top, pt.data.getFloat(v * STRIDE + 4) + pt.py)
        }
        bossTop = (if (top > 0.2f) top else 1.2f) * s

        // The fight is in the deepest chamber, across its middle.
        val ch = cv.chambers[cv.chambers.size - 1]
        mx = cv.x + ch[0]
        mz = cv.z + ch[1]
        val a = 0.7f
        dirX = sin(a)
        dirZ = cos(a)
        gap = bossFront + 2.4f
        bossX0 = mx + dirX * gap * 0.5f
        bossZ0 = mz + dirZ * gap * 0.5f
        heroX0 = mx - dirX * gap * 0.5f
        heroZ0 = mz - dirZ * gap * 0.5f
        floorY = cv.floorAt(mx - cv.x, mz - cv.z)
        boss.x = bossX0
        boss.z = bossZ0
        boss.y = cv.floorAt(bossX0 - cv.x, bossZ0 - cv.z)
        boss.yaw = atan2(-dirX, -dirZ)
        boss.wantYaw = boss.yaw

        // Where he lands: right where every new hero starts, in Greenhollow.
        val w = g.world
        sx = w.spawnX
        sz = w.spawnZ
        ground = w.groundAt(sx, sz)
        // Out away from the village centre, so the villagers come from behind him.
        val p0 = PLACES[0]
        val ox = sx - p0.x
        val oz = sz - p0.z
        val ol = hypot(ox, oz)
        if (ol > 0.5f) {
            fX = ox / ol
            fZ = oz / ol
        } else {
            fX = sin(w.spawnYaw)
            fZ = cos(w.spawnYaw)
        }
        placeName = p0.name

        // The nearest few people come over to see what's happened.
        val near = g.people.npcs
            .filter { !it.sitting && hypot(it.x - sx, it.z - sz) < 120f }
            .sortedBy { hypot(it.x - sx, it.z - sz) }
        gather.clear()
        for (n in near) {
            if (gather.size >= 4) break
            gather.add(n)
        }
        // Speaking order: an elder gets the last (and kindest) word if one came.
        val elder = gather.firstOrNull { it.role == NpcRole.QUEST }
        val talkers = (gather.filter { it !== elder } + listOfNotNull(elder)).toMutableList()
        for (i in names.indices) {
            val n = talkers.getOrNull(if (i == 2) talkers.size - 1 else i)
            names[i] = n?.title ?: "Villager"
        }
        if (talkers.size == 1) {
            names[0] = talkers[0].title
            names[1] = talkers[0].title
        }
        update(0f, g)
        return true
    }

    /** Moves everything on to this moment. Tells [g] when the scene changes from the realm to Greenhollow. */
    fun update(dt: Float, g: Game) {
        if (done) return
        if (skipAsked) {
            finish()
            return
        }
        t += dt
        if (t >= LENGTH) {
            finish()
            return
        }
        if (inRealm && t >= SWITCH) {
            inRealm = false
            g.introLeaveRealm()
            startGathering()
        }
        hurtFlash = max(0f, hurtFlash - dt * 2f)
        if (inRealm) realm(dt) else landing(dt)
        overlay()
    }

    private fun finish() {
        if (done) return
        done = true
        for (n in gather) n.gather = false
        caption = ""
        speaker = ""
        title = ""
        black = 1f
    }

    // ===================================================================================
    // Scene 1: the Grain Rot
    // ===================================================================================

    private fun realm(dt: Float) {
        val cv = cave ?: return
        bossVisible = true
        val sideX = dirZ
        val sideZ = -dirX

        // ---- The hero swings at it, twice, and is driven back by each blow it lands ----
        heroAttack = when {
            t in 0.8f..2.05f -> (t - 0.8f) / 1.25f
            t in 3.4f..4.65f -> (t - 3.4f) / 1.25f
            else -> -1f
        }
        var back = 0f
        var hp = 1f
        for ((i, imp) in IMPACTS.withIndex()) {
            val k = smooth((t - imp) / 0.35f)
            back += k * 1.1f
            if (t >= imp) {
                hp = HP_AFTER[i]
                if (sounded.add(100 + i)) {
                    hurtFlash = 1f
                    Sound.step(Surface.ROCK, 1.6f)
                }
            }
        }
        heroHp = hp
        // Each blow starts as a strike animation 0.6s earlier.
        boss.strike = 0f
        for (st in STRIKES) {
            val u = (t - st) / STRIKE_LEN
            if (u in 0f..1f) {
                boss.strike = 1f - u
                if (sounded.add(200 + (st * 10f).toInt())) Sound.call(growl, 1f)
            }
        }

        // Knocked flat by the third blow.
        heroLie = 0.85f * smooth((t - IMPACTS[2]) / 0.4f)
        heroTumble = -1f
        heroAir = 0f

        // ---- It stalks in, snatches him up ----
        val advance = (gap - bossFront - 0.6f).coerceAtLeast(0f) + back * 0.6f
        val walkK = smooth((t - 8.2f) / 1.2f)
        boss.x = bossX0 - dirX * advance * walkK
        boss.z = bossZ0 - dirZ * advance * walkK
        boss.y = cv.floorAt(boss.x - cv.x, boss.z - cv.z)
        boss.speed = if (t in 8.2f..9.4f) 1.4f else 0f
        boss.phase += dt * boss.speed * 3f

        var hx = heroX0 - dirX * back
        var hz = heroZ0 - dirZ * back
        var hy = cv.floorAt(hx - cv.x, hz - cv.z)
        // Its jaws: just in front of its snout, up at the height of its back.
        val jawX = boss.x - dirX * (bossFront * 0.95f)
        val jawZ = boss.z - dirZ * (bossFront * 0.95f)
        val jawY = boss.y + bossTop * 0.85f - 1.2f

        // The portal it rips open, off to one side.
        val pX = mx - dirX * 1.5f + sideX * 9f
        val pZ = mz - dirZ * 1.5f + sideZ * 9f
        portalX = pX
        portalZ = pZ
        portalY = cv.floorAt(pX - cv.x, pZ - cv.z) + 2.6f
        portalYaw = atan2(jawX - pX, jawZ - pZ)
        portalOpen = smooth((t - 9.8f) / 1.0f)

        if (t >= GRAB) {
            // Lifted off the ground, dangling.
            val k = smooth((t - GRAB) / 0.5f)
            val sway = sin(t * 5f) * 0.12f * k
            hx += (jawX - hx) * k + sideX * sway
            hz += (jawZ - hz) * k + sideZ * sway
            hy += (jawY - hy) * k
            heroLie = 0.85f * (1f - k)
            heroAir = k
        }
        if (t >= THROW) {
            // Hurled through the portal, tumbling end over end.
            val u = ((t - THROW) / 1.0f).coerceIn(0f, 1f)
            hx = jawX + (pX - jawX) * u
            hz = jawZ + (pZ - jawZ) * u
            hy = jawY + (portalY - 0.8f - jawY) * u + sin(u * PI) * 1.6f
            heroTumble = ((t - THROW) * 2.4f) % 1f
            heroLie = 0f
            heroAir = 1f
            if (sounded.add(300)) Sound.step(Surface.ROCK, 1.8f)
        }
        heroX = hx
        heroZ = hz
        heroFeet = hy
        heroYaw = atan2(boss.x - hx, boss.z - hz)

        // ---- Camera ----
        val midX = (hx + boss.x) * 0.5f
        val midZ = (hz + boss.z) * 0.5f
        when {
            t < 3.0f -> {
                // A slow wide orbit: the size of the thing he's fighting.
                val ang = atan2(sideX, sideZ) + 0.9f - t * 0.18f
                val r = 9f + bossFront
                look(midX + sin(ang) * r, floorY + 3.6f, midZ + cos(ang) * r, midX, floorY + bossTop * 0.55f, midZ)
            }
            t < 7.6f -> {
                // Over his shoulder, looking up at it.
                look(
                    hx - dirX * 3.4f + sideX * 1.3f, hy + 2.1f, hz - dirZ * 3.4f + sideZ * 1.3f,
                    boss.x, boss.y + bossTop * 0.75f, boss.z,
                )
            }
            t < THROW -> {
                // Low, from his flank: it comes on and lifts him.
                look(
                    midX + sideX * 10.5f - dirX * 2f, floorY + 1.4f, midZ + sideZ * 10.5f - dirZ * 2f,
                    midX, floorY + bossTop * 0.6f, midZ,
                )
            }
            else -> {
                // Wide, from behind where he stood, so the throw crosses the frame into the portal.
                val cx = (jawX + pX) * 0.5f
                val cz = (jawZ + pZ) * 0.5f
                look(cx - dirX * 11f - sideX * 2f, floorY + 3.2f, cz - dirZ * 11f - sideZ * 2f, cx, floorY + 2.4f, cz)
            }
        }
        keepInCave(cv)
    }

    /** Keeps the camera between the cave's floor and roof. */
    private fun keepInCave(cv: Cave) {
        val lx = cam[0] - cv.x
        val lz = cam[2] - cv.z
        val d = cv.inside(lx, lz)
        val lo = cv.floorFrom(lx, lz, d) + 0.5f
        val hi = cv.ceilFrom(lx, lz, d) - 0.6f
        cam[1] = cam[1].coerceIn(lo, max(lo, hi))
    }

    // ===================================================================================
    // Scene 2: Greenhollow
    // ===================================================================================

    private fun startGathering() {
        bossVisible = false
        // Where each of them stands round him: on the village side, in an arc.
        val baseAng = atan2(-fX, -fZ)
        val spread = floatArrayOf(-1.15f, -0.4f, 0.4f, 1.15f)
        for (i in gather.indices) {
            val a = baseAng + spread[i % spread.size]
            spotX[i] = sx + sin(a) * 2.5f
            spotZ[i] = sz + cos(a) * 2.5f
        }
    }

    private fun landing(dt: Float) {
        bossVisible = false
        val sideX = fZ
        val sideZ = -fX
        // The portal hangs in the air just outside the village.
        val pX = sx + fX * 9f
        val pZ = sz + fZ * 9f
        portalX = pX
        portalZ = pZ
        portalY = ground + 3.4f
        portalYaw = atan2(-fX, -fZ)
        portalOpen = smooth((t - SWITCH) / 0.4f) * (1f - smooth((t - 16f) / 1.0f))

        // Shot out of it, he hits the ground, rolls and lies still right on the spawn point.
        val outAt = SWITCH + 0.9f
        val landAt = outAt + 0.9f
        val stopAt = landAt + 1.3f
        val lx = sx + fX * 2.6f
        val lz = sz + fZ * 2.6f
        heroYaw = atan2(-fX, -fZ)
        heroAttack = -1f
        when {
            t < outAt -> {
                // Still inside: nothing to see but the portal.
                heroX = pX
                heroZ = pZ
                heroFeet = portalY - 0.8f
                heroTumble = ((t - SWITCH) * 2.4f) % 1f
                heroAir = 1f
                heroLie = 0f
            }
            t < landAt -> {
                val u = (t - outAt) / (landAt - outAt)
                heroX = pX + (lx - pX) * u
                heroZ = pZ + (lz - pZ) * u
                heroFeet = (portalY - 0.8f) + (ground - (portalY - 0.8f)) * u * u + sin(u * PI) * 0.8f
                heroTumble = ((t - outAt) * 2.4f) % 1f
                heroAir = 1f
                heroLie = 0f
            }
            t < stopAt -> {
                if (sounded.add(400)) Sound.step(Surface.GRASS, 1.8f)
                // Rolling along the ground, slowing down.
                val u = (t - landAt) / (stopAt - landAt)
                val e = 1f - (1f - u) * (1f - u)
                heroX = lx + (sx - lx) * e
                heroZ = lz + (sz - lz) * e
                heroFeet = ground
                heroTumble = (e * 2f) % 1f
                heroAir = 0f
                heroLie = smooth((u - 0.75f) / 0.25f)
                if (u > 0.5f && sounded.add(401)) Sound.step(Surface.GRASS, 1.2f)
            }
            else -> {
                heroX = sx
                heroZ = sz
                heroFeet = ground
                heroTumble = -1f
                heroAir = 0f
                // Flat out, then propped up on his elbows when he comes round.
                heroLie = 1f - 0.45f * smooth((t - 24.6f) / 1.2f)
            }
        }

        // The villagers come over once he's still.
        if (t >= 16.2f) {
            for ((i, n) in gather.withIndex()) {
                if (n.gather) continue
                n.goX = spotX[i]
                n.goZ = spotZ[i]
                n.gather = true
            }
        }

        // ---- Camera ----
        when {
            t < 16.4f -> {
                // From the side: out of the portal, onto the grass.
                val cx = (sx + pX) * 0.5f
                val cz = (sz + pZ) * 0.5f
                look(cx + sideX * 8f - fX * 1f, ground + 2.2f, cz + sideZ * 8f - fZ * 1f, cx, ground + 1.3f, cz)
            }
            t < 22.6f -> {
                // From beyond him: he lies in front of us and the village comes running.
                look(sx + fX * 5.2f + sideX * 1.6f, ground + 2.6f, sz + fZ * 5.2f + sideZ * 1.6f, sx - fX * 1.5f, ground + 0.8f, sz - fZ * 1.5f)
            }
            else -> {
                // What he sees as he comes round: faces looking down at him.
                val headX = sx + fX * 1.4f
                val headZ = sz + fZ * 1.4f
                var tx = sx - fX * 2f
                var tz = sz - fZ * 2f
                if (gather.isNotEmpty()) {
                    tx = gather.sumOf { it.x.toDouble() }.toFloat() / gather.size
                    tz = gather.sumOf { it.z.toDouble() }.toFloat() / gather.size
                }
                val rise = 0.35f + 0.5f * smooth((t - 24.6f) / 1.2f)
                look(headX, ground + rise, headZ, tx, ground + 1.55f, tz)
            }
        }
    }

    // ===================================================================================

    /** Captions, titles, fades and health bars for this moment. */
    private fun overlay() {
        black = when {
            t < 1.2f -> 1f - smooth(t / 1.2f)
            t > LENGTH - 1.5f -> smooth((t - (LENGTH - 1.5f)) / 1.3f)
            else -> 0f
        }
        white = when {
            t < THROW + 0.7f -> 0f
            t < SWITCH -> smooth((t - (THROW + 0.7f)) / (SWITCH - THROW - 0.7f))
            t < SWITCH + 1.1f -> 1f - smooth((t - SWITCH - 0.1f) / 1.0f)
            else -> 0f
        }
        showBars = t in 0.8f..(THROW + 0.6f)
        title = ""
        subtitle = ""
        if (t in 0.6f..3.2f) {
            title = "THE GRAIN ROT"
            subtitle = "The far side of the gate"
        } else if (t in SWITCH + 1.0f..16.2f) {
            title = Zone.MEADOW.title.uppercase()
            subtitle = placeName
        }
        speaker = ""
        caption = ""
        for (ln in lines()) {
            if (t >= ln.from && t < ln.to) {
                speaker = ln.who
                caption = ln.text
            }
        }
    }

    private class Line(val from: Float, val to: Float, val who: String, val text: String)

    private var cachedLines: List<Line>? = null

    private fun lines(): List<Line> = cachedLines ?: listOf(
        Line(3.3f, 5.8f, "Nullfang", "Another little hero, crawling into my realm."),
        Line(6.0f, 8.2f, "Nullfang", "You don't belong here. You never did."),
        Line(9.9f, 11.6f, "Nullfang", "Go back where you came from\u2026 and forget."),
        Line(16.9f, 19.3f, names[0], "Did you see that?! He fell right out of the sky!"),
        Line(19.5f, 21.8f, names[1], "He's breathing\u2026 barely. Look at those wounds."),
        Line(22.0f, 24.4f, names[2], "Stranger? Can you hear me? What's your name?"),
        Line(24.8f, 27.2f, "???", "I\u2026 I don't know. I can't remember anything."),
        Line(27.4f, 29.9f, names[2], "Then start with your hands. What were they made to hold?"),
    ).also { cachedLines = it }

    private fun look(ex: Float, ey: Float, ez: Float, tx: Float, ty: Float, tz: Float) {
        cam[0] = ex
        cam[1] = ey
        cam[2] = ez
        cam[3] = tx
        cam[4] = ty
        cam[5] = tz
        camYaw = atan2(tx - ex, tz - ez)
    }

    private fun smooth(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    companion object {
        /** The whole thing, in seconds. */
        const val LENGTH = 31.2f
        /** When the white flash is fullest and the scene jumps to Greenhollow. */
        const val SWITCH = 12.6f
        private const val GRAB = 9.6f
        private const val THROW = 11.2f
        private const val STRIKE_LEN = 1.0f
        private const val PI = 3.1415927f
        /** Its blows land at these times (each strike starts 0.6s earlier: see [STRIKES]). */
        private val IMPACTS = floatArrayOf(2.5f, 5.4f, 7.2f)
        private val STRIKES = floatArrayOf(1.9f, 4.8f, 6.6f, 9.0f, 10.6f)
        private val HP_AFTER = floatArrayOf(0.62f, 0.3f, 0.08f)
    }
}
