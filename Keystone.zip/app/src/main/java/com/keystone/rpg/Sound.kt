package com.keystone.rpg

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** What your feet are landing on, for the footstep sound. */
object Surface {
    const val GRASS = 0
    const val DIRT = 1
    const val SAND = 2
    const val SNOW = 3
    const val STONE = 4
    const val WOOD = 5
    const val WATER = 6
    const val ROCK = 7
    const val COUNT = 8
}

/**
 * All the game's sound, made in code (no audio files): footsteps for each kind of
 * ground, wind, rain and thunder. Runs on its own thread and streams to the speaker.
 */
object Sound {
    private const val RATE = 22050
    private const val VARIANTS = 4
    private const val VOICES = 12
    private const val CALLS = 14
    private const val TAU = 6.2831855f

    /** 0..~1.5 each, set by the game every frame; the sound eases towards them. */
    @Volatile var wind = 0f
    @Volatile var rain = 0f
    @Volatile var indoors = false

    /** Volume settings, 0..1 each, chosen in the settings menu and remembered. */
    @Volatile var volSteps = 1f
    @Volatile var volWind = 1f
    @Volatile var volRain = 1f
    @Volatile var volAnimals = 1f
    @Volatile var volMusic = 0.6f

    // Background music: "Moss Gate", looping.
    private var music: MediaPlayer? = null
    private var appCtx: Context? = null

    fun load(ctx: Context) {
        appCtx = ctx.applicationContext
        val p = ctx.getSharedPreferences("keystone_sound", Context.MODE_PRIVATE)
        volMusic = p.getFloat("music", 0.6f)
        volSteps = p.getFloat("steps", 1f)
        volWind = p.getFloat("wind", 1f)
        volRain = p.getFloat("rain", 1f)
        volAnimals = p.getFloat("animals", 1f)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("keystone_sound", Context.MODE_PRIVATE).edit()
            .putFloat("steps", volSteps)
            .putFloat("wind", volWind)
            .putFloat("rain", volRain)
            .putFloat("animals", volAnimals)
            .putFloat("music", volMusic)
            .apply()
    }

    /** True while the game screen is showing, so we come back after the app is paused. */
    @Volatile var wanted = false

    private val events = ConcurrentLinkedQueue<FloatArray>()
    @Volatile private var running = false
    private var thread: Thread? = null
    @Volatile private var bank: Array<Array<FloatArray>>? = null
    @Volatile private var calls: Array<FloatArray>? = null

    fun step(surface: Int, loud: Float) {
        if (running) events.add(floatArrayOf(0f, surface.toFloat(), loud))
    }

    /** A creature's call. [id] is its species number, [loud] falls off with distance. */
    fun call(id: Int, loud: Float) {
        if (running && loud > 0.02f) events.add(floatArrayOf(2f, id.toFloat(), loud))
    }

    fun thunder(delay: Float, loud: Float) {
        if (running) events.add(floatArrayOf(1f, delay, loud))
    }

    fun setMusicVolume(v: Float) {
        volMusic = v
        try {
            music?.setVolume(v * 0.8f, v * 0.8f)
        } catch (ignored: Throwable) {
        }
    }

    private fun playMusic() {
        try {
            var m = music
            if (m == null) {
                val c = appCtx ?: return
                m = MediaPlayer.create(c, R.raw.moss_gate) ?: return
                m.isLooping = true
                music = m
            }
            m.setVolume(volMusic * 0.8f, volMusic * 0.8f)
            if (!m.isPlaying) m.start()
        } catch (e: Throwable) {
            android.util.Log.e("Keystone", "Music failed: $e")
        }
    }

    private fun pauseMusic() {
        try {
            music?.let { if (it.isPlaying) it.pause() }
        } catch (ignored: Throwable) {
        }
    }

    @Synchronized
    fun start() {
        playMusic()
        if (running) return
        running = true
        thread = Thread({ loop() }, "KeystoneSound").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    @Synchronized
    fun stop() {
        pauseMusic()
        running = false
        try {
            thread?.join(600)
        } catch (ignored: InterruptedException) {
        }
        thread = null
        events.clear()
    }

    private fun loop() {
        var track: AudioTrack? = null
        try {
            val b = bank ?: makeBank().also { bank = it }
            val cl = calls ?: Array(CALLS) { synthCall(it) }.also { calls = it }
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(max(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val mixer = Mixer(b, cl)
            val out = ShortArray(441)
            while (running) {
                mixer.fill(out)
                track.write(out, 0, out.size)
            }
        } catch (e: Throwable) {
            android.util.Log.e("Keystone", "Sound stopped: $e")
        } finally {
            try {
                track?.pause()
                track?.flush()
                track?.release()
            } catch (ignored: Throwable) {
            }
        }
    }

    /** Mixes everything playing into the speaker, one small block at a time. */
    private class Mixer(val bank: Array<Array<FloatArray>>, val calls: Array<FloatArray>) {
        private var seed = 0x2545F491
        private fun noise(): Float {
            var x = seed
            x = x xor (x shl 13)
            x = x xor (x ushr 17)
            x = x xor (x shl 5)
            seed = x
            return (x and 0xFFFF) / 32767.5f - 1f
        }

        private val vSample = arrayOfNulls<FloatArray>(VOICES)
        private val vPos = IntArray(VOICES)
        private val vGain = FloatArray(VOICES)
        private val lastVariant = IntArray(Surface.COUNT)

        private var windL = 0f
        private var rainL = 0f
        private var roof = 0f
        private var gust = 0.6f
        private var gustT = 0.6f
        private var gustCount = 0
        private var w1 = 0f
        private var w2 = 0f
        private var whistle = 0f
        private var whistleLo = 0f
        private var r1 = 0f
        private var r2 = 0f
        private var r3 = 0f
        private var dropEnv = 0f
        private var dropPhase = 0f
        private var dropStep = 0f

        private var thunderWait = 0
        private var thunderLeft = 0
        private var thunderLen = 1
        private var thunderGain = 0f
        private var t1 = 0f
        private var t2 = 0f
        private var t3 = 0f

        fun fill(out: ShortArray) {
            while (true) {
                val e = events.poll() ?: break
                if (e[0] < 0.5f) {
                    startStep(e[1].toInt(), e[2] * volSteps)
                } else if (e[0] > 1.5f) {
                    val id = e[1].toInt()
                    if (id in calls.indices) startVoice(calls[id], e[2] * volAnimals)
                } else {
                    thunderWait = (e[1] * RATE).toInt()
                    thunderLen = (RATE * (3.5f + 1.5f * (noise() * 0.5f + 0.5f))).toInt()
                    thunderLeft = thunderLen
                    thunderGain = e[2].coerceIn(0.3f, 1.2f) * volRain
                }
            }
            val windT = wind * volWind
            val rainT = rain * volRain
            val roofT = if (indoors) 1f else 0f
            for (i in out.indices) {
                windL += (windT - windL) * 0.00008f
                rainL += (rainT - rainL) * 0.00008f
                roof += (roofT - roof) * 0.0002f
                val n = noise()

                // Wind: low rushing noise that swells and dies away in gusts, with a thin whistle on top.
                if (++gustCount >= 4096) {
                    gustCount = 0
                    gustT = 0.35f + 0.9f * (noise() * 0.5f + 0.5f)
                }
                gust += (gustT - gust) * 0.00006f
                val wa = 0.015f + 0.05f * gust * min(1.5f, windL)
                w1 += (n - w1) * wa
                w2 += (w1 - w2) * wa
                whistle += (n - whistle) * 0.09f
                whistleLo += (whistle - whistleLo) * 0.06f
                val gustier = gust * gust
                var s = (w2 * 7f + (whistle - whistleLo) * 0.5f * max(0f, windL - 0.5f)) * windL * gustier * (1f - 0.6f * roof)

                // Rain: bright hiss outdoors, a dull drumming on the roof indoors, plus single drops.
                r1 += (n - r1) * 0.35f
                r2 += (n - r2) * 0.06f
                r3 += (r2 - r3) * 0.06f
                val hiss = (n - r1) * 0.32f * (1f - roof) + r3 * 3.2f * roof
                if (dropEnv < 0.02f && noise() * 0.5f + 0.5f < rainL * 0.004f) {
                    dropEnv = 0.6f + 0.4f * (noise() * 0.5f + 0.5f)
                    dropStep = TAU * (2200f + 3000f * (noise() * 0.5f + 0.5f)) * (1f - 0.7f * roof) / RATE
                }
                dropEnv *= 0.992f
                dropPhase += dropStep
                if (dropPhase > TAU) dropPhase -= TAU
                s += (hiss + sin(dropPhase) * dropEnv * 0.18f) * rainL

                // Thunder: a sharp crack if it's close, then a long low rumble.
                if (thunderWait > 0) {
                    thunderWait--
                } else if (thunderLeft > 0) {
                    thunderLeft--
                    val age = 1f - thunderLeft.toFloat() / thunderLen
                    t1 += (n - t1) * 0.02f
                    t2 += (t1 - t2) * 0.02f
                    t3 += (n - t3) * 0.3f
                    val rumble = (1f - age) * (1f - age) * (0.7f + 0.3f * sin(age * 40f))
                    val crack = exp(-age * 40f) * max(0f, thunderGain - 0.6f)
                    s += (t2 * 26f * rumble + (n - t3) * crack * 0.9f) * thunderGain * min(1f, age * 30f)
                }

                // Footsteps.
                for (v in 0 until VOICES) {
                    val smp = vSample[v] ?: continue
                    s += smp[vPos[v]] * vGain[v]
                    if (++vPos[v] >= smp.size) vSample[v] = null
                }

                // Gentle limiter, so nothing ever clips harshly.
                val x = s * 0.9f
                val y = if (abs(x) < 0.7f) x else (if (x > 0f) 1f else -1f) * (0.7f + (abs(x) - 0.7f) / (1f + (abs(x) - 0.7f) * 3.3f))
                out[i] = (y * 32000f).toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        private fun startStep(surface: Int, loud: Float) {
            val sfc = surface.coerceIn(0, Surface.COUNT - 1)
            // Never the same step sound twice in a row.
            var pick = ((noise() * 0.5f + 0.5f) * VARIANTS).toInt().coerceIn(0, VARIANTS - 1)
            if (pick == lastVariant[sfc]) pick = (pick + 1) % VARIANTS
            lastVariant[sfc] = pick
            startVoice(bank[sfc][pick], loud * (0.85f + 0.3f * (noise() * 0.5f + 0.5f)))
        }

        private fun startVoice(sample: FloatArray, gain: Float) {
            if (gain < 0.01f) return
            var slot = 0
            var bestLeft = Int.MAX_VALUE
            for (v in 0 until VOICES) {
                val smp = vSample[v]
                if (smp == null) {
                    slot = v
                    break
                }
                val left = smp.size - vPos[v]
                if (left < bestLeft) {
                    bestLeft = left
                    slot = v
                }
            }
            vSample[slot] = sample
            vPos[slot] = 0
            vGain[slot] = gain
        }
    }

    // ---------- Creature calls, made once at start-up (order matches Fauna species) ----------

    private val CALL_SECONDS = floatArrayOf(1.6f, 2.2f, 1.3f, 0.9f, 2.0f, 2.4f, 1.2f, 1.4f, 2.6f, 1.8f, 1.2f, 1.6f, 1.0f, 1.1f)

    private fun synthCall(id: Int): FloatArray {
        val rnd = java.util.Random(id * 7919L + 3L)
        fun nz(): Float = rnd.nextFloat() * 2f - 1f
        val secs = CALL_SECONDS[id]
        val len = (RATE * secs).toInt()
        val o = FloatArray(len)
        var ph = 0f
        var ph2 = 0f
        var l1 = 0f
        var l2 = 0f
        var h1 = 0f
        var grain = 0f
        // Crystalback's chimes: when each one rings and at what pitch.
        val chimeT = FloatArray(6) { 0.45f + it * 0.2f + rnd.nextFloat() * 0.1f }
        val chimeF = FloatArray(6) { 2000f + rnd.nextFloat() * 2200f }
        for (i in 0 until len) {
            val t = i.toFloat() / RATE
            val u = t / secs
            val n = nz()
            val env = min(1f, t / 0.02f) * min(1f, (secs - t) / 0.08f)
            o[i] = env * when (id) {
                0 -> {
                    // Glimmerhorn: a rising chime, like tapping crystal, over a soft breath.
                    var v = 0f
                    val notes = floatArrayOf(880f, 1108.7f, 1318.5f)
                    for (k in 0 until 3) {
                        val tk = t - k * 0.13f
                        if (tk > 0f) v += exp(-tk / 0.5f) * (sin(TAU * notes[k] * tk) + 0.3f * sin(TAU * notes[k] * 2.76f * tk))
                    }
                    l1 += (n - l1) * 0.05f
                    v * 0.5f + l1 * 1.5f * exp(-t / 0.2f)
                }
                1 -> {
                    // Mossback: a deep, slow, rumbling groan.
                    val f = 68f + 14f * sin(TAU * 0.7f * t) + 3f * sin(TAU * 5f * t)
                    ph += TAU * f / RATE
                    l1 += (n - l1) * 0.02f
                    min(1f, t / 0.35f) * (sin(ph) + 0.5f * sin(2f * ph) + 0.33f * sin(3f * ph) + 0.2f * sin(4f * ph) + l1 * 3f)
                }
                2 -> {
                    // Shadelynx: a throaty purring growl that ends in a hiss.
                    ph += TAU * 95f / RATE
                    val purr = max(0f, sin(TAU * 27f * t))
                    val growl = (sin(ph) + 0.6f * sin(2f * ph) + 0.4f * sin(3f * ph)) * purr * (1f - smooth(0.55f, 0.75f, u))
                    h1 += (n - h1) * 0.4f
                    growl + (n - h1) * 1.2f * smooth(0.55f, 0.7f, u)
                }
                3 -> {
                    // Wispfox: three quick bright yips.
                    val k = (t / 0.25f).toInt()
                    val tk = t - k * 0.25f
                    if (k < 3 && tk < 0.14f) {
                        val f = 900f + 800f * (tk / 0.14f) - 300f * (tk / 0.14f) * (tk / 0.14f)
                        ph += TAU * f / RATE
                        (sin(ph) + 0.3f * sin(2f * ph)) * min(1f, tk / 0.01f) * (1f - tk / 0.14f)
                    } else 0f
                }
                4 -> {
                    // Frostmane: a big roar with an icy shimmer on top.
                    val f = 180f - 60f * u
                    ph += TAU * f / RATE
                    var saw = 0f
                    for (h in 1..6) saw += sin(ph * h) / h
                    val cut = 0.35f - 0.25f * u
                    l1 += (saw + n * 0.6f - l1) * cut
                    min(1f, t / 0.15f) * (1f - u * 0.6f) * l1 * 1.6f + sin(TAU * 2400f * t) * 0.08f * (0.5f + 0.5f * sin(TAU * 9f * t))
                }
                5 -> {
                    // Rimewooly: a long low horn-like bellow.
                    val f = 85f + 10f * sin(TAU * 0.4f * t)
                    ph += TAU * f / RATE
                    var saw = 0f
                    for (h in 1..8) saw += sin(ph * h) / h
                    l1 += (saw - l1) * 0.12f
                    min(1f, t / 0.4f) * l1 * 1.4f
                }
                6 -> {
                    // Sunstrider: two nasal honks.
                    val k = if (t < 0.5f) 0 else 1
                    val tk = t - k * 0.62f
                    if (tk in 0f..0.45f) {
                        val f = 320f - 40f * (tk / 0.45f)
                        ph += TAU * f / RATE
                        (sin(ph) + 0.45f * sin(3f * ph) + 0.25f * sin(5f * ph)) * min(1f, tk / 0.03f) * (1f - tk / 0.45f * 0.6f)
                    } else 0f
                }
                7 -> {
                    // Dunescale: a dry rattling hiss.
                    h1 += (n - h1) * 0.3f
                    val gate = if (sin(TAU * 32f * t) > 0.2f) 1f else 0.15f
                    if (rnd.nextFloat() < 0.004f) grain = 1f
                    grain *= 0.995f
                    (n - h1) * gate * smooth(0f, 0.3f, u) * (1f - smooth(0.8f, 1f, u)) * 1.3f + grain * n * 0.8f
                }
                8 -> {
                    // Voidhound: an eerie ghostly howl.
                    val f = if (u < 0.3f) 380f + 260f * smooth(0f, 0.3f, u) else 640f - 120f * smooth(0.3f, 0.6f, u)
                    val vib = f * (1f + 0.012f * sin(TAU * 6f * t))
                    ph += TAU * vib / RATE
                    ph2 += TAU * vib * 1.007f / RATE
                    smooth(0f, 0.15f, u) * (sin(ph) + 0.7f * sin(ph2) + 0.25f * sin(ph * 0.5f))
                }
                9 -> {
                    // Crystalback: a low grunt, then a scatter of crystal chimes.
                    var v = 0f
                    if (t < 0.4f) {
                        ph += TAU * 110f / RATE
                        v += (sin(ph) + 0.5f * sin(2f * ph) + 0.3f * sin(3f * ph)) * (1f - t / 0.4f)
                    }
                    for (k in 0 until 6) {
                        val tk = t - chimeT[k]
                        if (tk > 0f) v += sin(TAU * chimeF[k] * tk) * exp(-tk / 0.15f) * 0.6f
                    }
                    v
                }
                10 -> {
                    // Emberwing: a warbling, crackling fiery trill.
                    val f = 2300f + 300f * sin(TAU * 22f * t)
                    ph += TAU * f / RATE
                    if (rnd.nextFloat() < 0.01f) grain = 1f
                    grain *= 0.97f
                    sin(ph) * (0.6f + 0.4f * sin(TAU * 18f * t)) + grain * n * 0.7f
                }
                11 -> {
                    // Azure Tailwing: a short melodic song.
                    val notes = floatArrayOf(1568f, 1760f, 2093f, 1760f, 2349f, 2093f)
                    val k = min(5, (t / 0.26f).toInt())
                    val tk = t - k * 0.26f
                    val f = notes[k] * (1f + 0.03f * sin(TAU * 12f * t))
                    ph += TAU * f / RATE
                    sin(ph) * min(1f, tk / 0.02f) * exp(-tk / 0.12f)
                }
                12 -> {
                    // Frostkite: a thin, piercing falling cry.
                    val f = 3200f * exp(-u * 0.52f)
                    ph += TAU * f / RATE
                    (sin(ph) + 0.2f * sin(2f * ph)) * min(1f, t / 0.03f) * (1f - u * 0.7f)
                }
                else -> {
                    // Duskraven: two harsh caws.
                    val k = if (t < 0.45f) 0 else 1
                    val tk = t - k * 0.45f
                    if (tk < 0.3f) {
                        val f = 420f - 60f * (tk / 0.3f)
                        ph += TAU * f / RATE
                        var saw = 0f
                        for (h in 1..10) saw += sin(ph * h) / (1f + h * 0.7f)
                        l1 += (saw + n * 0.8f - l1) * 0.4f
                        l1 * min(1f, tk / 0.015f) * (1f - tk / 0.3f)
                    } else 0f
                }
            }
        }
        var peak = 1e-6f
        for (v in o) peak = max(peak, abs(v))
        val g = 0.75f / peak
        for (i in 0 until len) o[i] *= g
        return o
    }

    // ---------- Footstep sounds, made once at start-up ----------

    private fun makeBank(): Array<Array<FloatArray>> =
        Array(Surface.COUNT) { s -> Array(VARIANTS) { v -> synth(s, v) } }

    private fun att(t: Float, a: Float): Float = min(1f, t / a)

    private fun synth(surface: Int, variant: Int): FloatArray {
        val rnd = java.util.Random((surface * 977 + variant * 131 + 17).toLong())
        fun nz(): Float = rnd.nextFloat() * 2f - 1f
        fun chance(p: Float): Boolean = rnd.nextFloat() < p
        val seconds = when (surface) {
            Surface.GRASS -> 0.17f
            Surface.DIRT -> 0.15f
            Surface.SAND -> 0.22f
            Surface.SNOW -> 0.25f
            Surface.STONE -> 0.13f
            Surface.WOOD -> 0.22f
            Surface.WATER -> 0.36f
            else -> 0.15f
        }
        val len = (RATE * seconds).toInt()
        val o = FloatArray(len)
        val pitch = 0.88f + 0.24f * rnd.nextFloat()
        var l1 = 0f
        var l2 = 0f
        var h1 = 0f
        var ph1 = 0f
        var ph2 = 0f
        var grain = 0f
        for (i in 0 until len) {
            val t = i.toFloat() / RATE
            val n = nz()
            o[i] = when (surface) {
                Surface.GRASS -> {
                    // A soft swish of blades with little crinkles.
                    l1 += (n - l1) * 0.45f
                    h1 += (l1 - h1) * 0.08f
                    if (chance(0.02f)) grain = 1f
                    grain *= 0.995f
                    (l1 - h1) * att(t, 0.012f) * exp(-t / 0.05f) * (0.55f + 0.9f * grain)
                }
                Surface.DIRT -> {
                    // A dull thud with some grit.
                    l1 += (n - l1) * 0.18f
                    l2 += (l1 - l2) * 0.18f
                    ph1 += TAU * 85f * pitch / RATE
                    (l2 * 2.4f * exp(-t / 0.035f) + sin(ph1) * 0.7f * exp(-t / 0.03f) +
                        (n - l1) * 0.12f * exp(-t / 0.02f)) * att(t, 0.004f)
                }
                Surface.SAND -> {
                    // A soft shifting hush.
                    l1 += (n - l1) * 0.22f
                    h1 += (l1 - h1) * 0.03f
                    if (chance(0.05f)) grain = 1f
                    grain *= 0.99f
                    (l1 - h1) * 1.2f * att(t, 0.03f) * exp(-t / 0.07f) * (0.6f + 0.6f * grain)
                }
                Surface.SNOW -> {
                    // Crunch: a burst of tiny crackles over a soft thump.
                    if (chance(0.06f)) grain = 0.5f + rnd.nextFloat() * 0.5f
                    grain *= 0.93f
                    l1 += (n - l1) * 0.6f
                    h1 += (l1 - h1) * 0.12f
                    ph1 += TAU * 70f / RATE
                    (l1 - h1) * grain * 2.2f * att(t, 0.025f) * exp(-t / 0.08f) +
                        sin(ph1) * 0.4f * exp(-t / 0.04f) * att(t, 0.01f)
                }
                Surface.STONE, Surface.ROCK -> {
                    // Hard click and scuff; loose rock is lower and grittier.
                    val low = if (surface == Surface.ROCK) 0.7f else 1f
                    h1 += (n - h1) * 0.5f
                    ph1 += TAU * 1150f * pitch * low / RATE
                    ph2 += TAU * 130f * pitch * low / RATE
                    l1 += (n - l1) * 0.3f
                    var v = (n - h1) * 0.9f * exp(-t / 0.006f) + sin(ph1) * 0.35f * exp(-t / 0.012f) +
                        sin(ph2) * 0.6f * exp(-t / 0.025f) + l1 * 0.5f * exp(-t / 0.04f) * att(t, 0.01f)
                    if (surface == Surface.ROCK) {
                        if (chance(0.03f)) grain = 1f
                        grain *= 0.97f
                        v += (n - h1) * grain * 0.5f * exp(-t / 0.06f)
                    }
                    v
                }
                Surface.WOOD -> {
                    // Hollow knock on boards.
                    ph1 += TAU * 170f * pitch / RATE
                    ph2 += TAU * 410f * pitch / RATE
                    h1 += (n - h1) * 0.5f
                    (sin(ph1) * 0.8f * exp(-t / 0.06f) + sin(ph2) * 0.35f * exp(-t / 0.025f) +
                        (n - h1) * 0.5f * exp(-t / 0.005f)) * att(t, 0.002f)
                }
                else -> {
                    // Water: a splash with rising bubbles.
                    l1 += (n - l1) * 0.3f
                    h1 += (l1 - h1) * 0.05f
                    val bt = (t * 14f) % 1f
                    ph1 += TAU * (350f + bt * 600f) * pitch / RATE
                    (l1 - h1) * 1.4f * att(t, 0.01f) * exp(-t / 0.1f) + sin(ph1) * 0.25f * exp(-t / 0.12f) * (1f - bt)
                }
            }
        }
        var peak = 1e-6f
        for (v in o) peak = max(peak, abs(v))
        val level = when (surface) {
            Surface.GRASS -> 0.35f
            Surface.DIRT -> 0.5f
            Surface.SAND -> 0.3f
            Surface.SNOW -> 0.45f
            Surface.WOOD -> 0.55f
            Surface.WATER -> 0.5f
            else -> 0.45f
        }
        val gain = level / peak
        val fade = min(128, len)
        for (i in 0 until len) {
            var g = gain
            if (i >= len - fade) g *= (len - i).toFloat() / fade
            o[i] *= g
        }
        return o
    }
}
