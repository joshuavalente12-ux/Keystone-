package com.keystone.rpg

import kotlin.math.cos
import kotlin.math.sin

private const val MPI = 3.1415927f

private fun sh(c: Int, f: Float): Int = shadeRgb(c, f)

/** A pair of glowing eyes, [w] either side of the middle. */
private fun eyes(m: MeshBuilder, w: Float, y: Float, z: Float, r: Float, col: Int) {
    m.blob(-w, y, z, r, r * 0.8f, r * 0.6f, col, 901, 0f, FLAG_GLOW)
    m.blob(w, y, z, r, r * 0.8f, r * 0.6f, col, 902, 0f, FLAG_GLOW)
}

/** A pair of curved horns sweeping back from the head. */
private fun horns(m: MeshBuilder, s: Float, y: Float, z: Float, col: Int, spread: Float = 1f, len: Float = 1f) {
    for (side in intArrayOf(-1, 1)) {
        var px = side * 0.08f * s
        var py = y
        var pz = z
        for (seg in 0 until 4) {
            val nx = px + side * 0.07f * s * spread
            val ny = py + (0.1f - seg * 0.03f) * s * len
            val nz = pz - 0.08f * s * len
            m.limb(px, py, pz, nx, ny, nz, (0.05f - seg * 0.01f) * s, (0.04f - seg * 0.01f) * s, col, FLAG_SOLID)
            px = nx
            py = ny
            pz = nz
        }
    }
}

/** A row of spikes down the back. */
private fun spines(m: MeshBuilder, s: Float, y: Float, z0: Float, z1: Float, n: Int, col: Int, flag: Int) {
    for (i in 0 until n) {
        val t = if (n > 1) i / (n - 1f) else 0.5f
        val z = z0 + (z1 - z0) * t
        m.spike(0f, y, z, 0.05f * s, (0.18f + 0.1f * (i % 2)) * s, 0f, -0.3f, col, flag)
    }
}

/** Crystals sticking out at odd angles. */
private fun crystals(m: MeshBuilder, s: Float, y: Float, spread: Float, n: Int, col: Int, col2: Int) {
    for (i in 0 until n) {
        val a = i * 2.4f
        val r = spread * (0.3f + 0.7f * ((i * 37) % 10) / 10f)
        m.spike(sin(a) * r * s, y, cos(a) * r * s, 0.06f * s, (0.25f + 0.12f * (i % 3)) * s, sin(a) * 0.4f, cos(a) * 0.4f,
            if (i % 2 == 0) col else col2, FLAG_GLOW)
    }
}

// ---------- Body plans ----------

/** Four legs: wolves, boars, beasts. */
private fun beast(
    k: BodyKit, s: Float, fur: Int, belly: Int, eye: Int, foot: Int,
    long: Float = 1f, tail: Boolean = true,
    body: (MeshBuilder) -> Unit = {}, head: (MeshBuilder) -> Unit = {},
) {
    val hip = 0.75f * s
    k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
        m.blob(0f, hip + 0.18f * s, 0f, 0.34f * s, 0.32f * s, 0.72f * s * long, fur, k.s(), 0.08f, FLAG_FUR)
        m.blob(0f, hip + 0.06f * s, 0.05f * s, 0.26f * s, 0.2f * s, 0.58f * s * long, belly, k.s(), 0.06f, FLAG_FUR)
        m.blob(0f, hip + 0.28f * s, 0.42f * s * long, 0.33f * s, 0.32f * s, 0.32f * s, fur, k.s(), 0.08f, FLAG_FUR)
        body(m)
    }
    k.part(PartKind.HEAD, 0f, hip + 0.35f * s, 0.68f * s * long) { m ->
        m.limb(0f, -0.06f * s, -0.12f * s, 0f, 0.04f * s, 0.12f * s, 0.17f * s, 0.13f * s, fur, FLAG_FUR)
        m.blob(0f, 0.08f * s, 0.2f * s, 0.19f * s, 0.17f * s, 0.21f * s, fur, k.s(), 0.05f, FLAG_FUR)
        m.blob(0f, -0.01f * s, 0.41f * s, 0.11f * s, 0.09f * s, 0.16f * s, belly, k.s(), 0.04f, FLAG_FUR)
        m.blob(0f, 0.03f * s, 0.56f * s, 0.045f * s, 0.035f * s, 0.03f * s, 0x141014, k.s(), 0f, FLAG_SOLID)
        m.spike(-0.06f * s, -0.05f * s, 0.49f * s, 0.016f * s, -0.08f * s, 0f, 0f, 0xEEE8D8, FLAG_SOLID)
        m.spike(0.06f * s, -0.05f * s, 0.49f * s, 0.016f * s, -0.08f * s, 0f, 0f, 0xEEE8D8, FLAG_SOLID)
        m.spike(-0.1f * s, 0.2f * s, 0.12f * s, 0.045f * s, 0.14f * s, -0.2f, -0.2f, fur, FLAG_FUR)
        m.spike(0.1f * s, 0.2f * s, 0.12f * s, 0.045f * s, 0.14f * s, 0.2f, -0.2f, fur, FLAG_FUR)
        eyes(m, 0.09f * s, 0.13f * s, 0.36f * s, 0.032f * s, eye)
        head(m)
    }
    if (tail) {
        k.part(PartKind.TAIL, 0f, hip + 0.24f * s, -0.7f * s * long) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.05f * s, -0.45f * s, 0.07f * s, 0.02f * s, fur, FLAG_FUR)
        }
    }
    k.legs4(hip, 0.48f * s * long, -0.48f * s * long, 0.2f * s, hip, 0.1f * s, 0.06f * s, fur, foot)
}

/** Two legs and two arms: goblins, golems, trolls. [hand] is called for each arm with its side (-1 or 1). */
private fun brute(
    k: BodyKit, s: Float, skin: Int, cloth: Int, eye: Int, foot: Int,
    bulk: Float = 1f, hunch: Float = 0f, arms: Float = 1f, lump: Float = 0.06f,
    body: (MeshBuilder) -> Unit = {}, head: (MeshBuilder) -> Unit = {},
    hand: (MeshBuilder, Float, Float) -> Unit = { _, _, _ -> },
) {
    val hip = 0.85f * s
    val b = bulk
    k.leg(-0.14f * s * b, hip, 0f, 0f, hip, 0.1f * s * b, 0.075f * s * b, cloth, foot, 0f)
    k.leg(0.14f * s * b, hip, 0f, MPI, hip, 0.1f * s * b, 0.075f * s * b, cloth, foot, 0f)
    k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
        m.blob(0f, hip + 0.05f * s, 0f, 0.2f * s * b, 0.14f * s, 0.15f * s * b, cloth, k.s(), lump, FLAG_FUR)
        m.blob(0f, hip + 0.36f * s, hunch * 0.15f * s, 0.26f * s * b, 0.27f * s, 0.19f * s * b, skin, k.s(), lump, FLAG_FUR)
        m.blob(0f, hip + 0.58f * s, hunch * 0.25f * s, 0.33f * s * b, 0.12f * s, 0.18f * s * b, skin, k.s(), lump, FLAG_FUR)
        body(m)
    }
    k.part(PartKind.HEAD, 0f, hip + 0.68f * s, hunch * 0.35f * s) { m ->
        m.limb(0f, -0.06f * s, 0f, 0f, 0.06f * s, 0.02f * s, 0.08f * s * b, 0.07f * s * b, skin, FLAG_FUR)
        m.blob(0f, 0.14f * s, 0.02f * s, 0.14f * s, 0.15f * s, 0.14f * s, skin, k.s(), lump, FLAG_FUR)
        m.blob(0f, 0.05f * s, 0.09f * s, 0.1f * s, 0.07f * s, 0.08f * s, sh(skin, 0.9f), k.s(), 0.03f, FLAG_FUR)
        eyes(m, 0.055f * s, 0.16f * s, 0.13f * s, 0.024f * s, eye)
        head(m)
    }
    for (side in intArrayOf(-1, 1)) {
        val sd = side.toFloat()
        k.part(PartKind.ARM, sd * 0.36f * s * b, hip + 0.58f * s, hunch * 0.25f * s, if (side < 0) 0f else MPI) { m ->
            val l = 0.62f * s * arms
            m.limb(0f, 0f, 0f, sd * 0.05f * s, -l * 0.5f, 0.02f * s, 0.085f * s * b, 0.07f * s * b, skin, FLAG_FUR)
            m.limb(sd * 0.05f * s, -l * 0.5f, 0.02f * s, sd * 0.04f * s, -l, 0.08f * s, 0.07f * s * b, 0.06f * s * b, skin, FLAG_FUR)
            m.blob(sd * 0.04f * s, -l - 0.05f * s, 0.09f * s, 0.08f * s * b, 0.08f * s * b, 0.08f * s * b, sh(skin, 0.95f), k.s(), lump, FLAG_FUR)
            hand(m, sd, l)
        }
    }
}

/** A bouncing blob of goo with a glowing core. */
private fun slime(k: BodyKit, s: Float, col: Int, core: Int, eye: Int, body: (MeshBuilder) -> Unit = {}) {
    k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
        m.blob(0f, 0.42f * s, 0f, 0.55f * s, 0.42f * s, 0.55f * s, col, k.s(), 0.1f, FLAG_FUR)
        m.blob(0f, 0.2f * s, 0f, 0.62f * s, 0.18f * s, 0.62f * s, sh(col, 0.85f), k.s(), 0.12f, FLAG_FUR)
        m.blob(0.05f * s, 0.45f * s, -0.05f * s, 0.2f * s, 0.2f * s, 0.2f * s, core, k.s(), 0.2f, FLAG_GLOW)
        eyes(m, 0.17f * s, 0.6f * s, 0.46f * s, 0.07f * s, eye)
        m.blob(-0.17f * s, 0.6f * s, 0.5f * s, 0.03f * s, 0.03f * s, 0.02f * s, 0x101010, k.s(), 0f, FLAG_SOLID)
        m.blob(0.17f * s, 0.6f * s, 0.5f * s, 0.03f * s, 0.03f * s, 0.02f * s, 0x101010, k.s(), 0f, FLAG_SOLID)
        body(m)
    }
}

/** Many legs splayed wide: spiders, crabs, scorpions and beetles. */
private fun crawler(
    k: BodyKit, s: Float, shell: Int, under: Int, eye: Int, legCol: Int,
    pairs: Int = 4, abdomen: Float = 1f,
    body: (MeshBuilder) -> Unit = {}, head: (MeshBuilder) -> Unit = {},
) {
    val hip = 0.55f * s
    k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
        m.blob(0f, hip + 0.15f * s, -0.48f * s, 0.38f * s * abdomen, 0.32f * s * abdomen, 0.45f * s * abdomen, shell, k.s(), 0.06f, FLAG_FUR)
        m.blob(0f, hip, 0.08f * s, 0.26f * s, 0.18f * s, 0.3f * s, sh(shell, 0.9f), k.s(), 0.05f, FLAG_FUR)
        m.blob(0f, hip - 0.1f * s, 0.05f * s, 0.2f * s, 0.1f * s, 0.26f * s, under, k.s(), 0.05f, FLAG_FUR)
        body(m)
    }
    k.part(PartKind.HEAD, 0f, hip + 0.02f * s, 0.38f * s) { m ->
        m.blob(0f, 0f, 0.05f * s, 0.16f * s, 0.12f * s, 0.15f * s, shell, k.s(), 0.04f, FLAG_FUR)
        eyes(m, 0.06f * s, 0.07f * s, 0.16f * s, 0.028f * s, eye)
        eyes(m, 0.11f * s, 0.05f * s, 0.12f * s, 0.02f * s, eye)
        m.spike(-0.05f * s, -0.04f * s, 0.17f * s, 0.022f * s, -0.14f * s, 0f, 0.3f, legCol, FLAG_SOLID)
        m.spike(0.05f * s, -0.04f * s, 0.17f * s, 0.022f * s, -0.14f * s, 0f, 0.3f, legCol, FLAG_SOLID)
        head(m)
    }
    for (i in 0 until pairs) {
        val z = 0.26f * s - i * 0.16f * s
        val ph = if (i % 2 == 0) 0f else MPI
        k.leg(-0.2f * s, hip, z, ph, hip * 1.1f, 0.05f * s, 0.024f * s, legCol, legCol, -0.62f * s)
        k.leg(0.2f * s, hip, z, ph + MPI, hip * 1.1f, 0.05f * s, 0.024f * s, legCol, legCol, 0.62f * s)
    }
}

/** A long body in pieces that slithers. [segs] pieces, tapering to the tail. */
private fun serpent(
    k: BodyKit, s: Float, col: Int, belly: Int, band: Int, bandFlag: Int, eye: Int,
    segs: Int = 9, head: (MeshBuilder) -> Unit = {},
) {
    val r0 = 0.22f * s
    val seg = 0.42f * s
    var parent: CreaturePart? = null
    var prevR = r0
    for (i in 0 until segs) {
        val t = i / (segs - 1f)
        val rr = r0 * (1f - 0.72f * t)
        val py = if (i == 0) rr else rr - prevR
        val pz = if (i == 0) 0f else -seg
        parent = k.part(PartKind.SEGMENT, 0f, py, pz, i * 0.9f, parent) { m ->
            m.blob(0f, 0f, -seg * 0.5f, rr * 1.05f, rr, seg * 0.64f, col, k.s(), 0.04f, FLAG_FUR)
            m.blob(0f, -rr * 0.4f, -seg * 0.5f, rr * 0.85f, rr * 0.55f, seg * 0.56f, belly, k.s(), 0.03f, FLAG_FUR)
            if (i % 2 == 0) m.blob(0f, rr * 0.6f, -seg * 0.5f, rr * 0.55f, rr * 0.38f, seg * 0.26f, band, k.s(), 0f, bandFlag)
        }
        prevR = rr
    }
    k.part(PartKind.HEAD, 0f, r0 * 1.2f, 0.06f * s) { m ->
        m.limb(0f, -r0 * 0.3f, -0.1f * s, 0f, 0f, 0.1f * s, r0 * 0.95f, r0 * 0.9f, col, FLAG_FUR)
        m.blob(0f, 0f, 0.22f * s, r0 * 1.15f, r0 * 0.75f, r0 * 1.4f, col, k.s(), 0.04f, FLAG_FUR)
        m.blob(0f, -r0 * 0.35f, 0.26f * s, r0 * 0.9f, r0 * 0.35f, r0 * 1.2f, belly, k.s(), 0.03f, FLAG_FUR)
        eyes(m, r0 * 0.6f, r0 * 0.35f, 0.34f * s, 0.035f * s, eye)
        m.spike(-0.05f * s, -r0 * 0.4f, 0.44f * s, 0.018f * s, -0.1f * s, 0f, 0f, 0xEEE8D8, FLAG_SOLID)
        m.spike(0.05f * s, -r0 * 0.4f, 0.44f * s, 0.018f * s, -0.1f * s, 0f, 0f, 0xEEE8D8, FLAG_SOLID)
        head(m)
    }
}

/** Something that floats: wisps, eyes and wraiths, with tentacles or rags hanging below. */
private fun floater(
    k: BodyKit, s: Float, col: Int, glow: Int, eye: Int, tentacles: Int, tentCol: Int,
    body: (MeshBuilder) -> Unit = {}, head: (MeshBuilder) -> Unit = {},
) {
    k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
        m.blob(0f, 0f, 0f, 0.42f * s, 0.4f * s, 0.42f * s, col, k.s(), 0.08f, FLAG_FUR)
        m.blob(0f, 0f, 0f, 0.2f * s, 0.2f * s, 0.2f * s, glow, k.s(), 0.15f, FLAG_GLOW)
        body(m)
    }
    k.part(PartKind.HEAD, 0f, 0.05f * s, 0.2f * s) { m ->
        eyes(m, 0.12f * s, 0.05f * s, 0.18f * s, 0.05f * s, eye)
        head(m)
    }
    for (i in 0 until tentacles) {
        val a = i * 6.2831855f / tentacles
        k.part(PartKind.TAIL, cos(a) * 0.25f * s, -0.28f * s, sin(a) * 0.25f * s) { m ->
            m.limb(0f, 0f, 0f, cos(a) * 0.08f * s, -0.35f * s, sin(a) * 0.08f * s, 0.07f * s, 0.045f * s, tentCol, FLAG_FUR)
            m.limb(cos(a) * 0.08f * s, -0.35f * s, sin(a) * 0.08f * s, cos(a) * 0.02f * s, -0.7f * s, sin(a) * 0.02f * s, 0.045f * s, 0.012f * s, tentCol, FLAG_FUR)
            m.blob(cos(a) * 0.02f * s, -0.72f * s, sin(a) * 0.02f * s, 0.025f * s, 0.025f * s, 0.025f * s, glow, k.s(), 0f, FLAG_GLOW)
        }
    }
}

/** Buzzing wings for flying insects. */
private fun bugWings(k: BodyKit, s: Float, y: Float, z: Float, col: Int) {
    for (left in booleanArrayOf(true, false)) {
        val sd = if (left) -1f else 1f
        k.part(if (left) PartKind.WING_L else PartKind.WING_R, sd * 0.12f * s, y, z) { m ->
            m.quad(0f, 0f, 0.06f * s, sd * 0.7f * s, 0f, 0.1f * s, sd * 0.75f * s, 0f, -0.12f * s, 0f, 0f, -0.12f * s, col, FLAG_GLOW, 0f, -1f, 0f)
            m.limb(0f, 0.004f, 0.06f * s, sd * 0.7f * s, 0.004f, 0.1f * s, 0.008f * s, 0.004f * s, sh(col, 0.6f), FLAG_SOLID)
        }
    }
}

private fun mon(
    list: ArrayList<Species>, k: BodyKit, name: String, zone: Zone, walk: Float, run: Float,
    legSwing: Float, stride: Float, minS: Float, maxS: Float, herd: Int,
    hp: Int, damage: Float, reach: Float, lvMin: Int, lvMax: Int, growl: Int,
    hover: Float = 0f, bouncy: Boolean = false,
    defense: Float = 0f, ability: Int = Ability.NONE,
) {
    list.add(
        Species(
            name, arrayOf(zone), false, walk, run, false, false, legSwing, stride, minS, maxS, herd, k.parts,
            monster = true, hp = hp, damage = damage, reach = reach, hover = hover, bouncy = bouncy,
            levelMin = lvMin, levelMax = lvMax, growl = growl, defense = defense, ability = ability,
        ),
    )
}

/**
 * Forty monsters, eight in each region, getting tougher the further you go:
 * Greenhollow 1-20, Whisperwood 30-40, Frostpeak 60-70, Sunscar 90-100, Hollow Deep 110-150.
 */
internal fun buildMonsters(): List<Species> {
    val list = ArrayList<Species>()
    val g = Zone.MEADOW
    val f = Zone.FOREST
    val n = Zone.SNOW
    val d = Zone.DESERT
    val c = Zone.CAVES

    // ===== Greenhollow (levels 1-20) =====

    // Thornling: a walking thornbush with red berry eyes.
    run {
        val k = BodyKit()
        brute(k, 0.7f, 0x4E6A2E, 0x5A4228, 0xE0302A, 0x3A2A18, bulk = 1.3f, lump = 0.18f,
            body = { m ->
                for (i in 0 until 14) {
                    val a = i * 2.3f
                    m.spike(sin(a) * 0.2f, 0.95f + (i % 4) * 0.06f, cos(a) * 0.16f, 0.025f, 0.2f, sin(a) * 0.8f, cos(a) * 0.8f, 0x8A6A3A, FLAG_SOLID)
                }
            },
            head = { m -> for (i in 0 until 6) m.spike(sin(i * 1.05f) * 0.07f, 0.2f, cos(i * 1.05f) * 0.06f, 0.015f, 0.12f, sin(i * 1.05f), cos(i * 1.05f) * 0.5f, 0x8A6A3A, FLAG_SOLID) })
        mon(list, k, "Thornling", g, 1.0f, 4.5f, 0.6f, 5f, 0.9f, 1.1f, 2, 3, 5f, 0.6f, 1, 8, 17, defense = 0.0f, ability = Ability.NONE)
    }
    // Mudgrub: a gloopy slime of wet mud.
    run {
        val k = BodyKit()
        slime(k, 0.8f, 0x6A4E32, 0xC89A5A, 0xFFE070)
        mon(list, k, "Mudgrub", g, 1.2f, 3.8f, 0f, 3.5f, 0.8f, 1.2f, 3, 3, 5f, 0.5f, 1, 10, 19, bouncy = true, defense = 0.08f, ability = Ability.NONE)
    }
    // Barkbiter Boar: a boar with tusks of hard bark.
    run {
        val k = BodyKit()
        beast(k, 0.85f, 0x5A3E2A, 0x7A5A40, 0xFF6A2A, 0x2A1E14, long = 0.9f,
            body = { m -> spines(m, 0.85f, 1.05f, -0.3f, 0.45f, 7, 0x3A2A1A, FLAG_FUR) },
            head = { m ->
                m.limb(-0.08f, -0.02f, 0.45f, -0.14f, 0.12f, 0.55f, 0.03f, 0.008f, 0xC8B088, FLAG_SOLID)
                m.limb(0.08f, -0.02f, 0.45f, 0.14f, 0.12f, 0.55f, 0.03f, 0.008f, 0xC8B088, FLAG_SOLID)
            })
        mon(list, k, "Barkbiter Boar", g, 1.4f, 6.5f, 0.6f, 3.4f, 0.9f, 1.15f, 2, 4, 7f, 0.5f, 5, 15, 14, defense = 0.05f, ability = Ability.LUNGE)
    }
    // Goblin Scrapper: a wiry green goblin with a spiked club.
    run {
        val k = BodyKit()
        brute(k, 0.8f, 0x6A9A3A, 0x6A4A2A, 0xFFD040, 0x3A2A1A, bulk = 0.85f, hunch = 0.4f, arms = 1.1f,
            head = { m ->
                m.spike(-0.12f, 0.16f, 0.02f, 0.03f, 0.2f, -1.2f, -0.3f, 0x6A9A3A, FLAG_FUR)
                m.spike(0.12f, 0.16f, 0.02f, 0.03f, 0.2f, 1.2f, -0.3f, 0x6A9A3A, FLAG_FUR)
                m.blob(0f, 0.12f, 0.15f, 0.03f, 0.05f, 0.04f, 0x5A8A30, 950, 0f, FLAG_FUR)
            },
            hand = { m, side, l ->
                if (side > 0f) {
                    m.limb(0.03f, -l - 0.05f, 0.09f, 0.03f, -l + 0.1f, 0.6f, 0.03f, 0.05f, 0x6A4A2A, FLAG_FUR)
                    m.blob(0.03f, -l + 0.12f, 0.62f, 0.09f, 0.09f, 0.11f, 0x5A3E24, 951, 0.1f, FLAG_FUR)
                    for (i in 0 until 5) m.spike(0.03f + sin(i * 1.3f) * 0.07f, -l + 0.14f, 0.62f + cos(i * 1.3f) * 0.08f, 0.012f, 0.08f, sin(i * 1.3f), cos(i * 1.3f), 0x9A9EA6, FLAG_SOLID)
                }
            })
        mon(list, k, "Goblin Scrapper", g, 1.3f, 5.5f, 0.7f, 4.5f, 0.9f, 1.1f, 3, 4, 7f, 0.8f, 6, 16, 15, defense = 0.0f, ability = Ability.PACK)
    }
    // Hivewasp: a giant yellow-and-black wasp that dives at you.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0.15f, 0.14f, 0.13f, 0.18f, 0x2A2418, 960, 0.03f, FLAG_FUR)
            m.blob(0f, -0.05f, -0.3f, 0.17f, 0.16f, 0.3f, 0xE8B82A, 961, 0.03f, FLAG_FUR)
            for (i in 0 until 3) m.blob(0f, -0.05f, -0.18f - i * 0.12f, 0.175f, 0.165f, 0.035f, 0x1A1610, 962 + i, 0f, FLAG_FUR)
            m.spike(0f, -0.12f, -0.6f, 0.03f, -0.2f, 0f, -0.5f, 0x1A1610, FLAG_SOLID)
            for (side in intArrayOf(-1, 1)) for (i in 0 until 3) {
                m.limb(side * 0.08f, -0.08f, 0.2f - i * 0.1f, side * 0.18f, -0.3f, 0.15f - i * 0.12f, 0.015f, 0.01f, 0x1A1610, FLAG_SOLID)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.03f, 0.35f) { m ->
            m.blob(0f, 0f, 0.02f, 0.12f, 0.11f, 0.1f, 0xE8B82A, 966, 0.03f, FLAG_FUR)
            eyes(m, 0.07f, 0.03f, 0.06f, 0.05f, 0xC83A2A)
            m.spike(-0.03f, -0.06f, 0.08f, 0.012f, -0.08f, 0f, 0.4f, 0x1A1610, FLAG_SOLID)
            m.spike(0.03f, -0.06f, 0.08f, 0.012f, -0.08f, 0f, 0.4f, 0x1A1610, FLAG_SOLID)
        }
        bugWings(k, 1f, 0.12f, 0.08f, 0xD8E8F0)
        mon(list, k, "Hivewasp", g, 3f, 7f, 0f, 40f, 0.9f, 1.2f, 2, 3, 6f, 0.6f, 8, 18, 17, hover = 1.4f, defense = 0.0f, ability = Ability.LUNGE)
    }
    // Mossgolem: a squat boulder of a creature, grown over with moss.
    run {
        val k = BodyKit()
        brute(k, 1.25f, 0x7A7A70, 0x6A6A60, 0x9AE870, 0x4A4A44, bulk = 1.4f, arms = 1.15f, lump = 0.22f,
            body = { m ->
                m.blob(0f, 1.95f, 0f, 0.42f, 0.14f, 0.3f, 0x5A8A3A, 970, 0.3f, FLAG_FUR)
                m.blob(0.2f, 1.6f, 0.18f, 0.18f, 0.12f, 0.1f, 0x6A9A40, 971, 0.3f, FLAG_FUR)
            },
            head = { m -> m.blob(0f, 0.26f, 0f, 0.13f, 0.06f, 0.13f, 0x5A8A3A, 972, 0.3f, FLAG_FUR) })
        mon(list, k, "Mossgolem", g, 0.8f, 3.2f, 0.4f, 2.6f, 0.9f, 1.1f, 1, 6, 9f, 0.9f, 12, 20, 16, defense = 0.25f, ability = Ability.NONE)
    }
    // Rootsnake: a serpent of twisted roots.
    run {
        val k = BodyKit()
        serpent(k, 0.9f, 0x6A4A2E, 0x8A6A48, 0x6ACC4A, FLAG_GLOW, 0xB8FF6A,
            head = { m -> for (i in 0 until 4) m.spike(sin(i * 1.6f) * 0.1f, 0.12f, -0.05f + i * 0.06f, 0.015f, 0.14f, sin(i * 1.6f) * 0.6f, -0.4f, 0x5A3E24, FLAG_SOLID) })
        mon(list, k, "Rootsnake", g, 1.2f, 5f, 0f, 3f, 0.9f, 1.2f, 2, 3, 6f, 0.9f, 3, 12, 19, defense = 0.0f, ability = Ability.POISON)
    }
    // Hollowshroom: a mushroom that walks, its red cap spotted white.
    run {
        val k = BodyKit()
        brute(k, 0.75f, 0xE8DCC8, 0xD8CCB4, 0x2A2A2A, 0xB8A890, bulk = 1.2f,
            head = { m ->
                m.blob(0f, 0.3f, 0f, 0.36f, 0.16f, 0.36f, 0xC83A2A, 980, 0.05f, FLAG_FUR)
                m.blob(0f, 0.22f, 0f, 0.32f, 0.05f, 0.32f, 0xE8D8C0, 981, 0f, FLAG_FUR)
                for (i in 0 until 8) {
                    val a = i * 0.785f
                    m.blob(sin(a) * 0.22f, 0.4f, cos(a) * 0.22f, 0.05f, 0.03f, 0.05f, 0xFFF8F0, 982 + i, 0f, FLAG_FUR)
                }
                m.blob(0f, 0.44f, 0f, 0.07f, 0.03f, 0.07f, 0xFFF8F0, 990, 0f, FLAG_FUR)
            })
        mon(list, k, "Hollowshroom", g, 0.9f, 4f, 0.6f, 4.5f, 0.9f, 1.2f, 3, 3, 5f, 0.6f, 1, 12, 17, defense = 0.05f, ability = Ability.REGEN)
    }

    // ===== Whisperwood (levels 30-40) =====

    // Gloomspider: a dark spider with a cluster of glowing blue eyes.
    run {
        val k = BodyKit()
        crawler(k, 1.0f, 0x2A2432, 0x1A1620, 0x5AC8FF, 0x241E2C,
            body = { m -> m.blob(0f, 0.95f, -0.55f, 0.15f, 0.04f, 0.2f, 0x5AC8FF, 1000, 0.1f, FLAG_GLOW) })
        mon(list, k, "Gloomspider", f, 1.5f, 6.5f, 0.55f, 4.5f, 0.9f, 1.25f, 2, 5, 9f, 0.7f, 30, 38, 19, defense = 0.05f, ability = Ability.POISON)
    }
    // Wraithwolf: a ghostly wolf that glows pale blue.
    run {
        val k = BodyKit()
        beast(k, 0.9f, 0x5A7A98, 0x8AA8C0, 0xA8F0FF, 0x3A4A5A, long = 1.05f,
            body = { m -> spines(m, 0.9f, 1.1f, -0.45f, 0.5f, 9, 0x9ADCFF, FLAG_GLOW) },
            head = { m -> m.blob(0f, 0.1f, 0.2f, 0.2f, 0.18f, 0.22f, 0xA8E8FF, 1010, 0.06f, FLAG_GLOW) })
        mon(list, k, "Wraithwolf", f, 1.6f, 7.5f, 0.65f, 3.3f, 0.9f, 1.15f, 3, 5, 10f, 0.6f, 32, 40, 14, defense = 0.05f, ability = Ability.PACK)
    }
    // Bog Hag: a hunched swamp witch with long clawed arms.
    run {
        val k = BodyKit()
        brute(k, 0.95f, 0x7A8A6A, 0x3A4A30, 0xE8FF6A, 0x2A3020, bulk = 0.8f, hunch = 0.9f, arms = 1.35f,
            body = { m -> for (i in 0 until 6) m.limb(-0.2f + i * 0.08f, 1.1f, -0.12f, -0.22f + i * 0.09f, 0.6f, -0.18f, 0.02f, 0.01f, 0x4A5A38, FLAG_FUR) },
            head = { m ->
                m.blob(0f, 0.18f, -0.04f, 0.17f, 0.15f, 0.16f, 0x4A5A38, 1020, 0.2f, FLAG_FUR)
                m.limb(0f, 0.12f, 0.14f, 0f, 0.02f, 0.26f, 0.03f, 0.01f, 0x6A7A5A, FLAG_FUR)
            },
            hand = { m, side, l ->
                for (i in 0 until 3) m.spike(side * 0.04f + (i - 1) * 0.03f, -l - 0.1f, 0.12f, 0.01f, -0.12f, 0f, 0.4f, 0x2A2A20, FLAG_SOLID)
            })
        mon(list, k, "Bog Hag", f, 1.1f, 5f, 0.5f, 3.5f, 0.95f, 1.1f, 1, 6, 11f, 1.0f, 33, 40, 17, defense = 0.1f, ability = Ability.REGEN)
    }
    // Nightwisp: a drifting ball of cold light trailing tendrils.
    run {
        val k = BodyKit()
        floater(k, 0.8f, 0x3A5A8A, 0xBFE8FF, 0xFFFFFF, 5, 0x5A8ACC)
        mon(list, k, "Nightwisp", f, 1.5f, 5.5f, 0f, 2f, 0.8f, 1.1f, 3, 4, 8f, 0.8f, 30, 36, 17, hover = 1.6f, defense = 0.0f, ability = Ability.LUNGE)
    }
    // Rotstag: an undead stag of bone and rot with glowing green antlers.
    run {
        val k = BodyKit()
        beast(k, 1.1f, 0x4A4034, 0xC8BCA0, 0x7CFF6A, 0x1A1610, long = 1.1f,
            body = { m -> for (i in 0 until 5) m.limb(-0.3f, 1.25f - i * 0.02f, -0.3f + i * 0.17f, 0.3f, 1.25f - i * 0.02f, -0.3f + i * 0.17f, 0.025f, 0.025f, 0xD8CCB0, FLAG_SOLID) },
            head = { m ->
                for (side in intArrayOf(-1, 1)) {
                    m.limb(side * 0.07f, 0.22f, 0.1f, side * 0.25f, 0.6f, -0.05f, 0.03f, 0.018f, 0x7CFF6A, FLAG_GLOW)
                    m.limb(side * 0.17f, 0.42f, 0.03f, side * 0.35f, 0.5f, 0.15f, 0.018f, 0.008f, 0x7CFF6A, FLAG_GLOW)
                    m.limb(side * 0.22f, 0.54f, -0.02f, side * 0.18f, 0.75f, -0.1f, 0.016f, 0.006f, 0x7CFF6A, FLAG_GLOW)
                }
            })
        mon(list, k, "Rotstag", f, 1.5f, 7f, 0.6f, 2.6f, 0.95f, 1.15f, 2, 6, 11f, 0.9f, 34, 40, 16, defense = 0.05f, ability = Ability.LUNGE)
    }
    // Shadow Treant: a tall walking tree, black bark and burning eyes.
    run {
        val k = BodyKit()
        brute(k, 1.7f, 0x3A2E24, 0x2E241C, 0xFFB040, 0x1E1812, bulk = 1.1f, arms = 1.3f, lump = 0.15f,
            body = { m -> for (i in 0 until 5) m.limb(sin(i * 1.3f) * 0.3f, 2.2f, cos(i * 1.3f) * 0.2f, sin(i * 1.3f) * 0.7f, 2.9f, cos(i * 1.3f) * 0.4f, 0.06f, 0.02f, 0x3A2E24, FLAG_FUR) },
            head = { m ->
                for (i in 0 until 5) m.blob(sin(i * 1.26f) * 0.25f, 0.45f + (i % 2) * 0.1f, cos(i * 1.26f) * 0.2f, 0.22f, 0.18f, 0.22f, 0x243A2A, 1030 + i, 0.2f, FLAG_LEAF)
            })
        mon(list, k, "Shadow Treant", f, 0.9f, 4f, 0.4f, 1.8f, 0.95f, 1.1f, 1, 7, 13f, 1.4f, 36, 40, 16, defense = 0.3f, ability = Ability.NONE)
    }
    // Venomcoil: a purple serpent banded with glowing poison green.
    run {
        val k = BodyKit()
        serpent(k, 1.1f, 0x5A2A6A, 0x9A7AA8, 0x7CFF4A, FLAG_GLOW, 0x7CFF4A, segs = 10,
            head = { m -> for (side in intArrayOf(-1, 1)) m.blob(side * 0.22f, 0.02f, 0.05f, 0.14f, 0.2f, 0.04f, 0x6A3A7A, 1040, 0f, FLAG_FUR) })
        mon(list, k, "Venomcoil", f, 1.4f, 6f, 0f, 2.6f, 0.9f, 1.2f, 1, 5, 10f, 1.0f, 30, 38, 19, defense = 0.05f, ability = Ability.POISON)
    }
    // Barrow Wight: an armoured skeleton with a rusted blade.
    run {
        val k = BodyKit()
        brute(k, 1.0f, 0xD8CCB0, 0x5A5A60, 0x6AC8FF, 0x3A3A40, bulk = 0.8f, arms = 1.05f,
            body = { m ->
                m.blob(0f, 1.25f, 0.02f, 0.25f, 0.22f, 0.18f, 0x6A6E74, 1050, 0.02f, FLAG_BUCKLE_M)
                for (i in 0 until 4) m.limb(-0.16f, 1.1f + i * 0.08f, 0.17f, 0.16f, 1.1f + i * 0.08f, 0.17f, 0.012f, 0.012f, 0xC8BCA0, FLAG_SOLID)
            },
            head = { m ->
                m.blob(0f, 0.2f, 0f, 0.155f, 0.1f, 0.155f, 0x5A5E66, 1051, 0.02f, FLAG_BUCKLE_M)
                m.spike(0f, 0.28f, -0.02f, 0.03f, 0.16f, 0f, -0.4f, 0x8A2A2A, FLAG_FUR)
            },
            hand = { m, side, l ->
                if (side > 0f) {
                    m.box(0.04f, -l + 0.2f, 0.55f, 0.05f, 0.012f, 0.42f, 0f, 0x7A6A5A, FLAG_BUCKLE_M)
                    m.limb(-0.08f, -l - 0.05f, 0.14f, 0.16f, -l - 0.05f, 0.14f, 0.02f, 0.02f, 0x4A3A2A, FLAG_SOLID)
                }
            })
        mon(list, k, "Barrow Wight", f, 1.2f, 5.5f, 0.6f, 3.5f, 0.95f, 1.1f, 3, 6, 11f, 1.2f, 35, 40, 15, defense = 0.1f, ability = Ability.ENRAGE)
    }

    // ===== Frostpeak Highlands (levels 60-70) =====

    // Frost Yeti: a huge shaggy white ape.
    run {
        val k = BodyKit()
        brute(k, 1.5f, 0xE8ECF2, 0xD8DEE8, 0x6AC8FF, 0x8A94A2, bulk = 1.4f, hunch = 0.5f, arms = 1.3f, lump = 0.14f,
            head = { m ->
                m.blob(0f, 0.08f, 0.13f, 0.1f, 0.07f, 0.06f, 0x8A94A2, 1060, 0f, FLAG_FUR)
                m.spike(-0.05f, 0.02f, 0.18f, 0.012f, 0.06f, 0f, 0f, 0xFFFFFF, FLAG_SOLID)
                m.spike(0.05f, 0.02f, 0.18f, 0.012f, 0.06f, 0f, 0f, 0xFFFFFF, FLAG_SOLID)
            })
        mon(list, k, "Frost Yeti", n, 1.1f, 6f, 0.5f, 2.3f, 0.95f, 1.15f, 1, 8, 12f, 1.3f, 62, 70, 16, defense = 0.15f, ability = Ability.ENRAGE)
    }
    // Icefang Wolf: a white wolf with ice crystals down its spine.
    run {
        val k = BodyKit()
        beast(k, 0.95f, 0xDCE6F0, 0xF4F8FC, 0x6AE0FF, 0x7A8494,
            body = { m -> spines(m, 0.95f, 1.12f, -0.5f, 0.5f, 9, 0x9EDCFF, FLAG_GLOW) },
            head = { m -> m.spike(0f, 0.25f, 0.15f, 0.03f, 0.18f, 0f, -0.5f, 0x9EDCFF, FLAG_GLOW) })
        mon(list, k, "Icefang Wolf", n, 1.7f, 8f, 0.65f, 3.2f, 0.9f, 1.15f, 3, 7, 12f, 0.6f, 60, 68, 14, defense = 0.1f, ability = Ability.PACK)
    }
    // Rime Golem: a body of blue ice around a burning cold core.
    run {
        val k = BodyKit()
        brute(k, 1.6f, 0x9ECCE8, 0x7AAAD0, 0xFFFFFF, 0x5A8AB0, bulk = 1.35f, arms = 1.2f, lump = 0.2f,
            body = { m ->
                m.blob(0f, 2.0f, 0.18f, 0.16f, 0.16f, 0.1f, 0xBFF4FF, 1070, 0.1f, FLAG_GLOW)
                crystals(m, 1.6f, 2.35f, 0.25f, 7, 0xBEF0FF, 0x8ADCFF)
            })
        mon(list, k, "Rime Golem", n, 0.8f, 3.5f, 0.4f, 1.8f, 0.95f, 1.1f, 1, 9, 14f, 1.4f, 64, 70, 16, defense = 0.3f, ability = Ability.NONE)
    }
    // Snow Wyrm: a white serpent with a frill of ice.
    run {
        val k = BodyKit()
        serpent(k, 1.4f, 0xE0EAF4, 0xF6FAFE, 0x9EDCFF, FLAG_GLOW, 0x6AC8FF, segs = 10,
            head = { m -> for (i in 0 until 5) m.spike((i - 2) * 0.08f, 0.12f, -0.05f, 0.02f, 0.2f, (i - 2) * 0.3f, -0.6f, 0xBEF0FF, FLAG_GLOW) })
        mon(list, k, "Snow Wyrm", n, 1.3f, 6f, 0f, 2.2f, 0.9f, 1.2f, 1, 7, 13f, 1.2f, 60, 70, 19, defense = 0.1f, ability = Ability.POISON)
    }
    // Glacier Crab: a big crab with a shell of ice and heavy claws.
    run {
        val k = BodyKit()
        crawler(k, 1.0f, 0x8ABCE0, 0xD8E8F4, 0x2A2A40, 0x6A9AC0, pairs = 3, abdomen = 1.2f,
            head = { m ->
                for (side in intArrayOf(-1, 1)) {
                    m.limb(side * 0.12f, -0.05f, 0.1f, side * 0.35f, 0.05f, 0.45f, 0.06f, 0.05f, 0x6A9AC0, FLAG_FUR)
                    m.blob(side * 0.38f, 0.08f, 0.6f, 0.12f, 0.1f, 0.18f, 0x8ABCE0, 1080, 0.05f, FLAG_FUR)
                    m.spike(side * 0.38f, 0.08f, 0.74f, 0.05f, 0.18f, 0f, 0.8f, 0xBEF0FF, FLAG_GLOW)
                }
            },
            body = { m -> crystals(m, 1f, 0.9f, 0.3f, 6, 0xBEF0FF, 0x9EDCFF) })
        mon(list, k, "Glacier Crab", n, 1.0f, 4f, 0.55f, 4f, 0.9f, 1.2f, 2, 8, 12f, 0.9f, 62, 70, 17, defense = 0.3f, ability = Ability.NONE)
    }
    // Frostwisp: a spinning shard of living ice.
    run {
        val k = BodyKit()
        floater(k, 0.75f, 0xBEE4F8, 0xFFFFFF, 0x6AE0FF, 4, 0x9EDCFF,
            body = { m -> crystals(m, 0.75f, 0.1f, 0.4f, 8, 0xBEF0FF, 0xFFFFFF) })
        mon(list, k, "Frostwisp", n, 1.6f, 6f, 0f, 2.4f, 0.8f, 1.1f, 3, 6, 11f, 0.9f, 60, 66, 17, hover = 1.7f, defense = 0.05f, ability = Ability.LUNGE)
    }
    // Tuskhorn: a woolly mammoth-beast with four great tusks.
    run {
        val k = BodyKit()
        beast(k, 1.6f, 0x6A5444, 0x8A7460, 0xFF9A4A, 0x2A221A, long = 1.0f, tail = true,
            body = { m -> m.blob(0f, 2.05f, 0f, 0.6f, 0.18f, 0.9f, 0xF2F6FA, 1090, 0.2f, FLAG_SNOW) },
            head = { m ->
                for (side in intArrayOf(-1, 1)) {
                    m.limb(side * 0.1f, -0.05f, 0.35f, side * 0.25f, -0.25f, 0.8f, 0.05f, 0.03f, 0xF0E8D8, FLAG_SOLID)
                    m.limb(side * 0.25f, -0.25f, 0.8f, side * 0.2f, 0.05f, 1.05f, 0.03f, 0.01f, 0xF0E8D8, FLAG_SOLID)
                }
                m.limb(0f, -0.02f, 0.5f, 0f, -0.5f, 0.7f, 0.08f, 0.04f, 0x6A5444, FLAG_FUR)
            })
        mon(list, k, "Tuskhorn", n, 1.0f, 5f, 0.4f, 1.8f, 0.95f, 1.1f, 1, 9, 15f, 1.2f, 65, 70, 18, defense = 0.15f, ability = Ability.LUNGE)
    }
    // Ice Troll: a blue-grey troll carrying a club of solid ice.
    run {
        val k = BodyKit()
        brute(k, 1.45f, 0x7A8CA0, 0x5A5046, 0xFFE070, 0x4A5260, bulk = 1.25f, hunch = 0.6f, arms = 1.25f,
            head = { m ->
                m.blob(0f, 0.1f, 0.14f, 0.07f, 0.1f, 0.06f, 0x6A7C90, 1100, 0f, FLAG_FUR)
                m.spike(-0.06f, 0.0f, 0.16f, 0.02f, 0.1f, 0f, 0.2f, 0xE8E0C8, FLAG_SOLID)
                m.spike(0.06f, 0.0f, 0.16f, 0.02f, 0.1f, 0f, 0.2f, 0xE8E0C8, FLAG_SOLID)
            },
            hand = { m, side, l ->
                if (side > 0f) {
                    m.limb(0.04f, -l - 0.05f, 0.09f, 0.04f, -l + 0.2f, 0.9f, 0.05f, 0.14f, 0x9EDCFF, FLAG_GLOW)
                }
            })
        mon(list, k, "Ice Troll", n, 1.1f, 5.5f, 0.5f, 2.4f, 0.95f, 1.1f, 2, 8, 14f, 1.5f, 63, 70, 15, defense = 0.15f, ability = Ability.REGEN)
    }

    // ===== Sunscar Dunes (levels 90-100) =====

    // Dunestinger: a giant scorpion with a glowing sting.
    run {
        val k = BodyKit()
        crawler(k, 1.1f, 0x8A5A2A, 0xB88A4A, 0xFF4A2A, 0x6A4220, pairs = 4, abdomen = 0.9f,
            head = { m ->
                for (side in intArrayOf(-1, 1)) {
                    m.limb(side * 0.1f, -0.03f, 0.1f, side * 0.3f, 0.02f, 0.4f, 0.05f, 0.04f, 0x6A4220, FLAG_FUR)
                    m.blob(side * 0.33f, 0.03f, 0.52f, 0.1f, 0.07f, 0.14f, 0x8A5A2A, 1110, 0.05f, FLAG_FUR)
                }
            })
        var parent: CreaturePart? = null
        for (i in 0 until 6) {
            parent = k.part(PartKind.SEGMENT, 0f, if (i == 0) 0.8f else 0.12f, if (i == 0) -0.9f else -0.14f, i * 0.5f, parent) { m ->
                m.blob(0f, 0.06f, -0.07f, 0.1f - i * 0.008f, 0.09f - i * 0.008f, 0.1f, 0x8A5A2A, 1111 + i, 0.03f, FLAG_FUR)
                if (i == 5) m.spike(0f, 0.1f, -0.1f, 0.05f, 0.28f, 0f, 1.1f, 0xFF7A2A, FLAG_GLOW)
            }
        }
        mon(list, k, "Dunestinger", d, 1.4f, 6f, 0.55f, 4f, 0.9f, 1.2f, 1, 9, 14f, 1.1f, 90, 98, 19, defense = 0.1f, ability = Ability.POISON)
    }
    // Bone Jackal: a skeletal desert dog with burning eyes.
    run {
        val k = BodyKit()
        beast(k, 0.85f, 0xD8C8A8, 0x8A7A60, 0xFF6A2A, 0x5A4A38, long = 1.05f,
            body = { m -> for (i in 0 until 6) m.limb(-0.28f, 0.95f, -0.35f + i * 0.14f, 0.28f, 0.95f, -0.35f + i * 0.14f, 0.022f, 0.022f, 0xE8DCC0, FLAG_SOLID) })
        mon(list, k, "Bone Jackal", d, 1.8f, 8.5f, 0.7f, 3.6f, 0.9f, 1.1f, 3, 8, 13f, 0.6f, 90, 97, 14, defense = 0.05f, ability = Ability.PACK)
    }
    // Mummy Warden: a tomb guardian wrapped in old linen.
    run {
        val k = BodyKit()
        brute(k, 1.05f, 0xC8B890, 0xB8A880, 0x6AFFB8, 0x7A6A50, bulk = 0.95f, hunch = 0.2f, arms = 1.1f,
            body = { m -> for (i in 0 until 7) m.blob(0f, 1.0f + i * 0.1f, 0f, 0.28f, 0.03f, 0.2f, sh(0xC8B890, 0.85f + (i % 2) * 0.12f), 1120 + i, 0.1f, FLAG_FUR) },
            head = { m -> for (i in 0 until 3) m.blob(0f, 0.08f + i * 0.07f, 0.02f, 0.15f, 0.025f, 0.15f, 0xB0A078, 1130 + i, 0.1f, FLAG_FUR) },
            hand = { m, side, _ -> m.limb(side * 0.04f, -0.3f, 0.05f, side * 0.1f, -0.9f, 0.02f, 0.02f, 0.008f, 0xB8A880, FLAG_FUR) })
        mon(list, k, "Mummy Warden", d, 0.9f, 4.5f, 0.5f, 3f, 0.95f, 1.1f, 2, 10, 14f, 1.0f, 92, 100, 16, defense = 0.3f, ability = Ability.NONE)
    }
    // Duneworm: a huge worm that bursts up out of the sand.
    run {
        val k = BodyKit()
        serpent(k, 2.0f, 0xB8905A, 0xD8B88A, 0x8A6A40, FLAG_FUR, 0xFF5A2A, segs = 10,
            head = { m ->
                for (i in 0 until 8) {
                    val a = i * 0.785f
                    m.spike(sin(a) * 0.3f, cos(a) * 0.2f, 0.6f, 0.03f, 0.18f, sin(a) * 0.3f, 0.9f, 0xE8E0C8, FLAG_SOLID)
                }
                m.blob(0f, 0f, 0.55f, 0.28f, 0.2f, 0.06f, 0x5A1A14, 1140, 0f, FLAG_SOLID)
            })
        mon(list, k, "Duneworm", d, 1.2f, 6f, 0f, 1.6f, 0.9f, 1.15f, 1, 12, 17f, 1.6f, 94, 100, 18, defense = 0.15f, ability = Ability.LUNGE)
    }
    // Cinder Imp: a small fiery devil that floats on burning wings.
    run {
        val k = BodyKit()
        floater(k, 0.55f, 0xC83A1E, 0xFFB040, 0xFFE070, 0, 0xC83A1E,
            head = { m -> horns(m, 0.7f, 0.12f, 0.05f, 0x2A1A14, 0.8f, 0.8f) },
            body = { m -> m.limb(0f, -0.2f, -0.2f, 0f, -0.45f, -0.55f, 0.04f, 0.01f, 0xC83A1E, FLAG_FUR) })
        bugWings(k, 0.8f, 0.12f, -0.05f, 0xFF7A2A)
        mon(list, k, "Cinder Imp", d, 2f, 7f, 0f, 30f, 0.9f, 1.1f, 3, 7, 12f, 0.8f, 90, 96, 17, hover = 1.8f, defense = 0.05f, ability = Ability.LUNGE)
    }
    // Sun Basilisk: a lizard with a blazing frill.
    run {
        val k = BodyKit()
        beast(k, 1.0f, 0x9A7A3A, 0xC8B070, 0xFFD040, 0x5A4420, long = 1.25f,
            body = { m -> spines(m, 1.0f, 1.08f, -0.6f, 0.5f, 9, 0xFF9A2A, FLAG_GLOW) },
            head = { m ->
                for (i in 0 until 7) {
                    val a = -1.2f + i * 0.4f
                    m.spike(sin(a) * 0.12f, 0.1f + cos(a) * 0.05f, 0.05f, 0.03f, 0.3f, sin(a) * 1.2f, -0.3f, if (i % 2 == 0) 0xFFB040 else 0xFF6A2A, FLAG_GLOW)
                }
            })
        mon(list, k, "Sun Basilisk", d, 1.3f, 6.5f, 0.7f, 3.2f, 0.95f, 1.2f, 2, 10, 15f, 0.9f, 93, 100, 19, defense = 0.15f, ability = Ability.ENRAGE)
    }
    // Sand Golem: a hulking giant of packed sand and old stone.
    run {
        val k = BodyKit()
        brute(k, 1.8f, 0xC8A870, 0xB8985E, 0xFF8A2A, 0x8A7048, bulk = 1.4f, arms = 1.2f, lump = 0.25f,
            body = { m -> for (i in 0 until 5) m.blob(sin(i * 1.3f) * 0.35f, 2.2f + (i % 2) * 0.2f, cos(i * 1.3f) * 0.2f, 0.18f, 0.14f, 0.16f, 0x9A8A70, 1150 + i, 0.3f, FLAG_FUR) })
        mon(list, k, "Sand Golem", d, 0.8f, 3.5f, 0.4f, 1.6f, 0.95f, 1.1f, 1, 12, 18f, 1.6f, 95, 100, 16, defense = 0.35f, ability = Ability.NONE)
    }
    // Scarab Titan: a giant beetle with a shining gold shell.
    run {
        val k = BodyKit()
        crawler(k, 1.1f, 0x2A6A5A, 0x1A2A24, 0xFFD040, 0x1A2A24, pairs = 3, abdomen = 1.25f,
            body = { m ->
                m.blob(0f, 1.0f, -0.5f, 0.46f, 0.3f, 0.55f, 0xC8A040, 1160, 0.02f, FLAG_BUCKLE_M)
                m.blob(0f, 1.05f, -0.5f, 0.02f, 0.31f, 0.56f, 0x1A1A10, 1161, 0f, FLAG_SOLID)
            },
            head = { m -> m.limb(0f, 0.05f, 0.15f, 0f, 0.35f, 0.4f, 0.05f, 0.01f, 0x1A2A24, FLAG_SOLID) })
        mon(list, k, "Scarab Titan", d, 1.0f, 4.5f, 0.55f, 4f, 0.9f, 1.2f, 1, 11, 16f, 1.0f, 91, 100, 17, defense = 0.2f, ability = Ability.REGEN)
    }

    // ===== The Hollow Deep (levels 110-150) =====

    // Void Stalker: a tall, lean thing of shadow with violet eyes.
    run {
        val k = BodyKit()
        brute(k, 1.6f, 0x241C30, 0x1A1424, 0xC08AFF, 0x120E18, bulk = 0.7f, hunch = 0.5f, arms = 1.5f,
            body = { m -> spines(m, 1.4f, 2.1f, -0.2f, 0.2f, 5, 0xB070FF, FLAG_GLOW) },
            hand = { m, side, l -> for (i in 0 until 3) m.spike(side * 0.04f + (i - 1) * 0.04f, -l - 0.1f, 0.12f, 0.012f, -0.25f, 0f, 0.3f, 0xB070FF, FLAG_GLOW) })
        mon(list, k, "Void Stalker", c, 1.5f, 7.5f, 0.6f, 2.4f, 0.95f, 1.1f, 2, 12, 16f, 1.4f, 110, 125, 15, defense = 0.15f, ability = Ability.PACK)
    }
    // Crystal Golem: a giant grown from purple crystal.
    run {
        val k = BodyKit()
        brute(k, 1.9f, 0x4A3A5E, 0x3A2E4A, 0xE8D0FF, 0x2A2236, bulk = 1.35f, arms = 1.2f, lump = 0.2f,
            body = { m -> crystals(m, 1.9f, 2.45f, 0.3f, 9, 0xC8A0FF, 0x8ADCFF) },
            head = { m -> crystals(m, 1.0f, 0.25f, 0.1f, 4, 0xC8A0FF, 0xE8D0FF) })
        mon(list, k, "Crystal Golem", c, 0.8f, 3.8f, 0.4f, 1.6f, 0.95f, 1.1f, 1, 14, 20f, 1.7f, 115, 135, 16, defense = 0.4f, ability = Ability.NONE)
    }
    // Abyss Eye: a floating eye the size of a boulder, trailing tentacles.
    run {
        val k = BodyKit()
        floater(k, 1.2f, 0x3A2A4A, 0x9A5AFF, 0xFF4A6A, 7, 0x4A3A5E,
            head = { m ->
                m.blob(0f, 0.02f, 0.18f, 0.34f, 0.34f, 0.2f, 0xF0E8E0, 1170, 0f, FLAG_SOLID)
                m.blob(0f, 0.02f, 0.36f, 0.16f, 0.16f, 0.05f, 0xC83A5A, 1171, 0f, FLAG_GLOW)
                m.blob(0f, 0.02f, 0.4f, 0.07f, 0.07f, 0.02f, 0x100808, 1172, 0f, FLAG_SOLID)
            })
        mon(list, k, "Abyss Eye", c, 1.2f, 5f, 0f, 1.8f, 0.9f, 1.15f, 1, 12, 17f, 1.3f, 110, 130, 18, hover = 2.0f, defense = 0.1f, ability = Ability.POISON)
    }
    // Deep Crawler: a spider as big as a cart, glowing violet underneath.
    run {
        val k = BodyKit()
        crawler(k, 1.5f, 0x1E1828, 0x9A5AFF, 0xFF4AE0, 0x1A1422, pairs = 4, abdomen = 1.1f,
            body = { m -> spines(m, 1.5f, 1.3f, -1.0f, -0.2f, 6, 0xB070FF, FLAG_GLOW) })
        mon(list, k, "Deep Crawler", c, 1.4f, 7f, 0.55f, 3.5f, 0.9f, 1.2f, 2, 13, 18f, 1.1f, 112, 128, 19, defense = 0.15f, ability = Ability.LUNGE)
    }
    // Shade Serpent: a serpent of living darkness with violet bands.
    run {
        val k = BodyKit()
        serpent(k, 1.6f, 0x1E1628, 0x3A2E4A, 0xB070FF, FLAG_GLOW, 0xD8A0FF, segs = 11,
            head = { m -> horns(m, 1.0f, 0.12f, 0.0f, 0x2A2236, 1.2f, 1.2f) })
        mon(list, k, "Shade Serpent", c, 1.4f, 7f, 0f, 2f, 0.9f, 1.2f, 1, 12, 18f, 1.4f, 115, 135, 19, defense = 0.15f, ability = Ability.POISON)
    }
    // Lurker Horror: a many-eyed beast that stalks the caverns.
    run {
        val k = BodyKit()
        beast(k, 1.3f, 0x2A2236, 0x4A3A5E, 0xFF4A8A, 0x120E18, long = 1.1f,
            body = { m ->
                for (i in 0 until 8) m.blob(sin(i * 1.7f) * 0.3f, 1.45f + (i % 3) * 0.08f, -0.4f + i * 0.12f, 0.05f, 0.05f, 0.05f, 0xFF4A8A, 1180 + i, 0f, FLAG_GLOW)
            },
            head = { m ->
                for (i in 0 until 4) m.blob((i - 1.5f) * 0.08f, 0.24f, 0.3f, 0.03f, 0.03f, 0.03f, 0xFF4A8A, 1190 + i, 0f, FLAG_GLOW)
                horns(m, 1.3f, 0.2f, 0.1f, 0x3A2E4A)
            })
        mon(list, k, "Lurker Horror", c, 1.3f, 7f, 0.6f, 2.6f, 0.95f, 1.15f, 1, 14, 20f, 1.1f, 120, 140, 16, defense = 0.2f, ability = Ability.ENRAGE)
    }
    // Soulwraith: a hooded spirit in tattered robes, with clawed hands.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.limb(0f, 0.5f, 0f, 0f, -0.9f, 0f, 0.22f, 0.45f, 0x1E1A28, FLAG_FUR)
            for (i in 0 until 8) {
                val a = i * 0.785f
                m.limb(sin(a) * 0.4f, -0.8f, cos(a) * 0.4f, sin(a) * 0.45f, -1.25f, cos(a) * 0.45f, 0.06f, 0.01f, 0x2A2436, FLAG_FUR)
            }
            m.blob(0f, 0.1f, 0.1f, 0.12f, 0.12f, 0.06f, 0x9A5AFF, 1200, 0f, FLAG_GLOW)
        }
        k.part(PartKind.HEAD, 0f, 0.55f, 0f) { m ->
            m.blob(0f, 0.12f, -0.02f, 0.2f, 0.24f, 0.22f, 0x2A2436, 1201, 0.05f, FLAG_FUR)
            m.blob(0f, 0.1f, 0.08f, 0.14f, 0.16f, 0.14f, 0x08060C, 1202, 0f, FLAG_SOLID)
            eyes(m, 0.05f, 0.12f, 0.18f, 0.025f, 0xB8FFFF)
        }
        for (side in intArrayOf(-1, 1)) {
            val sd = side.toFloat()
            k.part(PartKind.ARM, sd * 0.3f, 0.4f, 0.05f, if (side < 0) 0f else MPI) { m ->
                m.limb(0f, 0f, 0f, sd * 0.05f, -0.6f, 0.1f, 0.08f, 0.1f, 0x1E1A28, FLAG_FUR)
                m.limb(sd * 0.05f, -0.6f, 0.1f, sd * 0.05f, -0.85f, 0.18f, 0.03f, 0.02f, 0xB8B0C8, FLAG_FUR)
                for (i in 0 until 3) m.spike(sd * 0.05f + (i - 1) * 0.03f, -0.85f, 0.2f, 0.01f, -0.18f, 0f, 0.4f, 0xB8B0C8, FLAG_SOLID)
            }
        }
        mon(list, k, "Soulwraith", c, 1.3f, 6.5f, 0.5f, 2f, 0.95f, 1.1f, 2, 13, 19f, 1.3f, 125, 145, 17, hover = 1.3f, defense = 0.2f, ability = Ability.REGEN)
    }
    // Hollow Titan: the giant that rules the deep. Slow, and devastating.
    run {
        val k = BodyKit()
        brute(k, 3.2f, 0x3A3044, 0x2A2236, 0xFF4A4A, 0x1A1422, bulk = 1.3f, hunch = 0.4f, arms = 1.2f, lump = 0.18f,
            body = { m ->
                crystals(m, 3.2f, 4.6f, 0.3f, 8, 0xB070FF, 0xFF6A8A)
                m.blob(0f, 4.0f, 0.55f, 0.3f, 0.3f, 0.12f, 0xFF4A6A, 1210, 0.1f, FLAG_GLOW)
            },
            head = { m -> horns(m, 3.2f, 0.35f, 0.05f, 0x1A1422, 1.3f, 1.2f) })
        mon(list, k, "Hollow Titan", c, 0.9f, 3.8f, 0.35f, 0.9f, 1f, 1f, 1, 30, 25f, 2.5f, 140, 150, 18, defense = 0.3f, ability = Ability.ENRAGE)
    }
    return list
}

/** Like [mon], but for a monster that only ever appears inside the Grain Rot Dimension: fixed at
 *  level 150, tagged [Species.grainOnly] so the outdoor spawner never picks it. */
private fun monGrain(
    list: ArrayList<Species>, k: BodyKit, name: String, walk: Float, run: Float,
    legSwing: Float, stride: Float, minS: Float, maxS: Float, herd: Int,
    hp: Int, damage: Float, reach: Float, growl: Int,
    hover: Float = 0f, bouncy: Boolean = false,
    defense: Float = 0f, ability: Int = Ability.NONE,
) {
    list.add(
        Species(
            name, arrayOf(Zone.CAVES), false, walk, run, false, false, legSwing, stride, minS, maxS, herd, k.parts,
            monster = true, hp = hp, damage = damage, reach = reach, hover = hover, bouncy = bouncy,
            levelMin = 150, levelMax = 150, growl = growl, defense = defense, ability = ability,
            grainOnly = true,
        ),
    )
}

/**
 * The four monsters that roam the Grain Rot Dimension's arrival platform, levels fixed at
 * 150. They carry [Zone.CAVES] purely so tier/loot lookups that key off a monster's zone
 * still work (the dimension shares The Hollow Deep's top loot tier) — [Species.grainOnly]
 * is what actually keeps them out of the outdoor world.
 */
internal fun buildGrainMonsters(): List<Species> {
    val list = ArrayList<Species>()
    val rot = 0x6B8E23
    val rotDark = 0x3A3A28
    val spore = 0x9ACD32
    val glow = 0xB6FF4A

    // Sporeling: a small swarming puffball that bursts in a cloud of spores when it strikes.
    run {
        val k = BodyKit()
        slime(k, 0.6f, rot, glow, 0xD8FF8A) { m ->
            for (i in 0 until 5) {
                val a = i * 1.3f
                m.spike(sin(a) * 0.3f, 0.55f, cos(a) * 0.3f, 0.04f, 0.14f, 0f, -0.3f, spore, FLAG_GLOW)
            }
        }
        monGrain(list, k, "Sporeling", 1.6f, 6.5f, 0f, 1.6f, 0.6f, 0.85f, 4, 5, 9f, 1.1f, 17, bouncy = true, ability = Ability.POISON)
    }
    // Husk Reaper: a rotted farmhand, gaunt and slow, with a long bone scythe.
    run {
        val k = BodyKit()
        brute(
            k, 1.7f, rotDark, 0x2A2418, spore, 0x1A1610, bulk = 0.75f, hunch = 0.3f, arms = 1.3f, lump = 0.12f,
            body = { m -> spines(m, 1.5f, 2.0f, -0.3f, 0.3f, 5, rot, FLAG_GLOW) },
            head = { m -> horns(m, 0.6f, 0.18f, 0.02f, 0x2A2418, 0.6f, 0.6f) },
            hand = { m, side, l -> m.spike(side * 0.05f, -l - 0.15f, 0.15f, 0.03f, 0.55f, side * 0.15f, 0.4f, 0xC8C8A0, FLAG_SOLID) },
        )
        monGrain(list, k, "Husk Reaper", 1.0f, 4.5f, 0.5f, 1.8f, 0.95f, 1.15f, 1, 18, 20f, 2.2f, 18, defense = 0.15f)
    }
    // Mire Shambler: a slow, hulking tank that leaves ooze wherever it drags itself.
    run {
        val k = BodyKit()
        brute(
            k, 2.0f, rotDark, 0x1E1E14, 0x7A8A3A, 0x14140E, bulk = 1.5f, hunch = 0.5f, arms = 1.0f, lump = 0.3f,
            body = { m ->
                for (i in 0 until 6) {
                    val a = i * 1.9f
                    m.blob(sin(a) * 0.3f, 1.6f + (i % 2) * 0.15f, cos(a) * 0.2f, 0.14f, 0.11f, 0.13f, 0x4A5A2A, 1400 + i, 0.2f, FLAG_FUR)
                }
            },
        )
        monGrain(list, k, "Mire Shambler", 0.6f, 2.2f, 0.3f, 1.2f, 1.0f, 1.2f, 1, 24, 15f, 1.7f, 17, defense = 0.35f, ability = Ability.REGEN)
    }
    // Fungal Weaver: a many-legged caster crowned with a fungal cap, lobbing spore clouds from range.
    run {
        val k = BodyKit()
        crawler(
            k, 1.1f, 0x4A5A2A, 0x2A3A1A, glow, 0x1A2410, pairs = 4, abdomen = 1.2f,
            body = { m ->
                m.blob(0f, 1.15f, -0.4f, 0.4f, 0.28f, 0.42f, rot, 1410, 0.05f, FLAG_FUR)
                for (i in 0 until 5) {
                    val a = i * 1.4f
                    m.spike(sin(a) * 0.25f, 1.35f, -0.4f + cos(a) * 0.2f, 0.05f, 0.16f, 0f, -0.3f, spore, FLAG_GLOW)
                }
            },
        )
        monGrain(list, k, "Fungal Weaver", 0.9f, 5f, 0.6f, 3.5f, 0.9f, 1.15f, 1, 13, 13f, 3.2f, 19, defense = 0.1f, ability = Ability.POISON)
    }
    return list
}

/** Metal armour and shells, lit like brushed steel. */
private const val FLAG_BUCKLE_M = 254


private fun monCave(
    list: ArrayList<Species>, k: BodyKit, name: String, walk: Float, run: Float,
    legSwing: Float, stride: Float, minS: Float, maxS: Float,
    hp: Int, damage: Float, reach: Float, growl: Int, defense: Float = 0f,
) {
    list.add(
        Species(
            name, arrayOf(Zone.MEADOW), false, walk, run, false, false, legSwing, stride, minS, maxS, 1, k.parts,
            monster = true, hp = hp, damage = damage, reach = reach,
            levelMin = 1, levelMax = 1, growl = growl, defense = defense, ability = Ability.NONE,
            caveOnly = true,
        ),
    )
}

/**
 * The two guards that stand watch in every cave: the Treasure Goblin (a sharp-eyed goblin with a
 * sack of loot on its back) and the Bone Guard (an armoured skeleton with sword and shield). Their
 * levels are set by the cave they guard, and [Species.caveOnly] keeps them out of the open world.
 */
internal fun buildCaveMonsters(): List<Species> {
    val list = ArrayList<Species>()

    // Treasure Goblin: wiry, gold-toothed, a bulging sack of coins on its back and a knife in hand.
    run {
        val k = BodyKit()
        brute(k, 0.85f, 0x7AA83A, 0x8A5A2A, 0xFFE040, 0x3A2A1A, bulk = 0.9f, hunch = 0.5f, arms = 1.1f,
            body = { m ->
                m.blob(0f, 1.05f, -0.28f, 0.2f, 0.22f, 0.17f, 0xB8923E, 1910, 0.12f, FLAG_FUR)
                m.blob(0.06f, 1.2f, -0.3f, 0.06f, 0.05f, 0.05f, 0xFFD24A, 1911, 0f, FLAG_GLOW)
            },
            head = { m ->
                m.spike(-0.12f, 0.16f, 0.02f, 0.03f, 0.2f, -1.2f, -0.3f, 0x7AA83A, FLAG_FUR)
                m.spike(0.12f, 0.16f, 0.02f, 0.03f, 0.2f, 1.2f, -0.3f, 0x7AA83A, FLAG_FUR)
                m.blob(0f, 0.12f, 0.15f, 0.03f, 0.05f, 0.04f, 0x6A9A30, 1912, 0f, FLAG_FUR)
                m.blob(0.02f, 0.04f, 0.15f, 0.012f, 0.014f, 0.01f, 0xFFD24A, 1913, 0f, FLAG_GLOW)
            },
            hand = { m, side, l ->
                if (side > 0f) {
                    m.limb(0.03f, -l - 0.05f, 0.09f, 0.03f, -l + 0.1f, 0.55f, 0.03f, 0.018f, 0xB8BEC6, FLAG_SOLID)
                    m.blob(0.03f, -l - 0.02f, 0.12f, 0.04f, 0.04f, 0.04f, 0x5A3E24, 1914, 0.05f, FLAG_FUR)
                }
            })
        monCave(list, k, "Treasure Goblin", 1.4f, 5.8f, 0.7f, 4.5f, 1.0f, 1.15f, 5, 8f, 0.8f, 15)
    }
    // Bone Guard: an armoured skeleton with a rusted sword and a round wooden shield.
    run {
        val k = BodyKit()
        brute(k, 1.05f, 0xE8E0C8, 0x5A5A60, 0xFF7A3A, 0x3A3A40, bulk = 0.8f, arms = 1.05f,
            body = { m ->
                m.blob(0f, 1.3f, 0.02f, 0.25f, 0.22f, 0.18f, 0x6A6E74, 1920, 0.02f, FLAG_BUCKLE_M)
                for (i in 0 until 4) m.limb(-0.16f, 1.12f + i * 0.08f, 0.17f, 0.16f, 1.12f + i * 0.08f, 0.17f, 0.012f, 0.012f, 0xD8D0B8, FLAG_SOLID)
            },
            head = { m ->
                m.blob(0f, 0.2f, 0f, 0.155f, 0.1f, 0.155f, 0x5A5E66, 1921, 0.02f, FLAG_BUCKLE_M)
                m.spike(0f, 0.28f, -0.02f, 0.03f, 0.16f, 0f, -0.4f, 0x8A2A2A, FLAG_FUR)
            },
            hand = { m, side, l ->
                if (side > 0f) {
                    m.box(0.04f, -l + 0.2f, 0.55f, 0.05f, 0.012f, 0.42f, 0f, 0x8A8A80, FLAG_BUCKLE_M)
                    m.limb(-0.08f, -l - 0.05f, 0.14f, 0.16f, -l - 0.05f, 0.14f, 0.02f, 0.02f, 0x4A3A2A, FLAG_SOLID)
                } else {
                    m.blob(-0.06f, -l + 0.02f, 0.16f, 0.03f, 0.24f, 0.24f, 0x6A4A2A, 1922, 0.04f, FLAG_FUR)
                    m.blob(-0.09f, -l + 0.02f, 0.16f, 0.015f, 0.06f, 0.06f, 0x9AA0A8, 1923, 0f, FLAG_BUCKLE_M)
                }
            })
        monCave(list, k, "Bone Guard", 1.2f, 4.6f, 0.6f, 3.5f, 1.1f, 1.25f, 7, 10f, 1.3f, 15, defense = 0.1f)
    }
    return list
}
