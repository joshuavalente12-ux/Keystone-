package com.keystone.rpg

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.games.PlayGames
import com.google.android.gms.games.SnapshotsClient
import com.google.android.gms.games.snapshot.SnapshotMetadataChange
import org.json.JSONArray
import org.json.JSONObject

/**
 * Google Play Games Services: automatic sign-in on launch, a manual "Sign in" retry, and
 * cloud copies of your save. Everything here is optional: if sign-in fails or is declined,
 * the game plays exactly the same as a guest with the save kept on the phone.
 */
object PlayGamesManager {
    enum class Status { CHECKING, SIGNED_IN, SIGNED_OUT }

    /** Where sign-in stands. The title screen watches this. */
    var status by mutableStateOf(Status.CHECKING)
        private set

    /** The signed-in player's display name, or empty. */
    var playerName by mutableStateOf("")
        private set

    private const val SLOT = "keystone_main"
    private const val PREFS = "keystone_save"

    /** Play Games signs the player in by itself at launch; this reads the result of that attempt. */
    fun check(activity: Activity) {
        status = Status.CHECKING
        try {
            PlayGames.getGamesSignInClient(activity).isAuthenticated().addOnCompleteListener { t ->
                val ok = t.isSuccessful && t.result.isAuthenticated()
                status = if (ok) Status.SIGNED_IN else Status.SIGNED_OUT
                if (ok) loadName(activity) else playerName = ""
            }
        } catch (e: Exception) {
            // Missing Play services, bad project ID, and so on: carry on as a guest.
            status = Status.SIGNED_OUT
        }
    }

    /** The "Sign in" button: asks the player to sign in if the automatic attempt didn't. */
    fun signIn(activity: Activity) {
        try {
            PlayGames.getGamesSignInClient(activity).signIn().addOnCompleteListener { check(activity) }
        } catch (e: Exception) {
            status = Status.SIGNED_OUT
        }
    }

    private fun loadName(activity: Activity) {
        try {
            PlayGames.getPlayersClient(activity).getCurrentPlayer().addOnCompleteListener { t ->
                playerName = if (t.isSuccessful) t.result.getDisplayName() ?: "" else ""
            }
        } catch (e: Exception) {
            playerName = ""
        }
    }

    /** Copies your local save up to your Google account. [done] gets (worked, message). */
    fun saveToCloud(activity: Activity, done: (Boolean, String) -> Unit) {
        if (status != Status.SIGNED_IN) {
            done(false, "Sign in to Google Play Games to save to the cloud.")
            return
        }
        val bytes = exportSave(activity).toByteArray(Charsets.UTF_8)
        val snaps = PlayGames.getSnapshotsClient(activity)
        snaps.open(SLOT, true, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED).addOnCompleteListener { t ->
            val snap = if (t.isSuccessful && !t.result.isConflict()) t.result.getData() else null
            if (snap == null) {
                done(false, "Couldn't reach your cloud save. Try again.")
                return@addOnCompleteListener
            }
            snap.getSnapshotContents().writeBytes(bytes)
            val meta = SnapshotMetadataChange.Builder().setDescription("Keystone save").build()
            snaps.commitAndClose(snap, meta).addOnCompleteListener { c ->
                if (c.isSuccessful) done(true, "Saved to the cloud.") else done(false, "The cloud save failed. Try again.")
            }
        }
    }

    private var lastAuto = 0L
    private var uploading = false

    /**
     * Quietly copies your save to the cloud while you play, if you're signed in. Called every couple of
     * minutes and whenever the app goes to the background. [force] skips the wait between uploads
     * (but never runs two at once). Guests, and saves with nothing in them yet, are left alone.
     */
    fun autoSave(activity: Activity, force: Boolean = false) {
        if (status != Status.SIGNED_IN || uploading) return
        val now = System.currentTimeMillis()
        if (now - lastAuto < (if (force) 15_000L else 110_000L)) return
        if (activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("weapon", "").isNullOrEmpty()) return
        uploading = true
        lastAuto = now
        saveToCloud(activity) { _, _ -> uploading = false }
    }

    /** Replaces your local save with the one in your Google account. */
    fun loadFromCloud(activity: Activity, done: (Boolean, String) -> Unit) {
        if (status != Status.SIGNED_IN) {
            done(false, "Sign in to Google Play Games to load from the cloud.")
            return
        }
        val snaps = PlayGames.getSnapshotsClient(activity)
        snaps.open(SLOT, false, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED).addOnCompleteListener { t ->
            val snap = if (t.isSuccessful && !t.result.isConflict()) t.result.getData() else null
            if (snap == null) {
                done(false, "No cloud save found.")
                return@addOnCompleteListener
            }
            val ok = try {
                importSave(activity, String(snap.getSnapshotContents().readFully(), Charsets.UTF_8))
                true
            } catch (e: Exception) {
                false
            }
            snaps.discardAndClose(snap)
            done(ok, if (ok) "Cloud save loaded." else "That cloud save couldn't be read.")
        }
    }

    // ---------- The local save, as text ----------

    private fun exportSave(ctx: Context): String {
        val out = JSONObject()
        for ((k, v) in ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all) {
            val e = JSONObject()
            when (v) {
                is String -> e.put("t", "s").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is Boolean -> e.put("t", "b").put("v", v)
                is Set<*> -> e.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            out.put(k, e)
        }
        return out.toString()
    }

    private fun importSave(ctx: Context, text: String) {
        val json = JSONObject(text)
        val ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear()
        for (k in json.keys()) {
            val e = json.getJSONObject(k)
            when (e.getString("t")) {
                "s" -> ed.putString(k, e.getString("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "ss" -> {
                    val a = e.getJSONArray("v")
                    ed.putStringSet(k, HashSet<String>().also { s -> for (i in 0 until a.length()) s.add(a.getString(i)) })
                }
            }
        }
        ed.commit()
    }

    /** New game: forgets the local save (sound and button layout settings stay). */
    fun wipeLocalSave(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
    }
}
