package com.keystone.rpg

import kotlin.math.cos
import kotlin.math.sin

/**
 * The Grain Rot's castle: pale stone, tall round towers under grey slate cones, and a great keep
 * at the back. Built only on the Grain Rot map; every castle in the main world is unchanged.
 */
fun buildRotCastle(
    st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, seed: Int,
    terrainAt: (Float, Float) -> Float,
) {
    val keepX = castleX(x, frontX, frontZ, 0f, -KEEP_BACK)
    val keepZ = castleZ(z, frontX, frontZ, 0f, -KEEP_BACK)
    val keepY = terrainAt(keepX, keepZ)
    buildKeep(st, keepX, keepY, keepZ, frontX, frontZ, Style.PALE, seed)
    buildKeepCluster(Kit(st, keepX, keepY, keepZ, frontX, frontZ), 0xB9AF98, 0x5C6672, 0xC8A02A)

    val k = Kit(st, x, y, z, frontX, frontZ)
    val stone = 0xB9AF98
    val slate = 0x5C6672
    val bannerC = 0xC8A02A
    val sf = FLAG_STONE
    val cw = CURTAIN
    val ct = 2.4f
    val wallTop = 12f
    val gate = 3.5f
    val gateH = 7.5f
    val foot = -4f

    // ---- The curtain wall, sunk into the ground so it never floats on the slope.
    k.wall(-cw - ct * 0.5f, -cw, cw + ct * 0.5f, -cw, foot, wallTop, ct, stone, sf)
    k.wall(-cw, -cw, -cw, cw, foot, wallTop, ct, stone, sf)
    k.wall(cw, -cw, cw, cw, foot, wallTop, ct, stone, sf)
    k.wall(-cw - ct * 0.5f, cw, -gate, cw, foot, wallTop, ct, stone, sf)
    k.wall(gate, cw, cw + ct * 0.5f, cw, foot, wallTop, ct, stone, sf)
    k.wall(-gate, cw, gate, cw, gateH, wallTop, ct, stone, sf)
    // A walkway ledge along the inside top, and battlements along the outside edge.
    for (side in intArrayOf(-1, 1)) {
        k.box(0f, wallTop - 0.2f, side * (cw - ct * 0.5f - 0.5f), cw, 0.2f, 0.55f, shadeRgb(stone, 0.9f), sf)
        k.box(side * (cw - ct * 0.5f - 0.5f), wallTop - 0.2f, 0f, 0.55f, 0.2f, cw, shadeRgb(stone, 0.9f), sf)
    }
    var m = -cw + 1f
    while (m < cw) {
        for (side in intArrayOf(-1, 1)) {
            k.box(m, wallTop + 0.6f, side * (cw + 0.6f), 0.6f, 0.6f, 0.45f, stone, sf)
            k.box(side * (cw + 0.6f), wallTop + 0.6f, m, 0.45f, 0.6f, 0.6f, stone, sf)
        }
        m += 2.4f
    }
    // Trim along the base.
    k.box(0f, 0.3f, -cw - ct * 0.5f - 0.15f, cw + 1f, 0.5f, 0.2f, shadeRgb(stone, 0.8f), sf)
    k.box(-cw - ct * 0.5f - 0.15f, 0.3f, 0f, 0.2f, 0.5f, cw + 1f, shadeRgb(stone, 0.8f), sf)
    k.box(cw + ct * 0.5f + 0.15f, 0.3f, 0f, 0.2f, 0.5f, cw + 1f, shadeRgb(stone, 0.8f), sf)

    // ---- Tall round towers at the four corners, shorter ones halfway along the sides.
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        roundTower(k, a * cw, b * cw, foot, wallTop + 9f, 6.4f, 5.4f, stone, slate, bannerC, 11f)
        k.blob(a * cw, 0.8f, b * cw + b * 6.2f, 2.4f, 1.2f, 1.8f, 0x4A6A38, FLAG_GRASS, seed + a * 5 + b)
    }
    for ((mu, mw) in listOf(Pair(-cw, 0f), Pair(cw, 0f), Pair(0f, -cw))) {
        roundTower(k, mu, mw, foot, wallTop + 4f, 4.6f, 4.0f, stone, slate, bannerC, 8f)
    }

    // ---- The gatehouse: two round towers either side of a tall arched gate.
    for (side in intArrayOf(-1, 1)) {
        val gu = side * (gate + 4.4f)
        roundTower(k, gu, cw, foot, wallTop + 6f, 4.8f, 4.1f, stone, slate, bannerC, 9f)
        banner(k, side * (gate + 0.2f), 9f, cw + 2.6f, 0f, bannerC)
        torch(k, side * (gate + 0.7f), 3.2f, cw + 2.65f, 1.5708f)
        torch(k, side * (gate + 0.7f), 3.2f, cw - 2.65f, -1.5708f)
    }
    // The arch over the gate, and the raised portcullis.
    k.box(0f, gateH + 0.35f, cw + ct * 0.5f + 0.15f, gate + 0.6f, 0.45f, 0.2f, shadeRgb(stone, 0.78f), sf)
    k.box(0f, gateH + 0.35f, cw - ct * 0.5f - 0.15f, gate + 0.6f, 0.45f, 0.2f, shadeRgb(stone, 0.78f), sf)
    var bar = -gate + 0.3f
    while (bar < gate) {
        k.box(bar, gateH - 0.5f, cw, 0.06f, 0.55f, 0.06f, 0x2A2A2E, FLAG_SOLID)
        bar += 0.5f
    }
    k.box(0f, gateH - 1.05f, cw, gate, 0.06f, 0.06f, 0x2A2A2E, FLAG_SOLID)

    // ---- A stone road from outside the gate to the keep door, with its own floor.
    val keepFront = -KEEP_BACK + KEEP_INNER + 1.2f
    val roadW = (cw + 8f + keepFront) * 0.5f
    val roadHalf = (cw + 8f - keepFront) * 0.5f
    k.box(0f, 0.04f, roadW, 2.6f, 0.06f, roadHalf, shadeRgb(stone, 0.85f), sf)
    k.floor(0f, roadW, 2.6f, roadHalf, 0.1f, ground = true)
    for (e in intArrayOf(-1, 1)) {
        k.box(e * 2.7f, 0.08f, (cw + keepFront) * 0.5f, 0.12f, 0.08f, (cw - keepFront) * 0.5f, shadeRgb(stone, 0.7f), sf)
    }

    // ---- A well in the grassy courtyard, and torches along the inside of the walls.
    buildWell(st, castleX(x, frontX, frontZ, -14f, 22f), y, castleZ(z, frontX, frontZ, -14f, 22f), Style.GREEN)
    var tw = -cw + 10f
    while (tw < cw - 6f) {
        torch(k, -cw + ct * 0.5f + 0.05f, 3f, tw, 0f)
        torch(k, cw - ct * 0.5f - 0.05f, 3f, tw, 3.1416f)
        tw += 12f
    }
}

/** One round, slightly tapered tower: a battlemented ring near the top, then a slate cone and a banner. */
private fun roundTower(
    k: Kit, u: Float, w: Float, foot: Float, topY: Float, r0: Float, r1: Float,
    stone: Int, slate: Int, bannerC: Int, coneH: Float,
) {
    val sf = FLAG_STONE
    val dark = shadeRgb(stone, 0.86f)
    k.prism(u, foot, w, r0, r1, topY - foot, 16, stone, sf, true, r1 * 0.95f)
    // A ring of stone that juts out, with battlements round its edge.
    k.prism(u, topY, w, r1 + 0.5f, r1 + 0.5f, 1.2f, 16, dark, sf)
    for (i in 0 until 14) {
        val a = i * 0.4488f
        k.box(u + cos(a) * (r1 + 0.2f), topY + 1.7f, w + sin(a) * (r1 + 0.2f), 0.45f, 0.5f, 0.45f, stone, sf, false, a)
    }
    // The narrower upper drum and the grey slate cone.
    k.prism(u, topY + 1.2f, w, r1 - 0.6f, r1 - 0.6f, 3.4f, 16, stone, sf)
    k.cone(u, topY + 4.6f, w, r1 + 0.3f, coneH, 16, slate, FLAG_ROOF)
    // Arrow slits facing the four ways.
    var sy = if (foot < 0f) 4f else foot + 4f
    while (sy < topY - 2f) {
        val rr = r0 + (r1 - r0) * (sy - foot) / (topY - foot)
        k.box(u + rr, sy, w, 0.05f, 0.7f, 0.25f, 0x2A3440, FLAG_SOLID)
        k.box(u - rr, sy, w, 0.05f, 0.7f, 0.25f, 0x2A3440, FLAG_SOLID)
        k.box(u, sy, w + rr, 0.25f, 0.7f, 0.05f, 0x2A3440, FLAG_SOLID)
        k.box(u, sy, w - rr, 0.25f, 0.7f, 0.05f, 0x2A3440, FLAG_SOLID)
        sy += 5f
    }
    // A flagpole on the tip of the cone.
    val tip = topY + 4.6f + coneH
    k.box(u, tip + 1.2f, w, 0.06f, 1.4f, 0.06f, 0x3A2818, FLAG_WOOD)
    k.box(u + 0.7f, tip + 2.0f, w, 0.7f, 0.45f, 0.02f, bannerC, FLAG_PLASTER)
}

/**
 * On top of the keep's roof: a tall square tower with a lower square block beside it, and a
 * crowd of round turrets of different heights, each under its own slate cone, packed in
 * against them. (Everything is in the keep's own frame, above its roof so the stairs still work.)
 */
private fun buildKeepCluster(k: Kit, stone: Int, slate: Int, bannerC: Int) {
    val sf = FLAG_STONE
    val base = 21.3f
    // The great square tower.
    val tu = -8f
    val tw = -2f
    val half = 5.5f
    val topA = 41f
    k.box(tu, (base + topA) * 0.5f, tw, half, (topA - base) * 0.5f, half, shadeRgb(stone, 1.03f), sf, true)
    // The lower square block beside it.
    val topB = 31f
    k.box(7f, (base + topB) * 0.5f, -3f, 4.5f, (topB - base) * 0.5f, 5f, stone, sf, true)
    // Battlements round both tops, and slits down the faces.
    for ((cu, cw, ch, top) in listOf(
        floatArrayOf(tu, tw, half, topA), floatArrayOf(7f, -3f, 4.8f, topB),
    )) {
        var b = -ch + 0.6f
        while (b < ch) {
            for (side in intArrayOf(-1, 1)) {
                k.box(cu + b, top + 0.5f, cw + side * ch, 0.55f, 0.5f, 0.4f, stone, sf)
                k.box(cu + side * ch, top + 0.5f, cw + b, 0.4f, 0.5f, 0.55f, stone, sf)
            }
            b += 2.2f
        }
    }
    var sy = base + 4f
    while (sy < topA - 2f) {
        for (p in floatArrayOf(-2.5f, 2.5f)) {
            k.box(tu + p, sy, tw + half + 0.02f, 0.25f, 0.7f, 0.04f, 0x2A3440, FLAG_SOLID)
            k.box(tu + p, sy, tw - half - 0.02f, 0.25f, 0.7f, 0.04f, 0x2A3440, FLAG_SOLID)
            k.box(tu + half + 0.02f, sy, tw + p, 0.04f, 0.7f, 0.25f, 0x2A3440, FLAG_SOLID)
            k.box(tu - half - 0.02f, sy, tw + p, 0.04f, 0.7f, 0.25f, 0x2A3440, FLAG_SOLID)
        }
        sy += 5f
    }
    // A flag on the tall tower.
    k.box(tu, topA + 3f, tw, 0.07f, 2.5f, 0.07f, 0x3A2818, FLAG_WOOD)
    k.box(tu + 1.0f, topA + 4.6f, tw, 1.0f, 0.6f, 0.02f, bannerC, FLAG_PLASTER)
    // The turrets, each a different height, leaning in on the towers.
    roundTower(k, tu + half + 0.8f, tw + half - 0.5f, base, 36f, 3.4f, 3.0f, stone, slate, bannerC, 9f)
    roundTower(k, tu - half - 0.5f, tw - half + 0.5f, base, 30f, 3.0f, 2.6f, stone, slate, bannerC, 7.5f)
    roundTower(k, tu + 1f, tw - half - 1.5f, base, 26f, 2.8f, 2.4f, stone, slate, bannerC, 7f)
    roundTower(k, 7f + 4.8f, -3f + 5f, base, 34f, 3.0f, 2.7f, stone, slate, bannerC, 8f)
    roundTower(k, 7f - 3f, -3f - 6f, base, 28f, 2.6f, 2.3f, stone, slate, bannerC, 6.5f)
}
