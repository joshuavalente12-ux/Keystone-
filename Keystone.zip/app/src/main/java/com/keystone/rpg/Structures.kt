package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Shapes a building is made of. */
object PartType {
    const val BOX = 0
    const val PRISM = 1
    const val CONE = 2
    const val BLOB = 3
    const val QUAD = 4
    const val FLAME = 5
    const val LIMB = 6
}

/** One shape, with its numbers in [f] (all in world space). */
class Part(val type: Int, val f: FloatArray, val rgb: Int, val flag: Int)

/** Something you bump into: a box turned [angle], reaching from height y0 to y1. */
class Solid(
    val x: Float, val z: Float, val hu: Float, val hw: Float, val angle: Float,
    val y0: Float, val y1: Float,
) {
    private val c = cos(angle)
    private val s = sin(angle)

    fun hits(px: Float, pz: Float, r: Float, feet: Float): Boolean {
        // You can walk under things above your head and step over very low things.
        if (feet + 1.75f < y0 || feet + 0.35f > y1) return false
        val dx = px - x
        val dz = pz - z
        val lu = dx * c + dz * s
        val lw = -dx * s + dz * c
        val eu = lu - lu.coerceIn(-hu, hu)
        val ew = lw - lw.coerceIn(-hw, hw)
        return eu * eu + ew * ew < r * r
    }
}

/** Somewhere you can stand: a floor, or a ramp rising by [rise] along its length. */
class Walk(
    val x: Float, val z: Float, val hu: Float, val hw: Float, val angle: Float,
    val y0: Float, val rise: Float,
) {
    private val c = cos(angle)
    private val s = sin(angle)

    /** Height here, or NaN if (px, pz) isn't on it. */
    fun heightAt(px: Float, pz: Float): Float {
        val dx = px - x
        val dz = pz - z
        val lu = dx * c + dz * s
        val lw = -dx * s + dz * c
        if (abs(lu) > hu || abs(lw) > hw) return Float.NaN
        return y0 + rise * (lu / hu * 0.5f + 0.5f)
    }
}

/** Everything built at one place: what it looks like, what blocks you, and where you can stand. */
class Structure(val cx: Float, val cz: Float, val radius: Float) {
    val parts = ArrayList<Part>()
    val solids = ArrayList<Solid>()
    val walks = ArrayList<Walk>()
    val smoke = ArrayList<FloatArray>()
}

/** Building styles, one per region. */
object Style {
    const val GREEN = 0
    const val FOREST = 1
    const val SAND = 2
    const val SNOW = 3
    const val DARK = 4

    fun of(zone: Zone): Int = when (zone) {
        Zone.MEADOW -> GREEN
        Zone.FOREST -> FOREST
        Zone.DESERT -> SAND
        Zone.SNOW -> SNOW
        Zone.CAVES -> DARK
    }
}

/**
 * Builds in a building's own frame: u runs across its front, w points out through
 * the front door, y is height above the ground it stands on.
 */
class Kit(private val st: Structure, private val ox: Float, private val oy: Float, private val oz: Float, frontX: Float, frontZ: Float) {
    val angle = atan2(-frontX, frontZ)
    private val c = cos(angle)
    private val s = sin(angle)

    fun wx(u: Float, w: Float) = ox + u * c - w * s
    fun wz(u: Float, w: Float) = oz + u * s + w * c

    fun box(
        u: Float, y: Float, w: Float, hu: Float, hy: Float, hw: Float, rgb: Int,
        flag: Int = FLAG_SOLID, solid: Boolean = false, rot: Float = 0f,
    ) {
        val x = wx(u, w)
        val z = wz(u, w)
        st.parts.add(Part(PartType.BOX, floatArrayOf(x, oy + y, z, hu, hy, hw, angle + rot), rgb, flag))
        if (solid) st.solids.add(Solid(x, z, hu, hw, angle + rot, oy + y - hy, oy + y + hy))
    }

    /** A solid wall from (u0, w0) to (u1, w1), between heights y0 and y1. */
    fun wall(u0: Float, w0: Float, u1: Float, w1: Float, y0: Float, y1: Float, thick: Float, rgb: Int, flag: Int) {
        val du = u1 - u0
        val dw = w1 - w0
        val len = sqrt(du * du + dw * dw)
        if (len < 0.05f) return
        box((u0 + u1) * 0.5f, (y0 + y1) * 0.5f, (w0 + w1) * 0.5f, len * 0.5f, (y1 - y0) * 0.5f, thick * 0.5f, rgb, flag, true, atan2(dw, du))
    }

    /** Blocks you without drawing anything. */
    fun solidOnly(u: Float, w: Float, hu: Float, hw: Float, y0: Float, y1: Float) {
        st.solids.add(Solid(wx(u, w), wz(u, w), hu, hw, angle, oy + y0, oy + y1))
    }

    fun floor(u: Float, w: Float, hu: Float, hw: Float, y: Float, rise: Float = 0f) {
        st.walks.add(Walk(wx(u, w), wz(u, w), hu, hw, angle, oy + y, rise))
    }

    fun prism(u: Float, y0: Float, w: Float, r0: Float, r1: Float, h: Float, sides: Int, rgb: Int, flag: Int, cap: Boolean = true, solidR: Float = 0f) {
        val x = wx(u, w)
        val z = wz(u, w)
        st.parts.add(Part(PartType.PRISM, floatArrayOf(x, oy + y0, z, r0, r1, h, sides.toFloat(), angle, if (cap) 1f else 0f), rgb, flag))
        if (solidR > 0f) {
            st.solids.add(Solid(x, z, solidR, solidR, 0f, oy + y0, oy + y0 + h))
            st.solids.add(Solid(x, z, solidR, solidR, 0.785f, oy + y0, oy + y0 + h))
        }
    }

    fun cone(u: Float, y0: Float, w: Float, r: Float, h: Float, sides: Int, rgb: Int, flag: Int, rot: Float = 0f) {
        st.parts.add(Part(PartType.CONE, floatArrayOf(wx(u, w), oy + y0, wz(u, w), r, h, sides.toFloat(), angle + rot), rgb, flag))
    }

    fun blob(u: Float, y: Float, w: Float, rx: Float, ry: Float, rz: Float, rgb: Int, flag: Int, seed: Int) {
        st.parts.add(Part(PartType.BLOB, floatArrayOf(wx(u, w), oy + y, wz(u, w), rx, ry, rz, seed.toFloat()), rgb, flag))
    }

    fun quad(
        u1: Float, y1: Float, w1: Float, u2: Float, y2: Float, w2: Float,
        u3: Float, y3: Float, w3: Float, u4: Float, y4: Float, w4: Float,
        rgb: Int, flag: Int, cu: Float, cy: Float, cw: Float,
    ) {
        st.parts.add(
            Part(
                PartType.QUAD,
                floatArrayOf(
                    wx(u1, w1), oy + y1, wz(u1, w1), wx(u2, w2), oy + y2, wz(u2, w2),
                    wx(u3, w3), oy + y3, wz(u3, w3), wx(u4, w4), oy + y4, wz(u4, w4),
                    wx(cu, cw), oy + cy, wz(cu, cw),
                ),
                rgb, flag,
            ),
        )
    }

    fun flame(u: Float, y: Float, w: Float, width: Float, h: Float) {
        st.parts.add(Part(PartType.FLAME, floatArrayOf(wx(u, w), oy + y, wz(u, w), width, h, angle), 0xFF6A10, FLAG_FIRE))
    }

    fun limb(u0: Float, y0: Float, w0: Float, u1: Float, y1: Float, w1: Float, r0: Float, r1: Float, rgb: Int, flag: Int) {
        st.parts.add(Part(PartType.LIMB, floatArrayOf(wx(u0, w0), oy + y0, wz(u0, w0), wx(u1, w1), oy + y1, wz(u1, w1), r0, r1), rgb, flag))
    }

    fun smoke(u: Float, y: Float, w: Float) {
        st.smoke.add(floatArrayOf(wx(u, w), oy + y, wz(u, w)))
    }
}

private fun pick(seed: Int, k: Int, options: IntArray): Int =
    options[(hash(seed, k, 4242) * options.size).toInt().coerceIn(0, options.size - 1)]

private fun roll(seed: Int, k: Int): Float = hash(seed, k, 4243)

// ---------------------------------------------------------------- Furniture

private fun bed(k: Kit, u: Float, w: Float, rot: Float, double: Boolean, blanket: Int, y: Float) {
    val hw = if (double) 0.75f else 0.48f
    // Along the bed is "rot" direction; the frame is drawn as boxes turned by rot.
    val cu = cos(rot)
    val su = sin(rot)
    fun at(a: Float, b: Float): Pair<Float, Float> = Pair(u + a * cu - b * su, w + a * su + b * cu)
    k.box(u, y + 0.22f, w, 1.05f, 0.22f, hw, 0x6A4A30, FLAG_WOOD, true, rot)
    k.box(u, y + 0.5f, w, 1.0f, 0.08f, hw - 0.04f, 0xE8E2D4, FLAG_PLASTER, false, rot)
    val (bu, bw) = at(0.25f, 0f)
    k.box(bu, y + 0.6f, bw, 0.78f, 0.05f, hw, blanket, FLAG_PLASTER, false, rot)
    val (pu, pw) = at(-0.8f, 0f)
    k.box(pu, y + 0.63f, pw, 0.18f, 0.07f, hw - 0.12f, 0xF4F0E6, FLAG_PLASTER, false, rot)
    val (hu, hwp) = at(-1.08f, 0f)
    k.box(hu, y + 0.6f, hwp, 0.05f, 0.6f, hw + 0.04f, 0x5A3E28, FLAG_WOOD, false, rot)
}

private fun table(k: Kit, u: Float, w: Float, round: Boolean, y: Float, chairs: Int, seed: Int) {
    val top = y + 0.78f
    if (round) {
        k.prism(u, top - 0.05f, w, 0.75f, 0.75f, 0.06f, 12, 0x7A5634, FLAG_WOOD)
        k.prism(u, y, w, 0.1f, 0.1f, 0.74f, 6, 0x5A3E28, FLAG_WOOD)
        k.solidOnly(u, w, 0.6f, 0.6f, y, y + 0.8f)
    } else {
        k.box(u, top, w, 0.8f, 0.04f, 0.5f, 0x7A5634, FLAG_WOOD, true)
        for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
            k.box(u + a * 0.7f, y + 0.38f, w + b * 0.4f, 0.05f, 0.38f, 0.05f, 0x5A3E28, FLAG_WOOD)
        }
    }
    // A candle and maybe a bowl or a jug.
    k.prism(u + 0.15f, top + 0.02f, w - 0.1f, 0.04f, 0.04f, 0.16f, 6, 0xEDE6D0, FLAG_SOLID)
    k.flame(u + 0.15f, top + 0.18f, w - 0.1f, 0.025f, 0.08f)
    if (roll(seed, 3) > 0.4f) k.prism(u - 0.25f, top + 0.02f, w + 0.1f, 0.14f, 0.1f, 0.08f, 8, 0x8A6A4A, FLAG_WOOD)
    val spots = arrayOf(floatArrayOf(-1.15f, 0f), floatArrayOf(1.15f, 0f), floatArrayOf(0f, -0.9f), floatArrayOf(0f, 0.9f))
    for (i in 0 until chairs.coerceAtMost(4)) {
        val cu = u + spots[i][0]
        val cw = w + spots[i][1]
        chair(k, cu, cw, atan2(w - cw, u - cu), y)
    }
}

private fun chair(k: Kit, u: Float, w: Float, face: Float, y: Float) {
    k.box(u, y + 0.45f, w, 0.22f, 0.03f, 0.22f, 0x6A4A30, FLAG_WOOD, false, face)
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        k.box(u + a * 0.17f, y + 0.22f, w + b * 0.17f, 0.03f, 0.22f, 0.03f, 0x5A3E28, FLAG_WOOD)
    }
    val bu = u - cos(face) * 0.2f
    val bw = w - sin(face) * 0.2f
    k.box(bu, y + 0.75f, bw, 0.03f, 0.3f, 0.22f, 0x6A4A30, FLAG_WOOD, false, face)
}

/** A stone fireplace built against a wall, with a fire and a chimney going up. */
private fun fireplace(k: Kit, u: Float, w: Float, rot: Float, y: Float, stone: Int, chimneyTop: Float) {
    val cu = cos(rot)
    val su = sin(rot)
    // "rot" points out of the wall into the room.
    k.box(u, y + 0.8f, w, 0.45f, 0.8f, 1.1f, stone, FLAG_STONE, true, rot)
    k.box(u + cu * 0.3f, y + 0.55f, w + su * 0.3f, 0.2f, 0.45f, 0.62f, 0x1A1410, FLAG_SOLID, false, rot)
    k.box(u + cu * 0.55f, y + 0.06f, w + su * 0.55f, 0.35f, 0.06f, 1.2f, shadeRgb(stone, 0.85f), FLAG_STONE, false, rot)
    k.box(u, y + 1.62f, w, 0.55f, 0.08f, 1.25f, shadeRgb(stone, 0.9f), FLAG_STONE, false, rot)
    // Chimney breast up to the roof and out.
    val bh = (chimneyTop - (y + 1.7f)) * 0.5f
    k.box(u - cu * 0.1f, y + 1.7f + bh, w - su * 0.1f, 0.35f, bh, 0.55f, stone, FLAG_STONE, false, rot)
    val fu = u + cu * 0.28f
    val fw = w + su * 0.28f
    k.limb(fu - su * 0.3f, y + 0.18f, fw + cu * 0.3f, fu + su * 0.3f, y + 0.18f, fw - cu * 0.3f, 0.07f, 0.07f, 0x3A2818, FLAG_BARK)
    k.prism(fu, y + 0.12f, fw, 0.3f, 0.25f, 0.05f, 8, 0xFF5A18, FLAG_FIRE)
    k.flame(fu, y + 0.16f, fw, 0.2f, 0.6f)
    k.flame(fu + su * 0.15f, y + 0.16f, fw - cu * 0.15f, 0.15f, 0.45f)
    k.smoke(u - cu * 0.1f, chimneyTop, w - su * 0.1f)
}

private fun counter(k: Kit, u: Float, w: Float, rot: Float, y: Float, len: Float, seed: Int) {
    val cu = cos(rot)
    val su = sin(rot)
    k.box(u, y + 0.44f, w, len, 0.44f, 0.3f, 0x7A5A3A, FLAG_WOOD, true, rot)
    k.box(u, y + 0.9f, w, len + 0.03f, 0.03f, 0.33f, 0x9C968A, FLAG_STONE, false, rot)
    // Pots, jars and a cutting board.
    var t = -len + 0.3f
    var i = 0
    while (t < len - 0.2f) {
        val pu = u + cu * t
        val pw = w + su * t
        when (pick(seed, 20 + i, intArrayOf(0, 1, 2, 3))) {
            0 -> k.prism(pu, y + 0.93f, pw, 0.14f, 0.12f, 0.2f, 8, 0x3A3A3E, FLAG_SOLID)
            1 -> k.prism(pu, y + 0.93f, pw, 0.08f, 0.07f, 0.24f, 8, 0xB87A4A, FLAG_SOLID)
            2 -> k.box(pu, y + 0.94f, pw, 0.2f, 0.02f, 0.13f, 0xA07A4A, FLAG_WOOD, false, rot)
            else -> k.blob(pu, y + 1.0f, pw, 0.09f, 0.09f, 0.09f, pick(seed, 30 + i, intArrayOf(0xC83A2A, 0x6AA040, 0xE8A030)), FLAG_SOLID, seed + i)
        }
        t += 0.55f
        i++
    }
    // Shelf on the wall above.
    val bu = u - cu * 0.0f
    k.box(bu, y + 1.75f, w, len, 0.03f, 0.17f, 0x6A4A30, FLAG_WOOD, false, rot)
    t = -len + 0.25f
    while (t < len - 0.1f) {
        k.prism(u + cu * t, y + 1.78f, w + su * t, 0.06f, 0.06f, 0.18f, 6, pick(seed, (t * 10f).toInt(), intArrayOf(0x4A6A8A, 0x8A6A4A, 0x6A8A5A, 0xC9B08E)), FLAG_SOLID)
        t += 0.3f
    }
}

private fun rug(k: Kit, u: Float, w: Float, hu: Float, hw: Float, y: Float, rgb: Int, rot: Float = 0f) {
    k.box(u, y + 0.015f, w, hu, 0.015f, hw, rgb, FLAG_PLASTER, false, rot)
    k.box(u, y + 0.02f, w, hu - 0.12f, 0.012f, hw - 0.12f, shadeRgb(rgb, 1.25f), FLAG_PLASTER, false, rot)
}

private fun chest(k: Kit, u: Float, w: Float, rot: Float, y: Float) {
    k.box(u, y + 0.28f, w, 0.45f, 0.28f, 0.3f, 0x6A4A2A, FLAG_WOOD, true, rot)
    k.box(u, y + 0.58f, w, 0.47f, 0.04f, 0.32f, 0x5A3A20, FLAG_WOOD, false, rot)
    k.box(u, y + 0.35f, w, 0.47f, 0.04f, 0.32f, 0x4A4A4E, FLAG_SOLID, false, rot)
}

private fun barrel(k: Kit, u: Float, w: Float, y: Float) {
    k.prism(u, y, w, 0.33f, 0.36f, 0.45f, 10, 0x7A5634, FLAG_WOOD, false, 0.36f)
    k.prism(u, y + 0.45f, w, 0.36f, 0.33f, 0.45f, 10, 0x7A5634, FLAG_WOOD)
    k.prism(u, y + 0.43f, w, 0.37f, 0.37f, 0.05f, 10, 0x4A4A4E, FLAG_SOLID, false)
}

private fun bookshelf(k: Kit, u: Float, w: Float, rot: Float, y: Float, seed: Int) {
    val cu = cos(rot)
    val su = sin(rot)
    k.box(u, y + 1.0f, w, 0.2f, 1.0f, 0.7f, 0x5A3E28, FLAG_WOOD, true, rot)
    for (row in 0 until 4) {
        val ry = y + 0.25f + row * 0.48f
        var t = -0.6f
        var i = 0
        while (t < 0.6f) {
            val bw = 0.05f + 0.04f * roll(seed, row * 20 + i)
            val bh = 0.14f + 0.06f * roll(seed, row * 20 + i + 7)
            k.box(
                u + cu * 0.12f - su * t, ry + bh, w + su * 0.12f + cu * t, 0.1f, bh, bw,
                pick(seed, row * 20 + i, intArrayOf(0x8A2A2A, 0x2A4A7A, 0x3A6A3A, 0x7A5A2A, 0x5A3A6A, 0xB89A5A)),
                FLAG_SOLID, false, rot,
            )
            t += bw * 2f + 0.01f
            i++
        }
    }
}

private fun torch(k: Kit, u: Float, y: Float, w: Float, rot: Float) {
    val ou = u + cos(rot) * 0.25f
    val ow = w + sin(rot) * 0.25f
    k.limb(u, y, w, ou, y + 0.35f, ow, 0.05f, 0.04f, 0x3A2818, FLAG_WOOD)
    k.flame(ou, y + 0.35f, ow, 0.09f, 0.35f)
}

private fun banner(k: Kit, u: Float, y: Float, w: Float, rot: Float, rgb: Int) {
    k.box(u, y, w, 0.6f, 1.3f, 0.03f, rgb, FLAG_PLASTER, false, rot)
    k.box(u, y + 1.32f, w, 0.7f, 0.04f, 0.05f, 0x3A2818, FLAG_WOOD, false, rot)
    k.box(u, y, w, 0.2f, 0.25f, 0.035f, 0xFFC940, FLAG_GLOW, false, rot)
}

// ---------------------------------------------------------------- Houses

/**
 * A house you can walk into, about 8 by 6 metres inside. Looks follow the region;
 * the furniture layout is shuffled by [seed] so no two are quite the same inside.
 */
fun buildHouse(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, style: Int, seed: Int) {
    val k = Kit(st, x, y, z, frontX, frontZ)
    val iu = 4f
    val iw = 3f
    val t = 0.3f
    val wallH = 3.4f
    val fy = 0.3f

    val wallC: Int
    val wallF: Int
    val roofC: Int
    val roofF: Int
    val trim = 0x4A3424
    val stone: Int
    when (style) {
        Style.FOREST -> {
            wallC = 0x6A4A30; wallF = FLAG_WOOD; roofC = 0x4E5A34; roofF = FLAG_ROOF; stone = 0x7A766E
        }
        Style.SNOW -> {
            wallC = 0x8A8C92; wallF = FLAG_STONE; roofC = 0xEEF2F6; roofF = FLAG_SNOW; stone = 0x6E7078
        }
        Style.SAND -> {
            wallC = 0xCDA878; wallF = FLAG_PLASTER; roofC = 0xB8966A; roofF = FLAG_PLASTER; stone = 0xA88A62
        }
        Style.DARK -> {
            wallC = 0x3E3848; wallF = FLAG_STONE; roofC = 0x2A2430; roofF = FLAG_ROOF; stone = 0x4A4452
        }
        else -> {
            wallC = pick(seed, 1, intArrayOf(0xD8CDB4, 0xC9B08E, 0xBEB8AC))
            wallF = FLAG_PLASTER
            roofC = pick(seed, 2, intArrayOf(0x8A3A2A, 0x5A4A3A, 0x4E5A66, 0x7A5A2A))
            roofF = FLAG_ROOF
            stone = 0x8C877D
        }
    }
    val inner = shadeRgb(wallC, 0.82f)

    // Floor.
    k.box(0f, 0.15f, 0f, iu + t, 0.15f, iw + t, 0x7A746A, FLAG_STONE)
    k.box(0f, fy + 0.01f, 0f, iu, 0.01f, iw, if (style == Style.SAND || style == Style.DARK) shadeRgb(stone, 0.9f) else 0x8A6A48, if (style == Style.SAND || style == Style.DARK) FLAG_STONE else FLAG_WOOD)
    k.floor(0f, 0f, iu + t, iw + t, fy)
    // A step up to the door.
    k.box(0f, 0.12f, iw + t + 0.35f, 0.8f, 0.12f, 0.35f, stone, FLAG_STONE)

    // Walls: back, sides, and the front with a doorway.
    val doorU = pick(seed, 3, intArrayOf(-1, 0, 1)) * 1.4f
    val doorHalf = 0.7f
    val doorTop = 2.4f
    val wy0 = 0f
    k.wall(-iu - t, -iw - t * 0.5f, iu + t, -iw - t * 0.5f, wy0, wallH, t, wallC, wallF)
    k.wall(-iu - t * 0.5f, -iw, -iu - t * 0.5f, iw, wy0, wallH, t, wallC, wallF)
    k.wall(iu + t * 0.5f, -iw, iu + t * 0.5f, iw, wy0, wallH, t, wallC, wallF)
    k.wall(-iu - t, iw + t * 0.5f, doorU - doorHalf, iw + t * 0.5f, wy0, wallH, t, wallC, wallF)
    k.wall(doorU + doorHalf, iw + t * 0.5f, iu + t, iw + t * 0.5f, wy0, wallH, t, wallC, wallF)
    k.wall(doorU - doorHalf, iw + t * 0.5f, doorU + doorHalf, iw + t * 0.5f, doorTop, wallH, t, wallC, wallF)
    // Inside faces a little darker, as rooms are.
    k.box(0f, fy + 1.6f, -iw + 0.01f, iu, 1.5f, 0.01f, inner, wallF)
    // The door, swung open against the inside wall.
    k.box(doorU - doorHalf + 0.05f, fy + 1.05f, iw - 0.55f, 0.04f, 1.05f, 0.55f, 0x5A3A22, FLAG_WOOD)
    k.box(doorU - doorHalf + 0.1f, fy + 1.05f, iw - 0.95f, 0.04f, 0.04f, 0.04f, 0xC9A227, FLAG_SOLID)
    k.box(doorU, doorTop + 0.1f, iw + t + 0.02f, doorHalf + 0.12f, 0.1f, 0.04f, trim, FLAG_WOOD)

    // Windows on the sides and back, with shutters outside.
    val glass = if (style == Style.DARK) 0x9A5AFF else 0x3A4A5A
    val glassF = if (style == Style.DARK) FLAG_GLOW else FLAG_SOLID
    for (side in intArrayOf(-1, 1)) {
        val wu = side * (iu + t + 0.02f)
        k.box(wu, 1.8f, 0f, 0.03f, 0.45f, 0.5f, glass, glassF)
        k.box(side * (iu - 0.02f), 1.8f, 0f, 0.02f, 0.45f, 0.5f, glass, glassF)
        k.box(wu, 1.8f, 0f, 0.05f, 0.04f, 0.55f, trim, FLAG_WOOD)
        if (style != Style.SAND) {
            k.box(wu + side * 0.03f, 1.8f, 0.72f, 0.03f, 0.47f, 0.18f, 0x3A6A4A, FLAG_WOOD)
            k.box(wu + side * 0.03f, 1.8f, -0.72f, 0.03f, 0.47f, 0.18f, 0x3A6A4A, FLAG_WOOD)
        }
    }
    for (wu in floatArrayOf(-2.2f, 2.2f)) {
        k.box(wu, 1.8f, -iw - t - 0.02f, 0.5f, 0.45f, 0.03f, glass, glassF)
        k.box(wu, 1.8f, -iw + 0.02f, 0.5f, 0.45f, 0.02f, glass, glassF)
    }
    val frontWinU = if (doorU <= 0f) 2.4f else -2.4f
    k.box(frontWinU, 1.8f, iw + t + 0.02f, 0.5f, 0.45f, 0.03f, glass, glassF)
    k.box(frontWinU, 1.8f, iw - 0.02f, 0.5f, 0.45f, 0.02f, glass, glassF)

    // Timber frame for the meadow cottages.
    if (style == Style.GREEN) {
        for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
            k.box(a * (iu + t), wallH * 0.5f, b * (iw + t), 0.16f, wallH * 0.5f, 0.16f, trim, FLAG_WOOD)
        }
        for (b in intArrayOf(-1, 1)) {
            k.box(0f, wallH - 0.1f, b * (iw + t + 0.03f), iu + t, 0.1f, 0.05f, trim, FLAG_WOOD)
            k.box(0f, 1.2f, b * (iw + t + 0.03f), iu + t, 0.08f, 0.05f, trim, FLAG_WOOD)
        }
    }
    // Foundation stones.
    k.box(0f, 0.25f, 0f, iu + t + 0.08f, 0.25f, iw + t + 0.08f, stone, FLAG_STONE)

    // Roof.
    val eaveW = iw + t + 0.6f
    val eaveU = iu + t + 0.45f
    if (style == Style.SAND) {
        // Flat roof with a low wall round the edge and beam ends poking out.
        k.box(0f, wallH + 0.1f, 0f, iu + t, 0.12f, iw + t, roofC, roofF)
        for (b in intArrayOf(-1, 1)) {
            k.box(0f, wallH + 0.45f, b * (iw + t - 0.1f), iu + t, 0.25f, 0.1f, wallC, FLAG_PLASTER)
            k.box(b * (iu + t - 0.1f), wallH + 0.45f, 0f, 0.1f, 0.25f, iw + t, wallC, FLAG_PLASTER)
        }
        var bu = -iu + 0.5f
        while (bu < iu) {
            k.limb(bu, wallH - 0.25f, iw + t, bu, wallH - 0.25f, iw + t + 0.5f, 0.09f, 0.08f, 0x5A3E28, FLAG_BARK)
            bu += 1.3f
        }
    } else {
        val ridgeY = wallH + if (style == Style.SNOW) 2.8f else 2.2f
        // Two slopes meeting along the ridge, running across the front.
        k.quad(-eaveU, wallH - 0.1f, eaveW, eaveU, wallH - 0.1f, eaveW, eaveU, ridgeY, 0f, -eaveU, ridgeY, 0f, roofC, roofF, 0f, 0f, 0f)
        k.quad(-eaveU, wallH - 0.1f, -eaveW, eaveU, wallH - 0.1f, -eaveW, eaveU, ridgeY, 0f, -eaveU, ridgeY, 0f, shadeRgb(roofC, 0.92f), roofF, 0f, 0f, 0f)
        // Underside, seen from inside.
        k.quad(-iu, wallH - 0.05f, iw, iu, wallH - 0.05f, iw, iu, ridgeY - 0.15f, 0f, -iu, ridgeY - 0.15f, 0f, 0x5A4430, FLAG_WOOD, 0f, 10f, 0f)
        k.quad(-iu, wallH - 0.05f, -iw, iu, wallH - 0.05f, -iw, iu, ridgeY - 0.15f, 0f, -iu, ridgeY - 0.15f, 0f, 0x5A4430, FLAG_WOOD, 0f, 10f, 0f)
        k.box(0f, ridgeY + 0.05f, 0f, eaveU, 0.1f, 0.14f, shadeRgb(roofC, 0.7f), FLAG_WOOD)
        // Triangle ends above the side walls.
        for (side in intArrayOf(-1, 1)) {
            val su = side * (iu + t * 0.5f)
            k.quad(su, wallH, -iw - t, su, wallH, iw + t, su, ridgeY - 0.2f, 0f, su, ridgeY - 0.2f, 0f, wallC, wallF, 0f, wallH, 0f)
        }
    }

    // ---- Inside. Everything is placed relative to which end the fireplace is on.
    val fs = if (roll(seed, 5) > 0.5f) 1f else -1f
    val fireW = pick(seed, 6, intArrayOf(-1, 0)) * 0.9f
    fireplace(k, fs * (iu - 0.45f), fireW, if (fs > 0f) 3.1416f else 0f, fy, stone, wallH + 3.2f)

    val blankets = intArrayOf(0x8A2A2A, 0x2A4A7A, 0x3A6A3A, 0x7A5A8A, 0xC9A060, 0x6A4A6A)
    val double = roll(seed, 7) > 0.45f
    val bedU = -fs * (iu - 1.1f)
    val bedW = -iw + 1.15f
    bed(k, bedU, bedW, 1.5708f, double, pick(seed, 8, blankets), fy)
    if (roll(seed, 9) > 0.35f) chest(k, bedU, bedW + 1.55f, 0f, fy)

    val counterU = pick(seed, 10, intArrayOf(-1, 0, 1)) * 0.6f + fs * 0.4f
    counter(k, counterU, -iw + 0.35f, 0f, fy, 1.1f, seed)

    val tableU = fs * 1.1f + (roll(seed, 11) - 0.5f) * 0.8f
    val tableW = 0.5f + (roll(seed, 12) - 0.5f) * 0.4f
    val rugs = intArrayOf(0x8A3A2A, 0x2A4A6A, 0x6A5A2A, 0x4A6A4A, 0x6A2A4A)
    rug(k, tableU, tableW, 1.6f, 1.2f, fy, pick(seed, 13, rugs))
    table(k, tableU, tableW, roll(seed, 14) > 0.5f, fy, 2 + (roll(seed, 15) * 3f).toInt(), seed)

    // One or two extras, different in each house.
    val extraU = -fs * (iu - 0.35f)
    when (pick(seed, 16, intArrayOf(0, 1, 2))) {
        0 -> bookshelf(k, extraU, 1.4f, if (fs > 0f) 0f else 3.1416f, fy, seed)
        1 -> {
            barrel(k, extraU, 1.6f, fy)
            barrel(k, extraU, 2.35f, fy)
        }
        else -> k.box(extraU, fy + 0.9f, 1.8f, 0.3f, 0.9f, 0.55f, 0x5A3E28, FLAG_WOOD, true)
    }
    if (roll(seed, 17) > 0.5f) barrel(k, doorU + if (doorU > 0f) -1.3f else 1.3f, iw - 0.45f, fy)
    // Hanging lamp.
    k.limb(0f, wallH + 0.8f, 0f, 0f, wallH - 0.35f, 0f, 0.02f, 0.02f, 0x2A2A2A, FLAG_SOLID)
    k.prism(0f, wallH - 0.55f, 0f, 0.12f, 0.08f, 0.2f, 6, 0xFFC860, FLAG_GLOW)

    // Walls block you; the doorway doesn't.
    // (Walls and furniture above already added their own solids.)
}

/** A stone well with a little roof. */
fun buildWell(st: Structure, x: Float, y: Float, z: Float, style: Int) {
    val k = Kit(st, x, y, z, 0f, 1f)
    val stone = when (style) {
        Style.SAND -> 0xA88A62
        Style.DARK -> 0x4A4452
        Style.SNOW -> 0x8A8C92
        else -> 0x8C877D
    }
    k.prism(0f, -0.3f, 0f, 1.25f, 1.2f, 1.25f, 12, stone, FLAG_STONE, false, 1.25f)
    k.prism(0f, -0.3f, 0f, 0.92f, 0.92f, 1.24f, 12, shadeRgb(stone, 0.6f), FLAG_STONE, false)
    // Rim.
    for (i in 0 until 12) {
        val a0 = i * 6.2831855f / 12f
        val a1 = (i + 1) * 6.2831855f / 12f
        k.quad(
            cos(a0) * 0.92f, 0.95f, sin(a0) * 0.92f, cos(a1) * 0.92f, 0.95f, sin(a1) * 0.92f,
            cos(a1) * 1.22f, 0.95f, sin(a1) * 1.22f, cos(a0) * 1.22f, 0.95f, sin(a0) * 1.22f,
            shadeRgb(stone, 1.1f), FLAG_STONE, 0f, -4f, 0f,
        )
    }
    k.prism(0f, 0.3f, 0f, 0.9f, 0.9f, 0.02f, 12, 0x1E3A5A, FLAG_WATER)
    for (side in intArrayOf(-1, 1)) {
        k.box(side * 1.12f, 1.35f, 0f, 0.09f, 1.35f, 0.09f, 0x5A3E22, FLAG_WOOD)
    }
    k.box(0f, 2.35f, 0f, 1.2f, 0.06f, 0.06f, 0x5A3E22, FLAG_WOOD)
    k.limb(0f, 2.3f, 0f, 0f, 1.3f, 0f, 0.012f, 0.012f, 0x8A7A5A, FLAG_SOLID)
    k.prism(0f, 1.0f, 0f, 0.16f, 0.18f, 0.3f, 8, 0x6A4A2A, FLAG_WOOD)
    val roof = if (style == Style.SNOW) 0xEEF2F6 else 0x7A3A2A
    val rf = if (style == Style.SNOW) FLAG_SNOW else FLAG_ROOF
    k.quad(-1.45f, 2.3f, 0.95f, 1.45f, 2.3f, 0.95f, 1.45f, 3.1f, 0f, -1.45f, 3.1f, 0f, roof, rf, 0f, 0f, 0f)
    k.quad(-1.45f, 2.3f, -0.95f, 1.45f, 2.3f, -0.95f, 1.45f, 3.1f, 0f, -1.45f, 3.1f, 0f, shadeRgb(roof, 0.92f), rf, 0f, 0f, 0f)
}

// ---------------------------------------------------------------- Castles

/**
 * A great four-storey keep, about 28 m square and 21 m to the battlements, with
 * towers at each corner. Stairs climb the back wall from floor to floor up to the
 * roof. Every floor is furnished: great hall, bedrooms, library and armoury, and
 * the lord's quarters with a throne.
 */
fun buildCastle(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, style: Int, seed: Int) {
    val k = Kit(st, x, y, z, frontX, frontZ)
    val inner = 12.8f
    val t = 1.2f
    val levels = floatArrayOf(0.3f, 5.3f, 10.3f, 15.3f, 20.3f)
    val top = 21.5f
    val gate = 1.9f
    val gateH = 4.4f

    val stone: Int
    val stoneF: Int
    val roofC: Int
    val roofF: Int
    val bannerC: Int
    val floorC: Int
    when (style) {
        Style.FOREST -> {
            stone = 0x6E726A; stoneF = FLAG_STONE; roofC = 0x3E4A2E; roofF = FLAG_ROOF; bannerC = 0x2E6A3A; floorC = 0x6A4A30
        }
        Style.SNOW -> {
            stone = 0xB8C0CC; stoneF = FLAG_STONE; roofC = 0xEEF2F6; roofF = FLAG_SNOW; bannerC = 0x2A4A8A; floorC = 0x8A8C92
        }
        Style.SAND -> {
            stone = 0xCBA774; stoneF = FLAG_STONE; roofC = 0xD8B884; roofF = FLAG_PLASTER; bannerC = 0xB83A2A; floorC = 0xA88A62
        }
        Style.DARK -> {
            stone = 0x2E2A36; stoneF = FLAG_STONE; roofC = 0x1E1A24; roofF = FLAG_ROOF; bannerC = 0x7A1A2A; floorC = 0x3A3444
        }
        else -> {
            stone = 0x8C8A84; stoneF = FLAG_STONE; roofC = 0x4E5A66; roofF = FLAG_ROOF; bannerC = 0x2A5A9A; floorC = 0x7A6A5A
        }
    }
    val innerWall = shadeRgb(stone, 0.78f)
    val windowC = when (style) {
        Style.DARK -> 0x9A4AFF
        Style.SNOW -> 0x8ABCE0
        else -> 0x2A3440
    }
    val windowF = if (style == Style.DARK || style == Style.SNOW) FLAG_GLOW else FLAG_SOLID

    // ---- Outer walls. The front has a great gate.
    val wc = inner + t * 0.5f
    k.wall(-inner - t, -wc, inner + t, -wc, 0f, top, t, stone, stoneF)
    k.wall(-wc, -inner, -wc, inner, 0f, top, t, stone, stoneF)
    k.wall(wc, -inner, wc, inner, 0f, top, t, stone, stoneF)
    k.wall(-inner - t, wc, -gate, wc, 0f, top, t, stone, stoneF)
    k.wall(gate, wc, inner + t, wc, 0f, top, t, stone, stoneF)
    k.wall(-gate, wc, gate, wc, gateH, top, t, stone, stoneF)
    // Darker inside faces.
    k.box(0f, top * 0.5f, -inner + 0.01f, inner, top * 0.5f - 0.3f, 0.01f, innerWall, stoneF)
    k.box(-inner + 0.01f, top * 0.5f, 0f, 0.01f, top * 0.5f - 0.3f, inner, innerWall, stoneF)
    k.box(inner - 0.01f, top * 0.5f, 0f, 0.01f, top * 0.5f - 0.3f, inner, innerWall, stoneF)
    // Plinth and a band of trim at each floor.
    k.box(0f, 0.4f, 0f, inner + t + 0.3f, 0.6f, inner + t + 0.3f, shadeRgb(stone, 0.8f), stoneF)
    for (l in 1..4) {
        val ly = levels[l] - 0.15f
        k.box(0f, ly, -wc - t * 0.5f - 0.1f, inner + t, 0.15f, 0.12f, shadeRgb(stone, 0.85f), stoneF)
        k.box(0f, ly, wc + t * 0.5f + 0.1f, inner + t, 0.15f, 0.12f, shadeRgb(stone, 0.85f), stoneF)
        k.box(-wc - t * 0.5f - 0.1f, ly, 0f, 0.12f, 0.15f, inner + t, shadeRgb(stone, 0.85f), stoneF)
        k.box(wc + t * 0.5f + 0.1f, ly, 0f, 0.12f, 0.15f, inner + t, shadeRgb(stone, 0.85f), stoneF)
    }
    // Battlements.
    var m = -inner - t + 0.5f
    while (m < inner + t) {
        for (side in intArrayOf(-1, 1)) {
            k.box(m, top + 0.45f, side * wc, 0.5f, 0.45f, t * 0.5f, stone, stoneF)
            k.box(side * wc, top + 0.45f, m, t * 0.5f, 0.45f, 0.5f, stone, stoneF)
        }
        m += 2f
    }

    // ---- Windows: tall slits on every floor.
    for (l in 0..3) {
        val wy = levels[l] + 2.3f
        for (p in floatArrayOf(-8f, 0f, 8f)) {
            for (side in intArrayOf(-1, 1)) {
                if (!(l == 0 && side == 1 && abs(p) < 3f)) {
                    k.box(p, wy, side * (wc + t * 0.5f + 0.02f), 0.35f, 0.9f, 0.03f, windowC, windowF)
                }
                k.box(side * (wc + t * 0.5f + 0.02f), wy, p, 0.03f, 0.9f, 0.35f, windowC, windowF)
                k.box(p, wy, side * (inner - 0.02f), 0.35f, 0.9f, 0.02f, windowC, windowF)
                k.box(side * (inner - 0.02f), wy, p, 0.02f, 0.9f, 0.35f, windowC, windowF)
            }
        }
    }

    // ---- The gate: arch trim, raised portcullis, torches and banners.
    k.box(0f, gateH + 0.3f, wc + t * 0.5f + 0.1f, gate + 0.5f, 0.35f, 0.15f, shadeRgb(stone, 0.8f), stoneF)
    var bar = -gate + 0.25f
    while (bar < gate) {
        k.box(bar, gateH - 0.4f, wc, 0.05f, 0.45f, 0.05f, 0x2A2A2E, FLAG_SOLID)
        bar += 0.45f
    }
    torch(k, -gate - 0.8f, 2.4f, wc + t * 0.5f, 1.5708f)
    torch(k, gate + 0.8f, 2.4f, wc + t * 0.5f, 1.5708f)
    banner(k, -6f, 9f, wc + t * 0.5f + 0.05f, 0f, bannerC)
    banner(k, 6f, 9f, wc + t * 0.5f + 0.05f, 0f, bannerC)
    k.box(0f, 0.2f, wc + 3f, gate + 0.4f, 0.2f, 2.4f, shadeRgb(stone, 0.9f), stoneF)

    // ---- Corner towers.
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        val tu = a * (inner + t)
        val tw = b * (inner + t)
        val th = top + 5f
        k.prism(tu, -0.3f, tw, 4.0f, 3.7f, th + 0.3f, 12, stone, stoneF, true, 3.8f)
        k.prism(tu, th, tw, 4.3f, 4.3f, 1.0f, 12, shadeRgb(stone, 0.9f), stoneF)
        for (l in 0..3) {
            val slit = levels[l] + 2.5f
            k.box(tu + a * 3.85f, slit, tw, 0.05f, 0.7f, 0.25f, windowC, windowF)
            k.box(tu, slit, tw + b * 3.85f, 0.25f, 0.7f, 0.05f, windowC, windowF)
        }
        when (style) {
            Style.SAND -> {
                k.blob(tu, th + 1.0f, tw, 3.8f, 3.4f, 3.8f, roofC, roofF, seed + a * 3 + b)
                k.prism(tu, th + 4.2f, tw, 0.08f, 0.02f, 1.5f, 4, 0xFFC940, FLAG_GLOW)
            }
            Style.DARK -> {
                k.cone(tu, th + 1.0f, tw, 4.4f, 11f, 12, roofC, roofF)
                k.cone(tu, th + 11.5f, tw, 0.25f, 2.5f, 4, 0x9A4AFF, FLAG_GLOW)
            }
            else -> k.cone(tu, th + 1.0f, tw, 4.6f, 6.5f, 12, roofC, roofF)
        }
        // Flag on top.
        val fh = if (style == Style.DARK) th + 14f else if (style == Style.SAND) th + 5.7f else th + 7.5f
        k.box(tu, fh + 1.0f, tw, 0.05f, 1.2f, 0.05f, 0x3A2818, FLAG_WOOD)
        k.box(tu + 0.6f, fh + 1.7f, tw, 0.6f, 0.4f, 0.02f, bannerC, FLAG_PLASTER)
    }

    // ---- Floors, with a gap above each staircase.
    val stripIn = -inner + 2.2f
    val stripC = (-inner + stripIn) * 0.5f
    val stripH = (stripIn + inner) * 0.5f
    k.box(0f, 0.15f, 0f, inner, 0.15f, inner, floorC, FLAG_STONE)
    k.floor(0f, 0f, inner, inner, levels[0])
    for (l in 1..4) {
        val y0 = levels[l]
        val holeA = if (l % 2 == 1) -9f else -1f
        val holeB = if (l % 2 == 1) 1f else 9f
        val mainC = (stripIn + inner) * 0.5f
        val mainH = (inner - stripIn) * 0.5f
        k.box(0f, y0 - 0.15f, mainC, inner, 0.15f, mainH, floorC, FLAG_STONE)
        k.floor(0f, mainC, inner, mainH, y0)
        val pA = (-inner + holeA) * 0.5f
        val hA = (holeA + inner) * 0.5f
        val pB = (holeB + inner) * 0.5f
        val hB = (inner - holeB) * 0.5f
        k.box(pA, y0 - 0.15f, stripC, hA, 0.15f, stripH, floorC, FLAG_STONE)
        k.floor(pA, stripC, hA, stripH, y0)
        k.box(pB, y0 - 0.15f, stripC, hB, 0.15f, stripH, floorC, FLAG_STONE)
        k.floor(pB, stripC, hB, stripH, y0)
        // A low rail along the stairwell so you don't step off by accident.
        k.box((holeA + holeB) * 0.5f, y0 + 0.5f, stripIn + 0.08f, 5f, 0.5f, 0.06f, 0x5A3E28, FLAG_WOOD, true)
    }
    // Stairs: switchbacks up the back wall.
    for (l in 0..3) {
        val y0 = levels[l]
        val even = l % 2 == 0
        val cu = if (even) -4f else 4f
        k.floor(cu, stripC, 5f, stripH, if (even) y0 else y0 + 5f, if (even) 5f else -5f)
        // You can't walk underneath the stairs, only up them from the bottom.
        for (s in 1 until 10) {
            val a = if (even) -9f + s else 9f - s - 1f
            k.solidOnly(a + 0.5f, stripC, 0.5f, stripH, y0 - 0.3f, y0 + s * 0.5f)
        }
        for (s in 0 until 12) {
            val f = (s + 0.5f) / 12f
            val su = if (even) -9f + f * 10f else 9f - f * 10f
            val sy = y0 + f * 5f
            k.box(su, (y0 + sy) * 0.5f - 0.1f, stripC, 0.43f, (sy - y0) * 0.5f + 0.12f, stripH, shadeRgb(floorC, 0.9f), FLAG_STONE)
        }
    }

    // ---- Ground floor: the great hall.
    val f0 = levels[0]
    k.box(0f, f0 + 0.02f, 7f, 1.2f, 0.02f, 5.6f, bannerC, FLAG_PLASTER)
    k.box(0f, f0 + 0.95f, 1f, 6f, 0.05f, 1.0f, 0x6A4A30, FLAG_WOOD, true)
    for (lx in floatArrayOf(-5.5f, 0f, 5.5f)) k.box(lx, f0 + 0.45f, 1f, 0.12f, 0.45f, 0.8f, 0x5A3E28, FLAG_WOOD)
    for (side in floatArrayOf(-1.6f, 3.6f)) k.box(0f, f0 + 0.45f, side, 6f, 0.05f, 0.28f, 0x6A4A30, FLAG_WOOD, true)
    var cx = -5f
    while (cx <= 5f) {
        k.prism(cx, f0 + 1.0f, 1f, 0.05f, 0.05f, 0.25f, 6, 0xEDE6D0, FLAG_SOLID)
        k.flame(cx, f0 + 1.25f, 1f, 0.03f, 0.1f)
        k.prism(cx + 1f, f0 + 1.0f, 1.3f, 0.2f, 0.15f, 0.06f, 8, 0x9C968A, FLAG_STONE)
        cx += 2.5f
    }
    k.box(0f, f0 + 1.35f, -0.2f, 0.5f, 0.35f, 0.4f, 0x7A3A2A, FLAG_WOOD, true)
    fireplace(k, inner - 0.5f, 2f, 3.1416f, f0, shadeRgb(stone, 0.9f), top + 1.5f)
    fireplace(k, -inner + 0.5f, 2f, 0f, f0, shadeRgb(stone, 0.9f), top + 1.5f)
    for (p in floatArrayOf(-6f, 6f)) {
        banner(k, p, f0 + 3.2f, -inner + 0.06f, 3.1416f, bannerC)
        torch(k, p + 3f, f0 + 2.6f, -inner + 0.05f, 1.5708f)
    }
    barrel(k, -inner + 0.6f, 10f, f0)
    barrel(k, -inner + 0.6f, 11.1f, f0)
    barrel(k, -inner + 1.5f, 11f, f0)
    barrel(k, inner - 0.6f, 11f, f0)
    chest(k, inner - 0.8f, 8.5f, 1.5708f, f0)

    // ---- First floor: bedrooms.
    val f1 = levels[1]
    val blankets = intArrayOf(0x8A2A2A, 0x2A4A7A, 0x3A6A3A, 0x7A5A8A)
    var bi = 0
    for (bu in floatArrayOf(-9f, -4.5f, 4.5f, 9f)) {
        bed(k, bu, inner - 1.2f, -1.5708f, bi % 2 == 0, blankets[bi], f1)
        chest(k, bu, inner - 2.8f, 0f, f1)
        rug(k, bu, inner - 2.2f, 1.0f, 1.5f, f1, pick(seed, 40 + bi, intArrayOf(0x8A3A2A, 0x2A4A6A, 0x6A5A2A)))
        bi++
    }
    k.wall(0f, 2f, 0f, inner, f1, levels[2] - 0.3f, 0.3f, innerWall, stoneF)
    k.box(-inner + 0.4f, f1 + 1.1f, 3f, 0.35f, 1.1f, 0.8f, 0x5A3E28, FLAG_WOOD, true)
    k.box(inner - 0.4f, f1 + 1.1f, 3f, 0.35f, 1.1f, 0.8f, 0x5A3E28, FLAG_WOOD, true)
    table(k, -6f, -3f, true, f1, 3, seed + 1)
    table(k, 6f, -3f, false, f1, 2, seed + 2)
    torch(k, -3f, f1 + 2.6f, -inner + 0.05f, 1.5708f)
    torch(k, 3f, f1 + 2.6f, -inner + 0.05f, 1.5708f)

    // ---- Second floor: library and armoury.
    val f2 = levels[2]
    var sw = -7f
    while (sw <= 9f) {
        bookshelf(k, -inner + 0.25f, sw, 0f, f2, seed + (sw * 3f).toInt())
        sw += 1.6f
    }
    table(k, -4f, 3f, false, f2, 4, seed + 3)
    k.box(-4f, f2 + 0.84f, 3f, 0.4f, 0.01f, 0.3f, 0xE8D8A8, FLAG_PLASTER)
    rug(k, -4f, 3f, 2.4f, 1.8f, f2, bannerC)
    // Weapon racks and suits of armour on the other side.
    var rw = -6f
    while (rw <= 8f) {
        k.box(inner - 0.3f, f2 + 1f, rw, 0.12f, 1f, 0.9f, 0x5A3E28, FLAG_WOOD, true)
        for (i in 0 until 3) {
            val sp = rw - 0.5f + i * 0.5f
            k.limb(inner - 0.45f, f2 + 0.1f, sp, inner - 0.45f, f2 + 1.9f, sp, 0.03f, 0.03f, 0x6A5A4A, FLAG_WOOD)
            k.cone(inner - 0.45f, f2 + 1.9f, sp, 0.07f, 0.3f, 4, 0xC0C6CE, FLAG_SOLID)
        }
        rw += 3.5f
    }
    for (au in floatArrayOf(2f, 6f)) {
        k.box(au, f2 + 0.05f, 9f, 0.3f, 0.05f, 0.3f, 0x4A4A4E, FLAG_SOLID, true)
        k.box(au, f2 + 1.1f, 9f, 0.22f, 0.45f, 0.14f, 0xA8AEB8, FLAG_SOLID)
        k.limb(au - 0.1f, f2 + 0.1f, 9f, au - 0.1f, f2 + 0.65f, 9f, 0.07f, 0.06f, 0x8A9098, FLAG_SOLID)
        k.limb(au + 0.1f, f2 + 0.1f, 9f, au + 0.1f, f2 + 0.65f, 9f, 0.07f, 0.06f, 0x8A9098, FLAG_SOLID)
        k.blob(au, f2 + 1.75f, 9f, 0.16f, 0.2f, 0.16f, 0xB8BEC8, FLAG_SOLID, 7)
    }
    for (i in 0 until 4) barrel(k, 8f + (i % 2) * 0.8f, -6f + (i / 2) * 0.8f, f2)
    torch(k, 0f, f2 + 2.6f, -inner + 0.05f, 1.5708f)

    // ---- Third floor: the lord's quarters and throne.
    val f3 = levels[3]
    k.box(0f, f3 + 0.12f, inner - 2.2f, 3.2f, 0.12f, 2.0f, shadeRgb(stone, 1.05f), stoneF)
    k.floor(0f, inner - 2.2f, 3.2f, 2.0f, f3 + 0.24f)
    k.box(0f, f3 + 0.02f, 3f, 1.1f, 0.02f, 6f, 0x8A2A2A, FLAG_PLASTER)
    val ty = f3 + 0.24f
    k.box(0f, ty + 0.3f, inner - 1.3f, 0.7f, 0.3f, 0.6f, 0x8A6A2A, FLAG_WOOD, true)
    k.box(0f, ty + 1.5f, inner - 0.8f, 0.7f, 1.2f, 0.12f, 0x8A6A2A, FLAG_WOOD)
    k.box(0f, ty + 2.75f, inner - 0.8f, 0.25f, 0.2f, 0.1f, 0xFFC940, FLAG_GLOW)
    k.box(0f, ty + 0.62f, inner - 1.35f, 0.62f, 0.04f, 0.55f, bannerC, FLAG_PLASTER)
    banner(k, -3f, f3 + 3.2f, inner - 0.06f, 0f, bannerC)
    banner(k, 3f, f3 + 3.2f, inner - 0.06f, 0f, bannerC)
    // Canopy bed.
    bed(k, -8f, -3f, 0f, true, 0x6A1A2A, f3)
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        k.box(-8f + a * 1.05f, f3 + 1.3f, -3f + b * 0.8f, 0.05f, 1.3f, 0.05f, 0x4A3020, FLAG_WOOD)
    }
    k.box(-8f, f3 + 2.62f, -3f, 1.15f, 0.04f, 0.9f, 0x6A1A2A, FLAG_PLASTER)
    chest(k, -6.3f, -3f, 1.5708f, f3)
    fireplace(k, -inner + 0.5f, 4f, 0f, f3, shadeRgb(stone, 0.9f), top + 1.5f)
    table(k, 6f, -2f, false, f3, 4, seed + 4)
    k.box(6f, f3 + 0.84f, -2f, 0.6f, 0.01f, 0.4f, 0xD8C898, FLAG_PLASTER)
    bookshelf(k, inner - 0.25f, 3f, 3.1416f, f3, seed + 9)
    bookshelf(k, inner - 0.25f, 4.6f, 3.1416f, f3, seed + 10)
    torch(k, -3f, f3 + 2.6f, -inner + 0.05f, 1.5708f)
    torch(k, 3f, f3 + 2.6f, -inner + 0.05f, 1.5708f)

    // ---- On the roof: a flagpole over the keep.
    val f4 = levels[4]
    k.box(0f, f4 + 3f, 0f, 0.08f, 3f, 0.08f, 0x3A2818, FLAG_WOOD)
    k.box(1.1f, f4 + 5.2f, 0f, 1.1f, 0.7f, 0.03f, bannerC, FLAG_PLASTER)
    k.box(0f, f4 + 0.3f, 0f, 0.6f, 0.3f, 0.6f, shadeRgb(stone, 0.9f), stoneF, true)

    // Style touches.
    when (style) {
        Style.GREEN, Style.FOREST -> {
            // Moss and grass growing on the old stone.
            for (i in 0 until 26) {
                val side = i % 4
                val p = (roll(seed, 200 + i) - 0.5f) * 2f * inner
                val hy = 0.5f + roll(seed, 300 + i) * (top - 1f)
                val (mu, mw) = when (side) {
                    0 -> Pair(p, wc + t * 0.5f)
                    1 -> Pair(p, -wc - t * 0.5f)
                    2 -> Pair(wc + t * 0.5f, p)
                    else -> Pair(-wc - t * 0.5f, p)
                }
                if (side == 0 && abs(p) < gate + 1f && hy < gateH + 1f) continue
                k.blob(mu, hy, mw, 0.9f, 0.5f, 0.9f, pick(seed, 400 + i, intArrayOf(0x4E7034, 0x5E8A3A, 0x3E5A2E)), FLAG_LEAF, seed + i)
            }
            var gm = -inner - t + 0.5f
            while (gm < inner + t) {
                if (roll(seed, 500 + (gm * 2f).toInt()) > 0.6f) k.blob(gm, top + 0.95f, wc, 0.5f, 0.2f, 0.5f, 0x5E8A3A, FLAG_LEAF, seed + (gm * 3f).toInt())
                gm += 2f
            }
        }
        Style.SNOW -> {
            m = -inner - t + 0.5f
            while (m < inner + t) {
                for (side in intArrayOf(-1, 1)) {
                    k.box(m, top + 0.95f, side * wc, 0.52f, 0.08f, t * 0.52f, 0xF2F6FA, FLAG_SNOW)
                    k.box(side * wc, top + 0.95f, m, t * 0.52f, 0.08f, 0.52f, 0xF2F6FA, FLAG_SNOW)
                }
                m += 2f
            }
            k.box(0f, levels[4] + 0.05f, 0f, inner, 0.05f, inner, 0xF2F6FA, FLAG_SNOW)
            for (i in 0 until 10) {
                val p = -inner + i * 2.8f
                k.cone(p, gateH + 0.1f, wc + t * 0.5f + 0.1f, 0.12f, -1.2f, 4, 0xCFE8F8, FLAG_GLOW)
            }
        }
        Style.SAND -> {
            // Sand heaped against the walls.
            for (i in 0 until 12) {
                val p = (roll(seed, 600 + i) - 0.5f) * 2f * inner
                k.blob(p, 0.2f, -wc - t, 2.5f, 1.0f, 1.6f, 0xD9B77A, FLAG_SAND, seed + i)
                k.blob(wc + t, 0.2f, p, 1.6f, 1.0f, 2.5f, 0xD9B77A, FLAG_SAND, seed + i + 50)
            }
        }
        Style.DARK -> {
            // Iron spikes along the battlements and eerie glowing braziers.
            m = -inner - t + 1.5f
            while (m < inner + t) {
                for (side in intArrayOf(-1, 1)) {
                    k.cone(m, top + 0.9f, side * wc, 0.12f, 1.2f, 4, 0x2A2A2E, FLAG_SOLID)
                    k.cone(side * wc, top + 0.9f, m, 0.12f, 1.2f, 4, 0x2A2A2E, FLAG_SOLID)
                }
                m += 2f
            }
            for (bu in floatArrayOf(-gate - 2.5f, gate + 2.5f)) {
                k.prism(bu, 0f, wc + t + 1.5f, 0.35f, 0.5f, 1.3f, 6, 0x2A2A2E, FLAG_SOLID, true, 0.5f)
                k.prism(bu, 1.3f, wc + t + 1.5f, 0.45f, 0.4f, 0.1f, 8, 0x9A4AFF, FLAG_GLOW)
                k.flame(bu, 1.35f, wc + t + 1.5f, 0.35f, 1.0f)
            }
            for (i in 0 until 8) {
                val p = (roll(seed, 700 + i) - 0.5f) * 2f * inner
                k.limb(p, 0f, -wc - t - 2f, p + 0.3f, 1.4f, -wc - t - 2f, 0.07f, 0.03f, 0xD8D0C0, FLAG_SOLID)
            }
        }
    }
}
