package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Shapes a building is made of. */
object PartType {
    const val BOX = 0
    const val PRISM = 1
    const val CONE = 2
    const val BLOB = 3
    const val QUAD = 4
    const val FLAME = 5
    const val LIMB = 6
}

/** One shape, with its numbers in [f] (all in world space). */
class Part(val type: Int, val f: FloatArray, val rgb: Int, val flag: Int)

/** Something you bump into: a box turned [angle], reaching from height y0 to y1. */
class Solid(
    val x: Float, val z: Float, val hu: Float, val hw: Float, val angle: Float,
    val y0: Float, val y1: Float,
) {
    private val c = cos(angle)
    private val s = sin(angle)

    fun hits(px: Float, pz: Float, r: Float, feet: Float): Boolean {
        // You can walk under things above your head and step over very low things.
        if (feet + 1.75f < y0 || feet + 0.35f > y1) return false
        val dx = px - x
        val dz = pz - z
        val lu = dx * c + dz * s
        val lw = -dx * s + dz * c
        val eu = lu - lu.coerceIn(-hu, hu)
        val ew = lw - lw.coerceIn(-hw, hw)
        return eu * eu + ew * ew < r * r
    }

    /** Whether a small ball at (px, py, pz) touches this block. Used to stop the camera going through walls. */
    fun hitsPoint(px: Float, py: Float, pz: Float, r: Float): Boolean {
        if (py < y0 - r || py > y1 + r) return false
        val dx = px - x
        val dz = pz - z
        val lu = dx * c + dz * s
        val lw = -dx * s + dz * c
        val eu = lu - lu.coerceIn(-hu, hu)
        val ew = lw - lw.coerceIn(-hw, hw)
        return eu * eu + ew * ew < r * r
    }
}

/** Somewhere you can stand: a floor, or a ramp rising by [rise] along its length. */
class Walk(
    val x: Float, val z: Float, val hu: Float, val hw: Float, val angle: Float,
    val y0: Float, val rise: Float,
) {
    private val c = cos(angle)
    private val s = sin(angle)

    /** Height here, or NaN if (px, pz) isn't on it. */
    fun heightAt(px: Float, pz: Float): Float {
        val dx = px - x
        val dz = pz - z
        val lu = dx * c + dz * s
        val lw = -dx * s + dz * c
        if (abs(lu) > hu || abs(lw) > hw) return Float.NaN
        return y0 + rise * (lu / hu * 0.5f + 0.5f)
    }
}

/** Everything built at one place: what it looks like, what blocks you, and where you can stand. */
class Structure(val cx: Float, val cz: Float, val radius: Float) {
    val parts = ArrayList<Part>()
    val solids = ArrayList<Solid>()
    val walks = ArrayList<Walk>()
    val smoke = ArrayList<FloatArray>()
}

/** Building styles, one per region. */
object Style {
    const val GREEN = 0
    const val FOREST = 1
    const val SAND = 2
    const val SNOW = 3
    const val DARK = 4

    fun of(zone: Zone): Int = when (zone) {
        Zone.MEADOW -> GREEN
        Zone.FOREST -> FOREST
        Zone.DESERT -> SAND
        Zone.SNOW -> SNOW
        Zone.CAVES -> DARK
    }
}

/**
 * Builds in a building's own frame: u runs across its front, w points out through
 * the front door, y is height above the ground it stands on.
 */
class Kit(private val st: Structure, private val ox: Float, private val oy: Float, private val oz: Float, frontX: Float, frontZ: Float) {
    val angle = atan2(-frontX, frontZ)
    private val c = cos(angle)
    private val s = sin(angle)

    fun wx(u: Float, w: Float) = ox + u * c - w * s
    fun wz(u: Float, w: Float) = oz + u * s + w * c

    fun box(
        u: Float, y: Float, w: Float, hu: Float, hy: Float, hw: Float, rgb: Int,
        flag: Int = FLAG_SOLID, solid: Boolean = false, rot: Float = 0f,
    ) {
        val x = wx(u, w)
        val z = wz(u, w)
        st.parts.add(Part(PartType.BOX, floatArrayOf(x, oy + y, z, hu, hy, hw, angle + rot), rgb, flag))
        if (solid) st.solids.add(Solid(x, z, hu, hw, angle + rot, oy + y - hy, oy + y + hy))
    }

    /** A solid wall from (u0, w0) to (u1, w1), between heights y0 and y1. */
    fun wall(u0: Float, w0: Float, u1: Float, w1: Float, y0: Float, y1: Float, thick: Float, rgb: Int, flag: Int) {
        val du = u1 - u0
        val dw = w1 - w0
        val len = sqrt(du * du + dw * dw)
        if (len < 0.05f) return
        box((u0 + u1) * 0.5f, (y0 + y1) * 0.5f, (w0 + w1) * 0.5f, len * 0.5f, (y1 - y0) * 0.5f, thick * 0.5f, rgb, flag, true, atan2(dw, du))
    }

    /** Blocks you without drawing anything. */
    fun solidOnly(u: Float, w: Float, hu: Float, hw: Float, y0: Float, y1: Float) {
        st.solids.add(Solid(wx(u, w), wz(u, w), hu, hw, angle, oy + y0, oy + y1))
    }

    fun floor(u: Float, w: Float, hu: Float, hw: Float, y: Float, rise: Float = 0f) {
        st.walks.add(Walk(wx(u, w), wz(u, w), hu, hw, angle, oy + y, rise))
    }

    fun prism(u: Float, y0: Float, w: Float, r0: Float, r1: Float, h: Float, sides: Int, rgb: Int, flag: Int, cap: Boolean = true, solidR: Float = 0f) {
        val x = wx(u, w)
        val z = wz(u, w)
        st.parts.add(Part(PartType.PRISM, floatArrayOf(x, oy + y0, z, r0, r1, h, sides.toFloat(), angle, if (cap) 1f else 0f), rgb, flag))
        if (solidR > 0f) {
            st.solids.add(Solid(x, z, solidR, solidR, 0f, oy + y0, oy + y0 + h))
            st.solids.add(Solid(x, z, solidR, solidR, 0.785f, oy + y0, oy + y0 + h))
        }
    }

    fun cone(u: Float, y0: Float, w: Float, r: Float, h: Float, sides: Int, rgb: Int, flag: Int, rot: Float = 0f) {
        st.parts.add(Part(PartType.CONE, floatArrayOf(wx(u, w), oy + y0, wz(u, w), r, h, sides.toFloat(), angle + rot), rgb, flag))
    }

    fun blob(u: Float, y: Float, w: Float, rx: Float, ry: Float, rz: Float, rgb: Int, flag: Int, seed: Int) {
        st.parts.add(Part(PartType.BLOB, floatArrayOf(wx(u, w), oy + y, wz(u, w), rx, ry, rz, seed.toFloat()), rgb, flag))
    }

    fun quad(
        u1: Float, y1: Float, w1: Float, u2: Float, y2: Float, w2: Float,
        u3: Float, y3: Float, w3: Float, u4: Float, y4: Float, w4: Float,
        rgb: Int, flag: Int, cu: Float, cy: Float, cw: Float,
    ) {
        st.parts.add(
            Part(
                PartType.QUAD,
                floatArrayOf(
                    wx(u1, w1), oy + y1, wz(u1, w1), wx(u2, w2), oy + y2, wz(u2, w2),
                    wx(u3, w3), oy + y3, wz(u3, w3), wx(u4, w4), oy + y4, wz(u4, w4),
                    wx(cu, cw), oy + cy, wz(cu, cw),
                ),
                rgb, flag,
            ),
        )
    }

    fun flame(u: Float, y: Float, w: Float, width: Float, h: Float) {
        st.parts.add(Part(PartType.FLAME, floatArrayOf(wx(u, w), oy + y, wz(u, w), width, h, angle), 0xFF6A10, FLAG_FIRE))
    }

    fun limb(u0: Float, y0: Float, w0: Float, u1: Float, y1: Float, w1: Float, r0: Float, r1: Float, rgb: Int, flag: Int) {
        st.parts.add(Part(PartType.LIMB, floatArrayOf(wx(u0, w0), oy + y0, wz(u0, w0), wx(u1, w1), oy + y1, wz(u1, w1), r0, r1), rgb, flag))
    }

    fun smoke(u: Float, y: Float, w: Float) {
        st.smoke.add(floatArrayOf(wx(u, w), oy + y, wz(u, w)))
    }
}

private fun pick(seed: Int, k: Int, options: IntArray): Int =
    options[(hash(seed, k, 4242) * options.size).toInt().coerceIn(0, options.size - 1)]

private fun roll(seed: Int, k: Int): Float = hash(seed, k, 4243)

// ---------------------------------------------------------------- Furniture

private fun bed(k: Kit, u: Float, w: Float, rot: Float, double: Boolean, blanket: Int, y: Float) {
    val hw = if (double) 0.75f else 0.48f
    // Along the bed is "rot" direction; the frame is drawn as boxes turned by rot.
    val cu = cos(rot)
    val su = sin(rot)
    fun at(a: Float, b: Float): Pair<Float, Float> = Pair(u + a * cu - b * su, w + a * su + b * cu)
    k.box(u, y + 0.22f, w, 1.05f, 0.22f, hw, 0x6A4A30, FLAG_WOOD, true, rot)
    k.box(u, y + 0.5f, w, 1.0f, 0.08f, hw - 0.04f, 0xE8E2D4, FLAG_PLASTER, false, rot)
    val (bu, bw) = at(0.25f, 0f)
    k.box(bu, y + 0.6f, bw, 0.78f, 0.05f, hw, blanket, FLAG_PLASTER, false, rot)
    val (pu, pw) = at(-0.8f, 0f)
    k.box(pu, y + 0.63f, pw, 0.18f, 0.07f, hw - 0.12f, 0xF4F0E6, FLAG_PLASTER, false, rot)
    val (hu, hwp) = at(-1.08f, 0f)
    k.box(hu, y + 0.6f, hwp, 0.05f, 0.6f, hw + 0.04f, 0x5A3E28, FLAG_WOOD, false, rot)
}

private fun table(k: Kit, u: Float, w: Float, round: Boolean, y: Float, chairs: Int, seed: Int) {
    val top = y + 0.78f
    if (round) {
        k.prism(u, top - 0.05f, w, 0.75f, 0.75f, 0.06f, 12, 0x7A5634, FLAG_WOOD)
        k.prism(u, y, w, 0.1f, 0.1f, 0.74f, 6, 0x5A3E28, FLAG_WOOD)
        k.solidOnly(u, w, 0.6f, 0.6f, y, y + 0.8f)
    } else {
        k.box(u, top, w, 0.8f, 0.04f, 0.5f, 0x7A5634, FLAG_WOOD, true)
        for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
            k.box(u + a * 0.7f, y + 0.38f, w + b * 0.4f, 0.05f, 0.38f, 0.05f, 0x5A3E28, FLAG_WOOD)
        }
    }
    // A candle and maybe a bowl or a jug.
    k.prism(u + 0.15f, top + 0.02f, w - 0.1f, 0.04f, 0.04f, 0.16f, 6, 0xEDE6D0, FLAG_SOLID)
    k.flame(u + 0.15f, top + 0.18f, w - 0.1f, 0.025f, 0.08f)
    if (roll(seed, 3) > 0.4f) k.prism(u - 0.25f, top + 0.02f, w + 0.1f, 0.14f, 0.1f, 0.08f, 8, 0x8A6A4A, FLAG_WOOD)
    val spots = arrayOf(floatArrayOf(-1.15f, 0f), floatArrayOf(1.15f, 0f), floatArrayOf(0f, -0.9f), floatArrayOf(0f, 0.9f))
    for (i in 0 until chairs.coerceAtMost(4)) {
        val cu = u + spots[i][0]
        val cw = w + spots[i][1]
        chair(k, cu, cw, atan2(w - cw, u - cu), y)
    }
}

private fun chair(k: Kit, u: Float, w: Float, face: Float, y: Float) {
    k.box(u, y + 0.45f, w, 0.22f, 0.03f, 0.22f, 0x6A4A30, FLAG_WOOD, false, face)
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        k.box(u + a * 0.17f, y + 0.22f, w + b * 0.17f, 0.03f, 0.22f, 0.03f, 0x5A3E28, FLAG_WOOD)
    }
    val bu = u - cos(face) * 0.2f
    val bw = w - sin(face) * 0.2f
    k.box(bu, y + 0.75f, bw, 0.03f, 0.3f, 0.22f, 0x6A4A30, FLAG_WOOD, false, face)
}

/** A stone fireplace built against a wall, with a fire and a chimney going up. */
private fun fireplace(k: Kit, u: Float, w: Float, rot: Float, y: Float, stone: Int, chimneyTop: Float) {
    val cu = cos(rot)
    val su = sin(rot)
    // "rot" points out of the wall into the room.
    k.box(u, y + 0.8f, w, 0.45f, 0.8f, 1.1f, stone, FLAG_STONE, true, rot)
    k.box(u + cu * 0.3f, y + 0.55f, w + su * 0.3f, 0.2f, 0.45f, 0.62f, 0x1A1410, FLAG_SOLID, false, rot)
    k.box(u + cu * 0.55f, y + 0.06f, w + su * 0.55f, 0.35f, 0.06f, 1.2f, shadeRgb(stone, 0.85f), FLAG_STONE, false, rot)
    k.box(u, y + 1.62f, w, 0.55f, 0.08f, 1.25f, shadeRgb(stone, 0.9f), FLAG_STONE, false, rot)
    // Chimney breast up to the roof and out.
    val bh = (chimneyTop - (y + 1.7f)) * 0.5f
    k.box(u - cu * 0.1f, y + 1.7f + bh, w - su * 0.1f, 0.35f, bh, 0.55f, stone, FLAG_STONE, false, rot)
    val fu = u + cu * 0.28f
    val fw = w + su * 0.28f
    k.limb(fu - su * 0.3f, y + 0.18f, fw + cu * 0.3f, fu + su * 0.3f, y + 0.18f, fw - cu * 0.3f, 0.07f, 0.07f, 0x3A2818, FLAG_BARK)
    k.prism(fu, y + 0.12f, fw, 0.3f, 0.25f, 0.05f, 8, 0xFF5A18, FLAG_FIRE)
    k.flame(fu, y + 0.16f, fw, 0.2f, 0.6f)
    k.flame(fu + su * 0.15f, y + 0.16f, fw - cu * 0.15f, 0.15f, 0.45f)
    k.smoke(u - cu * 0.1f, chimneyTop, w - su * 0.1f)
}

private fun counter(k: Kit, u: Float, w: Float, rot: Float, y: Float, len: Float, seed: Int) {
    val cu = cos(rot)
    val su = sin(rot)
    k.box(u, y + 0.44f, w, len, 0.44f, 0.3f, 0x7A5A3A, FLAG_WOOD, true, rot)
    k.box(u, y + 0.9f, w, len + 0.03f, 0.03f, 0.33f, 0x9C968A, FLAG_STONE, false, rot)
    // Pots, jars and a cutting board.
    var t = -len + 0.3f
    var i = 0
    while (t < len - 0.2f) {
        val pu = u + cu * t
        val pw = w + su * t
        when (pick(seed, 20 + i, intArrayOf(0, 1, 2, 3))) {
            0 -> k.prism(pu, y + 0.93f, pw, 0.14f, 0.12f, 0.2f, 8, 0x3A3A3E, FLAG_SOLID)
            1 -> k.prism(pu, y + 0.93f, pw, 0.08f, 0.07f, 0.24f, 8, 0xB87A4A, FLAG_SOLID)
            2 -> k.box(pu, y + 0.94f, pw, 0.2f, 0.02f, 0.13f, 0xA07A4A, FLAG_WOOD, false, rot)
            else -> k.blob(pu, y + 1.0f, pw, 0.09f, 0.09f, 0.09f, pick(seed, 30 + i, intArrayOf(0xC83A2A, 0x6AA040, 0xE8A030)), FLAG_SOLID, seed + i)
        }
        t += 0.55f
        i++
    }
    // Shelf on the wall above.
    val bu = u - cu * 0.0f
    k.box(bu, y + 1.75f, w, len, 0.03f, 0.17f, 0x6A4A30, FLAG_WOOD, false, rot)
    t = -len + 0.25f
    while (t < len - 0.1f) {
        k.prism(u + cu * t, y + 1.78f, w + su * t, 0.06f, 0.06f, 0.18f, 6, pick(seed, (t * 10f).toInt(), intArrayOf(0x4A6A8A, 0x8A6A4A, 0x6A8A5A, 0xC9B08E)), FLAG_SOLID)
        t += 0.3f
    }
}

private fun rug(k: Kit, u: Float, w: Float, hu: Float, hw: Float, y: Float, rgb: Int, rot: Float = 0f) {
    k.box(u, y + 0.015f, w, hu, 0.015f, hw, rgb, FLAG_PLASTER, false, rot)
    k.box(u, y + 0.02f, w, hu - 0.12f, 0.012f, hw - 0.12f, shadeRgb(rgb, 1.25f), FLAG_PLASTER, false, rot)
}

private fun chest(k: Kit, u: Float, w: Float, rot: Float, y: Float) {
    k.box(u, y + 0.28f, w, 0.45f, 0.28f, 0.3f, 0x6A4A2A, FLAG_WOOD, true, rot)
    k.box(u, y + 0.58f, w, 0.47f, 0.04f, 0.32f, 0x5A3A20, FLAG_WOOD, false, rot)
    k.box(u, y + 0.35f, w, 0.47f, 0.04f, 0.32f, 0x4A4A4E, FLAG_SOLID, false, rot)
}

private fun barrel(k: Kit, u: Float, w: Float, y: Float) {
    k.prism(u, y, w, 0.33f, 0.36f, 0.45f, 10, 0x7A5634, FLAG_WOOD, false, 0.36f)
    k.prism(u, y + 0.45f, w, 0.36f, 0.33f, 0.45f, 10, 0x7A5634, FLAG_WOOD)
    k.prism(u, y + 0.43f, w, 0.37f, 0.37f, 0.05f, 10, 0x4A4A4E, FLAG_SOLID, false)
}

private fun bookshelf(k: Kit, u: Float, w: Float, rot: Float, y: Float, seed: Int) {
    val cu = cos(rot)
    val su = sin(rot)
    k.box(u, y + 1.0f, w, 0.2f, 1.0f, 0.7f, 0x5A3E28, FLAG_WOOD, true, rot)
    for (row in 0 until 4) {
        val ry = y + 0.25f + row * 0.48f
        var t = -0.6f
        var i = 0
        while (t < 0.6f) {
            val bw = 0.05f + 0.04f * roll(seed, row * 20 + i)
            val bh = 0.14f + 0.06f * roll(seed, row * 20 + i + 7)
            k.box(
                u + cu * 0.12f - su * t, ry + bh, w + su * 0.12f + cu * t, 0.1f, bh, bw,
                pick(seed, row * 20 + i, intArrayOf(0x8A2A2A, 0x2A4A7A, 0x3A6A3A, 0x7A5A2A, 0x5A3A6A, 0xB89A5A)),
                FLAG_SOLID, false, rot,
            )
            t += bw * 2f + 0.01f
            i++
        }
    }
}

private fun torch(k: Kit, u: Float, y: Float, w: Float, rot: Float) {
    val ou = u + cos(rot) * 0.25f
    val ow = w + sin(rot) * 0.25f
    k.limb(u, y, w, ou, y + 0.35f, ow, 0.05f, 0.04f, 0x3A2818, FLAG_WOOD)
    k.flame(ou, y + 0.35f, ow, 0.09f, 0.35f)
}

private fun banner(k: Kit, u: Float, y: Float, w: Float, rot: Float, rgb: Int) {
    k.box(u, y, w, 0.6f, 1.3f, 0.03f, rgb, FLAG_PLASTER, false, rot)
    k.box(u, y + 1.32f, w, 0.7f, 0.04f, 0.05f, 0x3A2818, FLAG_WOOD, false, rot)
    k.box(u, y, w, 0.2f, 0.25f, 0.035f, 0xFFC940, FLAG_GLOW, false, rot)
}

// ---------------------------------------------------------------- Houses

/**
 * A house you can walk into, about 8 by 6 metres inside. Looks follow the region;
 * the furniture layout is shuffled by [seed] so no two are quite the same inside.
 */
fun buildHouse(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, style: Int, seed: Int) {
    val k = Kit(st, x, y, z, frontX, frontZ)
    val iu = 4f
    val iw = 3f
    val t = 0.3f
    val wallH = 3.4f
    val fy = 0.3f

    val wallC: Int
    val wallF: Int
    val roofC: Int
    val roofF: Int
    val trim = 0x4A3424
    val stone: Int
    when (style) {
        Style.FOREST -> {
            wallC = 0x6A4A30; wallF = FLAG_WOOD; roofC = 0x4E5A34; roofF = FLAG_ROOF; stone = 0x7A766E
        }
        Style.SNOW -> {
            wallC = 0x8A8C92; wallF = FLAG_STONE; roofC = 0xEEF2F6; roofF = FLAG_SNOW; stone = 0x6E7078
        }
        Style.SAND -> {
            wallC = 0xCDA878; wallF = FLAG_PLASTER; roofC = 0xB8966A; roofF = FLAG_PLASTER; stone = 0xA88A62
        }
        Style.DARK -> {
            wallC = 0x3E3848; wallF = FLAG_STONE; roofC = 0x2A2430; roofF = FLAG_ROOF; stone = 0x4A4452
        }
        else -> {
            wallC = pick(seed, 1, intArrayOf(0xD8CDB4, 0xC9B08E, 0xBEB8AC))
            wallF = FLAG_PLASTER
            roofC = pick(seed, 2, intArrayOf(0x8A3A2A, 0x5A4A3A, 0x4E5A66, 0x7A5A2A))
            roofF = FLAG_ROOF
            stone = 0x8C877D
        }
    }
    val inner = shadeRgb(wallC, 0.82f)

    // Floor.
    k.box(0f, 0.15f, 0f, iu + t, 0.15f, iw + t, 0x7A746A, FLAG_STONE)
    k.box(0f, fy + 0.01f, 0f, iu, 0.01f, iw, if (style == Style.SAND || style == Style.DARK) shadeRgb(stone, 0.9f) else 0x8A6A48, if (style == Style.SAND || style == Style.DARK) FLAG_STONE else FLAG_WOOD)
    k.floor(0f, 0f, iu + t, iw + t, fy)
    // Walls: back, sides, and the front with a doorway.
    val doorU = pick(seed, 3, intArrayOf(-1, 0, 1)) * 1.4f
    // Steps up to the door, lined up with the doorway wherever it is along the front,
    // and reaching down into the ground so they never float where the land dips away.
    k.box(doorU, -0.2f, iw + t + 0.35f, 0.8f, 0.44f, 0.35f, stone, FLAG_STONE)
    k.box(doorU, -0.4f, iw + t + 0.95f, 0.8f, 0.4f, 0.28f, shadeRgb(stone, 0.92f), FLAG_STONE)
    k.floor(doorU, iw + t + 0.35f, 0.8f, 0.35f, 0.24f)
    k.floor(doorU, iw + t + 0.95f, 0.8f, 0.28f, 0f)
    val doorHalf = 0.7f
    val doorTop = 2.4f
    val wy0 = 0f
    k.wall(-iu - t, -iw - t * 0.5f, iu + t, -iw - t * 0.5f, wy0, wallH, t, wallC, wallF)
    k.wall(-iu - t * 0.5f, -iw, -iu - t * 0.5f, iw, wy0, wallH, t, wallC, wallF)
    k.wall(iu + t * 0.5f, -iw, iu + t * 0.5f, iw, wy0, wallH, t, wallC, wallF)
    k.wall(-iu - t, iw + t * 0.5f, doorU - doorHalf, iw + t * 0.5f, wy0, wallH, t, wallC, wallF)
    k.wall(doorU + doorHalf, iw + t * 0.5f, iu + t, iw + t * 0.5f, wy0, wallH, t, wallC, wallF)
    k.wall(doorU - doorHalf, iw + t * 0.5f, doorU + doorHalf, iw + t * 0.5f, doorTop, wallH, t, wallC, wallF)
    // Inside faces a little darker, as rooms are.
    k.box(0f, fy + 1.6f, -iw + 0.01f, iu, 1.5f, 0.01f, inner, wallF)
    // The door, swung open against the inside wall.
    k.box(doorU - doorHalf + 0.05f, fy + 1.05f, iw - 0.55f, 0.04f, 1.05f, 0.55f, 0x5A3A22, FLAG_WOOD)
    k.box(doorU - doorHalf + 0.1f, fy + 1.05f, iw - 0.95f, 0.04f, 0.04f, 0.04f, 0xC9A227, FLAG_SOLID)
    k.box(doorU, doorTop + 0.1f, iw + t + 0.02f, doorHalf + 0.12f, 0.1f, 0.04f, trim, FLAG_WOOD)

    // Windows on the sides and back, with shutters outside.
    val glass = if (style == Style.DARK) 0x9A5AFF else 0x3A4A5A
    val glassF = if (style == Style.DARK) FLAG_GLOW else FLAG_SOLID
    for (side in intArrayOf(-1, 1)) {
        val wu = side * (iu + t + 0.02f)
        k.box(wu, 1.8f, 0f, 0.03f, 0.45f, 0.5f, glass, glassF)
        k.box(side * (iu - 0.02f), 1.8f, 0f, 0.02f, 0.45f, 0.5f, glass, glassF)
        k.box(wu, 1.8f, 0f, 0.05f, 0.04f, 0.55f, trim, FLAG_WOOD)
        if (style != Style.SAND) {
            k.box(wu + side * 0.03f, 1.8f, 0.72f, 0.03f, 0.47f, 0.18f, 0x3A6A4A, FLAG_WOOD)
            k.box(wu + side * 0.03f, 1.8f, -0.72f, 0.03f, 0.47f, 0.18f, 0x3A6A4A, FLAG_WOOD)
        }
    }
    for (wu in floatArrayOf(-2.2f, 2.2f)) {
        k.box(wu, 1.8f, -iw - t - 0.02f, 0.5f, 0.45f, 0.03f, glass, glassF)
        k.box(wu, 1.8f, -iw + 0.02f, 0.5f, 0.45f, 0.02f, glass, glassF)
    }
    val frontWinU = if (doorU <= 0f) 2.4f else -2.4f
    k.box(frontWinU, 1.8f, iw + t + 0.02f, 0.5f, 0.45f, 0.03f, glass, glassF)
    k.box(frontWinU, 1.8f, iw - 0.02f, 0.5f, 0.45f, 0.02f, glass, glassF)

    // Timber frame for the meadow cottages.
    if (style == Style.GREEN) {
        for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
            k.box(a * (iu + t), (wallH - 0.15f) * 0.5f, b * (iw + t), 0.16f, (wallH - 0.15f) * 0.5f, 0.16f, trim, FLAG_WOOD)
        }
        for (b in intArrayOf(-1, 1)) {
            k.box(0f, wallH - 0.22f, b * (iw + t + 0.03f), iu + t, 0.1f, 0.05f, trim, FLAG_WOOD)
        }
        // The middle band goes all the way round the back, but stops either side of the door.
        k.box(0f, 1.2f, -(iw + t + 0.03f), iu + t, 0.08f, 0.05f, trim, FLAG_WOOD)
        val leftEnd = doorU - doorHalf - 0.06f
        val rightEnd = doorU + doorHalf + 0.06f
        val outer = iu + t
        k.box((-outer + leftEnd) * 0.5f, 1.2f, iw + t + 0.03f, (leftEnd + outer) * 0.5f, 0.08f, 0.05f, trim, FLAG_WOOD)
        k.box((rightEnd + outer) * 0.5f, 1.2f, iw + t + 0.03f, (outer - rightEnd) * 0.5f, 0.08f, 0.05f, trim, FLAG_WOOD)
        // Upright posts framing the doorway, so the band has something to stop against.
        for (e in floatArrayOf(doorU - doorHalf - 0.06f, doorU + doorHalf + 0.06f)) {
            k.box(e, doorTop * 0.5f, iw + t + 0.04f, 0.07f, doorTop * 0.5f, 0.06f, trim, FLAG_WOOD)
        }
    }
    // Foundation stones.
    k.box(0f, 0.25f, 0f, iu + t + 0.08f, 0.25f, iw + t + 0.08f, stone, FLAG_STONE)

    // Roof.
    val eaveW = iw + t + 0.6f
    val eaveU = iu + t + 0.45f
    if (style == Style.SAND) {
        // Flat roof with a low wall round the edge and beam ends poking out.
        k.box(0f, wallH + 0.1f, 0f, iu + t, 0.12f, iw + t, roofC, roofF)
        for (b in intArrayOf(-1, 1)) {
            k.box(0f, wallH + 0.45f, b * (iw + t - 0.1f), iu + t, 0.25f, 0.1f, wallC, FLAG_PLASTER)
            k.box(b * (iu + t - 0.1f), wallH + 0.45f, 0f, 0.1f, 0.25f, iw + t, wallC, FLAG_PLASTER)
        }
        var bu = -iu + 0.5f
        while (bu < iu) {
            k.limb(bu, wallH - 0.25f, iw + t, bu, wallH - 0.25f, iw + t + 0.5f, 0.09f, 0.08f, 0x5A3E28, FLAG_BARK)
            bu += 1.3f
        }
    } else {
        val ridgeY = wallH + if (style == Style.SNOW) 2.8f else 2.2f
        // The roof plane passes exactly over the outer top edge of the front and back
        // walls, so it sits right on them with no gap, then carries on out to the eaves.
        val wo = iw + t
        val slope = (ridgeY - wallH) / wo
        val eaveY = wallH - (eaveW - wo) * slope
        // Thick enough that the ceiling meets the inside top edge of the walls exactly.
        val thick = t * slope + 0.02f
        // Two slopes meeting along the ridge, running across the front.
        k.quad(-eaveU, eaveY, eaveW, eaveU, eaveY, eaveW, eaveU, ridgeY, 0f, -eaveU, ridgeY, 0f, roofC, roofF, 0f, 0f, 0f)
        k.quad(-eaveU, eaveY, -eaveW, eaveU, eaveY, -eaveW, eaveU, ridgeY, 0f, -eaveU, ridgeY, 0f, shadeRgb(roofC, 0.92f), roofF, 0f, 0f, 0f)
        // Underside of the overhang and the ceiling inside, a roof-thickness lower.
        k.quad(-eaveU, eaveY - thick, eaveW, eaveU, eaveY - thick, eaveW, eaveU, ridgeY - thick, 0f, -eaveU, ridgeY - thick, 0f, 0x5A4430, FLAG_WOOD, 0f, 10f, 0f)
        k.quad(-eaveU, eaveY - thick, -eaveW, eaveU, eaveY - thick, -eaveW, eaveU, ridgeY - thick, 0f, -eaveU, ridgeY - thick, 0f, 0x5A4430, FLAG_WOOD, 0f, 10f, 0f)
        // Fascia boards closing the edge along each eave and each gable end.
        for (b in intArrayOf(-1, 1)) {
            k.box(0f, eaveY - thick * 0.5f, b * eaveW, eaveU, thick * 0.5f, 0.04f, shadeRgb(roofC, 0.75f), FLAG_WOOD)
        }
        for (side in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
            k.quad(
                side * eaveU, eaveY, b * eaveW, side * eaveU, ridgeY, 0f,
                side * eaveU, ridgeY - thick, 0f, side * eaveU, eaveY - thick, b * eaveW,
                shadeRgb(roofC, 0.75f), FLAG_WOOD, 0f, wallH, 0f,
            )
        }
        k.box(0f, ridgeY + 0.05f, 0f, eaveU, 0.1f, 0.14f, shadeRgb(roofC, 0.7f), FLAG_WOOD)
        // Triangle ends above the side walls, reaching right up under the roof.
        for (side in intArrayOf(-1, 1)) for (face in intArrayOf(-1, 1)) {
            val su = side * (iu + t * 0.5f) + face * t * 0.5f
            k.quad(su, wallH - 0.02f, -wo, su, wallH - 0.02f, wo, su, ridgeY, 0f, su, ridgeY, 0f, if (face == side) wallC else inner, wallF, su - face * 5f, wallH, 0f)
        }
    }

    // ---- Inside. Everything is placed relative to which end the fireplace is on.
    val fs = if (roll(seed, 5) > 0.5f) 1f else -1f
    val fireW = pick(seed, 6, intArrayOf(-1, 0)) * 0.9f
    fireplace(k, fs * (iu - 0.45f), fireW, if (fs > 0f) 3.1416f else 0f, fy, stone, wallH + 3.2f)

    val blankets = intArrayOf(0x8A2A2A, 0x2A4A7A, 0x3A6A3A, 0x7A5A8A, 0xC9A060, 0x6A4A6A)
    val double = roll(seed, 7) > 0.45f
    val bedU = -fs * (iu - 1.1f)
    val bedW = -iw + 1.15f
    bed(k, bedU, bedW, 1.5708f, double, pick(seed, 8, blankets), fy)
    if (roll(seed, 9) > 0.35f) chest(k, bedU, bedW + 1.55f, 0f, fy)

    val counterU = pick(seed, 10, intArrayOf(-1, 0, 1)) * 0.6f + fs * 0.4f
    counter(k, counterU, -iw + 0.35f, 0f, fy, 1.1f, seed)

    val tableU = fs * 1.1f + (roll(seed, 11) - 0.5f) * 0.8f
    val tableW = 0.5f + (roll(seed, 12) - 0.5f) * 0.4f
    val rugs = intArrayOf(0x8A3A2A, 0x2A4A6A, 0x6A5A2A, 0x4A6A4A, 0x6A2A4A)
    rug(k, tableU, tableW, 1.6f, 1.2f, fy, pick(seed, 13, rugs))
    table(k, tableU, tableW, roll(seed, 14) > 0.5f, fy, 2 + (roll(seed, 15) * 3f).toInt(), seed)

    // One or two extras, different in each house.
    val extraU = -fs * (iu - 0.35f)
    when (pick(seed, 16, intArrayOf(0, 1, 2))) {
        0 -> bookshelf(k, extraU, 1.4f, if (fs > 0f) 0f else 3.1416f, fy, seed)
        1 -> {
            barrel(k, extraU, 1.6f, fy)
            barrel(k, extraU, 2.35f, fy)
        }
        else -> k.box(extraU, fy + 0.9f, 1.8f, 0.3f, 0.9f, 0.55f, 0x5A3E28, FLAG_WOOD, true)
    }
    if (roll(seed, 17) > 0.5f) barrel(k, doorU + if (doorU > 0f) -1.3f else 1.3f, iw - 0.45f, fy)
    // Hanging lamp.
    k.limb(0f, wallH + 0.8f, 0f, 0f, wallH - 0.35f, 0f, 0.02f, 0.02f, 0x2A2A2A, FLAG_SOLID)
    k.prism(0f, wallH - 0.55f, 0f, 0.12f, 0.08f, 0.2f, 6, 0xFFC860, FLAG_GLOW)

    // Walls block you; the doorway doesn't.
    // (Walls and furniture above already added their own solids.)
}

/** A stone well with a little roof. */
fun buildWell(st: Structure, x: Float, y: Float, z: Float, style: Int) {
    val k = Kit(st, x, y, z, 0f, 1f)
    val stone = when (style) {
        Style.SAND -> 0xA88A62
        Style.DARK -> 0x4A4452
        Style.SNOW -> 0x8A8C92
        else -> 0x8C877D
    }
    k.prism(0f, -0.3f, 0f, 1.25f, 1.2f, 1.25f, 12, stone, FLAG_STONE, false, 1.25f)
    k.prism(0f, -0.3f, 0f, 0.92f, 0.92f, 1.24f, 12, shadeRgb(stone, 0.6f), FLAG_STONE, false)
    // Rim.
    for (i in 0 until 12) {
        val a0 = i * 6.2831855f / 12f
        val a1 = (i + 1) * 6.2831855f / 12f
        k.quad(
            cos(a0) * 0.92f, 0.95f, sin(a0) * 0.92f, cos(a1) * 0.92f, 0.95f, sin(a1) * 0.92f,
            cos(a1) * 1.22f, 0.95f, sin(a1) * 1.22f, cos(a0) * 1.22f, 0.95f, sin(a0) * 1.22f,
            shadeRgb(stone, 1.1f), FLAG_STONE, 0f, -4f, 0f,
        )
    }
    k.prism(0f, 0.3f, 0f, 0.9f, 0.9f, 0.02f, 12, 0x1E3A5A, FLAG_WATER)
    for (side in intArrayOf(-1, 1)) {
        k.box(side * 1.12f, 1.35f, 0f, 0.09f, 1.35f, 0.09f, 0x5A3E22, FLAG_WOOD)
    }
    k.box(0f, 2.35f, 0f, 1.2f, 0.06f, 0.06f, 0x5A3E22, FLAG_WOOD)
    k.limb(0f, 2.3f, 0f, 0f, 1.3f, 0f, 0.012f, 0.012f, 0x8A7A5A, FLAG_SOLID)
    k.prism(0f, 1.0f, 0f, 0.16f, 0.18f, 0.3f, 8, 0x6A4A2A, FLAG_WOOD)
    val roof = if (style == Style.SNOW) 0xEEF2F6 else 0x7A3A2A
    val rf = if (style == Style.SNOW) FLAG_SNOW else FLAG_ROOF
    k.quad(-1.45f, 2.3f, 0.95f, 1.45f, 2.3f, 0.95f, 1.45f, 3.1f, 0f, -1.45f, 3.1f, 0f, roof, rf, 0f, 0f, 0f)
    k.quad(-1.45f, 2.3f, -0.95f, 1.45f, 2.3f, -0.95f, 1.45f, 3.1f, 0f, -1.45f, 3.1f, 0f, shadeRgb(roof, 0.92f), rf, 0f, 0f, 0f)
}

// ---------------------------------------------------------------- Castles

/**
 * A great four-storey keep, about 28 m square and 21 m to the battlements, with
 * towers at each corner. Stairs climb the back wall from floor to floor up to the
 * roof. Every floor is furnished: great hall, bedrooms, library and armoury, and
 * the lord's quarters with a throne.
 */
fun buildKeep(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, style: Int, seed: Int) {
    val k = Kit(st, x, y, z, frontX, frontZ)
    val inner = KEEP_INNER
    val t = 1.2f
    val levels = floatArrayOf(0.3f, 5.3f, 10.3f, 15.3f, 20.3f)
    val top = 21.5f
    val gate = 1.9f
    val gateH = 4.4f

    val stone: Int
    val stoneF: Int
    val roofC: Int
    val roofF: Int
    val bannerC: Int
    val floorC: Int
    when (style) {
        Style.FOREST -> {
            stone = 0x6E726A; stoneF = FLAG_STONE; roofC = 0x3E4A2E; roofF = FLAG_ROOF; bannerC = 0x2E6A3A; floorC = 0x6A4A30
        }
        Style.SNOW -> {
            stone = 0xB8C0CC; stoneF = FLAG_STONE; roofC = 0xEEF2F6; roofF = FLAG_SNOW; bannerC = 0x6A2A4A; floorC = 0x8A8C92
        }
        Style.SAND -> {
            stone = 0xCBA774; stoneF = FLAG_STONE; roofC = 0xD8B884; roofF = FLAG_PLASTER; bannerC = 0xB83A2A; floorC = 0xA88A62
        }
        Style.DARK -> {
            stone = 0x2E2A36; stoneF = FLAG_STONE; roofC = 0x1E1A24; roofF = FLAG_ROOF; bannerC = 0x7A1A2A; floorC = 0x3A3444
        }
        else -> {
            stone = 0x8C8A84; stoneF = FLAG_STONE; roofC = 0x4E5A66; roofF = FLAG_ROOF; bannerC = 0x9A2A24; floorC = 0x7A6A5A
        }
    }
    val innerWall = shadeRgb(stone, 0.78f)
    val windowC = when (style) {
        Style.DARK -> 0x9A4AFF
        Style.SNOW -> 0x8ABCE0
        else -> 0x2A3440
    }
    val windowF = if (style == Style.DARK || style == Style.SNOW) FLAG_GLOW else FLAG_SOLID

    // ---- Outer walls. The front has a great gate.
    val wc = inner + t * 0.5f
    k.wall(-inner - t, -wc, inner + t, -wc, 0f, top, t, stone, stoneF)
    k.wall(-wc, -inner, -wc, inner, 0f, top, t, stone, stoneF)
    k.wall(wc, -inner, wc, inner, 0f, top, t, stone, stoneF)
    k.wall(-inner - t, wc, -gate, wc, 0f, top, t, stone, stoneF)
    k.wall(gate, wc, inner + t, wc, 0f, top, t, stone, stoneF)
    k.wall(-gate, wc, gate, wc, gateH, top, t, stone, stoneF)
    // Darker inside faces.
    k.box(0f, top * 0.5f, -inner + 0.01f, inner, top * 0.5f - 0.3f, 0.01f, innerWall, stoneF)
    k.box(-inner + 0.01f, top * 0.5f, 0f, 0.01f, top * 0.5f - 0.3f, inner, innerWall, stoneF)
    k.box(inner - 0.01f, top * 0.5f, 0f, 0.01f, top * 0.5f - 0.3f, inner, innerWall, stoneF)
    // Plinth and a band of trim at each floor.
    k.box(0f, 0.4f, 0f, inner + t + 0.3f, 0.6f, inner + t + 0.3f, shadeRgb(stone, 0.8f), stoneF)
    for (l in 1..4) {
        val ly = levels[l] - 0.15f
        k.box(0f, ly, -wc - t * 0.5f - 0.1f, inner + t, 0.15f, 0.12f, shadeRgb(stone, 0.85f), stoneF)
        k.box(0f, ly, wc + t * 0.5f + 0.1f, inner + t, 0.15f, 0.12f, shadeRgb(stone, 0.85f), stoneF)
        k.box(-wc - t * 0.5f - 0.1f, ly, 0f, 0.12f, 0.15f, inner + t, shadeRgb(stone, 0.85f), stoneF)
        k.box(wc + t * 0.5f + 0.1f, ly, 0f, 0.12f, 0.15f, inner + t, shadeRgb(stone, 0.85f), stoneF)
    }
    // Battlements.
    var m = -inner - t + 0.5f
    while (m < inner + t) {
        for (side in intArrayOf(-1, 1)) {
            k.box(m, top + 0.45f, side * wc, 0.5f, 0.45f, t * 0.5f, stone, stoneF)
            k.box(side * wc, top + 0.45f, m, t * 0.5f, 0.45f, 0.5f, stone, stoneF)
        }
        m += 2f
    }

    // ---- Windows: tall slits on every floor.
    for (l in 0..3) {
        val wy = levels[l] + 2.3f
        for (p in floatArrayOf(-12f, -4.5f, 4.5f, 12f)) {
            for (side in intArrayOf(-1, 1)) {
                if (!(l == 0 && side == 1 && abs(p) < 3f)) {
                    k.box(p, wy, side * (wc + t * 0.5f + 0.02f), 0.35f, 0.9f, 0.03f, windowC, windowF)
                }
                k.box(side * (wc + t * 0.5f + 0.02f), wy, p, 0.03f, 0.9f, 0.35f, windowC, windowF)
                k.box(p, wy, side * (inner - 0.02f), 0.35f, 0.9f, 0.02f, windowC, windowF)
                k.box(side * (inner - 0.02f), wy, p, 0.02f, 0.9f, 0.35f, windowC, windowF)
            }
        }
    }

    // ---- The gate: arch trim, raised portcullis, torches and banners.
    k.box(0f, gateH + 0.3f, wc + t * 0.5f + 0.1f, gate + 0.5f, 0.35f, 0.15f, shadeRgb(stone, 0.8f), stoneF)
    var bar = -gate + 0.25f
    while (bar < gate) {
        k.box(bar, gateH - 0.4f, wc, 0.05f, 0.45f, 0.05f, 0x2A2A2E, FLAG_SOLID)
        bar += 0.45f
    }
    torch(k, -gate - 0.8f, 2.4f, wc + t * 0.5f, 1.5708f)
    torch(k, gate + 0.8f, 2.4f, wc + t * 0.5f, 1.5708f)
    banner(k, -6f, 9f, wc + t * 0.5f + 0.05f, 0f, bannerC)
    banner(k, 6f, 9f, wc + t * 0.5f + 0.05f, 0f, bannerC)
    k.box(0f, 0.2f, wc + 3f, gate + 0.4f, 0.2f, 2.4f, shadeRgb(stone, 0.9f), stoneF)

    // ---- Corner towers.
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        val tu = a * (inner + t)
        val tw = b * (inner + t)
        val th = top + 5f
        k.prism(tu, -0.3f, tw, 4.0f, 3.7f, th + 0.3f, 12, stone, stoneF, true, 3.8f)
        k.prism(tu, th, tw, 4.3f, 4.3f, 1.0f, 12, shadeRgb(stone, 0.9f), stoneF)
        for (l in 0..3) {
            val slit = levels[l] + 2.5f
            k.box(tu + a * 3.85f, slit, tw, 0.05f, 0.7f, 0.25f, windowC, windowF)
            k.box(tu, slit, tw + b * 3.85f, 0.25f, 0.7f, 0.05f, windowC, windowF)
        }
        when (style) {
            Style.SAND -> {
                k.blob(tu, th + 1.0f, tw, 3.8f, 3.4f, 3.8f, roofC, roofF, seed + a * 3 + b)
                k.prism(tu, th + 4.2f, tw, 0.08f, 0.02f, 1.5f, 4, 0xFFC940, FLAG_GLOW)
            }
            Style.DARK -> {
                k.cone(tu, th + 1.0f, tw, 4.4f, 11f, 12, roofC, roofF)
                k.cone(tu, th + 11.5f, tw, 0.25f, 2.5f, 4, 0x9A4AFF, FLAG_GLOW)
            }
            else -> k.cone(tu, th + 1.0f, tw, 4.6f, 6.5f, 12, roofC, roofF)
        }
        // Flag on top.
        val fh = if (style == Style.DARK) th + 14f else if (style == Style.SAND) th + 5.7f else th + 7.5f
        k.box(tu, fh + 1.0f, tw, 0.05f, 1.2f, 0.05f, 0x3A2818, FLAG_WOOD)
        k.box(tu + 0.6f, fh + 1.7f, tw, 0.6f, 0.4f, 0.02f, bannerC, FLAG_PLASTER)
    }

    // ---- Floors and stairs.
    // The stairs run along the back wall in two lanes, a switchback: flights 0 and 2
    // climb in the outer lane (against the wall) going +u, flights 1 and 3 climb in
    // the inner lane going back -u. At the top of each flight you step round the end
    // into the other lane and carry on up. Flights never sit above each other's tops,
    // so nothing blocks the way.
    val laneW = 1.5f
    val stripIn = -inner + laneW * 2f
    val laneO = -inner + laneW * 0.5f
    val laneI = -inner + laneW * 1.5f
    val laneEdge = -inner + laneW
    val sA = -5f
    val sB = 5f
    val runLen = sB - sA
    val rise = levels[1] - levels[0]
    val railC = 0x5A3E28
    val mainC = (stripIn + inner) * 0.5f
    val mainH = (inner - stripIn) * 0.5f

    k.box(0f, 0.15f, 0f, inner, 0.15f, inner, floorC, FLAG_STONE)
    k.floor(0f, 0f, inner, inner, levels[0])

    // A floor slab over one lane, from u0 to u1.
    fun laneFloor(lw: Float, u0: Float, u1: Float, y0: Float) {
        if (u1 - u0 < 0.05f) return
        k.box((u0 + u1) * 0.5f, y0 - 0.15f, lw, (u1 - u0) * 0.5f, 0.15f, laneW * 0.5f, floorC, FLAG_STONE)
        k.floor((u0 + u1) * 0.5f, lw, (u1 - u0) * 0.5f, laneW * 0.5f, y0)
    }

    // A waist-high rail from (u0, w0) to (u1, w1) at a steady height, drawn and solid.
    fun flatRail(u0: Float, w0: Float, u1: Float, w1: Float, y0: Float) {
        k.wall(u0, w0, u1, w1, y0, y0 + 1.0f, 0.12f, railC, FLAG_WOOD)
    }

    for (l in 1..4) {
        val y0 = levels[l]
        k.box(0f, y0 - 0.15f, mainC, inner, 0.15f, mainH, floorC, FLAG_STONE)
        k.floor(0f, mainC, inner, mainH, y0)
        // The flight coming up from below lands here; leave a hole over it.
        val holeOuter = l % 2 == 1
        val holeLane = if (holeOuter) laneO else laneI
        val fullLane = if (holeOuter) laneI else laneO
        laneFloor(fullLane, -inner, inner, y0)
        laneFloor(holeLane, -inner, sA, y0)
        laneFloor(holeLane, sB, inner, y0)
        // Where the flight below starts low, a rail across the end of the hole.
        val lowEnd = if (holeOuter) sA else sB
        val hw0 = if (holeOuter) -inner else laneEdge
        val hw1 = if (holeOuter) laneEdge else stripIn
        flatRail(lowEnd, hw0 + 0.06f, lowEnd, hw1 - 0.06f, y0)
        // Along the side of the hole that faces the room (the wall guards the other).
        // (Where a flight climbs beside the hole, that flight's own handrail does the job.)
        if (!holeOuter) flatRail(sA, stripIn, sB, stripIn, y0)
        if (l == 4) flatRail(sA, laneEdge, sB, laneEdge, y0)
    }

    // The four flights.
    for (l in 0..3) {
        val y0 = levels[l]
        val outer = l % 2 == 0
        val lw = if (outer) laneO else laneI
        val dir = if (outer) 1f else -1f
        val startU = if (outer) sA else sB
        // Ramp you walk on: rises "rise" from startU to the far end.
        k.floor((sA + sB) * 0.5f, lw, runLen * 0.5f, laneW * 0.5f, if (outer) y0 else y0 + rise, if (outer) rise else -rise)
        // Visible steps, each a solid stone block down to the floor it stands on.
        val steps = 14
        for (sIdx in 0 until steps) {
            val f = (sIdx + 0.5f) / steps
            val su = startU + dir * f * runLen
            val sy = y0 + (sIdx + 0.6f) / steps * rise
            k.box(su, (y0 + sy) * 0.5f, lw, runLen / steps * 0.5f, (sy - y0) * 0.5f, laneW * 0.5f, shadeRgb(floorC, 0.9f), FLAG_STONE)
        }
        // You can only get on at the bottom end, not climb in from the side or underneath.
        for (sIdx in 1 until runLen.toInt()) {
            val su = startU + dir * (sIdx + 0.5f)
            k.solidOnly(su, lw, 0.5f, laneW * 0.5f, y0 - 0.3f, y0 + sIdx * rise / runLen)
        }
        // A sloping handrail on the open side, between the two lanes (or facing the room).
        val railW = if (outer) laneEdge - 0.06f else stripIn - 0.06f
        k.limb(startU, y0 + 1.0f, railW, startU + dir * runLen, y0 + rise + 1.0f, railW, 0.05f, 0.05f, railC, FLAG_WOOD)
        var pu = 0f
        while (pu <= runLen + 0.01f) {
            val py = y0 + pu / runLen * rise
            k.box(startU + dir * pu, py + 0.5f, railW, 0.05f, 0.5f, 0.05f, railC, FLAG_WOOD)
            pu += 2.5f
        }
        for (sIdx in 0 until runLen.toInt()) {
            val su = startU + dir * (sIdx + 0.5f)
            val sy = y0 + (sIdx + 0.5f) / runLen * rise
            k.solidOnly(su, railW, 0.5f, 0.06f, sy - 0.2f, sy + 1.1f)
        }
        // Inner-lane flights also need a rail on the lane-edge side, above the hole.
        if (!outer) {
            val ew = laneEdge + 0.06f
            k.limb(startU, y0 + 1.0f, ew, startU + dir * runLen, y0 + rise + 1.0f, ew, 0.05f, 0.05f, railC, FLAG_WOOD)
            for (sIdx in 0 until runLen.toInt()) {
                val su = startU + dir * (sIdx + 0.5f)
                val sy = y0 + (sIdx + 0.5f) / runLen * rise
                k.solidOnly(su, ew, 0.5f, 0.06f, sy - 0.2f, sy + 1.1f)
            }
        }
    }

    // ---- Ground floor: the great hall.
    val f0 = levels[0]
    k.box(0f, f0 + 0.02f, 7f, 1.2f, 0.02f, 5.6f, bannerC, FLAG_PLASTER)
    k.box(0f, f0 + 0.95f, 1f, 6f, 0.05f, 1.0f, 0x6A4A30, FLAG_WOOD, true)
    for (lx in floatArrayOf(-5.5f, 0f, 5.5f)) k.box(lx, f0 + 0.45f, 1f, 0.12f, 0.45f, 0.8f, 0x5A3E28, FLAG_WOOD)
    for (side in floatArrayOf(-1.6f, 3.6f)) k.box(0f, f0 + 0.45f, side, 6f, 0.05f, 0.28f, 0x6A4A30, FLAG_WOOD, true)
    var cx = -5f
    while (cx <= 5f) {
        k.prism(cx, f0 + 1.0f, 1f, 0.05f, 0.05f, 0.25f, 6, 0xEDE6D0, FLAG_SOLID)
        k.flame(cx, f0 + 1.25f, 1f, 0.03f, 0.1f)
        k.prism(cx + 1f, f0 + 1.0f, 1.3f, 0.2f, 0.15f, 0.06f, 8, 0x9C968A, FLAG_STONE)
        cx += 2.5f
    }
    k.box(0f, f0 + 1.35f, -0.2f, 0.5f, 0.35f, 0.4f, 0x7A3A2A, FLAG_WOOD, true)
    fireplace(k, inner - 0.5f, 2f, 3.1416f, f0, shadeRgb(stone, 0.9f), top + 1.5f)
    fireplace(k, -inner + 0.5f, 2f, 0f, f0, shadeRgb(stone, 0.9f), top + 1.5f)
    for (p in floatArrayOf(-8f, 8f)) {
        banner(k, p, f0 + 3.2f, -inner + 0.06f, 3.1416f, bannerC)
        torch(k, p * 1.3f, f0 + 2.6f, -inner + 0.05f, 1.5708f)
    }
    barrel(k, -inner + 0.6f, 10f, f0)
    barrel(k, -inner + 0.6f, 11.1f, f0)
    barrel(k, -inner + 1.5f, 11f, f0)
    barrel(k, inner - 0.6f, 11f, f0)
    chest(k, inner - 0.8f, 8.5f, 1.5708f, f0)

    // ---- First floor: bedrooms.
    val f1 = levels[1]
    val blankets = intArrayOf(0x8A2A2A, 0x2A4A7A, 0x3A6A3A, 0x7A5A8A)
    var bi = 0
    for (bu in floatArrayOf(-9f, -4.5f, 4.5f, 9f)) {
        bed(k, bu, inner - 1.2f, -1.5708f, bi % 2 == 0, blankets[bi], f1)
        chest(k, bu, inner - 2.8f, 0f, f1)
        rug(k, bu, inner - 2.2f, 1.0f, 1.5f, f1, pick(seed, 40 + bi, intArrayOf(0x8A3A2A, 0x2A4A6A, 0x6A5A2A)))
        bi++
    }
    k.wall(0f, 2f, 0f, inner, f1, levels[2] - 0.3f, 0.3f, innerWall, stoneF)
    k.box(-inner + 0.4f, f1 + 1.1f, 3f, 0.35f, 1.1f, 0.8f, 0x5A3E28, FLAG_WOOD, true)
    k.box(inner - 0.4f, f1 + 1.1f, 3f, 0.35f, 1.1f, 0.8f, 0x5A3E28, FLAG_WOOD, true)
    table(k, -6f, -3f, true, f1, 3, seed + 1)
    table(k, 6f, -3f, false, f1, 2, seed + 2)
    torch(k, -3f, f1 + 2.6f, -inner + 0.05f, 1.5708f)
    torch(k, 3f, f1 + 2.6f, -inner + 0.05f, 1.5708f)

    // ---- Second floor: library and armoury.
    val f2 = levels[2]
    var sw = -7f
    while (sw <= 9f) {
        bookshelf(k, -inner + 0.25f, sw, 0f, f2, seed + (sw * 3f).toInt())
        sw += 1.6f
    }
    table(k, -4f, 3f, false, f2, 4, seed + 3)
    k.box(-4f, f2 + 0.84f, 3f, 0.4f, 0.01f, 0.3f, 0xE8D8A8, FLAG_PLASTER)
    rug(k, -4f, 3f, 2.4f, 1.8f, f2, bannerC)
    // Weapon racks and suits of armour on the other side.
    var rw = -6f
    while (rw <= 8f) {
        k.box(inner - 0.3f, f2 + 1f, rw, 0.12f, 1f, 0.9f, 0x5A3E28, FLAG_WOOD, true)
        for (i in 0 until 3) {
            val sp = rw - 0.5f + i * 0.5f
            k.limb(inner - 0.45f, f2 + 0.1f, sp, inner - 0.45f, f2 + 1.9f, sp, 0.03f, 0.03f, 0x6A5A4A, FLAG_WOOD)
            k.cone(inner - 0.45f, f2 + 1.9f, sp, 0.07f, 0.3f, 4, 0xC0C6CE, FLAG_SOLID)
        }
        rw += 3.5f
    }
    for (au in floatArrayOf(2f, 6f)) {
        k.box(au, f2 + 0.05f, 9f, 0.3f, 0.05f, 0.3f, 0x4A4A4E, FLAG_SOLID, true)
        k.box(au, f2 + 1.1f, 9f, 0.22f, 0.45f, 0.14f, 0xA8AEB8, FLAG_SOLID)
        k.limb(au - 0.1f, f2 + 0.1f, 9f, au - 0.1f, f2 + 0.65f, 9f, 0.07f, 0.06f, 0x8A9098, FLAG_SOLID)
        k.limb(au + 0.1f, f2 + 0.1f, 9f, au + 0.1f, f2 + 0.65f, 9f, 0.07f, 0.06f, 0x8A9098, FLAG_SOLID)
        k.blob(au, f2 + 1.75f, 9f, 0.16f, 0.2f, 0.16f, 0xB8BEC8, FLAG_SOLID, 7)
    }
    for (i in 0 until 4) barrel(k, 8f + (i % 2) * 0.8f, -6f + (i / 2) * 0.8f, f2)
    torch(k, 9f, f2 + 2.6f, -inner + 0.05f, 1.5708f)

    // ---- Third floor: the lord's quarters and throne.
    val f3 = levels[3]
    k.box(0f, f3 + 0.12f, inner - 2.2f, 3.2f, 0.12f, 2.0f, shadeRgb(stone, 1.05f), stoneF)
    k.floor(0f, inner - 2.2f, 3.2f, 2.0f, f3 + 0.24f)
    k.box(0f, f3 + 0.02f, 3f, 1.1f, 0.02f, 6f, 0x8A2A2A, FLAG_PLASTER)
    val ty = f3 + 0.24f
    k.box(0f, ty + 0.3f, inner - 1.3f, 0.7f, 0.3f, 0.6f, 0x8A6A2A, FLAG_WOOD, true)
    k.box(0f, ty + 1.5f, inner - 0.8f, 0.7f, 1.2f, 0.12f, 0x8A6A2A, FLAG_WOOD)
    k.box(0f, ty + 2.75f, inner - 0.8f, 0.25f, 0.2f, 0.1f, 0xFFC940, FLAG_GLOW)
    k.box(0f, ty + 0.62f, inner - 1.35f, 0.62f, 0.04f, 0.55f, bannerC, FLAG_PLASTER)
    banner(k, -3f, f3 + 3.2f, inner - 0.06f, 0f, bannerC)
    banner(k, 3f, f3 + 3.2f, inner - 0.06f, 0f, bannerC)
    // Canopy bed.
    bed(k, -8f, -3f, 0f, true, 0x6A1A2A, f3)
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        k.box(-8f + a * 1.05f, f3 + 1.3f, -3f + b * 0.8f, 0.05f, 1.3f, 0.05f, 0x4A3020, FLAG_WOOD)
    }
    k.box(-8f, f3 + 2.62f, -3f, 1.15f, 0.04f, 0.9f, 0x6A1A2A, FLAG_PLASTER)
    chest(k, -6.3f, -3f, 1.5708f, f3)
    fireplace(k, -inner + 0.5f, 4f, 0f, f3, shadeRgb(stone, 0.9f), top + 1.5f)
    table(k, 6f, -2f, false, f3, 4, seed + 4)
    k.box(6f, f3 + 0.84f, -2f, 0.6f, 0.01f, 0.4f, 0xD8C898, FLAG_PLASTER)
    bookshelf(k, inner - 0.25f, 3f, 3.1416f, f3, seed + 9)
    bookshelf(k, inner - 0.25f, 4.6f, 3.1416f, f3, seed + 10)
    torch(k, -3f, f3 + 2.6f, -inner + 0.05f, 1.5708f)
    torch(k, 3f, f3 + 2.6f, -inner + 0.05f, 1.5708f)

    // ---- On the roof: a flagpole over the keep.
    val f4 = levels[4]
    k.box(0f, f4 + 3f, 0f, 0.08f, 3f, 0.08f, 0x3A2818, FLAG_WOOD)
    k.box(1.1f, f4 + 5.2f, 0f, 1.1f, 0.7f, 0.03f, bannerC, FLAG_PLASTER)
    k.box(0f, f4 + 0.3f, 0f, 0.6f, 0.3f, 0.6f, shadeRgb(stone, 0.9f), stoneF, true)

    // Style touches.
    when (style) {
        Style.GREEN, Style.FOREST -> {
            // Moss and grass growing on the old stone.
            for (i in 0 until 26) {
                val side = i % 4
                val p = (roll(seed, 200 + i) - 0.5f) * 2f * inner
                val hy = 0.5f + roll(seed, 300 + i) * (top - 1f)
                val (mu, mw) = when (side) {
                    0 -> Pair(p, wc + t * 0.5f)
                    1 -> Pair(p, -wc - t * 0.5f)
                    2 -> Pair(wc + t * 0.5f, p)
                    else -> Pair(-wc - t * 0.5f, p)
                }
                if (side == 0 && abs(p) < gate + 1f && hy < gateH + 1f) continue
                k.blob(mu, hy, mw, 0.9f, 0.5f, 0.9f, pick(seed, 400 + i, intArrayOf(0x4E7034, 0x5E8A3A, 0x3E5A2E)), FLAG_LEAF, seed + i)
            }
            var gm = -inner - t + 0.5f
            while (gm < inner + t) {
                if (roll(seed, 500 + (gm * 2f).toInt()) > 0.6f) k.blob(gm, top + 0.95f, wc, 0.5f, 0.2f, 0.5f, 0x5E8A3A, FLAG_LEAF, seed + (gm * 3f).toInt())
                gm += 2f
            }
        }
        Style.SNOW -> {
            m = -inner - t + 0.5f
            while (m < inner + t) {
                for (side in intArrayOf(-1, 1)) {
                    k.box(m, top + 0.95f, side * wc, 0.52f, 0.08f, t * 0.52f, 0xF2F6FA, FLAG_SNOW)
                    k.box(side * wc, top + 0.95f, m, t * 0.52f, 0.08f, 0.52f, 0xF2F6FA, FLAG_SNOW)
                }
                m += 2f
            }
            k.box(0f, levels[4] + 0.05f, 0f, inner, 0.05f, inner, 0xF2F6FA, FLAG_SNOW)
            for (i in 0 until 10) {
                val p = -inner + i * 2.8f
                k.cone(p, gateH + 0.1f, wc + t * 0.5f + 0.1f, 0.12f, -1.2f, 4, 0xCFE8F8, FLAG_GLOW)
            }
        }
        Style.SAND -> {
            // Sand heaped against the walls.
            for (i in 0 until 12) {
                val p = (roll(seed, 600 + i) - 0.5f) * 2f * inner
                k.blob(p, 0.2f, -wc - t, 2.5f, 1.0f, 1.6f, 0xD9B77A, FLAG_SAND, seed + i)
                k.blob(wc + t, 0.2f, p, 1.6f, 1.0f, 2.5f, 0xD9B77A, FLAG_SAND, seed + i + 50)
            }
        }
        Style.DARK -> {
            // Iron spikes along the battlements and eerie glowing braziers.
            m = -inner - t + 1.5f
            while (m < inner + t) {
                for (side in intArrayOf(-1, 1)) {
                    k.cone(m, top + 0.9f, side * wc, 0.12f, 1.2f, 4, 0x2A2A2E, FLAG_SOLID)
                    k.cone(side * wc, top + 0.9f, m, 0.12f, 1.2f, 4, 0x2A2A2E, FLAG_SOLID)
                }
                m += 2f
            }
            for (bu in floatArrayOf(-gate - 2.5f, gate + 2.5f)) {
                k.prism(bu, 0f, wc + t + 1.5f, 0.35f, 0.5f, 1.3f, 6, 0x2A2A2E, FLAG_SOLID, true, 0.5f)
                k.prism(bu, 1.3f, wc + t + 1.5f, 0.45f, 0.4f, 0.1f, 8, 0x9A4AFF, FLAG_GLOW)
                k.flame(bu, 1.35f, wc + t + 1.5f, 0.35f, 1.0f)
            }
            for (i in 0 until 8) {
                val p = (roll(seed, 700 + i) - 0.5f) * 2f * inner
                k.limb(p, 0f, -wc - t - 2f, p + 0.3f, 1.4f, -wc - t - 2f, 0.07f, 0.03f, 0xD8D0C0, FLAG_SOLID)
            }
        }
    }
}

// ---------------------------------------------------------------- Castle grounds

/** Half the width of the keep's inside, in metres. */
const val KEEP_INNER = 16f
/** The keep stands this far back from the middle of the castle grounds. */
const val KEEP_BACK = 12f
/** Half the width of the curtain wall round the castle grounds. */
const val CURTAIN = 42f

/** Castle-grounds position (u across the front, w out through the gate) to the world. */
fun castleX(x: Float, frontX: Float, frontZ: Float, u: Float, w: Float): Float = x + u * frontZ + w * frontX
fun castleZ(z: Float, frontX: Float, frontZ: Float, u: Float, w: Float): Float = z - u * frontX + w * frontZ

/**
 * A whole castle: a great curtain wall with a gatehouse and towers round a courtyard,
 * and the four-storey keep at the back. Inside the walls: houses, a well, a market
 * stall, tents, a training yard and a stone road from the gate to the keep door.
 */
fun buildCastle(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, style: Int, seed: Int) {
    buildKeep(
        st, castleX(x, frontX, frontZ, 0f, -KEEP_BACK), y, castleZ(z, frontX, frontZ, 0f, -KEEP_BACK),
        frontX, frontZ, style, seed,
    )
    val k = Kit(st, x, y, z, frontX, frontZ)
    val stone: Int
    val roofC: Int
    val roofF: Int
    val bannerC: Int
    when (style) {
        Style.FOREST -> { stone = 0x6E726A; roofC = 0x3E4A2E; roofF = FLAG_ROOF; bannerC = 0x2E6A3A }
        Style.SNOW -> { stone = 0xB8C0CC; roofC = 0xEEF2F6; roofF = FLAG_SNOW; bannerC = 0x6A2A4A }
        Style.SAND -> { stone = 0xCBA774; roofC = 0xD8B884; roofF = FLAG_PLASTER; bannerC = 0xB83A2A }
        Style.DARK -> { stone = 0x2E2A36; roofC = 0x1E1A24; roofF = FLAG_ROOF; bannerC = 0x7A1A2A }
        else -> { stone = 0x8C8A84; roofC = 0x4E5A66; roofF = FLAG_ROOF; bannerC = 0x9A2A24 }
    }
    val sf = FLAG_STONE
    val cw = CURTAIN
    val ct = 1.8f
    val wallTop = 10f
    val gate = 3f
    val gateH = 6.5f
    val foot = -3f

    // ---- The curtain wall, sunk into the ground so it never floats on a slope.
    k.wall(-cw - ct * 0.5f, -cw, cw + ct * 0.5f, -cw, foot, wallTop, ct, stone, sf)
    k.wall(-cw, -cw, -cw, cw, foot, wallTop, ct, stone, sf)
    k.wall(cw, -cw, cw, cw, foot, wallTop, ct, stone, sf)
    k.wall(-cw - ct * 0.5f, cw, -gate, cw, foot, wallTop, ct, stone, sf)
    k.wall(gate, cw, cw + ct * 0.5f, cw, foot, wallTop, ct, stone, sf)
    k.wall(-gate, cw, gate, cw, gateH, wallTop, ct, stone, sf)
    // A walkway ledge along the inside top, and battlements along the outside edge.
    for (side in intArrayOf(-1, 1)) {
        k.box(0f, wallTop - 0.2f, side * (cw - ct * 0.5f - 0.5f), cw, 0.2f, 0.55f, shadeRgb(stone, 0.9f), sf)
        k.box(side * (cw - ct * 0.5f - 0.5f), wallTop - 0.2f, 0f, 0.55f, 0.2f, cw, shadeRgb(stone, 0.9f), sf)
    }
    var m = -cw + 1f
    while (m < cw) {
        for (side in intArrayOf(-1, 1)) {
            k.box(m, wallTop + 0.5f, side * (cw + 0.5f), 0.55f, 0.5f, 0.4f, stone, sf)
            k.box(side * (cw + 0.5f), wallTop + 0.5f, m, 0.4f, 0.5f, 0.55f, stone, sf)
        }
        m += 2.2f
    }
    // Trim along the base.
    k.box(0f, 0.3f, -cw - ct * 0.5f - 0.15f, cw + 1f, 0.5f, 0.2f, shadeRgb(stone, 0.8f), sf)
    k.box(-cw - ct * 0.5f - 0.15f, 0.3f, 0f, 0.2f, 0.5f, cw + 1f, shadeRgb(stone, 0.8f), sf)
    k.box(cw + ct * 0.5f + 0.15f, 0.3f, 0f, 0.2f, 0.5f, cw + 1f, shadeRgb(stone, 0.8f), sf)

    // ---- Round towers at the corners, square towers halfway along each side.
    for (a in intArrayOf(-1, 1)) for (b in intArrayOf(-1, 1)) {
        val tu = a * cw
        val tw = b * cw
        val th = wallTop + 5f
        k.prism(tu, foot, tw, 4.4f, 4.1f, th - foot, 12, stone, sf, true, 4.2f)
        k.prism(tu, th, tw, 4.7f, 4.7f, 0.9f, 12, shadeRgb(stone, 0.9f), sf)
        for (l in 0 until 2) {
            val slit = 3f + l * 5f
            k.box(tu + a * 4.2f, slit, tw, 0.05f, 0.7f, 0.25f, 0x2A3440, FLAG_SOLID)
            k.box(tu, slit, tw + b * 4.2f, 0.25f, 0.7f, 0.05f, 0x2A3440, FLAG_SOLID)
        }
        when (style) {
            Style.SAND -> k.blob(tu, th + 0.9f, tw, 4.1f, 3.6f, 4.1f, roofC, roofF, seed + a * 5 + b)
            Style.DARK -> k.cone(tu, th + 0.9f, tw, 4.8f, 12f, 12, roofC, roofF)
            else -> k.cone(tu, th + 0.9f, tw, 5f, 7f, 12, roofC, roofF)
        }
        k.box(tu, th + 9f, tw, 0.06f, 1.4f, 0.06f, 0x3A2818, FLAG_WOOD)
        k.box(tu + 0.7f, th + 9.8f, tw, 0.7f, 0.45f, 0.02f, bannerC, FLAG_PLASTER)
    }
    for ((mu, mw) in listOf(Pair(-cw, 0f), Pair(cw, 0f), Pair(0f, -cw))) {
        k.box(mu, (foot + wallTop + 3f) * 0.5f, mw, 2.8f, (wallTop + 3f - foot) * 0.5f, 2.8f, shadeRgb(stone, 0.96f), sf, true)
        var bm = -2.4f
        while (bm <= 2.5f) {
            for (side in intArrayOf(-1, 1)) {
                k.box(mu + bm, wallTop + 3.45f, mw + side * 2.5f, 0.4f, 0.45f, 0.3f, stone, sf)
                k.box(mu + side * 2.5f, wallTop + 3.45f, mw + bm, 0.3f, 0.45f, 0.4f, stone, sf)
            }
            bm += 1.6f
        }
    }

    // ---- The gatehouse: two towers either side of a tall arched gate.
    for (side in intArrayOf(-1, 1)) {
        val gu = side * (gate + 2.6f)
        k.box(gu, (foot + wallTop + 4f) * 0.5f, cw, 2.6f, (wallTop + 4f - foot) * 0.5f, 2.6f, shadeRgb(stone, 1.04f), sf, true)
        var bm = -2.2f
        while (bm <= 2.3f) {
            k.box(gu + bm, wallTop + 4.45f, cw + 2.35f, 0.4f, 0.45f, 0.3f, stone, sf)
            k.box(gu + bm, wallTop + 4.45f, cw - 2.35f, 0.4f, 0.45f, 0.3f, stone, sf)
            bm += 1.5f
        }
        banner(k, gu, 7.5f, cw + 2.65f, 0f, bannerC)
        torch(k, side * (gate + 0.7f), 3.2f, cw + 2.65f, 1.5708f)
        torch(k, side * (gate + 0.7f), 3.2f, cw - 2.65f, -1.5708f)
    }
    // Arch over the gate and the raised portcullis.
    k.box(0f, gateH + 0.35f, cw + ct * 0.5f + 0.15f, gate + 0.6f, 0.4f, 0.2f, shadeRgb(stone, 0.78f), sf)
    k.box(0f, gateH + 0.35f, cw - ct * 0.5f - 0.15f, gate + 0.6f, 0.4f, 0.2f, shadeRgb(stone, 0.78f), sf)
    var bar = -gate + 0.3f
    while (bar < gate) {
        k.box(bar, gateH - 0.5f, cw, 0.06f, 0.55f, 0.06f, 0x2A2A2E, FLAG_SOLID)
        bar += 0.5f
    }
    k.box(0f, gateH - 1.05f, cw, gate, 0.06f, 0.06f, 0x2A2A2E, FLAG_SOLID)

    // ---- A stone road from outside the gate to the keep door.
    val keepFront = -KEEP_BACK + KEEP_INNER + 1.2f
    k.box(0f, 0.04f, (cw + 8f + keepFront) * 0.5f, 2.4f, 0.06f, (cw + 8f - keepFront) * 0.5f, shadeRgb(stone, 0.85f), sf)
    for (e in intArrayOf(-1, 1)) {
        k.box(e * 2.5f, 0.08f, (cw + keepFront) * 0.5f, 0.12f, 0.08f, (cw - keepFront) * 0.5f, shadeRgb(stone, 0.7f), sf)
    }

    // ---- Houses along each side of the courtyard.
    for (side in intArrayOf(-1, 1)) {
        for ((hi, hw) in floatArrayOf(-6f, 16f).withIndex()) {
            val hu = side * (cw - 11f)
            // Front faces the middle of the courtyard.
            val fu = -side.toFloat()
            buildHouse(
                st, castleX(x, frontX, frontZ, hu, hw), y, castleZ(z, frontX, frontZ, hu, hw),
                fu * frontZ, -fu * frontX, style, seed * 7 + side * 3 + hi,
            )
        }
    }

    // ---- The well, the market stall, tents and a training yard.
    buildWell(st, castleX(x, frontX, frontZ, -14f, 24f), y, castleZ(z, frontX, frontZ, -14f, 24f), style)
    buildStall(
        st, castleX(x, frontX, frontZ, CASTLE_STALL_U, CASTLE_STALL_W), y, castleZ(z, frontX, frontZ, CASTLE_STALL_U, CASTLE_STALL_W),
        -frontZ, frontX, style, seed + 3,
    )
    for ((tu, tw) in listOf(Pair(20f, 23f), Pair(29f, 31f))) {
        tent(k, tu, tw, pick(seed, 60 + tu.toInt(), intArrayOf(0xB8A27A, 0x8A5A3A, 0x6A7A5A, 0xA83A2A)))
    }
    for (i in 0 until 4) {
        dummy(k, -22f - (i % 2) * 5f, 29f + (i / 2) * 5f)
    }
    k.box(-33f, 0.9f, 31f, 0.08f, 0.9f, 1.6f, 0x5A3E22, FLAG_WOOD, true)
    for (i in 0 until 3) {
        k.limb(-32.8f, 0.3f, 30.4f + i * 0.6f, -32.9f, 1.9f, 30.6f + i * 0.6f, 0.03f, 0.03f, 0x6A5A4A, FLAG_WOOD)
        k.cone(-32.9f, 1.9f, 30.6f + i * 0.6f, 0.06f, 0.28f, 4, 0xC0C6CE, FLAG_SOLID)
    }
    // Crates and hay by the walls.
    for (i in 0 until 5) {
        val cu = cw - 3f - (i % 3) * 1.3f
        val cz = -cw + 3f + (i / 3) * 1.3f
        k.box(cu, 0.5f, cz, 0.55f, 0.5f, 0.55f, 0x8A6A40, FLAG_WOOD, true)
    }
    for (i in 0 until 4) {
        k.blob(-cw + 3f + i * 2.2f, 0.6f, -cw + 3f, 1.0f, 0.7f, 0.8f, 0xD8B85A, FLAG_GRASS, seed + 70 + i)
    }
    // Torches round the courtyard walls.
    var tw = -cw + 8f
    while (tw < cw - 4f) {
        torch(k, -cw + ct * 0.5f + 0.05f, 3f, tw, 0f)
        torch(k, cw - ct * 0.5f - 0.05f, 3f, tw, 3.1416f)
        tw += 12f
    }
}

/** Where a castle's market stall stands in its grounds (see [castleX]). */
const val CASTLE_STALL_U = 9f
const val CASTLE_STALL_W = 31f

/** A training dummy: a post with a straw-stuffed sack. */
private fun dummy(k: Kit, u: Float, w: Float) {
    k.box(u, 0.9f, w, 0.07f, 0.9f, 0.07f, 0x5A3E22, FLAG_WOOD, true)
    k.box(u, 1.5f, w, 0.55f, 0.05f, 0.05f, 0x5A3E22, FLAG_WOOD)
    k.blob(u, 1.35f, w, 0.3f, 0.42f, 0.25f, 0xC8A870, FLAG_GRASS, (u * 7f + w).toInt())
    k.blob(u, 1.95f, w, 0.18f, 0.2f, 0.18f, 0xC8A870, FLAG_GRASS, (u * 5f - w).toInt())
}

/** A canvas tent with its flap open towards +w. */
private fun tent(k: Kit, u: Float, w: Float, cloth: Int) {
    k.quad(u - 1.8f, 0f, w + 1.6f, u - 1.8f, 0f, w - 1.6f, u, 2.4f, w - 1.6f, u, 2.4f, w + 1.6f, cloth, FLAG_PLASTER, u, 1f, w)
    k.quad(u + 1.8f, 0f, w + 1.6f, u + 1.8f, 0f, w - 1.6f, u, 2.4f, w - 1.6f, u, 2.4f, w + 1.6f, shadeRgb(cloth, 0.9f), FLAG_PLASTER, u, 1f, w)
    k.quad(u - 1.8f, 0f, w - 1.6f, u + 1.8f, 0f, w - 1.6f, u, 2.4f, w - 1.6f, u, 2.4f, w - 1.6f, shadeRgb(cloth, 0.8f), FLAG_PLASTER, u, 1f, w)
    k.box(u, 1.2f, w + 1.6f, 0.05f, 1.2f, 0.05f, 0x5A3E22, FLAG_WOOD)
    k.solidOnly(u, w, 1.5f, 1.5f, 0f, 2.4f)
}

/**
 * A market stall: a counter under a striped awning, with goods laid out.
 * Built facing +w (towards the customer); the trader stands behind it at w = -1.
 */
fun buildStall(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float, style: Int, seed: Int) {
    val k = Kit(st, x, y, z, frontX, frontZ)
    val wood = if (style == Style.SAND) 0x9A7A52 else 0x6A4A2C
    val stripeA = pick(seed, 1, intArrayOf(0xB83A2A, 0x2A5A9A, 0x3A7A3A, 0x8A3A8A))
    val stripeB = 0xE8E0CC
    k.box(0f, 0.5f, 0.3f, 1.5f, 0.5f, 0.35f, wood, FLAG_WOOD, true)
    k.box(0f, 1.02f, 0.3f, 1.6f, 0.03f, 0.42f, shadeRgb(wood, 1.15f), FLAG_WOOD)
    for (a in intArrayOf(-1, 1)) {
        k.box(a * 1.5f, 1.3f, 0.65f, 0.06f, 1.3f, 0.06f, wood, FLAG_WOOD, true)
        k.box(a * 1.5f, 1.5f, -1.5f, 0.06f, 1.5f, 0.06f, wood, FLAG_WOOD, true)
    }
    for (i in 0 until 6) {
        val u0 = -1.7f + i * 0.567f
        val u1 = u0 + 0.567f
        k.quad(u0, 2.6f, 1.0f, u1, 2.6f, 1.0f, u1, 3.05f, -1.6f, u0, 3.05f, -1.6f, if (i % 2 == 0) stripeA else stripeB, FLAG_PLASTER, (u0 + u1) * 0.5f, 0f, 0f)
    }
    // Goods on the counter: jars, a rolled cloth, a sword and some fruit.
    for (i in 0 until 3) k.prism(-1.1f + i * 0.3f, 1.05f, 0.25f, 0.09f, 0.07f, 0.22f, 6, pick(seed, 10 + i, intArrayOf(0x3A6A9A, 0x9A6A3A, 0x6A9A5A)), FLAG_SOLID)
    k.limb(0.1f, 1.12f, 0.35f, 0.8f, 1.12f, 0.35f, 0.07f, 0.07f, stripeA, FLAG_PLASTER)
    k.box(0.5f, 1.08f, 0.1f, 0.5f, 0.015f, 0.04f, 0xC0C6CE, FLAG_SOLID)
    for (i in 0 until 4) k.blob(1.05f + (i % 2) * 0.15f, 1.12f, 0.35f + (i / 2) * 0.15f, 0.07f, 0.07f, 0.07f, 0xC83A2A, FLAG_SOLID, seed + i)
    // Crates and a barrel behind.
    k.box(-1.0f, 0.35f, -1.1f, 0.35f, 0.35f, 0.35f, 0x8A6A40, FLAG_WOOD, true)
    barrel(k, 1.0f, -1.1f, 0f)
}

/** A notice board where people pin up jobs that need doing. Faces +w. */
fun buildBoard(st: Structure, x: Float, y: Float, z: Float, frontX: Float, frontZ: Float) {
    val k = Kit(st, x, y, z, frontX, frontZ)
    for (a in intArrayOf(-1, 1)) k.box(a * 0.9f, 1.1f, 0f, 0.07f, 1.1f, 0.07f, 0x5A3E22, FLAG_WOOD, true)
    k.box(0f, 1.45f, 0f, 0.95f, 0.6f, 0.04f, 0x7A5A36, FLAG_WOOD)
    k.box(0f, 2.15f, 0f, 1.1f, 0.06f, 0.2f, 0x4A3424, FLAG_WOOD)
    for (i in 0 until 5) {
        val pu = -0.6f + i * 0.3f
        val py = 1.25f + (i % 2) * 0.35f
        k.box(pu, py, 0.05f, 0.11f, 0.14f, 0.005f, 0xE8DCB8, FLAG_PLASTER)
    }
}
