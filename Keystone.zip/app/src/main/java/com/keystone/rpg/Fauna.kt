package com.keystone.rpg

import android.opengl.Matrix
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** How each piece of a creature moves. */
object PartKind {
    const val BODY = 0
    const val HEAD = 1
    const val LEG = 2
    const val TAIL = 3
    const val WING_L = 4
    const val WING_R = 5
}

/** Soft fur and feathers (lit gently, no ground pattern). */
const val FLAG_FUR = 253

/** One moving piece. Its mesh is built around its own pivot (hip, neck, shoulder...). */
class CreaturePart(
    val kind: Int, val px: Float, val py: Float, val pz: Float, val phase: Float,
    val data: ByteBuffer, val count: Int,
) {
    var buffer = 0
}

class Species(
    val name: String,
    val zones: Array<Zone>,
    val bird: Boolean,
    val walk: Float,
    val run: Float,
    val timid: Boolean,
    val grazes: Boolean,
    val legSwing: Float,
    val stride: Float,
    val minScale: Float,
    val maxScale: Float,
    val herd: Int,
    val parts: List<CreaturePart>,
) {
    /** Index into the creature calls made by [Sound]. */
    var call = 0
}

/** One living animal or bird in the world. */
class Creature {
    var active = false
    var sp = 0
    var x = 0f
    var y = 0f
    var z = 0f
    var yaw = 0f
    var wantYaw = 0f
    var speed = 0f
    var state = 0
    var timer = 0f
    var phase = 0f
    var scale = 1f
    var callIn = 5f
    var head = 0f
    // Birds: circling centre, radius, height above ground, angle, wing beat.
    var cx = 0f
    var cz = 0f
    var radius = 30f
    var alt = 30f
    var angle = 0f
    var flap = 1f
    var flapWant = 1f
    var roll = 0f
}

/**
 * The wildlife: ten invented beasts (two per region) and four birds, each with its
 * own look, walk, behaviour and call. Animals spawn around you in the region they
 * belong to and wander off again when you leave.
 */
class Fauna(private val world: World) {
    val species: List<Species> = buildSpecies()
    val animals = Array(26) { Creature() }
    val birds = Array(9) { Creature() }

    private val rnd = Random(90210)
    private val probe = Probe()
    private var spawnTimer = 0f
    private val tmp = FloatArray(16)

    init {
        for (i in species.indices) species[i].call = i
    }

    fun update(dt: Float, px: Float, pz: Float, time: Float) {
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            spawnTimer = 0.4f
            trySpawnAnimals(px, pz)
            trySpawnBird(px, pz)
        }
        for (c in animals) if (c.active) stepAnimal(c, dt, px, pz)
        for (c in birds) if (c.active) stepBird(c, dt, px, pz, time)
    }

    private fun speciesFor(zone: Zone, bird: Boolean): Int {
        var n = 0
        for (s in species) if (s.bird == bird && zone in s.zones) n++
        if (n == 0) return -1
        var pick = rnd.nextInt(n)
        for (i in species.indices) {
            val s = species[i]
            if (s.bird == bird && zone in s.zones) {
                if (pick == 0) return i
                pick--
            }
        }
        return -1
    }

    private fun goodGround(x: Float, z: Float): Boolean {
        if (x < 20f || z < 20f || x > WORLD_SIZE - 20f || z > WORLD_SIZE - 20f) return false
        world.probe(x, z, probe)
        if (probe.mountain > 0.25f || probe.site < 12f) return false
        if (world.terrainAt(x, z) < 0.8f) return false
        return !world.isBlocked(x, z, probe)
    }

    private fun trySpawnAnimals(px: Float, pz: Float) {
        var alive = 0
        for (c in animals) if (c.active) alive++
        if (alive >= 16) return
        val a = rnd.nextFloat() * 6.2831855f
        val r = 60f + rnd.nextFloat() * 90f
        val x = px + cos(a) * r
        val z = pz + sin(a) * r
        if (!goodGround(x, z)) return
        val si = speciesFor(probe.zone, false)
        if (si < 0) return
        val sp = species[si]
        val count = 1 + rnd.nextInt(sp.herd)
        for (k in 0 until count) {
            val c = animals.firstOrNull { !it.active } ?: return
            val hx = x + (rnd.nextFloat() - 0.5f) * 10f
            val hz = z + (rnd.nextFloat() - 0.5f) * 10f
            if (!goodGround(hx, hz)) continue
            c.active = true
            c.sp = si
            c.x = hx
            c.z = hz
            c.y = world.terrainAt(hx, hz)
            c.yaw = rnd.nextFloat() * 6.2831855f
            c.wantYaw = c.yaw
            c.speed = 0f
            c.state = 0
            c.timer = 1f + rnd.nextFloat() * 4f
            c.phase = rnd.nextFloat() * 6f
            c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
            c.callIn = 3f + rnd.nextFloat() * 14f
            c.head = 0f
        }
    }

    private fun trySpawnBird(px: Float, pz: Float) {
        var alive = 0
        for (c in birds) if (c.active) alive++
        if (alive >= 6) return
        val c = birds.firstOrNull { !it.active } ?: return
        val a = rnd.nextFloat() * 6.2831855f
        val r = 30f + rnd.nextFloat() * 110f
        val x = (px + cos(a) * r).coerceIn(30f, WORLD_SIZE - 30f)
        val z = (pz + sin(a) * r).coerceIn(30f, WORLD_SIZE - 30f)
        world.probe(x, z, probe)
        val si = speciesFor(probe.zone, true)
        if (si < 0) return
        val sp = species[si]
        c.active = true
        c.sp = si
        c.cx = x
        c.cz = z
        c.radius = 18f + rnd.nextFloat() * 30f
        c.alt = 22f + rnd.nextFloat() * 30f
        c.angle = rnd.nextFloat() * 6.2831855f
        c.speed = sp.walk * (0.85f + 0.3f * rnd.nextFloat()) * (if (rnd.nextBoolean()) 1f else -1f)
        c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
        c.callIn = 4f + rnd.nextFloat() * 16f
        c.flap = 1f
        c.flapWant = 1f
        c.timer = 2f + rnd.nextFloat() * 4f
        c.phase = rnd.nextFloat() * 6f
        placeBird(c)
        c.y = world.terrainAt(c.x, c.z) + c.alt
    }

    private fun stepAnimal(c: Creature, dt: Float, px: Float, pz: Float) {
        val sp = species[c.sp]
        val dx = c.x - px
        val dz = c.z - pz
        val dist = hypot(dx, dz)
        if (dist > 230f) {
            c.active = false
            return
        }
        // Shy creatures bolt when you get close.
        if (sp.timid && dist < 14f && c.state != 2) {
            c.state = 2
            c.timer = 4f + rnd.nextFloat() * 2f
            c.wantYaw = atan2(dx, dz) + (rnd.nextFloat() - 0.5f) * 0.8f
            c.callIn = min(c.callIn, 0.2f)
        }
        c.timer -= dt
        when (c.state) {
            0 -> {
                c.speed += (0f - c.speed) * min(1f, dt * 4f)
                if (c.timer <= 0f) {
                    c.state = 1
                    c.timer = 3f + rnd.nextFloat() * 7f
                    c.wantYaw = c.yaw + (rnd.nextFloat() - 0.5f) * 2.4f
                }
            }
            1 -> {
                c.speed += (sp.walk - c.speed) * min(1f, dt * 2f)
                if (rnd.nextFloat() < dt * 0.3f) c.wantYaw += (rnd.nextFloat() - 0.5f) * 1.2f
                if (c.timer <= 0f) {
                    c.state = 0
                    c.timer = 2f + rnd.nextFloat() * 6f
                }
            }
            else -> {
                c.speed += (sp.run - c.speed) * min(1f, dt * 3f)
                if (c.timer <= 0f) {
                    c.state = 0
                    c.timer = 2f + rnd.nextFloat() * 3f
                }
            }
        }
        // Turn smoothly towards where it wants to go.
        var d = c.wantYaw - c.yaw
        while (d > 3.1415927f) d -= 6.2831855f
        while (d < -3.1415927f) d += 6.2831855f
        c.yaw += d * min(1f, dt * 2.5f)

        if (c.speed > 0.05f) {
            val nx = c.x + sin(c.yaw) * c.speed * dt
            val nz = c.z + cos(c.yaw) * c.speed * dt
            if (goodGround(nx, nz)) {
                c.x = nx
                c.z = nz
            } else {
                c.wantYaw = c.yaw + 3.1415927f + (rnd.nextFloat() - 0.5f)
            }
        }
        c.y += (world.terrainAt(c.x, c.z) - c.y) * min(1f, dt * 10f)
        c.phase += dt * c.speed * sp.stride / c.scale
        // Grazers lower their heads to eat while standing still.
        val headWant = if (sp.grazes && c.state == 0 && c.speed < 0.3f) 1f else 0f
        c.head += (headWant - c.head) * min(1f, dt * 1.5f)

        c.callIn -= dt
        if (c.callIn <= 0f) {
            c.callIn = 9f + rnd.nextFloat() * 18f
            if (dist < 90f) Sound.call(c.sp, callLevel(dist))
        }
    }

    private fun placeBird(c: Creature) {
        c.x = c.cx + cos(c.angle) * c.radius
        c.z = c.cz + sin(c.angle) * c.radius
    }

    private fun stepBird(c: Creature, dt: Float, px: Float, pz: Float, time: Float) {
        val sp = species[c.sp]
        val dist = hypot(c.x - px, c.z - pz)
        if (dist > 260f) {
            c.active = false
            return
        }
        c.angle += c.speed / c.radius * dt
        // The circle itself drifts slowly across the sky.
        c.cx += sin(time * 0.05f + c.phase) * 1.5f * dt
        c.cz += cos(time * 0.04f + c.phase) * 1.5f * dt
        placeBird(c)
        // Flap for a while, then glide.
        c.timer -= dt
        if (c.timer <= 0f) {
            c.flapWant = if (c.flapWant > 0.5f) 0.15f else 1f
            c.timer = if (c.flapWant > 0.5f) 2f + rnd.nextFloat() * 3f else 2f + rnd.nextFloat() * 4f
        }
        c.flap += (c.flapWant - c.flap) * min(1f, dt * 2f)
        c.phase += dt * sp.stride * (0.4f + 0.6f * c.flap)
        // Face along the circle and lean into the turn.
        val dir = if (c.speed >= 0f) 1f else -1f
        c.yaw = atan2(-sin(c.angle) * dir, cos(c.angle) * dir)
        c.roll = 0.35f * dir
        val ground = max(world.terrainAt(c.x, c.z), 0f)
        c.y += (ground + c.alt - c.y) * min(1f, dt * 0.8f)
        c.callIn -= dt
        if (c.callIn <= 0f) {
            c.callIn = 10f + rnd.nextFloat() * 20f
            val d3 = hypot(dist, c.y - world.terrainAt(px, pz))
            if (d3 < 100f) Sound.call(c.sp, callLevel(d3 * 0.8f))
        }
    }

    private fun callLevel(d: Float): Float {
        val k = (1f - d / 95f).coerceIn(0f, 1f)
        return k * k * 1.1f + 0.05f
    }

    /**
     * Builds the model matrix for one part of one creature into [out]: where it stands,
     * which way it faces, its size, and how this piece is swinging right now.
     */
    fun pose(c: Creature, part: CreaturePart, time: Float, out: FloatArray) {
        val sp = species[c.sp]
        Matrix.setIdentityM(out, 0)
        val bob = if (sp.bird) sin(c.phase * 1f) * 0.12f * c.flap else abs(sin(c.phase)) * 0.04f * min(1f, c.speed)
        Matrix.translateM(out, 0, c.x, c.y + bob * c.scale, c.z)
        Matrix.rotateM(out, 0, Math.toDegrees(c.yaw.toDouble()).toFloat(), 0f, 1f, 0f)
        if (sp.bird) Matrix.rotateM(out, 0, Math.toDegrees(c.roll.toDouble()).toFloat(), 0f, 0f, 1f)
        Matrix.scaleM(out, 0, c.scale, c.scale, c.scale)
        Matrix.translateM(out, 0, part.px, part.py, part.pz)
        val moving = min(1f, c.speed / max(0.1f, sp.walk))
        when (part.kind) {
            PartKind.LEG -> {
                val swing = sin(c.phase + part.phase) * sp.legSwing * moving
                Matrix.rotateM(out, 0, Math.toDegrees(swing.toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.HEAD -> {
                val nod = c.head * 0.9f + sin(time * 0.7f + c.phase) * 0.05f
                val look = sin(time * 0.31f + c.x) * 0.25f * (1f - c.head)
                Matrix.rotateM(out, 0, Math.toDegrees(look.toDouble()).toFloat(), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, Math.toDegrees(nod.toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.TAIL -> {
                val wag = sin(time * 2.2f + c.phase * 0.5f) * 0.35f
                Matrix.rotateM(out, 0, Math.toDegrees(wag.toDouble()).toFloat(), 0f, 1f, 0f)
            }
            PartKind.WING_L, PartKind.WING_R -> {
                val beat = sin(c.phase) * 0.75f * c.flap + 0.12f
                val a = if (part.kind == PartKind.WING_L) -beat else beat
                Matrix.rotateM(out, 0, Math.toDegrees(a.toDouble()).toFloat(), 0f, 0f, 1f)
            }
            else -> {}
        }
    }
}

// ---------- The creatures ----------

private class BodyKit {
    val parts = ArrayList<CreaturePart>()
    private var seed = 1

    fun part(kind: Int, px: Float, py: Float, pz: Float, phase: Float = 0f, draw: (MeshBuilder) -> Unit) {
        val m = MeshBuilder(512)
        draw(m)
        parts.add(CreaturePart(kind, px, py, pz, phase, m.finish(), m.vertexCount))
    }

    fun s(): Int = seed++ * 37

    /** Four legs in a diagonal walking gait. [splay] pushes the feet outwards (lizards). */
    fun legs4(hipY: Float, fz: Float, bz: Float, hw: Float, len: Float, r0: Float, r1: Float, col: Int, foot: Int, splay: Float = 0f) {
        val spots = arrayOf(
            floatArrayOf(-hw, fz, 0f), floatArrayOf(hw, fz, 3.1415927f),
            floatArrayOf(-hw, bz, 3.1415927f), floatArrayOf(hw, bz, 0f),
        )
        for (sp in spots) leg(sp[0], hipY, sp[1], sp[2], len, r0, r1, col, foot, if (sp[0] < 0f) -splay else splay)
    }

    fun leg(x: Float, hipY: Float, z: Float, phase: Float, len: Float, r0: Float, r1: Float, col: Int, foot: Int, out: Float) {
        val sd = s()
        part(PartKind.LEG, x, hipY, z, phase) { m ->
            m.limb(0f, 0.05f, 0f, out * 0.6f, -len * 0.55f, 0.02f, r0, (r0 + r1) * 0.5f, col, FLAG_FUR)
            m.limb(out * 0.6f, -len * 0.55f, 0.02f, out, -len + r1, 0f, (r0 + r1) * 0.5f, r1, col, FLAG_FUR)
            m.blob(out, -len + r1 * 0.8f, 0.03f, r1 * 1.3f, r1 * 0.9f, r1 * 1.6f, foot, sd, 0.1f, FLAG_SOLID)
        }
    }
}

private fun buildSpecies(): List<Species> {
    val list = ArrayList<Species>()

    // 1. Glimmerhorn (Greenhollow): a graceful deer whose antlers are living crystal.
    run {
        val k = BodyKit()
        val fur = 0xB8875A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.25f, 0f, 0.34f, 0.38f, 0.82f, fur, 11, 0.08f, FLAG_FUR)
            m.blob(0f, 1.12f, 0.05f, 0.28f, 0.22f, 0.66f, 0xE6D2B4, 12, 0.08f, FLAG_FUR)
            for (i in 0 until 5) m.blob(-0.2f + i * 0.1f, 1.5f, -0.4f + i * 0.2f, 0.05f, 0.03f, 0.05f, 0xF4ECDC, 20 + i, 0f, FLAG_FUR)
        }
        k.part(PartKind.HEAD, 0f, 1.42f, 0.66f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.42f, 0.24f, 0.13f, 0.09f, fur, FLAG_FUR)
            m.blob(0f, 0.52f, 0.36f, 0.13f, 0.14f, 0.24f, fur, 13, 0.05f, FLAG_FUR)
            m.blob(0f, 0.47f, 0.58f, 0.06f, 0.06f, 0.06f, 0x2A1E18, 14, 0f, FLAG_SOLID)
            m.spike(-0.1f, 0.6f, 0.3f, 0.04f, 0.14f, -0.6f, -0.3f, fur, FLAG_FUR)
            m.spike(0.1f, 0.6f, 0.3f, 0.04f, 0.14f, 0.6f, -0.3f, fur, FLAG_FUR)
            m.blob(-0.09f, 0.56f, 0.46f, 0.025f, 0.025f, 0.025f, 0x101014, 15, 0f, FLAG_SOLID)
            m.blob(0.09f, 0.56f, 0.46f, 0.025f, 0.025f, 0.025f, 0x101014, 16, 0f, FLAG_SOLID)
            for (side in intArrayOf(-1, 1)) {
                val sx = side * 0.07f
                m.spike(sx, 0.62f, 0.3f, 0.035f, 0.45f, side * 0.35f, -0.25f, 0x8FE6FF, FLAG_GLOW)
                m.spike(sx + side * 0.1f, 0.8f, 0.24f, 0.025f, 0.28f, side * 0.7f, 0.2f, 0xA8F0FF, FLAG_GLOW)
                m.spike(sx + side * 0.13f, 0.92f, 0.2f, 0.02f, 0.22f, side * 0.1f, -0.5f, 0x7ADCFF, FLAG_GLOW)
            }
        }
        k.part(PartKind.TAIL, 0f, 1.35f, -0.78f) { m ->
            m.blob(0f, -0.02f, -0.06f, 0.08f, 0.1f, 0.08f, 0xF4ECDC, 17, 0.1f, FLAG_FUR)
        }
        k.legs4(1.02f, 0.52f, -0.52f, 0.17f, 1.0f, 0.075f, 0.04f, fur, 0x2A2018)
        list.add(Species("Glimmerhorn", arrayOf(Zone.MEADOW), false, 1.6f, 9.5f, true, true, 0.55f, 2.4f, 0.9f, 1.1f, 3, k.parts))
    }

    // 2. Mossback (Greenhollow): a slow, gentle giant with a mossy shell and ferns growing on it.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.15f, 0f, 1.1f, 0.78f, 1.4f, 0x4F7A38, 21, 0.12f, FLAG_FUR)
            m.blob(0f, 0.72f, 0f, 0.95f, 0.35f, 1.2f, 0x6A5238, 22, 0.1f, FLAG_FUR)
            for (i in 0 until 9) {
                val a = i * 0.7f
                val r = 0.2f + (i % 3) * 0.28f
                m.spike(sin(a) * r, 1.72f, cos(a) * r * 1.2f, 0.07f, 0.55f + (i % 2) * 0.2f, sin(a) * 0.5f, cos(a) * 0.4f, 0x5E9A3A, FLAG_FUR)
            }
            for (i in 0 until 4) m.blob(-0.6f + i * 0.4f, 1.55f + (i % 2) * 0.15f, 0.5f - i * 0.3f, 0.08f, 0.06f, 0.08f, 0xE8D86A, 30 + i, 0f, FLAG_GLOW)
        }
        k.part(PartKind.HEAD, 0f, 0.95f, 1.3f) { m ->
            m.blob(0f, 0f, 0.3f, 0.36f, 0.3f, 0.4f, 0x6A5238, 23, 0.08f, FLAG_FUR)
            m.blob(0f, -0.05f, 0.62f, 0.22f, 0.16f, 0.12f, 0x4E3C2A, 24, 0.05f, FLAG_FUR)
            m.blob(-0.18f, 0.12f, 0.55f, 0.04f, 0.04f, 0.04f, 0x101014, 25, 0f, FLAG_SOLID)
            m.blob(0.18f, 0.12f, 0.55f, 0.04f, 0.04f, 0.04f, 0x101014, 26, 0f, FLAG_SOLID)
            m.spike(-0.2f, 0.2f, 0.2f, 0.06f, 0.25f, -0.4f, -0.3f, 0xCEC0A0, FLAG_SOLID)
            m.spike(0.2f, 0.2f, 0.2f, 0.06f, 0.25f, 0.4f, -0.3f, 0xCEC0A0, FLAG_SOLID)
        }
        k.part(PartKind.TAIL, 0f, 0.85f, -1.35f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.15f, -0.4f, 0.15f, 0.05f, 0x6A5238, FLAG_FUR)
        }
        k.legs4(0.75f, 0.8f, -0.8f, 0.78f, 0.75f, 0.24f, 0.2f, 0x6A5238, 0x3A2C20)
        list.add(Species("Mossback", arrayOf(Zone.MEADOW), false, 0.9f, 1.4f, false, true, 0.35f, 2.2f, 0.85f, 1.2f, 1, k.parts))
    }

    // 3. Shadelynx (Whisperwood): a dark cat with glowing blue stripes and eyes.
    run {
        val k = BodyKit()
        val fur = 0x2A2A38
        val glow = 0x5AC8FF
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.85f, 0f, 0.3f, 0.3f, 0.8f, fur, 31, 0.06f, FLAG_FUR)
            for (i in 0 until 5) {
                val z = -0.5f + i * 0.25f
                m.box(0f, 1.13f, z, 0.03f, 0.02f, 0.2f, 0f, glow, FLAG_GLOW)
                m.box(-0.24f, 0.95f, z, 0.02f, 0.12f, 0.03f, 0f, glow, FLAG_GLOW)
                m.box(0.24f, 0.95f, z, 0.02f, 0.12f, 0.03f, 0f, glow, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.98f, 0.72f) { m ->
            m.blob(0f, 0.04f, 0.18f, 0.22f, 0.19f, 0.23f, fur, 32, 0.05f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.38f, 0.1f, 0.08f, 0.08f, 0x1A1A24, 33, 0f, FLAG_FUR)
            m.spike(-0.14f, 0.18f, 0.12f, 0.05f, 0.26f, -0.2f, -0.1f, fur, FLAG_FUR)
            m.spike(0.14f, 0.18f, 0.12f, 0.05f, 0.26f, 0.2f, -0.1f, fur, FLAG_FUR)
            m.spike(-0.19f, 0.42f, 0.1f, 0.012f, 0.1f, 0f, 0f, glow, FLAG_GLOW)
            m.spike(0.19f, 0.42f, 0.1f, 0.012f, 0.1f, 0f, 0f, glow, FLAG_GLOW)
            m.box(-0.09f, 0.1f, 0.38f, 0.045f, 0.025f, 0.02f, 0f, 0x9CF0FF, FLAG_GLOW)
            m.box(0.09f, 0.1f, 0.38f, 0.045f, 0.025f, 0.02f, 0f, 0x9CF0FF, FLAG_GLOW)
        }
        k.part(PartKind.TAIL, 0f, 1.0f, -0.75f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.15f, -0.5f, 0.07f, 0.05f, fur, FLAG_FUR)
            m.limb(0f, 0.15f, -0.5f, 0f, 0.45f, -0.9f, 0.05f, 0.035f, fur, FLAG_FUR)
            m.blob(0f, 0.47f, -0.93f, 0.06f, 0.06f, 0.06f, glow, 34, 0f, FLAG_GLOW)
        }
        k.legs4(0.66f, 0.5f, -0.5f, 0.17f, 0.66f, 0.08f, 0.06f, fur, 0x1A1A22)
        list.add(Species("Shadelynx", arrayOf(Zone.FOREST), false, 1.4f, 7f, false, false, 0.6f, 3.2f, 0.9f, 1.15f, 1, k.parts))
    }

    // 4. Wispfox (Whisperwood): a small fox whose tail trails glowing wisps.
    run {
        val k = BodyKit()
        val fur = 0x8A4A2A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.45f, 0f, 0.15f, 0.16f, 0.38f, fur, 41, 0.06f, FLAG_FUR)
            m.blob(0f, 0.4f, 0.12f, 0.11f, 0.1f, 0.22f, 0xE8D8C8, 42, 0.05f, FLAG_FUR)
        }
        k.part(PartKind.HEAD, 0f, 0.53f, 0.35f) { m ->
            m.blob(0f, 0.02f, 0.08f, 0.12f, 0.11f, 0.13f, fur, 43, 0.05f, FLAG_FUR)
            m.limb(0f, 0f, 0.14f, 0f, -0.03f, 0.32f, 0.06f, 0.015f, fur, FLAG_FUR)
            m.blob(0f, -0.03f, 0.33f, 0.022f, 0.022f, 0.022f, 0x101014, 44, 0f, FLAG_SOLID)
            m.spike(-0.07f, 0.1f, 0.04f, 0.04f, 0.16f, -0.25f, -0.15f, fur, FLAG_FUR)
            m.spike(0.07f, 0.1f, 0.04f, 0.04f, 0.16f, 0.25f, -0.15f, fur, FLAG_FUR)
            m.box(-0.05f, 0.05f, 0.19f, 0.02f, 0.012f, 0.01f, 0f, 0x7CFFB8, FLAG_GLOW)
            m.box(0.05f, 0.05f, 0.19f, 0.02f, 0.012f, 0.01f, 0f, 0x7CFFB8, FLAG_GLOW)
        }
        k.part(PartKind.TAIL, 0f, 0.5f, -0.34f) { m ->
            m.blob(0f, 0.06f, -0.3f, 0.12f, 0.12f, 0.32f, fur, 45, 0.1f, FLAG_FUR)
            m.blob(0f, 0.12f, -0.62f, 0.08f, 0.08f, 0.1f, 0x7CFFB8, 46, 0f, FLAG_GLOW)
            m.blob(0.06f, 0.2f, -0.76f, 0.05f, 0.05f, 0.05f, 0xA8FFD8, 47, 0f, FLAG_GLOW)
            m.blob(-0.05f, 0.27f, -0.88f, 0.035f, 0.035f, 0.035f, 0xC8FFE8, 48, 0f, FLAG_GLOW)
        }
        k.legs4(0.34f, 0.22f, -0.22f, 0.08f, 0.34f, 0.04f, 0.028f, 0x3A2418, 0x1A1410)
        list.add(Species("Wispfox", arrayOf(Zone.FOREST), false, 1.8f, 8.5f, true, false, 0.7f, 5.5f, 0.9f, 1.1f, 2, k.parts))
    }

    // 5. Frostmane (Frostpeak): a white lion with a mane of ice crystals.
    run {
        val k = BodyKit()
        val fur = 0xE8ECF2
        val ice = 0x9EDCFF
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.0f, 0f, 0.38f, 0.38f, 0.9f, fur, 51, 0.06f, FLAG_FUR)
            m.blob(0f, 1.05f, 0.55f, 0.42f, 0.42f, 0.35f, 0xD8E0EA, 52, 0.08f, FLAG_FUR)
        }
        k.part(PartKind.HEAD, 0f, 1.15f, 0.8f) { m ->
            m.blob(0f, 0f, 0.22f, 0.27f, 0.25f, 0.3f, fur, 53, 0.05f, FLAG_FUR)
            m.blob(0f, -0.06f, 0.48f, 0.13f, 0.11f, 0.1f, 0xC8D0DA, 54, 0f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.58f, 0.04f, 0.035f, 0.03f, 0x303040, 55, 0f, FLAG_SOLID)
            m.box(-0.1f, 0.08f, 0.47f, 0.05f, 0.025f, 0.02f, 0f, 0xBEF0FF, FLAG_GLOW)
            m.box(0.1f, 0.08f, 0.47f, 0.05f, 0.025f, 0.02f, 0f, 0xBEF0FF, FLAG_GLOW)
            for (i in 0 until 12) {
                val a = i * 0.5236f
                val ca = cos(a)
                val sa = sin(a)
                m.spike(ca * 0.3f, sa * 0.3f - 0.05f, 0.02f, 0.05f, 0.32f + (i % 3) * 0.1f, ca * 0.9f, -0.5f, if (i % 2 == 0) ice else 0xC8F0FF, FLAG_GLOW)
            }
        }
        k.part(PartKind.TAIL, 0f, 1.1f, -0.85f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.35f, -0.6f, 0.07f, 0.04f, fur, FLAG_FUR)
            m.spike(0f, -0.4f, -0.62f, 0.06f, 0.22f, 0f, -0.8f, ice, FLAG_GLOW)
        }
        k.legs4(0.76f, 0.58f, -0.58f, 0.22f, 0.76f, 0.11f, 0.085f, fur, 0x8A94A2)
        list.add(Species("Frostmane", arrayOf(Zone.SNOW), false, 1.3f, 6f, false, false, 0.5f, 2.6f, 0.9f, 1.15f, 1, k.parts))
    }

    // 6. Rimewooly (Frostpeak): a huge shaggy grazer with curled horns and frost on its back.
    run {
        val k = BodyKit()
        val wool = 0x8E7C68
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.75f, 0f, 0.95f, 1.0f, 1.4f, wool, 61, 0.14f, FLAG_FUR)
            for (i in 0 until 10) {
                val a = i * 0.628f
                m.blob(sin(a) * 0.85f, 1.05f, cos(a) * 1.2f, 0.28f, 0.45f, 0.28f, 0x7A6A58, 62 + i, 0.2f, FLAG_FUR)
            }
            m.blob(0f, 2.62f, -0.1f, 0.7f, 0.2f, 1.0f, 0xF2F6FA, 75, 0.2f, FLAG_SNOW)
        }
        k.part(PartKind.HEAD, 0f, 1.7f, 1.3f) { m ->
            m.blob(0f, -0.1f, 0.3f, 0.45f, 0.45f, 0.5f, wool, 76, 0.12f, FLAG_FUR)
            m.blob(0f, -0.3f, 0.72f, 0.24f, 0.2f, 0.14f, 0x4A3E32, 77, 0.05f, FLAG_FUR)
            m.blob(-0.25f, 0.05f, 0.7f, 0.04f, 0.04f, 0.04f, 0x101014, 78, 0f, FLAG_SOLID)
            m.blob(0.25f, 0.05f, 0.7f, 0.04f, 0.04f, 0.04f, 0x101014, 79, 0f, FLAG_SOLID)
            for (side in intArrayOf(-1, 1)) {
                var px = side * 0.3f
                var py = 0.2f
                var pz = 0.3f
                for (seg in 0 until 6) {
                    val a = seg * 0.9f
                    val nx = side * (0.45f + 0.25f * cos(a))
                    val ny = 0.25f - 0.3f * sin(a) * (seg / 6f) - seg * 0.04f
                    val nz = 0.3f - 0.3f * sin(a)
                    m.limb(px, py, pz, nx, ny, nz, 0.1f - seg * 0.013f, 0.09f - seg * 0.013f, 0xE8DCC0, FLAG_SOLID)
                    px = nx
                    py = ny
                    pz = nz
                }
            }
        }
        k.part(PartKind.TAIL, 0f, 1.9f, -1.38f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.4f, -0.15f, 0.1f, 0.06f, wool, FLAG_FUR)
        }
        k.legs4(1.15f, 0.8f, -0.8f, 0.55f, 1.15f, 0.27f, 0.22f, 0x6A5A48, 0x2A2420)
        list.add(Species("Rimewooly", arrayOf(Zone.SNOW), false, 1.0f, 3.5f, true, true, 0.4f, 1.8f, 0.85f, 1.15f, 3, k.parts))
    }

    // 7. Sunstrider (Sunscar): a tall, long-necked runner with a glowing golden sail.
    run {
        val k = BodyKit()
        val hide = 0xC89A5A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 2.0f, 0f, 0.4f, 0.45f, 1.0f, hide, 81, 0.06f, FLAG_FUR)
            m.blob(0f, 1.85f, 0f, 0.32f, 0.3f, 0.8f, 0xE8D4B0, 82, 0.05f, FLAG_FUR)
            for (i in 0 until 7) {
                val z = -0.6f + i * 0.2f
                val h = 0.35f + sin(i * 0.45f) * 0.5f
                m.tri(0f, 2.35f, z, 0f, 2.35f + h, z + 0.1f, 0f, 2.35f, z + 0.2f, 0xFFC24A, FLAG_GLOW, 1f, 2.4f, z)
            }
        }
        k.part(PartKind.HEAD, 0f, 2.25f, 0.85f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.9f, 0.35f, 0.14f, 0.09f, hide, FLAG_FUR)
            m.blob(0f, 1.0f, 0.5f, 0.14f, 0.15f, 0.3f, hide, 83, 0.05f, FLAG_FUR)
            m.blob(0f, 0.95f, 0.78f, 0.06f, 0.06f, 0.05f, 0x3A2A1E, 84, 0f, FLAG_SOLID)
            m.blob(-0.1f, 1.06f, 0.6f, 0.025f, 0.025f, 0.025f, 0x101014, 85, 0f, FLAG_SOLID)
            m.blob(0.1f, 1.06f, 0.6f, 0.025f, 0.025f, 0.025f, 0x101014, 86, 0f, FLAG_SOLID)
            m.spike(-0.07f, 1.12f, 0.4f, 0.03f, 0.35f, -0.2f, -0.6f, 0x3A2A1E, FLAG_SOLID)
            m.spike(0.07f, 1.12f, 0.4f, 0.03f, 0.35f, 0.2f, -0.6f, 0x3A2A1E, FLAG_SOLID)
        }
        k.part(PartKind.TAIL, 0f, 2.0f, -1.0f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.5f, -0.25f, 0.05f, 0.02f, hide, FLAG_FUR)
            m.blob(0f, -0.55f, -0.27f, 0.06f, 0.1f, 0.06f, 0xFFC24A, 87, 0f, FLAG_GLOW)
        }
        k.legs4(1.78f, 0.62f, -0.62f, 0.22f, 1.78f, 0.085f, 0.05f, hide, 0x3A2A1E)
        list.add(Species("Sunstrider", arrayOf(Zone.DESERT), false, 1.8f, 11f, true, true, 0.55f, 1.6f, 0.9f, 1.1f, 3, k.parts))
    }

    // 8. Dunescale (Sunscar): a low armoured lizard with glowing amber plates down its back.
    run {
        val k = BodyKit()
        val hide = 0x9A7A4A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.45f, 0f, 0.4f, 0.26f, 1.0f, hide, 91, 0.1f, FLAG_FUR)
            m.blob(0f, 0.36f, 0f, 0.34f, 0.16f, 0.9f, 0xC8B088, 92, 0.05f, FLAG_FUR)
            for (i in 0 until 8) {
                val z = -0.8f + i * 0.23f
                m.spike(0f, 0.62f, z, 0.07f, 0.2f + (i % 3) * 0.06f, 0f, -0.3f, 0xFF9A3A, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.46f, 0.95f) { m ->
            m.blob(0f, 0f, 0.22f, 0.22f, 0.15f, 0.32f, hide, 93, 0.06f, FLAG_FUR)
            m.box(-0.14f, 0.07f, 0.3f, 0.04f, 0.025f, 0.03f, 0f, 0xFFD06A, FLAG_GLOW)
            m.box(0.14f, 0.07f, 0.3f, 0.04f, 0.025f, 0.03f, 0f, 0xFFD06A, FLAG_GLOW)
            m.spike(-0.12f, 0.1f, 0.05f, 0.04f, 0.18f, -0.4f, -0.6f, 0x6A5030, FLAG_SOLID)
            m.spike(0.12f, 0.1f, 0.05f, 0.04f, 0.18f, 0.4f, -0.6f, 0x6A5030, FLAG_SOLID)
        }
        k.part(PartKind.TAIL, 0f, 0.42f, -0.95f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.12f, -0.8f, 0.16f, 0.08f, hide, FLAG_FUR)
            m.limb(0f, -0.12f, -0.8f, 0f, -0.25f, -1.5f, 0.08f, 0.02f, hide, FLAG_FUR)
        }
        k.legs4(0.38f, 0.55f, -0.5f, 0.36f, 0.38f, 0.08f, 0.06f, hide, 0x4A3A22, splay = 0.2f)
        list.add(Species("Dunescale", arrayOf(Zone.DESERT), false, 1.1f, 4f, false, false, 0.7f, 3.5f, 0.9f, 1.2f, 2, k.parts))
    }

    // 9. Voidhound (Hollow Deep): a lean shadow hound with purple crystal spines.
    run {
        val k = BodyKit()
        val fur = 0x2A2238
        val glow = 0xB070FF
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.95f, 0f, 0.26f, 0.28f, 0.75f, fur, 101, 0.08f, FLAG_FUR)
            for (i in 0 until 7) {
                val z = -0.55f + i * 0.18f
                m.spike(0f, 1.18f, z, 0.05f, 0.18f + (i % 2) * 0.12f, 0f, -0.4f, glow, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 1.05f, 0.7f) { m ->
            m.blob(0f, 0f, 0.15f, 0.18f, 0.16f, 0.22f, fur, 102, 0.05f, FLAG_FUR)
            m.limb(0f, -0.02f, 0.28f, 0f, -0.06f, 0.5f, 0.09f, 0.05f, fur, FLAG_FUR)
            m.spike(-0.1f, 0.12f, 0.06f, 0.04f, 0.22f, -0.2f, -0.5f, fur, FLAG_FUR)
            m.spike(0.1f, 0.12f, 0.06f, 0.04f, 0.22f, 0.2f, -0.5f, fur, FLAG_FUR)
            m.box(-0.08f, 0.06f, 0.33f, 0.04f, 0.02f, 0.02f, 0f, 0xD8A0FF, FLAG_GLOW)
            m.box(0.08f, 0.06f, 0.33f, 0.04f, 0.02f, 0.02f, 0f, 0xD8A0FF, FLAG_GLOW)
        }
        k.part(PartKind.TAIL, 0f, 1.0f, -0.72f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.1f, -0.6f, 0.06f, 0.02f, fur, FLAG_FUR)
            m.blob(0f, 0.11f, -0.62f, 0.05f, 0.05f, 0.05f, glow, 103, 0f, FLAG_GLOW)
        }
        k.legs4(0.72f, 0.5f, -0.5f, 0.15f, 0.72f, 0.07f, 0.05f, fur, 0x14101C)
        list.add(Species("Voidhound", arrayOf(Zone.CAVES), false, 1.6f, 7f, false, false, 0.65f, 3.2f, 0.9f, 1.15f, 2, k.parts))
    }

    // 10. Crystalback (Hollow Deep): a six-legged armoured beast covered in glowing crystals.
    run {
        val k = BodyKit()
        val shell = 0x3A3048
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.95f, 0f, 0.8f, 0.6f, 1.1f, shell, 111, 0.12f, FLAG_SOLID)
            m.blob(0f, 0.65f, 0f, 0.7f, 0.25f, 1.0f, 0x28202E, 112, 0.1f, FLAG_FUR)
            for (i in 0 until 11) {
                val a = i * 1.1f
                val r = 0.15f + (i % 4) * 0.14f
                m.spike(sin(a) * r, 1.4f, cos(a) * r * 1.4f, 0.09f, 0.35f + (i % 3) * 0.2f, sin(a) * 0.4f, cos(a) * 0.3f,
                    if (i % 2 == 0) 0xC8A0FF else 0x8ADCFF, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.85f, 1.05f) { m ->
            m.blob(0f, 0f, 0.2f, 0.35f, 0.3f, 0.35f, shell, 113, 0.08f, FLAG_SOLID)
            m.limb(0f, 0.1f, 0.45f, 0f, 0.35f, 0.95f, 0.1f, 0.01f, 0xC8A0FF, FLAG_GLOW)
            m.box(-0.18f, 0.08f, 0.5f, 0.04f, 0.03f, 0.02f, 0f, 0xE8D0FF, FLAG_GLOW)
            m.box(0.18f, 0.08f, 0.5f, 0.04f, 0.03f, 0.02f, 0f, 0xE8D0FF, FLAG_GLOW)
        }
        for ((z, ph) in listOf(0.6f to 0f, 0f to 3.1415927f, -0.6f to 0f)) {
            k.leg(-0.65f, 0.62f, z, ph, 0.62f, 0.1f, 0.07f, shell, 0x1A1422, -0.3f)
            k.leg(0.65f, 0.62f, z, ph + 3.1415927f, 0.62f, 0.1f, 0.07f, shell, 0x1A1422, 0.3f)
        }
        list.add(Species("Crystalback", arrayOf(Zone.CAVES), false, 0.8f, 2f, false, false, 0.5f, 3f, 0.85f, 1.2f, 1, k.parts))
    }

    // ---- Birds ----
    fun wing(k: BodyKit, left: Boolean, span: Float, inner: Int, outer: Int, tip: Int, tipFlag: Int) {
        val s = if (left) -1f else 1f
        k.part(if (left) PartKind.WING_L else PartKind.WING_R, s * 0.1f, 0.04f, 0f) { m ->
            val a = span * 0.45f
            m.quad(0f, 0f, 0.13f, s * a, 0f, 0.12f, s * a, 0f, -0.2f, 0f, 0f, -0.15f, inner, FLAG_FUR, 0f, -1f, 0f)
            m.quad(s * a, 0f, 0.12f, s * span * 0.85f, 0f, 0.02f, s * span * 0.8f, 0f, -0.28f, s * a, 0f, -0.2f, outer, FLAG_FUR, 0f, -1f, 0f)
            m.tri(s * span * 0.85f, 0f, 0.02f, s * span, 0f, -0.1f, s * span * 0.8f, 0f, -0.28f, tip, tipFlag, 0f, -1f, 0f)
        }
    }

    // 11. Emberwing (Sunscar): a fiery red and gold bird trailing glowing tail plumes.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.17f, 0.17f, 0.42f, 0xC8321E, 121, 0.05f, FLAG_FUR)
            m.blob(0f, 0.1f, 0.4f, 0.12f, 0.12f, 0.13f, 0xE0501E, 122, 0.05f, FLAG_FUR)
            m.limb(0f, 0.08f, 0.5f, 0f, 0.03f, 0.66f, 0.04f, 0.005f, 0xFFC040, FLAG_SOLID)
            m.box(-0.08f, 0.14f, 0.48f, 0.015f, 0.015f, 0.015f, 0f, 0xFFE070, FLAG_GLOW)
            m.box(0.08f, 0.14f, 0.48f, 0.015f, 0.015f, 0.015f, 0f, 0xFFE070, FLAG_GLOW)
            m.spike(0f, 0.2f, 0.36f, 0.03f, 0.18f, 0f, -0.8f, 0xFF8A2A, FLAG_GLOW)
            for (i in -1..1) m.tri(0f, 0f, -0.35f, i * 0.2f - 0.08f, -0.05f, -1.1f, i * 0.2f + 0.08f, -0.05f, -1.1f, 0xFF8A2A, FLAG_GLOW, 0f, -1f, -0.5f)
        }
        wing(k, true, 1.0f, 0xC8321E, 0xE06A28, 0xFFB040, FLAG_GLOW)
        wing(k, false, 1.0f, 0xC8321E, 0xE06A28, 0xFFB040, FLAG_GLOW)
        list.add(Species("Emberwing", arrayOf(Zone.DESERT), true, 10f, 10f, false, false, 0f, 7f, 0.9f, 1.3f, 1, k.parts))
    }

    // 12. Azure Tailwing (Greenhollow): a bright blue songbird with long ribbon tail feathers.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.13f, 0.13f, 0.3f, 0x3A7ADC, 131, 0.05f, FLAG_FUR)
            m.blob(0f, 0.07f, 0.3f, 0.1f, 0.1f, 0.1f, 0x5A9AF0, 132, 0.05f, FLAG_FUR)
            m.blob(0f, -0.04f, 0.1f, 0.09f, 0.08f, 0.18f, 0xF0E8C8, 133, 0.05f, FLAG_FUR)
            m.limb(0f, 0.06f, 0.38f, 0f, 0.04f, 0.48f, 0.03f, 0.004f, 0x2A2A2A, FLAG_SOLID)
            m.box(-0.06f, 0.1f, 0.36f, 0.012f, 0.012f, 0.012f, 0f, 0x101014, FLAG_SOLID)
            m.box(0.06f, 0.1f, 0.36f, 0.012f, 0.012f, 0.012f, 0f, 0x101014, FLAG_SOLID)
            m.tri(-0.03f, 0f, -0.25f, -0.12f, -0.02f, -1.0f, -0.04f, -0.02f, -1.0f, 0x6AD8FF, FLAG_GLOW, 0f, -1f, -0.5f)
            m.tri(0.03f, 0f, -0.25f, 0.04f, -0.02f, -1.0f, 0.12f, -0.02f, -1.0f, 0x6AD8FF, FLAG_GLOW, 0f, -1f, -0.5f)
        }
        wing(k, true, 0.75f, 0x3A7ADC, 0x2A5AB8, 0x1A3A88, FLAG_FUR)
        wing(k, false, 0.75f, 0x3A7ADC, 0x2A5AB8, 0x1A3A88, FLAG_FUR)
        list.add(Species("Azure Tailwing", arrayOf(Zone.MEADOW), true, 9f, 9f, false, false, 0f, 10f, 0.9f, 1.2f, 1, k.parts))
    }

    // 13. Frostkite (Frostpeak): a pale hunting bird with wing edges of glowing ice.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.15f, 0.14f, 0.45f, 0xDCEAF5, 141, 0.05f, FLAG_FUR)
            m.blob(0f, 0.08f, 0.42f, 0.11f, 0.11f, 0.13f, 0xF4F8FC, 142, 0.05f, FLAG_FUR)
            m.limb(0f, 0.06f, 0.52f, 0f, -0.02f, 0.64f, 0.035f, 0.004f, 0x5A6A7A, FLAG_SOLID)
            m.box(-0.07f, 0.12f, 0.48f, 0.014f, 0.014f, 0.014f, 0f, 0xA8E4FF, FLAG_GLOW)
            m.box(0.07f, 0.12f, 0.48f, 0.014f, 0.014f, 0.014f, 0f, 0xA8E4FF, FLAG_GLOW)
            m.tri(-0.1f, 0f, -0.38f, 0.1f, 0f, -0.38f, 0f, -0.02f, -0.85f, 0xC8DCEA, FLAG_FUR, 0f, -1f, -0.5f)
        }
        wing(k, true, 1.3f, 0xDCEAF5, 0xB8CCDC, 0xA8E4FF, FLAG_GLOW)
        wing(k, false, 1.3f, 0xDCEAF5, 0xB8CCDC, 0xA8E4FF, FLAG_GLOW)
        list.add(Species("Frostkite", arrayOf(Zone.SNOW), true, 12f, 12f, false, false, 0f, 5f, 0.9f, 1.2f, 1, k.parts))
    }

    // 14. Duskraven (Whisperwood and the Hollow Deep): a black bird with violet-glowing eyes and wing edges.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.15f, 0.15f, 0.38f, 0x1E1A24, 151, 0.05f, FLAG_FUR)
            m.blob(0f, 0.08f, 0.36f, 0.12f, 0.12f, 0.13f, 0x2A2432, 152, 0.05f, FLAG_FUR)
            m.limb(0f, 0.06f, 0.46f, 0f, 0.01f, 0.64f, 0.045f, 0.005f, 0x14121A, FLAG_SOLID)
            m.box(-0.07f, 0.12f, 0.43f, 0.016f, 0.016f, 0.016f, 0f, 0xC08AFF, FLAG_GLOW)
            m.box(0.07f, 0.12f, 0.43f, 0.016f, 0.016f, 0.016f, 0f, 0xC08AFF, FLAG_GLOW)
            m.tri(-0.12f, 0f, -0.3f, 0.12f, 0f, -0.3f, 0f, -0.02f, -0.8f, 0x1E1A24, FLAG_FUR, 0f, -1f, -0.5f)
        }
        wing(k, true, 1.0f, 0x1E1A24, 0x28222E, 0x9A5AFF, FLAG_GLOW)
        wing(k, false, 1.0f, 0x1E1A24, 0x28222E, 0x9A5AFF, FLAG_GLOW)
        list.add(Species("Duskraven", arrayOf(Zone.FOREST, Zone.CAVES), true, 9f, 9f, false, false, 0f, 6f, 0.9f, 1.2f, 1, k.parts))
    }
    return list
}
