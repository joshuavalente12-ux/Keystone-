package com.keystone.rpg

import android.opengl.Matrix
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/** How each piece of a creature moves. */
object PartKind {
    const val BODY = 0
    const val HEAD = 1
    const val LEG = 2
    const val TAIL = 3
    const val WING_L = 4
    const val WING_R = 5
    /** Lower leg, hanging from the knee of its parent [LEG]. */
    const val SHIN = 6
    /** Outer half of a wing, hanging from the tip of its parent wing. */
    const val WING_TIP_L = 7
    const val WING_TIP_R = 8
    /** A monster's arm: swings as it walks, and comes down hard when it attacks. */
    const val ARM = 9
    /** One piece of a serpent's body, hanging from the piece in front of it. */
    const val SEGMENT = 10
}

/** Soft fur and feathers (lit gently, no ground pattern). */
const val FLAG_FUR = 253

/** A monster's special combat trait, on top of its raw stats. */
object Ability {
    /** Nothing special: stats alone do the talking (usually a tankier, high-defense brute). */
    const val NONE = 0
    /** Dashes at you fast during the windup of its swing, instead of standing still. */
    const val LUNGE = 1
    /** Slowly heals back up if it hasn't been hit in a few seconds. */
    const val REGEN = 2
    /** Hits much harder and moves faster once it's below 30% health. */
    const val ENRAGE = 3
    /** Its bite leaves a poison that keeps draining your health for a few seconds after. */
    const val POISON = 4
    /** Calls its kind nearby to jump in the moment it spots you. */
    const val PACK = 5

    /** A short name for the Bestiary, or "" for [NONE]. */
    fun label(a: Int): String = when (a) {
        LUNGE -> "Lunge"
        REGEN -> "Regenerates"
        ENRAGE -> "Enrages"
        POISON -> "Poison bite"
        PACK -> "Pack hunter"
        else -> ""
    }

    /** What that trait means for a fight, for the Bestiary. */
    fun desc(a: Int): String = when (a) {
        LUNGE -> "Dashes in fast right before it swings — don't count on backing away."
        REGEN -> "Heals back up if you're not actively pressuring it."
        ENRAGE -> "Hits harder and moves faster once it's badly hurt."
        POISON -> "Its bite keeps draining your health for a few seconds after."
        PACK -> "Calls its kind in from nearby the moment it spots you."
        else -> "No special trait — its stats do the talking."
    }
}

/** One moving piece. Its mesh is built around its own pivot (hip, neck, shoulder...). */
class CreaturePart(
    val kind: Int, val px: Float, val py: Float, val pz: Float, val phase: Float,
    val data: ByteBuffer, val count: Int,
    /** The piece this one hangs from; its pivot (px, py, pz) is then in the parent's space. */
    val parent: CreaturePart? = null,
) {
    var buffer = 0
}

class Species(
    val name: String,
    val zones: Array<Zone>,
    val bird: Boolean,
    val walk: Float,
    val run: Float,
    val timid: Boolean,
    val grazes: Boolean,
    val legSwing: Float,
    val stride: Float,
    val minScale: Float,
    val maxScale: Float,
    val herd: Int,
    val parts: List<CreaturePart>,
    /** Monsters hunt you instead of running away. */
    val monster: Boolean = false,
    /** Hits it takes to bring down. */
    val hp: Int = 3,
    /** How much of your health one of its attacks takes. */
    val damage: Float = 0f,
    /** How far past its body it can reach you. */
    val reach: Float = 0f,
    /** Floats this high above the ground (0 = walks). */
    val hover: Float = 0f,
    /** Bounces along like a slime. */
    val bouncy: Boolean = false,
    val levelMin: Int = 0,
    val levelMax: Int = 0,
    /** Which monster growl it makes (see [Sound]). */
    val growl: Int = 14,
    /** Cuts down damage it takes from you: 0.25 means a quarter less. */
    val defense: Float = 0f,
    /** Its special trait in a fight, on top of hp/damage/reach/defense (see [Ability]). */
    val ability: Int = Ability.NONE,
    /** Only ever placed by [Fauna.trySpawnGrainFoes] on the Grain Rot platform — never spawns outdoors. */
    val grainOnly: Boolean = false,
    /** Only ever placed by [Fauna.spawnCaveGuards] inside a cave: never spawns outdoors. */
    val caveOnly: Boolean = false,
    /** Fires a bolt of lightning at you from this far away instead of striking up close (0 = melee only). */
    val ranged: Float = 0f,
) {
    /** Index into the creature calls made by [Sound]. */
    var call = 0

    // Solid body for bumping into, measured from the body mesh: a sausage lying along
    // the animal (radius, half-length of the middle bit, and how far forward its middle is).
    val colR: Float
    val colHalf: Float
    val colZ: Float

    init {
        var minX = 0f
        var maxX = 0f
        var minZ = 0f
        var maxZ = 0f
        var first = true
        // Serpents have no single body piece: measure the pieces at the front instead.
        val noBody = parts.none { it.kind == PartKind.BODY }
        for (pt in parts) {
            if (pt.kind != PartKind.BODY && !(noBody && pt.parent == null)) continue
            for (v in 0 until pt.count) {
                val px = pt.data.getFloat(v * STRIDE) + pt.px
                val pz = pt.data.getFloat(v * STRIDE + 8) + pt.pz
                if (first) {
                    minX = px
                    maxX = px
                    minZ = pz
                    maxZ = pz
                    first = false
                } else {
                    minX = min(minX, px)
                    maxX = max(maxX, px)
                    minZ = min(minZ, pz)
                    maxZ = max(maxZ, pz)
                }
            }
        }
        colR = (maxX - minX) * 0.5f * 0.9f
        colHalf = max(0f, (maxZ - minZ) * 0.5f - colR)
        colZ = (maxZ + minZ) * 0.5f
    }
}

/** One living animal or bird in the world. */
class Creature {
    var active = false
    var sp = 0
    var x = 0f
    var y = 0f
    var z = 0f
    var yaw = 0f
    var wantYaw = 0f
    var speed = 0f
    var state = 0
    var timer = 0f
    var phase = 0f
    var scale = 1f
    var callIn = 5f
    var head = 0f
    // Birds: circling centre, radius, height above ground, angle, wing beat.
    var cx = 0f
    var cz = 0f
    var radius = 30f
    var alt = 30f
    var angle = 0f
    var flap = 1f
    var flapWant = 1f
    var roll = 0f
    /** Nose up or down to follow the slope it's standing on. */
    var pitch = 0f
    /** Health left before it goes down (a basic hit takes 1). */
    var health = 3f
    /** Flinch after being hit, counting down from 1. */
    var hurt = 0f
    /** Seconds since it went down, or -1 while it's alive. */
    var dying = -1f
    /** Seconds since you last landed a hit on it (for [Ability.REGEN]). */
    var sinceHit = 999f
    // Knocked-back speed.
    var kvx = 0f
    var kvz = 0f
    // Monsters only.
    var level = 1
    var maxHealth = 3f
    /** Hunting you right now. */
    var aggro = false
    /** Attack in progress: counts down from 1 to 0. */
    var strike = 0f
    var cooldown = 0f
    var homeX = 0f
    var homeZ = 0f
    /** Which region boss this is (index into [BOSSES]), or -1 for an ordinary monster. */
    var boss = -1
    /** Which carriage ambush spawned this (index into Carriages.spots), or -1 for an ordinary monster. */
    var ambush = -1
    /** Its body stays lying there, waiting to be searched, while this is on. */
    var keep = false
}

/**
 * The wildlife: ten invented beasts (two per region) and four birds, each with its
 * own look, walk, behaviour and call. Animals spawn around you in the region they
 * belong to and wander off again when you leave.
 */
class Fauna(private val world: World) {
    companion object {
        const val BOLT_MAX = 12
    }

    val species: List<Species> = buildSpecies() + buildMonsters() + buildGrainMonsters() + buildCaveMonsters()
    val animals = Array(26) { Creature() }
    val birds = Array(9) { Creature() }
    /** Monsters roaming near you. */
    val foes = Array(10) { Creature() }
    /** Seconds left before each foe slot is allowed to spawn again, after something there was killed. */
    private val foeCooldown = FloatArray(foes.size)
    /** How long a monster stays gone after you kill it: 20 minutes. */
    private val RESPAWN_COOLDOWN = 1200f

    /** Called the moment an ordinary monster (not a boss) falls: its spot won't spawn again for a while. */
    fun startCooldown(c: Creature) {
        val i = foes.indexOf(c)
        if (i >= 0) foeCooldown[i] = RESPAWN_COOLDOWN
    }
    /** The region bosses, one each, waiting in their lairs. */
    val bosses = Array(BOSSES.size) { Creature() }
    /** Monsters roaming the Grain Rot arrival platform — only stepped while [grainActive]. */
    val grainFoes = Array(16) { Creature() }
    /** Set by the game: whether the player is inside the Grain Rot Dimension right now. */
    var grainActive = false
    /** Set by the game: the real-world spot the dimension's platform sits under (its centre). */
    var grainCenterX = 0f
    var grainCenterZ = 0f
    private var grainSpawnTimer = 0f
    /** Set by the game: you're inside a cave, whose guards live in [grainFoes] while you're there. */
    var caveActive = false
    var caveRef: Cave? = null
    /** Set by the game: how high your chest is, so bolts aim at you. */
    var playerY = 0f
    /** Lightning bolts in flight: x, y, z, vx, vy, vz, age (age < 0 = free slot). */
    val bolts = FloatArray(BOLT_MAX * 7).also { for (i in 0 until BOLT_MAX) it[i * 7 + 6] = -1f }
    /** Everything on the ground you can hit or bump into: animals, monsters, bosses and grain foes. */
    val creatures: Array<Creature> = animals + foes + bosses + grainFoes

    /** Set by the game: a monster you're hunting for a quest nearby, so more of them turn up (-1 = none). */
    var favorSpecies = -1
    /** Set by the game: which bosses are already beaten (they don't come back). */
    var bossMask = 0
    /** Set by the game: where each boss's lair is. */
    var lairX = FloatArray(BOSSES.size)
    var lairZ = FloatArray(BOSSES.size)
    private val bossSpecies = IntArray(BOSSES.size) { -1 }

    /** Damage monsters have done to you since the game last collected it. */
    var pendingDamage = 0f
    /** The monster that hit you last. */
    var lastAttacker: Creature? = null
    /** Set by the game: monsters stop hunting while you're down. */
    var playerDown = false
    /** Set by the game: your level. Monsters well above it hit much harder. */
    var playerLevel = 1
    /** Seconds of poison left on you from an [Ability.POISON] bite, and how hard it drains per second. */
    var poisonTime = 0f
    var poisonDps = 0f
    private var foeTimer = 0f

    private val rnd = Random(90210)
    private val probe = Probe()
    private var spawnTimer = 0f
    private val tmp = FloatArray(16)

    init {
        for (i in species.indices) species[i].call = if (species[i].monster) species[i].growl else i
        for (b in BOSSES.indices) bossSpecies[b] = species.indexOfFirst { it.name == BOSSES[b].base }
    }

    fun update(dt: Float, px: Float, pz: Float, time: Float) {
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            spawnTimer = 0.4f
            trySpawnAnimals(px, pz)
            trySpawnBird(px, pz)
        }
        foeTimer -= dt
        if (foeTimer <= 0f) {
            foeTimer = 1.2f
            trySpawnFoes(px, pz)
            trySpawnBosses(px, pz)
        }
        if (poisonTime > 0f) {
            poisonTime -= dt
            if (poisonTime <= 0f) { poisonTime = 0f; poisonDps = 0f }
        }
        for (i in foeCooldown.indices) if (foeCooldown[i] > 0f) foeCooldown[i] -= dt
        for (c in animals) if (c.active) stepAnimal(c, dt, px, pz)
        for (c in birds) if (c.active) stepBird(c, dt, px, pz, time)
        for (c in foes) if (c.active) stepFoe(c, dt, px, pz, time)
        for (c in bosses) if (c.active) stepFoe(c, dt, px, pz, time)
        if (grainActive) {
            grainSpawnTimer -= dt
            if (grainSpawnTimer <= 0f) {
                grainSpawnTimer = 0.5f
                trySpawnGrainFoes()
            }
            for (c in grainFoes) if (c.active) stepGrainFoe(c, dt, px, pz)
        } else if (caveActive) {
            for (c in grainFoes) if (c.active) stepGrainFoe(c, dt, px, pz)
            stepBolts(dt, px, pz)
        } else {
            for (i in 0 until BOLT_MAX) bolts[i * 7 + 6] = -1f
            for (c in grainFoes) c.active = false
        }
    }

    /** A boss appears in its lair when you come near, unless you've already beaten it. */
    private fun trySpawnBosses(px: Float, pz: Float) {
        if (playerDown) return
        for (i in bosses.indices) {
            val c = bosses[i]
            val si = bossSpecies[i]
            if (c.active || si < 0 || ((bossMask shr i) and 1) == 1) continue
            if (hypot(px - lairX[i], pz - lairZ[i]) > 150f) continue
            val sp = species[si]
            val b = BOSSES[i]
            c.active = true
            c.sp = si
            c.boss = i
            c.keep = false
            c.x = lairX[i]
            c.z = lairZ[i]
            c.homeX = c.x
            c.homeZ = c.z
            c.y = world.terrainAt(c.x, c.z) + sp.hover
            c.yaw = rnd.nextFloat() * 6.2831855f
            c.wantYaw = c.yaw
            c.speed = 0f
            c.state = 0
            c.timer = 2f
            c.phase = rnd.nextFloat() * 6f
            c.scale = sp.maxScale * b.scale
            c.callIn = 3f
            c.head = 0f
            c.pitch = 0f
            c.dying = -1f
            c.hurt = 0f
            c.kvx = 0f
            c.kvz = 0f
            c.flap = 1f
            c.aggro = false
            c.strike = 0f
            c.cooldown = 0f
            c.level = b.level
            c.maxHealth = b.health
            c.health = b.health
        }
    }

    /** A pack hunter spots you and drags its nearby kin into the fight too. */
    private fun alertPack(c: Creature) {
        for (o in foes) {
            if (o === c || !o.active || o.dying >= 0f || o.aggro || o.sp != c.sp) continue
            if (hypot(o.x - c.x, o.z - c.z) < 22f) {
                o.aggro = true
                o.callIn = min(o.callIn, 0.2f)
            }
        }
    }

    /** Every monster forgets about you (after you've been knocked out). */
    fun calmAll() {
        for (c in foes + bosses) {
            c.aggro = false
            c.strike = 0f
        }
    }

    /** Where a monster may go: it keeps out of villages (they're safe), deep water and the high peaks. */
    private fun foeGround(x: Float, z: Float, hover: Boolean): Boolean {
        if (x < 20f || z < 20f || x > WORLD_SIZE - 20f || z > WORLD_SIZE - 20f) return false
        world.probe(x, z, probe)
        if (probe.mountain > 0.75f || probe.site < 25f) return false
        if (!hover && world.terrainAt(x, z) < 0.8f) return false
        return !world.isBlocked(x, z, probe)
    }

    private fun trySpawnFoes(px: Float, pz: Float) {
        var alive = 0
        for (c in foes) if (c.active) alive++
        if (alive >= 7) return
        val a = rnd.nextFloat() * 6.2831855f
        val r = 50f + rnd.nextFloat() * 60f
        val x = px + cos(a) * r
        val z = pz + sin(a) * r
        if (!foeGround(x, z, false)) return
        if (probe.mountain > 0.25f || probe.site < 45f) return
        val zone = probe.zone
        var n = 0
        for (sp in species) if (sp.monster && zone in sp.zones && !sp.grainOnly && !sp.caveOnly) n++
        if (n == 0) return
        var pick = rnd.nextInt(n)
        var si = -1
        for (i in species.indices) {
            val sp = species[i]
            if (sp.monster && zone in sp.zones && !sp.grainOnly && !sp.caveOnly) {
                if (pick == 0) {
                    si = i
                    break
                }
                pick--
            }
        }
        if (si < 0) return
        val fav = favorSpecies
        if (fav in species.indices && zone in species[fav].zones && !species[fav].grainOnly && !species[fav].caveOnly && rnd.nextFloat() < 0.6f) si = fav
        val sp = species[si]
        val count = 1 + rnd.nextInt(sp.herd)
        for (k in 0 until count) {
            val slot = foes.indices.firstOrNull { !foes[it].active && foeCooldown[it] <= 0f } ?: return
            val c = foes[slot]
            val hx = x + (rnd.nextFloat() - 0.5f) * 8f
            val hz = z + (rnd.nextFloat() - 0.5f) * 8f
            if (!foeGround(hx, hz, sp.hover > 0f)) continue
            c.active = true
            c.sp = si
            c.boss = -1
            c.ambush = -1
            c.keep = false
            c.x = hx
            c.z = hz
            c.homeX = hx
            c.homeZ = hz
            c.y = world.terrainAt(hx, hz) + sp.hover
            c.yaw = rnd.nextFloat() * 6.2831855f
            c.wantYaw = c.yaw
            c.speed = 0f
            c.state = 0
            c.timer = 1f + rnd.nextFloat() * 3f
            c.phase = rnd.nextFloat() * 6f
            c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
            c.callIn = 2f + rnd.nextFloat() * 8f
            c.head = 0f
            c.pitch = 0f
            c.dying = -1f
            c.hurt = 0f
            c.kvx = 0f
            c.kvz = 0f
            c.flap = 1f
            c.aggro = false
            c.strike = 0f
            c.cooldown = 0f
            c.level = sp.levelMin + rnd.nextInt(sp.levelMax - sp.levelMin + 1)
            // Monster toughness grows with its own level, not just its species base.
            c.maxHealth = (sp.hp * (1f + c.level * 0.09f)).coerceAtLeast(1f)
            c.health = c.maxHealth
        }
    }

    /**
     * Forces one monster fitting [zone] into a free slot in [foes] at ([x], [z]), tagged with
     * [ambushId] so a Carriages spot can tell when everything it spawned is dead. Used for
     * carriage ambushes, which need a monster to appear at an exact spot rather than near you.
     * Returns whether a slot and a species were both available.
     */
    fun spawnAmbushFoe(x: Float, z: Float, zone: Zone, ambushId: Int): Boolean {
        val slot = foes.indices.firstOrNull { !foes[it].active && foeCooldown[it] <= 0f } ?: return false
        var n = 0
        for (sp in species) if (sp.monster && zone in sp.zones && !sp.grainOnly && !sp.caveOnly) n++
        if (n == 0) return false
        var pick = rnd.nextInt(n)
        var si = -1
        for (i in species.indices) {
            val sp = species[i]
            if (sp.monster && zone in sp.zones && !sp.grainOnly && !sp.caveOnly) {
                if (pick == 0) {
                    si = i
                    break
                }
                pick--
            }
        }
        if (si < 0) return false
        val sp = species[si]
        val hx = x + (rnd.nextFloat() - 0.5f) * 6f
        val hz = z + (rnd.nextFloat() - 0.5f) * 6f
        val c = foes[slot]
        c.active = true
        c.sp = si
        c.boss = -1
        c.ambush = ambushId
        c.keep = false
        c.x = hx
        c.z = hz
        c.homeX = hx
        c.homeZ = hz
        c.y = world.terrainAt(hx, hz) + sp.hover
        c.yaw = rnd.nextFloat() * 6.2831855f
        c.wantYaw = c.yaw
        c.speed = 0f
        c.state = 0
        c.timer = 1f + rnd.nextFloat() * 3f
        c.phase = rnd.nextFloat() * 6f
        c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
        c.callIn = 2f + rnd.nextFloat() * 8f
        c.head = 0f
        c.pitch = 0f
        c.dying = -1f
        c.hurt = 0f
        c.kvx = 0f
        c.kvz = 0f
        c.flap = 1f
        c.aggro = true
        c.strike = 0f
        c.cooldown = 0f
        c.level = sp.levelMin + rnd.nextInt(sp.levelMax - sp.levelMin + 1)
        c.maxHealth = (sp.hp * (1f + c.level * 0.09f)).coerceAtLeast(1f)
        c.health = c.maxHealth
        return true
    }

    private fun stepFoe(c: Creature, dt: Float, px: Float, pz: Float, time: Float) {
        val sp = species[c.sp]
        val dx = px - c.x
        val dz = pz - c.z
        val dist = hypot(dx, dz)
        if (dist > 200f) {
            c.active = false
            return
        }
        knockBack(c, dt, sp.hover > 0f)
        if (c.hurt > 0f) c.hurt = max(0f, c.hurt - dt * 4f)
        if (c.dying >= 0f) {
            c.dying += dt
            // A body waiting to be searched lies still; once it's been searched it sinks away.
            if (c.keep && c.dying > 3.4f) c.dying = 3.4f
            c.speed = 0f
            c.strike = 0f
            c.y += (world.terrainAt(c.x, c.z) - c.y) * min(1f, dt * 6f)
            if (c.dying > 4.5f) c.active = false
            return
        }
        c.cooldown -= dt
        c.timer -= dt
        c.sinceHit += dt
        if (sp.ability == Ability.REGEN && c.sinceHit > 3f && c.health < c.maxHealth) {
            c.health = min(c.maxHealth, c.health + c.maxHealth * 0.05f * dt)
        }
        val body = (sp.colR + sp.colHalf * 0.5f) * c.scale
        val homeD = hypot(c.x - c.homeX, c.z - c.homeZ)
        val isBoss = c.boss >= 0
        // Spots you, or gives up the chase. Bosses guard their lair and won't be drawn far from it.
        if (!c.aggro && !playerDown && dist < (if (isBoss) 26f else 15f) + body) {
            c.aggro = true
            c.callIn = min(c.callIn, 0.1f)
            if (sp.ability == Ability.PACK) alertPack(c)
        }
        if (c.aggro && (dist > (if (isBoss) 60f else 45f) || homeD > (if (isBoss) 45f else 75f) || playerDown)) c.aggro = false
        // A boss that lost you heals back up once it's home.
        if (isBoss && !c.aggro && homeD < 6f) c.health = min(c.maxHealth, c.health + c.maxHealth * 0.1f * dt)
        var turnRate = 2.5f
        if (c.strike > 0f) {
            // Mid-attack: the blow lands halfway through, if you're still in reach.
            val before = c.strike
            c.strike -= dt / 0.7f
            if (before > 0.5f && c.strike <= 0.5f && !playerDown && dist < sp.reach * c.scale + body + 0.9f) {
                // Stronger at higher levels, and much more dangerous if it outlevels you.
                val gap = (1f + (c.level - playerLevel) * 0.05f).coerceIn(0.25f, 3f)
                val mul = if (c.boss >= 0) BOSSES[c.boss].hitMul else 1f
                // Enraged monsters hit noticeably harder once they're on their last legs.
                val enrage = if (sp.ability == Ability.ENRAGE && c.health < c.maxHealth * 0.3f) 1.6f else 1f
                val dealt = sp.damage * (1f + c.level * 0.1f) * gap * mul * enrage
                pendingDamage += dealt
                if (sp.ability == Ability.POISON) {
                    poisonTime = max(poisonTime, 4f)
                    poisonDps = max(poisonDps, dealt * 0.15f)
                }
                lastAttacker = c
            }
            if (c.strike < 0f) c.strike = 0f
            // Lungers close the gap fast in the first half of their windup, then plant for the hit.
            val enrageSpeed = if (sp.ability == Ability.ENRAGE && c.health < c.maxHealth * 0.3f) 1.35f else 1f
            if (sp.ability == Ability.LUNGE && before > 0.5f) {
                c.speed += (sp.run * 1.7f * enrageSpeed - c.speed) * min(1f, dt * 6f)
            } else {
                c.speed += (0f - c.speed) * min(1f, dt * 8f)
            }
        } else if (c.aggro) {
            c.wantYaw = atan2(dx, dz)
            turnRate = 6f
            val reachD = sp.reach * c.scale + body
            if (dist > reachD) {
                val enraged = sp.ability == Ability.ENRAGE && c.health < c.maxHealth * 0.3f
                c.speed += (sp.run * (if (enraged) 1.35f else 1f) - c.speed) * min(1f, dt * 3f)
            } else {
                c.speed += (0f - c.speed) * min(1f, dt * 8f)
                var d = c.wantYaw - c.yaw
                while (d > 3.1415927f) d -= 6.2831855f
                while (d < -3.1415927f) d += 6.2831855f
                if (c.cooldown <= 0f && abs(d) < 0.6f) {
                    c.strike = 1f
                    val enraged = sp.ability == Ability.ENRAGE && c.health < c.maxHealth * 0.3f
                    c.cooldown = (1.3f + rnd.nextFloat() * 0.7f) * (if (enraged) 0.6f else 1f)
                    if (rnd.nextFloat() < 0.4f) Sound.call(sp.call, callLevel(dist))
                }
            }
        } else if (homeD > (if (isBoss) 6f else 30f)) {
            // Wander back towards home.
            c.wantYaw = atan2(c.homeX - c.x, c.homeZ - c.z)
            c.speed += (sp.walk - c.speed) * min(1f, dt * 2f)
        } else {
            when (c.state) {
                0 -> {
                    c.speed += (0f - c.speed) * min(1f, dt * 4f)
                    if (c.timer <= 0f) {
                        c.state = 1
                        c.timer = 3f + rnd.nextFloat() * 5f
                        c.wantYaw = c.yaw + (rnd.nextFloat() - 0.5f) * 2.4f
                    }
                }
                else -> {
                    c.speed += (sp.walk - c.speed) * min(1f, dt * 2f)
                    if (c.timer <= 0f) {
                        c.state = 0
                        c.timer = 2f + rnd.nextFloat() * 5f
                    }
                }
            }
        }
        var d = c.wantYaw - c.yaw
        while (d > 3.1415927f) d -= 6.2831855f
        while (d < -3.1415927f) d += 6.2831855f
        c.yaw += d * min(1f, dt * turnRate)
        if (c.speed > 0.05f) {
            val nx = c.x + sin(c.yaw) * c.speed * dt
            val nz = c.z + cos(c.yaw) * c.speed * dt
            val dNew = hypot(nx - px, nz - pz)
            if (dNew < body + 0.55f && dNew < dist) {
                c.speed = 0f
            } else if (foeGround(nx, nz, sp.hover > 0f)) {
                c.x = nx
                c.z = nz
            } else if (!c.aggro) {
                c.wantYaw = c.yaw + 3.1415927f + (rnd.nextFloat() - 0.5f)
            }
        }
        val ground = world.terrainAt(c.x, c.z)
        if (sp.hover > 0f) {
            val want = max(ground, 0f) + sp.hover * c.scale + sin(time * 1.8f + c.phase) * 0.25f
            c.y += (want - c.y) * min(1f, dt * 3f)
            c.phase += dt * sp.stride
            c.flap = 1f
        } else {
            c.y += (ground - c.y) * min(1f, dt * 10f)
            val reach = 0.8f * c.scale
            val hf = world.terrainAt(c.x + sin(c.yaw) * reach, c.z + cos(c.yaw) * reach)
            val hb = world.terrainAt(c.x - sin(c.yaw) * reach, c.z - cos(c.yaw) * reach)
            val wantPitch = (-atan2(hf - hb, reach * 2f)).coerceIn(-0.4f, 0.4f)
            c.pitch += (wantPitch - c.pitch) * min(1f, dt * 5f)
            c.phase += dt * c.speed * sp.stride / c.scale
        }
        c.callIn -= dt
        if (c.callIn <= 0f) {
            c.callIn = (if (c.aggro) 4f else 10f) + rnd.nextFloat() * 10f
            if (dist < 80f) Sound.call(sp.call, callLevel(dist))
        }
    }

    /** Whether a spot is still inside the arrival platform, clear of its edge. */
    private fun grainGround(x: Float, z: Float): Boolean {
        val cv = caveRef
        if (caveActive && cv != null) return cv.walkable(x - cv.x, z - cv.z, 0.6f)
        return hypot(x - grainCenterX, z - grainCenterZ) < GRAIN_PLATFORM_R - 3f
    }

    /** How high the floor is under (x, z) for whichever arena the monsters are in: a cave or the dimension platform. */
    private fun arenaY(x: Float, z: Float): Float {
        val cv = caveRef
        if (caveActive && cv != null) return cv.floorAt(x - cv.x, z - cv.z)
        return GRAIN_DIM_Y + 1.6f
    }

    private fun fireBolt(c: Creature, sp: Species, px: Float, pz: Float) {
        var slot = -1
        for (i in 0 until BOLT_MAX) if (bolts[i * 7 + 6] < 0f) { slot = i; break }
        if (slot < 0) return
        val o = slot * 7
        val sx = c.x + sin(c.yaw) * 0.6f * c.scale
        val sz = c.z + cos(c.yaw) * 0.6f * c.scale
        val sy = c.y + 1.6f * c.scale
        val dx = px - sx
        val dy = playerY - sy
        val dz = pz - sz
        val l = max(0.5f, sqrt(dx * dx + dy * dy + dz * dz))
        val v = 26f
        bolts[o] = sx
        bolts[o + 1] = sy
        bolts[o + 2] = sz
        bolts[o + 3] = dx / l * v
        bolts[o + 4] = dy / l * v
        bolts[o + 5] = dz / l * v
        bolts[o + 6] = 0f
        // Remember who cast it, for the damage.
        boltCaster = c
    }

    private var boltCaster: Creature? = null

    /** Moves lightning bolts along; one that reaches you does its damage, one that hits a wall fizzles. */
    private fun stepBolts(dt: Float, px: Float, pz: Float) {
        val cv = caveRef
        for (i in 0 until BOLT_MAX) {
            val o = i * 7
            if (bolts[o + 6] < 0f) continue
            bolts[o + 6] += dt
            bolts[o] += bolts[o + 3] * dt
            bolts[o + 1] += bolts[o + 4] * dt
            bolts[o + 2] += bolts[o + 5] * dt
            val hx = bolts[o] - px
            val hz = bolts[o + 2] - pz
            val hy = bolts[o + 1] - playerY
            if (hx * hx + hz * hz < 0.8f * 0.8f && abs(hy) < 1.3f) {
                val w = boltCaster
                val sp = if (w != null) species[w.sp] else null
                val gap = (1f + ((w?.level ?: 1) - playerLevel) * 0.05f).coerceIn(0.25f, 3f)
                pendingDamage += (sp?.damage ?: 8f) * (1f + (w?.level ?: 1) * 0.1f) * gap
                lastAttacker = w
                bolts[o + 6] = -1f
                continue
            }
            var dead = bolts[o + 6] > 2.5f
            if (cv != null) {
                val lx = bolts[o] - cv.x
                val lz = bolts[o + 2] - cv.z
                val d = cv.inside(lx, lz)
                if (d < 0.2f || bolts[o + 1] < cv.floorFrom(lx, lz, d)) dead = true
            }
            if (dead) bolts[o + 6] = -1f
        }
    }

    /** Sets a cave's goblins and skeletons at their posts. Leaving the cave clears them again. */
    fun spawnCaveGuards(cv: Cave) {
        caveRef = cv
        caveActive = true
        for (c in grainFoes) c.active = false
        val kinds = cv.guardKinds.map { nm -> species.indexOfFirst { it.name == nm } }
        if (kinds.any { it < 0 }) return
        val lv = when (cv.zone) {
            Zone.MEADOW -> 12
            Zone.FOREST -> 36
            Zone.SNOW -> 66
            Zone.DESERT -> 96
            Zone.CAVES -> 130
        }
        var n = 0
        for (g in cv.guards) {
            if (n >= grainFoes.size) break
            val c = grainFoes[n++]
            val si = kinds[g[2].toInt().coerceIn(0, kinds.size - 1)]
            val sp = species[si]
            c.active = true
            c.sp = si
            c.boss = -1
            c.ambush = -1
            c.keep = false
            c.x = cv.x + g[0]
            c.z = cv.z + g[1]
            c.homeX = c.x
            c.homeZ = c.z
            c.y = cv.floorAt(g[0], g[1])
            c.yaw = rnd.nextFloat() * 6.2831855f
            c.wantYaw = c.yaw
            c.speed = 0f
            c.state = 0
            c.timer = 1f + rnd.nextFloat() * 3f
            c.phase = rnd.nextFloat() * 6f
            c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
            c.callIn = 2f + rnd.nextFloat() * 8f
            c.head = 0f
            c.pitch = 0f
            c.dying = -1f
            c.hurt = 0f
            c.kvx = 0f
            c.kvz = 0f
            c.flap = 1f
            c.aggro = false
            c.strike = 0f
            c.cooldown = 0f
            c.sinceHit = 999f
            c.level = lv + rnd.nextInt(5)
            c.maxHealth = (sp.hp * (1f + c.level * 0.09f)).coerceAtLeast(1f)
            c.health = c.maxHealth
        }
    }

    /** Brings up another Grain Rot monster somewhere on the platform, away from its centre. */
    private fun trySpawnGrainFoes() {
        var alive = 0
        for (c in grainFoes) if (c.active) alive++
        if (alive >= grainFoes.size) return
        val pool = species.indices.filter { species[it].monster && species[it].grainOnly }
        if (pool.isEmpty()) return
        val slot = grainFoes.firstOrNull { !it.active } ?: return
        val si = pool[rnd.nextInt(pool.size)]
        val sp = species[si]
        val a = rnd.nextFloat() * 6.2831855f
        val r = 6f + rnd.nextFloat() * (GRAIN_PLATFORM_R - 11f)
        val hx = grainCenterX + sin(a) * r
        val hz = grainCenterZ + cos(a) * r
        slot.active = true
        slot.sp = si
        slot.boss = -1
        slot.keep = false
        slot.x = hx
        slot.z = hz
        slot.homeX = hx
        slot.homeZ = hz
        slot.y = GRAIN_DIM_Y + 1.6f
        slot.yaw = rnd.nextFloat() * 6.2831855f
        slot.wantYaw = slot.yaw
        slot.speed = 0f
        slot.state = 0
        slot.timer = 1f + rnd.nextFloat() * 3f
        slot.phase = rnd.nextFloat() * 6f
        slot.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
        slot.callIn = 2f + rnd.nextFloat() * 8f
        slot.head = 0f
        slot.pitch = 0f
        slot.dying = -1f
        slot.hurt = 0f
        slot.kvx = 0f
        slot.kvz = 0f
        slot.flap = 1f
        slot.aggro = false
        slot.strike = 0f
        slot.cooldown = 0f
        slot.level = 150
        slot.maxHealth = (sp.hp * (1f + 150 * 0.09f)).coerceAtLeast(1f)
        slot.health = slot.maxHealth
    }

    /** Slides a Grain Rot monster along after a hit, kept inside the platform's edge. */
    private fun knockBackGrain(c: Creature, dt: Float) {
        if (c.kvx == 0f && c.kvz == 0f) return
        val nx = c.x + c.kvx * dt
        val nz = c.z + c.kvz * dt
        if (grainGround(nx, nz)) {
            c.x = nx
            c.z = nz
        }
        val fade = max(0f, 1f - dt * 6f)
        c.kvx *= fade
        c.kvz *= fade
        if (abs(c.kvx) + abs(c.kvz) < 0.05f) {
            c.kvx = 0f
            c.kvz = 0f
        }
    }

    /**
     * A Grain Rot monster's turn: the same hunt-and-strike logic as [stepFoe], but confined
     * to the flat arrival platform instead of the outdoor terrain (no world height, no lair,
     * no giving up the chase — there's nowhere else on that platform for you to go).
     */
    private fun stepGrainFoe(c: Creature, dt: Float, px: Float, pz: Float) {
        val sp = species[c.sp]
        knockBackGrain(c, dt)
        if (c.hurt > 0f) c.hurt = max(0f, c.hurt - dt * 4f)
        if (c.dying >= 0f) {
            c.dying += dt
            if (c.keep && c.dying > 3.4f) c.dying = 3.4f
            c.speed = 0f
            c.strike = 0f
            if (c.dying > 4.5f) c.active = false
            return
        }
        val dx = px - c.x
        val dz = pz - c.z
        val dist = hypot(dx, dz)
        c.cooldown -= dt
        c.timer -= dt
        c.sinceHit += dt
        if (sp.ability == Ability.REGEN && c.sinceHit > 3f && c.health < c.maxHealth) {
            c.health = min(c.maxHealth, c.health + c.maxHealth * 0.05f * dt)
        }
        val body = (sp.colR + sp.colHalf * 0.5f) * c.scale
        if (!c.aggro && dist < (if (sp.ranged > 0f) 30f else 16f) + body) {
            c.aggro = true
            c.callIn = min(c.callIn, 0.1f)
        }
        var turnRate = 2.5f
        if (c.strike > 0f) {
            val before = c.strike
            c.strike -= dt / 0.7f
            if (before > 0.5f && c.strike <= 0.5f && sp.ranged > 0f) {
                fireBolt(c, sp, px, pz)
            } else if (before > 0.5f && c.strike <= 0.5f && dist < sp.reach * c.scale + body + 0.9f) {
                val gap = (1f + (c.level - playerLevel) * 0.05f).coerceIn(0.25f, 3f)
                val dealt = sp.damage * (1f + c.level * 0.1f) * gap
                pendingDamage += dealt
                if (sp.ability == Ability.POISON) {
                    poisonTime = max(poisonTime, 4f)
                    poisonDps = max(poisonDps, dealt * 0.15f)
                }
                lastAttacker = c
            }
            if (c.strike < 0f) c.strike = 0f
            c.speed += (0f - c.speed) * min(1f, dt * 8f)
        } else if (c.aggro) {
            c.wantYaw = atan2(dx, dz)
            turnRate = 6f
            val reachD = if (sp.ranged > 0f) sp.ranged else sp.reach * c.scale + body
            if (dist > reachD) {
                c.speed += (sp.run - c.speed) * min(1f, dt * 3f)
            } else {
                c.speed += (0f - c.speed) * min(1f, dt * 8f)
                var d = c.wantYaw - c.yaw
                while (d > 3.1415927f) d -= 6.2831855f
                while (d < -3.1415927f) d += 6.2831855f
                if (c.cooldown <= 0f && abs(d) < 0.6f) {
                    c.strike = 1f
                    c.cooldown = 1.3f + rnd.nextFloat() * 0.7f
                    if (rnd.nextFloat() < 0.4f) Sound.call(sp.call, callLevel(dist))
                }
            }
        } else {
            when (c.state) {
                0 -> {
                    c.speed += (0f - c.speed) * min(1f, dt * 4f)
                    if (c.timer <= 0f) {
                        c.state = 1
                        c.timer = 3f + rnd.nextFloat() * 5f
                        c.wantYaw = c.yaw + (rnd.nextFloat() - 0.5f) * 2.4f
                    }
                }
                else -> {
                    c.speed += (sp.walk - c.speed) * min(1f, dt * 2f)
                    if (c.timer <= 0f) {
                        c.state = 0
                        c.timer = 2f + rnd.nextFloat() * 5f
                    }
                }
            }
        }
        var d = c.wantYaw - c.yaw
        while (d > 3.1415927f) d -= 6.2831855f
        while (d < -3.1415927f) d += 6.2831855f
        c.yaw += d * min(1f, dt * turnRate)
        if (c.speed > 0.05f) {
            val nx = c.x + sin(c.yaw) * c.speed * dt
            val nz = c.z + cos(c.yaw) * c.speed * dt
            if (grainGround(nx, nz)) {
                c.x = nx
                c.z = nz
            } else if (!c.aggro) {
                c.wantYaw = c.yaw + 3.1415927f + (rnd.nextFloat() - 0.5f)
            }
        }
        c.y = arenaY(c.x, c.z)
        c.phase += dt * c.speed * sp.stride / c.scale
        c.callIn -= dt
        if (c.callIn <= 0f) {
            c.callIn = (if (c.aggro) 4f else 10f) + rnd.nextFloat() * 10f
            if (dist < 80f) Sound.call(sp.call, callLevel(dist))
        }
    }

    /** Slides a creature along after a hit, slowing quickly. */
    private fun knockBack(c: Creature, dt: Float, hover: Boolean) {
        if (c.kvx == 0f && c.kvz == 0f) return
        val nx = c.x + c.kvx * dt
        val nz = c.z + c.kvz * dt
        val ok = if (species[c.sp].monster) foeGround(nx, nz, hover) else walkable(nx, nz)
        if (ok) {
            c.x = nx
            c.z = nz
        }
        val fade = max(0f, 1f - dt * 6f)
        c.kvx *= fade
        c.kvz *= fade
        if (abs(c.kvx) + abs(c.kvz) < 0.05f) {
            c.kvx = 0f
            c.kvz = 0f
        }
    }

    private fun speciesFor(zone: Zone, bird: Boolean): Int {
        var n = 0
        for (s in species) if (s.bird == bird && !s.monster && zone in s.zones) n++
        if (n == 0) return -1
        var pick = rnd.nextInt(n)
        for (i in species.indices) {
            val s = species[i]
            if (s.bird == bird && !s.monster && zone in s.zones) {
                if (pick == 0) return i
                pick--
            }
        }
        return -1
    }

    private fun goodGround(x: Float, z: Float): Boolean {
        if (x < 20f || z < 20f || x > WORLD_SIZE - 20f || z > WORLD_SIZE - 20f) return false
        world.probe(x, z, probe)
        if (probe.mountain > 0.25f || probe.site < 12f) return false
        if (world.terrainAt(x, z) < 0.8f) return false
        return !world.isBlocked(x, z, probe)
    }

    /** Where an animal already out and about may walk: it can climb the lower mountainsides. */
    private fun walkable(x: Float, z: Float): Boolean {
        if (x < 20f || z < 20f || x > WORLD_SIZE - 20f || z > WORLD_SIZE - 20f) return false
        world.probe(x, z, probe)
        if (probe.mountain > 0.75f || probe.site < 12f) return false
        if (world.terrainAt(x, z) < 0.8f) return false
        return !world.isBlocked(x, z, probe)
    }

    private fun trySpawnAnimals(px: Float, pz: Float) {
        var alive = 0
        for (c in animals) if (c.active) alive++
        if (alive >= 16) return
        val a = rnd.nextFloat() * 6.2831855f
        val r = 60f + rnd.nextFloat() * 90f
        val x = px + cos(a) * r
        val z = pz + sin(a) * r
        if (!goodGround(x, z)) return
        val si = speciesFor(probe.zone, false)
        if (si < 0) return
        val sp = species[si]
        val count = 1 + rnd.nextInt(sp.herd)
        for (k in 0 until count) {
            val c = animals.firstOrNull { !it.active } ?: return
            val hx = x + (rnd.nextFloat() - 0.5f) * 10f
            val hz = z + (rnd.nextFloat() - 0.5f) * 10f
            if (!goodGround(hx, hz)) continue
            c.active = true
            c.sp = si
            c.x = hx
            c.z = hz
            c.y = world.terrainAt(hx, hz)
            c.yaw = rnd.nextFloat() * 6.2831855f
            c.wantYaw = c.yaw
            c.speed = 0f
            c.state = 0
            c.timer = 1f + rnd.nextFloat() * 4f
            c.phase = rnd.nextFloat() * 6f
            c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
            c.callIn = 3f + rnd.nextFloat() * 14f
            c.head = 0f
            c.pitch = 0f
            c.dying = -1f
            c.hurt = 0f
            c.kvx = 0f
            c.kvz = 0f
            c.health = (2 + ((sp.colR + sp.colHalf * 0.5f) * c.scale * 5f).toInt()).toFloat()
        }
    }

    private fun trySpawnBird(px: Float, pz: Float) {
        var alive = 0
        for (c in birds) if (c.active) alive++
        if (alive >= 6) return
        val c = birds.firstOrNull { !it.active } ?: return
        val a = rnd.nextFloat() * 6.2831855f
        val r = 30f + rnd.nextFloat() * 110f
        val x = (px + cos(a) * r).coerceIn(30f, WORLD_SIZE - 30f)
        val z = (pz + sin(a) * r).coerceIn(30f, WORLD_SIZE - 30f)
        world.probe(x, z, probe)
        val si = speciesFor(probe.zone, true)
        if (si < 0) return
        val sp = species[si]
        c.active = true
        c.sp = si
        c.cx = x
        c.cz = z
        c.radius = 18f + rnd.nextFloat() * 30f
        c.alt = 22f + rnd.nextFloat() * 30f
        c.angle = rnd.nextFloat() * 6.2831855f
        c.speed = sp.walk * (0.85f + 0.3f * rnd.nextFloat()) * (if (rnd.nextBoolean()) 1f else -1f)
        c.scale = sp.minScale + (sp.maxScale - sp.minScale) * rnd.nextFloat()
        c.callIn = 4f + rnd.nextFloat() * 16f
        c.flap = 1f
        c.flapWant = 1f
        c.timer = 2f + rnd.nextFloat() * 4f
        c.phase = rnd.nextFloat() * 6f
        placeBird(c)
        c.y = world.terrainAt(c.x, c.z) + c.alt
    }

    /** A blow worth [damage] lands on [c], coming from direction (dx, dz). */
    fun hit(c: Creature, dx: Float, dz: Float, damage: Float = 1f) {
        if (c.dying >= 0f) return
        val sp = species[c.sp]
        c.sinceHit = 0f
        c.health -= if (sp.defense > 0f) damage * (1f - sp.defense) else damage
        c.hurt = 1f
        val push = 5f / max(0.6f, (sp.colR + sp.colHalf) * c.scale)
        c.kvx = dx * push
        c.kvz = dz * push
        Sound.call(sp.call, 1f)
        if (c.health <= 0f) {
            c.dying = 0f
            c.speed = 0f
            return
        }
        // Monsters fight back.
        if (sp.monster) {
            val fresh = !c.aggro
            c.aggro = true
            if (fresh && sp.ability == Ability.PACK) alertPack(c)
            return
        }
        // Run away from you.
        c.state = 2
        c.timer = 5f + rnd.nextFloat() * 3f
        c.wantYaw = atan2(dx, dz) + (rnd.nextFloat() - 0.5f) * 0.6f
    }

    private fun stepAnimal(c: Creature, dt: Float, px: Float, pz: Float) {
        val sp = species[c.sp]
        // Knocked back by a blow.
        if (c.kvx != 0f || c.kvz != 0f) {
            val nx = c.x + c.kvx * dt
            val nz = c.z + c.kvz * dt
            if (walkable(nx, nz)) {
                c.x = nx
                c.z = nz
            }
            val fade = max(0f, 1f - dt * 6f)
            c.kvx *= fade
            c.kvz *= fade
            if (abs(c.kvx) + abs(c.kvz) < 0.05f) {
                c.kvx = 0f
                c.kvz = 0f
            }
        }
        if (c.hurt > 0f) c.hurt = max(0f, c.hurt - dt * 4f)
        // Down: it topples over, lies still for a moment, then is gone.
        if (c.dying >= 0f) {
            c.dying += dt
            c.speed = 0f
            c.y += (world.terrainAt(c.x, c.z) - c.y) * min(1f, dt * 10f)
            if (c.dying > 4.5f) c.active = false
            return
        }
        val dx = c.x - px
        val dz = c.z - pz
        val dist = hypot(dx, dz)
        if (dist > 230f) {
            c.active = false
            return
        }
        // Shy creatures bolt when you get close.
        if (sp.timid && dist < 14f && c.state != 2) {
            c.state = 2
            c.timer = 4f + rnd.nextFloat() * 2f
            c.wantYaw = atan2(dx, dz) + (rnd.nextFloat() - 0.5f) * 0.8f
            c.callIn = min(c.callIn, 0.2f)
        }
        c.timer -= dt
        when (c.state) {
            0 -> {
                c.speed += (0f - c.speed) * min(1f, dt * 4f)
                if (c.timer <= 0f) {
                    c.state = 1
                    c.timer = 3f + rnd.nextFloat() * 7f
                    c.wantYaw = c.yaw + (rnd.nextFloat() - 0.5f) * 2.4f
                }
            }
            1 -> {
                c.speed += (sp.walk - c.speed) * min(1f, dt * 2f)
                if (rnd.nextFloat() < dt * 0.3f) c.wantYaw += (rnd.nextFloat() - 0.5f) * 1.2f
                if (c.timer <= 0f) {
                    c.state = 0
                    c.timer = 2f + rnd.nextFloat() * 6f
                }
            }
            else -> {
                c.speed += (sp.run - c.speed) * min(1f, dt * 3f)
                if (c.timer <= 0f) {
                    c.state = 0
                    c.timer = 2f + rnd.nextFloat() * 3f
                }
            }
        }
        // Turn smoothly towards where it wants to go.
        var d = c.wantYaw - c.yaw
        while (d > 3.1415927f) d -= 6.2831855f
        while (d < -3.1415927f) d += 6.2831855f
        c.yaw += d * min(1f, dt * 2.5f)

        if (c.speed > 0.05f) {
            val nx = c.x + sin(c.yaw) * c.speed * dt
            val nz = c.z + cos(c.yaw) * c.speed * dt
            // Don't walk into the player: stop and turn away instead.
            val keep = (sp.colR + sp.colHalf * 0.6f) * c.scale + 0.7f
            val dNow = hypot(c.x - px, c.z - pz)
            val dNew = hypot(nx - px, nz - pz)
            if (dNew < keep && dNew < dNow) {
                c.speed = 0f
                c.wantYaw = atan2(c.x - px, c.z - pz) + (rnd.nextFloat() - 0.5f) * 1.2f
            } else if (walkable(nx, nz)) {
                c.x = nx
                c.z = nz
            } else {
                c.wantYaw = c.yaw + 3.1415927f + (rnd.nextFloat() - 0.5f)
            }
        }
        c.y += (world.terrainAt(c.x, c.z) - c.y) * min(1f, dt * 10f)
        // Lean with the slope: nose up going uphill, down going downhill.
        val reach = 0.8f * c.scale
        val hf = world.terrainAt(c.x + sin(c.yaw) * reach, c.z + cos(c.yaw) * reach)
        val hb = world.terrainAt(c.x - sin(c.yaw) * reach, c.z - cos(c.yaw) * reach)
        val wantPitch = (-atan2(hf - hb, reach * 2f)).coerceIn(-0.4f, 0.4f)
        c.pitch += (wantPitch - c.pitch) * min(1f, dt * 5f)
        c.phase += dt * c.speed * sp.stride / c.scale
        // Grazers lower their heads to eat while standing still.
        val headWant = if (sp.grazes && c.state == 0 && c.speed < 0.3f) 1f else 0f
        c.head += (headWant - c.head) * min(1f, dt * 1.5f)

        c.callIn -= dt
        if (c.callIn <= 0f) {
            c.callIn = 9f + rnd.nextFloat() * 18f
            if (dist < 90f) Sound.call(sp.call, callLevel(dist))
        }
    }

    private fun placeBird(c: Creature) {
        c.x = c.cx + cos(c.angle) * c.radius
        c.z = c.cz + sin(c.angle) * c.radius
    }

    private fun stepBird(c: Creature, dt: Float, px: Float, pz: Float, time: Float) {
        val sp = species[c.sp]
        val dist = hypot(c.x - px, c.z - pz)
        if (dist > 260f) {
            c.active = false
            return
        }
        c.angle += c.speed / c.radius * dt
        // The circle itself drifts slowly across the sky.
        c.cx += sin(time * 0.05f + c.phase) * 1.5f * dt
        c.cz += cos(time * 0.04f + c.phase) * 1.5f * dt
        placeBird(c)
        // Flap for a while, then glide.
        c.timer -= dt
        if (c.timer <= 0f) {
            c.flapWant = if (c.flapWant > 0.5f) 0.15f else 1f
            c.timer = if (c.flapWant > 0.5f) 2f + rnd.nextFloat() * 3f else 2f + rnd.nextFloat() * 4f
        }
        c.flap += (c.flapWant - c.flap) * min(1f, dt * 2f)
        c.phase += dt * sp.stride * (0.4f + 0.6f * c.flap)
        // Face along the circle and lean into the turn.
        val dir = if (c.speed >= 0f) 1f else -1f
        c.yaw = atan2(-sin(c.angle) * dir, cos(c.angle) * dir)
        c.roll = 0.35f * dir
        val ground = max(world.terrainAt(c.x, c.z), 0f)
        c.y += (ground + c.alt - c.y) * min(1f, dt * 0.8f)
        c.callIn -= dt
        if (c.callIn <= 0f) {
            c.callIn = 10f + rnd.nextFloat() * 20f
            val d3 = hypot(dist, c.y - world.terrainAt(px, pz))
            if (d3 < 100f) Sound.call(sp.call, callLevel(d3 * 0.8f))
        }
    }

    private fun callLevel(d: Float): Float {
        val k = (1f - d / 95f).coerceIn(0f, 1f)
        return k * k * 1.1f + 0.05f
    }

    /**
     * Builds the model matrix for one part of one creature into [out]: where it stands,
     * which way it faces, its size, and how this piece is swinging right now.
     */
    fun pose(c: Creature, part: CreaturePart, time: Float, out: FloatArray) {
        val sp = species[c.sp]
        Matrix.setIdentityM(out, 0)
        var bob = if (sp.bird) sin(c.phase * 1f) * 0.12f * c.flap else abs(sin(c.phase)) * 0.04f * min(1f, c.speed)
        if (sp.bouncy) bob = abs(sin(c.phase)) * 0.3f * min(1f, c.speed / max(0.1f, sp.walk))
        Matrix.translateM(out, 0, c.x, c.y + bob * c.scale, c.z)
        Matrix.rotateM(out, 0, Math.toDegrees(c.yaw.toDouble()).toFloat(), 0f, 1f, 0f)
        // A monster's attack: it lunges forward and dips into the blow.
        val lunge = if (c.strike > 0f) sin((1f - c.strike) * 3.1415927f) else 0f
        if (lunge > 0f) {
            Matrix.translateM(out, 0, 0f, 0f, lunge * 0.35f * c.scale)
            if (sp.hover <= 0f && !sp.bouncy) Matrix.rotateM(out, 0, lunge * 14f, 1f, 0f, 0f)
        }
        if (sp.bird) Matrix.rotateM(out, 0, Math.toDegrees(c.roll.toDouble()).toFloat(), 0f, 0f, 1f)
        else Matrix.rotateM(out, 0, Math.toDegrees((c.pitch - c.hurt * 0.25f).toDouble()).toFloat(), 1f, 0f, 0f)
        if (c.dying >= 0f) {
            // Topple onto its side, and sink into the ground at the very end.
            val fall = min(1f, c.dying / 0.6f)
            val roll = fall * fall * 1.45f
            Matrix.translateM(out, 0, 0f, -max(0f, c.dying - 3.5f) * 0.6f * c.scale, 0f)
            Matrix.rotateM(out, 0, Math.toDegrees(roll.toDouble()).toFloat(), 0f, 0f, 1f)
        }
        Matrix.scaleM(out, 0, c.scale, c.scale, c.scale)
        applyPart(c, sp, part, time, out)
    }

    /** Moves [out] from the parent's space into this part's, parents first. */
    private fun applyPart(c: Creature, sp: Species, part: CreaturePart, time: Float, out: FloatArray) {
        val parent = part.parent
        if (parent != null) applyPart(c, sp, parent, time, out)
        Matrix.translateM(out, 0, part.px, part.py, part.pz)
        val moving = min(1f, c.speed / max(0.1f, sp.walk))
        when (part.kind) {
            PartKind.BODY -> {
                // Slow breathing; slimes squash and stretch as they bounce.
                val br = sin(time * 1.7f + c.phase * 0.1f) * 0.012f
                if (sp.bouncy) {
                    val sq = cos(c.phase * 2f) * 0.12f * moving + sin(time * 3f + c.phase) * 0.03f
                    Matrix.scaleM(out, 0, 1f + sq, 1f - sq, 1f + sq)
                } else {
                    Matrix.scaleM(out, 0, 1f + br, 1f + br * 1.4f, 1f)
                }
            }
            PartKind.ARM -> {
                // Swings opposite the leg on its side while walking; raised and brought down to attack.
                val lunge = if (c.strike > 0f) sin((1f - c.strike) * 3.1415927f) else 0f
                val swing = -sin(c.phase + part.phase) * sp.legSwing * 0.8f * moving
                val idle = sin(time * 1.3f + part.phase) * 0.05f
                Matrix.rotateM(out, 0, Math.toDegrees((swing + idle - lunge * 2.3f).toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.SEGMENT -> {
                // Serpent bodies slither: a wave runs down from head to tail.
                val wave = sin(c.phase * 1.2f - part.phase) * 0.32f * (0.35f + 0.65f * moving) +
                    sin(time * 1.4f - part.phase) * 0.06f
                Matrix.rotateM(out, 0, Math.toDegrees(wave.toDouble()).toFloat(), 0f, 1f, 0f)
            }
            PartKind.LEG -> {
                val swing = sin(c.phase + part.phase) * sp.legSwing * moving
                Matrix.rotateM(out, 0, Math.toDegrees(swing.toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.SHIN -> {
                // The knee bends while the leg swings forward, lifting the foot clear.
                val bend = max(0f, -cos(c.phase + part.phase)) * sp.legSwing * 1.7f * moving
                Matrix.rotateM(out, 0, Math.toDegrees(bend.toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.HEAD -> {
                val bite = if (c.strike > 0f) sin((1f - c.strike) * 3.1415927f) * 0.45f else 0f
                val nod = c.head * 0.9f - c.pitch * 0.6f + sin(time * 0.7f + c.phase) * 0.05f + bite
                val look = sin(time * 0.31f + c.x) * 0.25f * (1f - c.head)
                Matrix.rotateM(out, 0, Math.toDegrees(look.toDouble()).toFloat(), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, Math.toDegrees(nod.toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.TAIL -> {
                val wag = sin(time * 2.2f + c.phase * 0.5f) * 0.35f
                val lift = sin(time * 1.3f + c.phase * 0.3f) * 0.1f
                Matrix.rotateM(out, 0, Math.toDegrees(wag.toDouble()).toFloat(), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, Math.toDegrees(lift.toDouble()).toFloat(), 1f, 0f, 0f)
            }
            PartKind.WING_L, PartKind.WING_R -> {
                val beat = sin(c.phase) * 0.75f * c.flap + 0.12f
                val a = if (part.kind == PartKind.WING_L) -beat else beat
                Matrix.rotateM(out, 0, Math.toDegrees(a.toDouble()).toFloat(), 0f, 0f, 1f)
            }
            PartKind.WING_TIP_L, PartKind.WING_TIP_R -> {
                // The outer wing lags behind, so the whole wing ripples like a real stroke.
                val beat = sin(c.phase - 0.7f) * 0.5f * c.flap + 0.05f
                val a = if (part.kind == PartKind.WING_TIP_L) -beat else beat
                Matrix.rotateM(out, 0, Math.toDegrees(a.toDouble()).toFloat(), 0f, 0f, 1f)
            }
            else -> {}
        }
    }
}

// ---------- The creatures ----------

internal class BodyKit {
    val parts = ArrayList<CreaturePart>()
    private var seed = 1

    fun part(
        kind: Int, px: Float, py: Float, pz: Float, phase: Float = 0f, parent: CreaturePart? = null,
        draw: (MeshBuilder) -> Unit,
    ): CreaturePart {
        val m = MeshBuilder(2048)
        m.hd = true
        draw(m)
        val cp = CreaturePart(kind, px, py, pz, phase, m.finish(), m.vertexCount, parent)
        parts.add(cp)
        return cp
    }

    fun s(): Int = seed++ * 37

    /** Four legs in a diagonal walking gait. [splay] pushes the feet outwards (lizards). */
    fun legs4(hipY: Float, fz: Float, bz: Float, hw: Float, len: Float, r0: Float, r1: Float, col: Int, foot: Int, splay: Float = 0f) {
        val spots = arrayOf(
            floatArrayOf(-hw, fz, 0f), floatArrayOf(hw, fz, 3.1415927f),
            floatArrayOf(-hw, bz, 3.1415927f), floatArrayOf(hw, bz, 0f),
        )
        for (sp in spots) leg(sp[0], hipY, sp[1], sp[2], len, r0, r1, col, foot, if (sp[0] < 0f) -splay else splay)
    }

    /** One leg in two pieces: the thigh swings from the hip, the shin bends at the knee. */
    fun leg(x: Float, hipY: Float, z: Float, phase: Float, len: Float, r0: Float, r1: Float, col: Int, foot: Int, out: Float) {
        val sd = s()
        val rm = (r0 + r1) * 0.5f
        val kx = out * 0.5f
        val ky = -len * 0.5f
        val thigh = part(PartKind.LEG, x, hipY, z, phase) { m ->
            m.limb(0f, 0.05f, 0f, kx, ky, 0.02f, r0, rm, col, FLAG_FUR)
            // Muscle at the top of the leg, blending into the body.
            m.blob(kx * 0.2f, -len * 0.1f, 0f, r0 * 1.3f, len * 0.2f, r0 * 1.4f, col, sd + 1, 0.03f, FLAG_FUR)
        }
        part(PartKind.SHIN, kx, ky, 0.02f, phase, thigh) { m ->
            m.limb(0f, 0f, 0f, out * 0.5f, -len * 0.5f + r1, -0.02f, rm, r1, col, FLAG_FUR)
            m.blob(out * 0.5f, -len * 0.5f + r1 * 0.8f, 0.01f, r1 * 1.3f, r1 * 0.9f, r1 * 1.6f, foot, sd, 0.1f, FLAG_SOLID)
        }
    }
}

private fun buildSpecies(): List<Species> {
    val list = ArrayList<Species>()

    // 1. Glimmerhorn (Greenhollow): a graceful deer whose antlers are living crystal.
    run {
        val k = BodyKit()
        val fur = 0xB8875A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.25f, 0f, 0.34f, 0.38f, 0.82f, fur, 11, 0.08f, FLAG_FUR)
            m.blob(0f, 1.12f, 0.05f, 0.28f, 0.22f, 0.66f, 0xE6D2B4, 12, 0.08f, FLAG_FUR)
            for (i in 0 until 5) m.blob(-0.2f + i * 0.1f, 1.5f, -0.4f + i * 0.2f, 0.05f, 0.03f, 0.05f, 0xF4ECDC, 20 + i, 0f, FLAG_FUR)
        }
        k.part(PartKind.HEAD, 0f, 1.42f, 0.66f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.42f, 0.24f, 0.13f, 0.09f, fur, FLAG_FUR)
            m.blob(0f, 0.52f, 0.36f, 0.13f, 0.14f, 0.24f, fur, 13, 0.05f, FLAG_FUR)
            m.blob(0f, 0.47f, 0.58f, 0.06f, 0.06f, 0.06f, 0x2A1E18, 14, 0f, FLAG_SOLID)
            m.spike(-0.1f, 0.6f, 0.3f, 0.04f, 0.14f, -0.6f, -0.3f, fur, FLAG_FUR)
            m.spike(0.1f, 0.6f, 0.3f, 0.04f, 0.14f, 0.6f, -0.3f, fur, FLAG_FUR)
            m.blob(-0.09f, 0.56f, 0.46f, 0.025f, 0.025f, 0.025f, 0x101014, 15, 0f, FLAG_SOLID)
            m.blob(0.09f, 0.56f, 0.46f, 0.025f, 0.025f, 0.025f, 0x101014, 16, 0f, FLAG_SOLID)
            for (side in intArrayOf(-1, 1)) {
                val sx = side * 0.07f
                m.spike(sx, 0.62f, 0.3f, 0.035f, 0.45f, side * 0.35f, -0.25f, 0x8FE6FF, FLAG_GLOW)
                m.spike(sx + side * 0.1f, 0.8f, 0.24f, 0.025f, 0.28f, side * 0.7f, 0.2f, 0xA8F0FF, FLAG_GLOW)
                m.spike(sx + side * 0.13f, 0.92f, 0.2f, 0.02f, 0.22f, side * 0.1f, -0.5f, 0x7ADCFF, FLAG_GLOW)
            }
        }
        k.part(PartKind.TAIL, 0f, 1.35f, -0.78f) { m ->
            m.blob(0f, -0.02f, -0.06f, 0.08f, 0.1f, 0.08f, 0xF4ECDC, 17, 0.1f, FLAG_FUR)
        }
        k.legs4(1.02f, 0.52f, -0.52f, 0.17f, 1.0f, 0.075f, 0.04f, fur, 0x2A2018)
        list.add(Species("Glimmerhorn", arrayOf(Zone.MEADOW), false, 1.6f, 9.5f, true, true, 0.55f, 2.4f, 0.9f, 1.1f, 3, k.parts))
    }

    // 2. Mossback (Greenhollow): a slow, gentle giant with a mossy shell and ferns growing on it.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.15f, 0f, 1.1f, 0.78f, 1.4f, 0x4F7A38, 21, 0.12f, FLAG_FUR)
            m.blob(0f, 0.72f, 0f, 0.95f, 0.35f, 1.2f, 0x6A5238, 22, 0.1f, FLAG_FUR)
            for (i in 0 until 9) {
                val a = i * 0.7f
                val r = 0.2f + (i % 3) * 0.28f
                m.spike(sin(a) * r, 1.72f, cos(a) * r * 1.2f, 0.07f, 0.55f + (i % 2) * 0.2f, sin(a) * 0.5f, cos(a) * 0.4f, 0x5E9A3A, FLAG_FUR)
            }
            for (i in 0 until 4) m.blob(-0.6f + i * 0.4f, 1.55f + (i % 2) * 0.15f, 0.5f - i * 0.3f, 0.08f, 0.06f, 0.08f, 0xE8D86A, 30 + i, 0f, FLAG_GLOW)
        }
        k.part(PartKind.HEAD, 0f, 0.95f, 1.3f) { m ->
            m.blob(0f, 0f, 0.3f, 0.36f, 0.3f, 0.4f, 0x6A5238, 23, 0.08f, FLAG_FUR)
            m.blob(0f, -0.05f, 0.62f, 0.22f, 0.16f, 0.12f, 0x4E3C2A, 24, 0.05f, FLAG_FUR)
            m.blob(-0.18f, 0.12f, 0.55f, 0.04f, 0.04f, 0.04f, 0x101014, 25, 0f, FLAG_SOLID)
            m.blob(0.18f, 0.12f, 0.55f, 0.04f, 0.04f, 0.04f, 0x101014, 26, 0f, FLAG_SOLID)
            m.spike(-0.2f, 0.2f, 0.2f, 0.06f, 0.25f, -0.4f, -0.3f, 0xCEC0A0, FLAG_SOLID)
            m.spike(0.2f, 0.2f, 0.2f, 0.06f, 0.25f, 0.4f, -0.3f, 0xCEC0A0, FLAG_SOLID)
        }
        k.part(PartKind.TAIL, 0f, 0.85f, -1.35f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.15f, -0.4f, 0.15f, 0.05f, 0x6A5238, FLAG_FUR)
        }
        k.legs4(0.75f, 0.8f, -0.8f, 0.78f, 0.75f, 0.24f, 0.2f, 0x6A5238, 0x3A2C20)
        list.add(Species("Mossback", arrayOf(Zone.MEADOW), false, 0.9f, 1.4f, false, true, 0.35f, 2.2f, 0.85f, 1.2f, 1, k.parts))
    }

    // 3. Shadelynx (Whisperwood): a dark cat with glowing blue stripes and eyes.
    run {
        val k = BodyKit()
        val fur = 0x2A2A38
        val glow = 0x5AC8FF
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.85f, 0f, 0.3f, 0.3f, 0.8f, fur, 31, 0.06f, FLAG_FUR)
            for (i in 0 until 5) {
                val z = -0.5f + i * 0.25f
                m.box(0f, 1.13f, z, 0.03f, 0.02f, 0.2f, 0f, glow, FLAG_GLOW)
                m.box(-0.24f, 0.95f, z, 0.02f, 0.12f, 0.03f, 0f, glow, FLAG_GLOW)
                m.box(0.24f, 0.95f, z, 0.02f, 0.12f, 0.03f, 0f, glow, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.98f, 0.72f) { m ->
            m.blob(0f, 0.04f, 0.18f, 0.22f, 0.19f, 0.23f, fur, 32, 0.05f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.38f, 0.1f, 0.08f, 0.08f, 0x1A1A24, 33, 0f, FLAG_FUR)
            m.spike(-0.14f, 0.18f, 0.12f, 0.05f, 0.26f, -0.2f, -0.1f, fur, FLAG_FUR)
            m.spike(0.14f, 0.18f, 0.12f, 0.05f, 0.26f, 0.2f, -0.1f, fur, FLAG_FUR)
            m.spike(-0.19f, 0.42f, 0.1f, 0.012f, 0.1f, 0f, 0f, glow, FLAG_GLOW)
            m.spike(0.19f, 0.42f, 0.1f, 0.012f, 0.1f, 0f, 0f, glow, FLAG_GLOW)
            m.box(-0.09f, 0.1f, 0.38f, 0.045f, 0.025f, 0.02f, 0f, 0x9CF0FF, FLAG_GLOW)
            m.box(0.09f, 0.1f, 0.38f, 0.045f, 0.025f, 0.02f, 0f, 0x9CF0FF, FLAG_GLOW)
        }
        k.part(PartKind.TAIL, 0f, 1.0f, -0.75f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.15f, -0.5f, 0.07f, 0.05f, fur, FLAG_FUR)
            m.limb(0f, 0.15f, -0.5f, 0f, 0.45f, -0.9f, 0.05f, 0.035f, fur, FLAG_FUR)
            m.blob(0f, 0.47f, -0.93f, 0.06f, 0.06f, 0.06f, glow, 34, 0f, FLAG_GLOW)
        }
        k.legs4(0.66f, 0.5f, -0.5f, 0.17f, 0.66f, 0.08f, 0.06f, fur, 0x1A1A22)
        list.add(Species("Shadelynx", arrayOf(Zone.FOREST), false, 1.4f, 7f, false, false, 0.6f, 3.2f, 0.9f, 1.15f, 1, k.parts))
    }

    // 4. Wispfox (Whisperwood): a small fox whose tail trails glowing wisps.
    run {
        val k = BodyKit()
        val fur = 0x8A4A2A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.45f, 0f, 0.15f, 0.16f, 0.38f, fur, 41, 0.06f, FLAG_FUR)
            m.blob(0f, 0.4f, 0.12f, 0.11f, 0.1f, 0.22f, 0xE8D8C8, 42, 0.05f, FLAG_FUR)
        }
        k.part(PartKind.HEAD, 0f, 0.53f, 0.35f) { m ->
            m.blob(0f, 0.02f, 0.08f, 0.12f, 0.11f, 0.13f, fur, 43, 0.05f, FLAG_FUR)
            m.limb(0f, 0f, 0.14f, 0f, -0.03f, 0.32f, 0.06f, 0.015f, fur, FLAG_FUR)
            m.blob(0f, -0.03f, 0.33f, 0.022f, 0.022f, 0.022f, 0x101014, 44, 0f, FLAG_SOLID)
            m.spike(-0.07f, 0.1f, 0.04f, 0.04f, 0.16f, -0.25f, -0.15f, fur, FLAG_FUR)
            m.spike(0.07f, 0.1f, 0.04f, 0.04f, 0.16f, 0.25f, -0.15f, fur, FLAG_FUR)
            m.box(-0.05f, 0.05f, 0.19f, 0.02f, 0.012f, 0.01f, 0f, 0x7CFFB8, FLAG_GLOW)
            m.box(0.05f, 0.05f, 0.19f, 0.02f, 0.012f, 0.01f, 0f, 0x7CFFB8, FLAG_GLOW)
        }
        k.part(PartKind.TAIL, 0f, 0.5f, -0.34f) { m ->
            m.blob(0f, 0.06f, -0.3f, 0.12f, 0.12f, 0.32f, fur, 45, 0.1f, FLAG_FUR)
            m.blob(0f, 0.12f, -0.62f, 0.08f, 0.08f, 0.1f, 0x7CFFB8, 46, 0f, FLAG_GLOW)
            m.blob(0.06f, 0.2f, -0.76f, 0.05f, 0.05f, 0.05f, 0xA8FFD8, 47, 0f, FLAG_GLOW)
            m.blob(-0.05f, 0.27f, -0.88f, 0.035f, 0.035f, 0.035f, 0xC8FFE8, 48, 0f, FLAG_GLOW)
        }
        k.legs4(0.34f, 0.22f, -0.22f, 0.08f, 0.34f, 0.04f, 0.028f, 0x3A2418, 0x1A1410)
        list.add(Species("Wispfox", arrayOf(Zone.FOREST), false, 1.8f, 8.5f, true, false, 0.7f, 5.5f, 0.9f, 1.1f, 2, k.parts))
    }

    // 5. Frostmane (Frostpeak): a white lion with a mane of ice crystals.
    run {
        val k = BodyKit()
        val fur = 0xE8ECF2
        val ice = 0x9EDCFF
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.0f, 0f, 0.38f, 0.38f, 0.9f, fur, 51, 0.06f, FLAG_FUR)
            m.blob(0f, 1.05f, 0.55f, 0.42f, 0.42f, 0.35f, 0xD8E0EA, 52, 0.08f, FLAG_FUR)
        }
        k.part(PartKind.HEAD, 0f, 1.15f, 0.8f) { m ->
            m.blob(0f, 0f, 0.22f, 0.27f, 0.25f, 0.3f, fur, 53, 0.05f, FLAG_FUR)
            m.blob(0f, -0.06f, 0.48f, 0.13f, 0.11f, 0.1f, 0xC8D0DA, 54, 0f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.58f, 0.04f, 0.035f, 0.03f, 0x303040, 55, 0f, FLAG_SOLID)
            m.box(-0.1f, 0.08f, 0.47f, 0.05f, 0.025f, 0.02f, 0f, 0xBEF0FF, FLAG_GLOW)
            m.box(0.1f, 0.08f, 0.47f, 0.05f, 0.025f, 0.02f, 0f, 0xBEF0FF, FLAG_GLOW)
            for (i in 0 until 12) {
                val a = i * 0.5236f
                val ca = cos(a)
                val sa = sin(a)
                m.spike(ca * 0.3f, sa * 0.3f - 0.05f, 0.02f, 0.05f, 0.32f + (i % 3) * 0.1f, ca * 0.9f, -0.5f, if (i % 2 == 0) ice else 0xC8F0FF, FLAG_GLOW)
            }
        }
        k.part(PartKind.TAIL, 0f, 1.1f, -0.85f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.35f, -0.6f, 0.07f, 0.04f, fur, FLAG_FUR)
            m.spike(0f, -0.4f, -0.62f, 0.06f, 0.22f, 0f, -0.8f, ice, FLAG_GLOW)
        }
        k.legs4(0.76f, 0.58f, -0.58f, 0.22f, 0.76f, 0.11f, 0.085f, fur, 0x8A94A2)
        list.add(Species("Frostmane", arrayOf(Zone.SNOW), false, 1.3f, 6f, false, false, 0.5f, 2.6f, 0.9f, 1.15f, 1, k.parts))
    }

    // 6. Rimewooly (Frostpeak): a huge shaggy grazer with curled horns and frost on its back.
    run {
        val k = BodyKit()
        val wool = 0x8E7C68
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 1.75f, 0f, 0.95f, 1.0f, 1.4f, wool, 61, 0.14f, FLAG_FUR)
            for (i in 0 until 10) {
                val a = i * 0.628f
                m.blob(sin(a) * 0.85f, 1.05f, cos(a) * 1.2f, 0.28f, 0.45f, 0.28f, 0x7A6A58, 62 + i, 0.2f, FLAG_FUR)
            }
            m.blob(0f, 2.62f, -0.1f, 0.7f, 0.2f, 1.0f, 0xF2F6FA, 75, 0.2f, FLAG_SNOW)
        }
        k.part(PartKind.HEAD, 0f, 1.7f, 1.3f) { m ->
            m.blob(0f, -0.1f, 0.3f, 0.45f, 0.45f, 0.5f, wool, 76, 0.12f, FLAG_FUR)
            m.blob(0f, -0.3f, 0.72f, 0.24f, 0.2f, 0.14f, 0x4A3E32, 77, 0.05f, FLAG_FUR)
            m.blob(-0.25f, 0.05f, 0.7f, 0.04f, 0.04f, 0.04f, 0x101014, 78, 0f, FLAG_SOLID)
            m.blob(0.25f, 0.05f, 0.7f, 0.04f, 0.04f, 0.04f, 0x101014, 79, 0f, FLAG_SOLID)
            for (side in intArrayOf(-1, 1)) {
                var px = side * 0.3f
                var py = 0.2f
                var pz = 0.3f
                for (seg in 0 until 6) {
                    val a = seg * 0.9f
                    val nx = side * (0.45f + 0.25f * cos(a))
                    val ny = 0.25f - 0.3f * sin(a) * (seg / 6f) - seg * 0.04f
                    val nz = 0.3f - 0.3f * sin(a)
                    m.limb(px, py, pz, nx, ny, nz, 0.1f - seg * 0.013f, 0.09f - seg * 0.013f, 0xE8DCC0, FLAG_SOLID)
                    px = nx
                    py = ny
                    pz = nz
                }
            }
        }
        k.part(PartKind.TAIL, 0f, 1.9f, -1.38f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.4f, -0.15f, 0.1f, 0.06f, wool, FLAG_FUR)
        }
        k.legs4(1.15f, 0.8f, -0.8f, 0.55f, 1.15f, 0.27f, 0.22f, 0x6A5A48, 0x2A2420)
        list.add(Species("Rimewooly", arrayOf(Zone.SNOW), false, 1.0f, 3.5f, true, true, 0.4f, 1.8f, 0.85f, 1.15f, 3, k.parts))
    }

    // 7. Sunstrider (Sunscar): a tall, long-necked runner with a glowing golden sail.
    run {
        val k = BodyKit()
        val hide = 0xC89A5A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 2.0f, 0f, 0.4f, 0.45f, 1.0f, hide, 81, 0.06f, FLAG_FUR)
            m.blob(0f, 1.85f, 0f, 0.32f, 0.3f, 0.8f, 0xE8D4B0, 82, 0.05f, FLAG_FUR)
            for (i in 0 until 7) {
                val z = -0.6f + i * 0.2f
                val h = 0.35f + sin(i * 0.45f) * 0.5f
                m.tri(0f, 2.35f, z, 0f, 2.35f + h, z + 0.1f, 0f, 2.35f, z + 0.2f, 0xFFC24A, FLAG_GLOW, 1f, 2.4f, z)
            }
        }
        k.part(PartKind.HEAD, 0f, 2.25f, 0.85f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.9f, 0.35f, 0.14f, 0.09f, hide, FLAG_FUR)
            m.blob(0f, 1.0f, 0.5f, 0.14f, 0.15f, 0.3f, hide, 83, 0.05f, FLAG_FUR)
            m.blob(0f, 0.95f, 0.78f, 0.06f, 0.06f, 0.05f, 0x3A2A1E, 84, 0f, FLAG_SOLID)
            m.blob(-0.1f, 1.06f, 0.6f, 0.025f, 0.025f, 0.025f, 0x101014, 85, 0f, FLAG_SOLID)
            m.blob(0.1f, 1.06f, 0.6f, 0.025f, 0.025f, 0.025f, 0x101014, 86, 0f, FLAG_SOLID)
            m.spike(-0.07f, 1.12f, 0.4f, 0.03f, 0.35f, -0.2f, -0.6f, 0x3A2A1E, FLAG_SOLID)
            m.spike(0.07f, 1.12f, 0.4f, 0.03f, 0.35f, 0.2f, -0.6f, 0x3A2A1E, FLAG_SOLID)
        }
        k.part(PartKind.TAIL, 0f, 2.0f, -1.0f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.5f, -0.25f, 0.05f, 0.02f, hide, FLAG_FUR)
            m.blob(0f, -0.55f, -0.27f, 0.06f, 0.1f, 0.06f, 0xFFC24A, 87, 0f, FLAG_GLOW)
        }
        k.legs4(1.78f, 0.62f, -0.62f, 0.22f, 1.78f, 0.085f, 0.05f, hide, 0x3A2A1E)
        list.add(Species("Sunstrider", arrayOf(Zone.DESERT), false, 1.8f, 11f, true, true, 0.55f, 1.6f, 0.9f, 1.1f, 3, k.parts))
    }

    // 8. Dunescale (Sunscar): a low armoured lizard with glowing amber plates down its back.
    run {
        val k = BodyKit()
        val hide = 0x9A7A4A
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.45f, 0f, 0.4f, 0.26f, 1.0f, hide, 91, 0.1f, FLAG_FUR)
            m.blob(0f, 0.36f, 0f, 0.34f, 0.16f, 0.9f, 0xC8B088, 92, 0.05f, FLAG_FUR)
            for (i in 0 until 8) {
                val z = -0.8f + i * 0.23f
                m.spike(0f, 0.62f, z, 0.07f, 0.2f + (i % 3) * 0.06f, 0f, -0.3f, 0xFF9A3A, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.46f, 0.95f) { m ->
            m.blob(0f, 0f, 0.22f, 0.22f, 0.15f, 0.32f, hide, 93, 0.06f, FLAG_FUR)
            m.box(-0.14f, 0.07f, 0.3f, 0.04f, 0.025f, 0.03f, 0f, 0xFFD06A, FLAG_GLOW)
            m.box(0.14f, 0.07f, 0.3f, 0.04f, 0.025f, 0.03f, 0f, 0xFFD06A, FLAG_GLOW)
            m.spike(-0.12f, 0.1f, 0.05f, 0.04f, 0.18f, -0.4f, -0.6f, 0x6A5030, FLAG_SOLID)
            m.spike(0.12f, 0.1f, 0.05f, 0.04f, 0.18f, 0.4f, -0.6f, 0x6A5030, FLAG_SOLID)
        }
        k.part(PartKind.TAIL, 0f, 0.42f, -0.95f) { m ->
            m.limb(0f, 0f, 0f, 0f, -0.12f, -0.8f, 0.16f, 0.08f, hide, FLAG_FUR)
            m.limb(0f, -0.12f, -0.8f, 0f, -0.25f, -1.5f, 0.08f, 0.02f, hide, FLAG_FUR)
        }
        k.legs4(0.38f, 0.55f, -0.5f, 0.36f, 0.38f, 0.08f, 0.06f, hide, 0x4A3A22, splay = 0.2f)
        list.add(Species("Dunescale", arrayOf(Zone.DESERT), false, 1.1f, 4f, false, false, 0.7f, 3.5f, 0.9f, 1.2f, 2, k.parts))
    }

    // 9. Voidhound (Hollow Deep): a lean shadow hound with purple crystal spines.
    run {
        val k = BodyKit()
        val fur = 0x2A2238
        val glow = 0xB070FF
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.95f, 0f, 0.26f, 0.28f, 0.75f, fur, 101, 0.08f, FLAG_FUR)
            for (i in 0 until 7) {
                val z = -0.55f + i * 0.18f
                m.spike(0f, 1.18f, z, 0.05f, 0.18f + (i % 2) * 0.12f, 0f, -0.4f, glow, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 1.05f, 0.7f) { m ->
            m.blob(0f, 0f, 0.15f, 0.18f, 0.16f, 0.22f, fur, 102, 0.05f, FLAG_FUR)
            m.limb(0f, -0.02f, 0.28f, 0f, -0.06f, 0.5f, 0.09f, 0.05f, fur, FLAG_FUR)
            m.spike(-0.1f, 0.12f, 0.06f, 0.04f, 0.22f, -0.2f, -0.5f, fur, FLAG_FUR)
            m.spike(0.1f, 0.12f, 0.06f, 0.04f, 0.22f, 0.2f, -0.5f, fur, FLAG_FUR)
            m.box(-0.08f, 0.06f, 0.33f, 0.04f, 0.02f, 0.02f, 0f, 0xD8A0FF, FLAG_GLOW)
            m.box(0.08f, 0.06f, 0.33f, 0.04f, 0.02f, 0.02f, 0f, 0xD8A0FF, FLAG_GLOW)
        }
        k.part(PartKind.TAIL, 0f, 1.0f, -0.72f) { m ->
            m.limb(0f, 0f, 0f, 0f, 0.1f, -0.6f, 0.06f, 0.02f, fur, FLAG_FUR)
            m.blob(0f, 0.11f, -0.62f, 0.05f, 0.05f, 0.05f, glow, 103, 0f, FLAG_GLOW)
        }
        k.legs4(0.72f, 0.5f, -0.5f, 0.15f, 0.72f, 0.07f, 0.05f, fur, 0x14101C)
        list.add(Species("Voidhound", arrayOf(Zone.CAVES), false, 1.6f, 7f, false, false, 0.65f, 3.2f, 0.9f, 1.15f, 2, k.parts))
    }

    // 10. Crystalback (Hollow Deep): a six-legged armoured beast covered in glowing crystals.
    run {
        val k = BodyKit()
        val shell = 0x3A3048
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0.95f, 0f, 0.8f, 0.6f, 1.1f, shell, 111, 0.12f, FLAG_SOLID)
            m.blob(0f, 0.65f, 0f, 0.7f, 0.25f, 1.0f, 0x28202E, 112, 0.1f, FLAG_FUR)
            for (i in 0 until 11) {
                val a = i * 1.1f
                val r = 0.15f + (i % 4) * 0.14f
                m.spike(sin(a) * r, 1.4f, cos(a) * r * 1.4f, 0.09f, 0.35f + (i % 3) * 0.2f, sin(a) * 0.4f, cos(a) * 0.3f,
                    if (i % 2 == 0) 0xC8A0FF else 0x8ADCFF, FLAG_GLOW)
            }
        }
        k.part(PartKind.HEAD, 0f, 0.85f, 1.05f) { m ->
            m.blob(0f, 0f, 0.2f, 0.35f, 0.3f, 0.35f, shell, 113, 0.08f, FLAG_SOLID)
            m.limb(0f, 0.1f, 0.45f, 0f, 0.35f, 0.95f, 0.1f, 0.01f, 0xC8A0FF, FLAG_GLOW)
            m.box(-0.18f, 0.08f, 0.5f, 0.04f, 0.03f, 0.02f, 0f, 0xE8D0FF, FLAG_GLOW)
            m.box(0.18f, 0.08f, 0.5f, 0.04f, 0.03f, 0.02f, 0f, 0xE8D0FF, FLAG_GLOW)
        }
        for ((z, ph) in listOf(0.6f to 0f, 0f to 3.1415927f, -0.6f to 0f)) {
            k.leg(-0.65f, 0.62f, z, ph, 0.62f, 0.1f, 0.07f, shell, 0x1A1422, -0.3f)
            k.leg(0.65f, 0.62f, z, ph + 3.1415927f, 0.62f, 0.1f, 0.07f, shell, 0x1A1422, 0.3f)
        }
        list.add(Species("Crystalback", arrayOf(Zone.CAVES), false, 0.8f, 2f, false, false, 0.5f, 3f, 0.85f, 1.2f, 1, k.parts))
    }

    // ---- Birds ----
    /**
     * A wing in two hinged halves, so it folds as it beats. The inner half carries a
     * row of secondary feathers; the outer half fans out long primary feathers.
     */
    fun wing(k: BodyKit, left: Boolean, span: Float, inner: Int, outer: Int, tip: Int, tipFlag: Int) {
        val s = if (left) -1f else 1f
        val a = span * 0.45f
        val l = span - a
        val innerPart = k.part(if (left) PartKind.WING_L else PartKind.WING_R, s * 0.1f, 0.04f, 0f) { m ->
            // Rounded leading edge (the arm bone under the feathers).
            m.limb(0f, 0.005f, 0.11f, s * a, 0.005f, 0.1f, 0.03f, 0.022f, inner, FLAG_FUR)
            m.quad(0f, 0f, 0.13f, s * a, 0f, 0.12f, s * a, 0f, -0.18f, 0f, 0f, -0.13f, inner, FLAG_FUR, 0f, -1f, 0f)
            for (i in 0 until 5) {
                val t = i / 4f
                val bx = s * a * (0.1f + 0.85f * t)
                val w = a * 0.11f
                m.tri(
                    bx - s * w, 0.003f + i * 0.002f, -0.1f,
                    bx + s * w, 0.003f + i * 0.002f, -0.1f,
                    bx + s * w * 0.4f, 0.003f + i * 0.002f, -0.27f - 0.03f * t,
                    shadeRgb(outer, 0.9f + 0.05f * (i % 2)), FLAG_FUR, 0f, -1f, 0f,
                )
            }
        }
        k.part(if (left) PartKind.WING_TIP_L else PartKind.WING_TIP_R, s * a, 0f, 0f, 0f, innerPart) { m ->
            m.limb(0f, 0.005f, 0.1f, s * l * 0.75f, 0.005f, 0.03f, 0.022f, 0.012f, outer, FLAG_FUR)
            m.quad(0f, 0.004f, 0.12f, s * l * 0.78f, 0.004f, 0.03f, s * l * 0.6f, 0.004f, -0.12f, 0f, 0.004f, -0.18f, outer, FLAG_FUR, 0f, -1f, 0f)
            // Primary feathers fanning from pointing outward to pointing back.
            for (i in 0 until 6) {
                val t = i / 5f
                val ang = t * 1.25f
                val bx = s * l * (0.72f - 0.55f * t)
                val bz = 0.02f - 0.13f * t
                val fl = l * (0.55f - 0.12f * t)
                val dxf = s * cos(ang)
                val dzf = -sin(ang)
                val w = l * 0.075f
                val y = 0.001f * (6 - i)
                val col = if (i < 2) tip else shadeRgb(outer, 0.92f + 0.06f * (i % 2))
                val fl2 = if (i < 2) tipFlag else FLAG_FUR
                m.tri(
                    bx - dzf * w, y, bz + dxf * w,
                    bx + dzf * w, y, bz - dxf * w,
                    bx + dxf * fl, y, bz + dzf * fl,
                    col, fl2, 0f, -1f, 0f,
                )
            }
        }
    }

    // 11. Emberwing (Sunscar): a fiery red and gold bird trailing glowing tail plumes.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.17f, 0.17f, 0.42f, 0xC8321E, 121, 0.05f, FLAG_FUR)
            m.blob(0f, 0.1f, 0.4f, 0.12f, 0.12f, 0.13f, 0xE0501E, 122, 0.05f, FLAG_FUR)
            m.limb(0f, 0.08f, 0.5f, 0f, 0.03f, 0.66f, 0.04f, 0.005f, 0xFFC040, FLAG_SOLID)
            m.box(-0.08f, 0.14f, 0.48f, 0.015f, 0.015f, 0.015f, 0f, 0xFFE070, FLAG_GLOW)
            m.box(0.08f, 0.14f, 0.48f, 0.015f, 0.015f, 0.015f, 0f, 0xFFE070, FLAG_GLOW)
            m.spike(0f, 0.2f, 0.36f, 0.03f, 0.18f, 0f, -0.8f, 0xFF8A2A, FLAG_GLOW)
            for (i in -1..1) m.tri(0f, 0f, -0.35f, i * 0.2f - 0.08f, -0.05f, -1.1f, i * 0.2f + 0.08f, -0.05f, -1.1f, 0xFF8A2A, FLAG_GLOW, 0f, -1f, -0.5f)
        }
        wing(k, true, 1.0f, 0xC8321E, 0xE06A28, 0xFFB040, FLAG_GLOW)
        wing(k, false, 1.0f, 0xC8321E, 0xE06A28, 0xFFB040, FLAG_GLOW)
        list.add(Species("Emberwing", arrayOf(Zone.DESERT), true, 10f, 10f, false, false, 0f, 7f, 0.9f, 1.3f, 1, k.parts))
    }

    // 12. Azure Tailwing (Greenhollow): a bright blue songbird with long ribbon tail feathers.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.13f, 0.13f, 0.3f, 0x3A7ADC, 131, 0.05f, FLAG_FUR)
            m.blob(0f, 0.07f, 0.3f, 0.1f, 0.1f, 0.1f, 0x5A9AF0, 132, 0.05f, FLAG_FUR)
            m.blob(0f, -0.04f, 0.1f, 0.09f, 0.08f, 0.18f, 0xF0E8C8, 133, 0.05f, FLAG_FUR)
            m.limb(0f, 0.06f, 0.38f, 0f, 0.04f, 0.48f, 0.03f, 0.004f, 0x2A2A2A, FLAG_SOLID)
            m.box(-0.06f, 0.1f, 0.36f, 0.012f, 0.012f, 0.012f, 0f, 0x101014, FLAG_SOLID)
            m.box(0.06f, 0.1f, 0.36f, 0.012f, 0.012f, 0.012f, 0f, 0x101014, FLAG_SOLID)
            m.tri(-0.03f, 0f, -0.25f, -0.12f, -0.02f, -1.0f, -0.04f, -0.02f, -1.0f, 0x6AD8FF, FLAG_GLOW, 0f, -1f, -0.5f)
            m.tri(0.03f, 0f, -0.25f, 0.04f, -0.02f, -1.0f, 0.12f, -0.02f, -1.0f, 0x6AD8FF, FLAG_GLOW, 0f, -1f, -0.5f)
        }
        wing(k, true, 0.75f, 0x3A7ADC, 0x2A5AB8, 0x1A3A88, FLAG_FUR)
        wing(k, false, 0.75f, 0x3A7ADC, 0x2A5AB8, 0x1A3A88, FLAG_FUR)
        list.add(Species("Azure Tailwing", arrayOf(Zone.MEADOW), true, 9f, 9f, false, false, 0f, 10f, 0.9f, 1.2f, 1, k.parts))
    }

    // 13. Frostkite (Frostpeak): a pale hunting bird with wing edges of glowing ice.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.15f, 0.14f, 0.45f, 0xDCEAF5, 141, 0.05f, FLAG_FUR)
            m.blob(0f, 0.08f, 0.42f, 0.11f, 0.11f, 0.13f, 0xF4F8FC, 142, 0.05f, FLAG_FUR)
            m.limb(0f, 0.06f, 0.52f, 0f, -0.02f, 0.64f, 0.035f, 0.004f, 0x5A6A7A, FLAG_SOLID)
            m.box(-0.07f, 0.12f, 0.48f, 0.014f, 0.014f, 0.014f, 0f, 0xA8E4FF, FLAG_GLOW)
            m.box(0.07f, 0.12f, 0.48f, 0.014f, 0.014f, 0.014f, 0f, 0xA8E4FF, FLAG_GLOW)
            m.tri(-0.1f, 0f, -0.38f, 0.1f, 0f, -0.38f, 0f, -0.02f, -0.85f, 0xC8DCEA, FLAG_FUR, 0f, -1f, -0.5f)
        }
        wing(k, true, 1.3f, 0xDCEAF5, 0xB8CCDC, 0xA8E4FF, FLAG_GLOW)
        wing(k, false, 1.3f, 0xDCEAF5, 0xB8CCDC, 0xA8E4FF, FLAG_GLOW)
        list.add(Species("Frostkite", arrayOf(Zone.SNOW), true, 12f, 12f, false, false, 0f, 5f, 0.9f, 1.2f, 1, k.parts))
    }

    // 14. Duskraven (Whisperwood and the Hollow Deep): a black bird with violet-glowing eyes and wing edges.
    run {
        val k = BodyKit()
        k.part(PartKind.BODY, 0f, 0f, 0f) { m ->
            m.blob(0f, 0f, 0f, 0.15f, 0.15f, 0.38f, 0x1E1A24, 151, 0.05f, FLAG_FUR)
            m.blob(0f, 0.08f, 0.36f, 0.12f, 0.12f, 0.13f, 0x2A2432, 152, 0.05f, FLAG_FUR)
            m.limb(0f, 0.06f, 0.46f, 0f, 0.01f, 0.64f, 0.045f, 0.005f, 0x14121A, FLAG_SOLID)
            m.box(-0.07f, 0.12f, 0.43f, 0.016f, 0.016f, 0.016f, 0f, 0xC08AFF, FLAG_GLOW)
            m.box(0.07f, 0.12f, 0.43f, 0.016f, 0.016f, 0.016f, 0f, 0xC08AFF, FLAG_GLOW)
            m.tri(-0.12f, 0f, -0.3f, 0.12f, 0f, -0.3f, 0f, -0.02f, -0.8f, 0x1E1A24, FLAG_FUR, 0f, -1f, -0.5f)
        }
        wing(k, true, 1.0f, 0x1E1A24, 0x28222E, 0x9A5AFF, FLAG_GLOW)
        wing(k, false, 1.0f, 0x1E1A24, 0x28222E, 0x9A5AFF, FLAG_GLOW)
        list.add(Species("Duskraven", arrayOf(Zone.FOREST, Zone.CAVES), true, 9f, 9f, false, false, 0f, 6f, 0.9f, 1.2f, 1, k.parts))
    }
    return list
}
