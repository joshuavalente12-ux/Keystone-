package com.keystone.rpg

import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** One carriage out on a road. */
class CarriageEvent(
    val id: Int,
    /** Which of [World.carriageSpots] it stands at. */
    val spot: Int,
    val x: Float,
    val z: Float,
    val yaw: Float,
    val y: Float,
) {
    /** 0 = waiting for you to come near, 1 = monsters are on it, 2 = saved. */
    @Volatile var state = 0
    var spawned = 0
    var kills = 0
    var timer = 0f
}

/**
 * Carriages caught on the roads. A handful sit at random spots along the roads near wherever you
 * are, glowing with a beacon so you can see them from afar. Come close and monsters (goblins most
 * of all) are on them; drive them all off to save the travellers and earn a reward. Saved
 * carriages are left behind, and new ones turn up at other random spots.
 */
class Carriages(private val main: World) {
    val meshes = ArrayList<CreaturePart>()

    val wagon: CreaturePart = mesh { buildWagon(it) }
    val beacon: CreaturePart = mesh { buildBeacon(it) }
    val traveller: CreaturePart = mesh { buildTraveller(it) }

    /** Everything on the road right now. Read by the drawing thread as well. */
    val live = CopyOnWriteArrayList<CarriageEvent>()

    private val rnd = kotlin.random.Random(System.nanoTime())
    private var nextId = 1
    private var topUp = 1f
    /** Spots that were just used, and how many seconds before they can be used again. */
    private val cooling = HashMap<Int, Float>()

    private fun mesh(build: (MeshBuilder) -> Unit): CreaturePart {
        val m = MeshBuilder(4096)
        build(m)
        val cp = CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
        meshes.add(cp)
        return cp
    }

    /** One of your kills was an attacker of carriage [id]. */
    fun noteKill(id: Int) {
        for (ev in live) if (ev.id == id) ev.kills++
    }

    /**
     * Runs the carriages. [down] is true while you're dead. [onAmbush] fires when the monsters
     * jump a carriage as you come near, [onSaved] when you've driven the last one off.
     */
    fun update(dt: Float, px: Float, pz: Float, fauna: Fauna, down: Boolean, onAmbush: () -> Unit, onSaved: () -> Unit) {
        val spots = main.carriageSpots
        if (spots.isEmpty()) return

        val it = cooling.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            e.setValue(e.value - dt)
            if (e.value <= 0f) it.remove()
        }

        topUp -= dt
        if (topUp <= 0f) {
            topUp = 3f
            if (live.size < MAX_LIVE) addOne(spots, px, pz)
        }

        for (ev in live) {
            val d = hypot(px - ev.x, pz - ev.z)
            when (ev.state) {
                0 -> {
                    if (d < SPAWN_DIST && !down) {
                        val made = fauna.spawnCarriageFoes(ev.x, ev.z, 3 + rnd.nextInt(3), ev.id)
                        if (made > 0) {
                            ev.state = 1
                            ev.spawned = made
                            ev.kills = 0
                            onAmbush()
                        }
                    } else if (d > DROP_DIST) {
                        // You wandered off: it'll turn up somewhere nearer instead.
                        retire(ev, 60f)
                    }
                }
                1 -> {
                    if (down || d > GIVE_UP_DIST) {
                        // You fell or ran off: the monsters melt away and the carriage waits for you again.
                        fauna.clearCarriage(ev.id)
                        ev.state = 0
                        ev.spawned = 0
                        ev.kills = 0
                    } else if (fauna.carriageLeft(ev.id) == 0) {
                        if (ev.kills >= ev.spawned) {
                            ev.state = 2
                            ev.timer = 0f
                            onSaved()
                        } else {
                            // The monsters were lost some other way (a change of map, say): start over.
                            ev.state = 0
                            ev.spawned = 0
                            ev.kills = 0
                        }
                    }
                }
                else -> {
                    ev.timer += dt
                    if (d > 100f && ev.timer > 30f) retire(ev, COOLDOWN)
                }
            }
        }
    }

    private fun retire(ev: CarriageEvent, cooldown: Float) {
        live.remove(ev)
        cooling[ev.spot] = cooldown
    }

    /** Puts a carriage at a random spot on a road, not too close to you and not too far, and clear of the others. */
    private fun addOne(spots: List<FloatArray>, px: Float, pz: Float) {
        for (attempt in 0 until 14) {
            val i = rnd.nextInt(spots.size)
            if (cooling.containsKey(i) || live.any { it.spot == i }) continue
            val s = spots[i]
            val d = hypot(px - s[0], pz - s[1])
            if (d < MIN_SPAWN_DIST || d > MAX_SPAWN_DIST) continue
            if (live.any { hypot(it.x - s[0], it.z - s[1]) < 120f }) continue
            live.add(CarriageEvent(nextId++, i, s[0], s[1], s[2], main.terrainAt(s[0], s[1])))
            return
        }
    }

    // ---------- What they look like ----------

    private fun buildWagon(m: MeshBuilder) {
        val wood = 0x8A5A32
        val dark = 0x5E3C22
        val iron = 0x4A4E56
        val canvas = 0xE6DCC2
        val stripe = 0xA83A32

        // The bed and its sides: a long box on four wheels, facing +z.
        m.box(0f, 0.95f, -0.1f, 0.9f, 0.06f, 1.55f, 0f, wood, FLAG_WOOD)
        m.box(-0.9f, 1.25f, -0.1f, 0.04f, 0.28f, 1.55f, 0f, wood, FLAG_WOOD)
        m.box(0.9f, 1.25f, -0.1f, 0.04f, 0.28f, 1.55f, 0f, wood, FLAG_WOOD)
        m.box(0f, 1.25f, -1.63f, 0.9f, 0.28f, 0.04f, 0f, wood, FLAG_WOOD)
        // The driver's bench at the front.
        m.box(0f, 1.45f, 1.05f, 0.85f, 0.05f, 0.3f, 0f, dark, FLAG_WOOD)
        m.box(0f, 1.78f, 0.78f, 0.85f, 0.25f, 0.04f, 0f, dark, FLAG_WOOD)
        // The canvas hood over the back half, with a red stripe along the ridge.
        val z0 = -1.62f
        val z1 = 0.45f
        m.quad(-0.9f, 1.5f, z0, 0f, 2.7f, z0, 0f, 2.7f, z1, -0.9f, 1.5f, z1, canvas, FLAG_PLASTER, 0f, 1.9f, -0.6f)
        m.quad(0.9f, 1.5f, z0, 0f, 2.7f, z0, 0f, 2.7f, z1, 0.9f, 1.5f, z1, canvas, FLAG_PLASTER, 0f, 1.9f, -0.6f)
        m.box(0f, 2.72f, (z0 + z1) * 0.5f, 0.06f, 0.03f, (z1 - z0) * 0.5f, 0f, stripe, FLAG_PLASTER)
        for (hz in floatArrayOf(-1.55f, -0.6f, 0.4f)) {
            m.limb(-0.9f, 1.5f, hz, 0f, 2.68f, hz, 0.035f, 0.035f, dark, FLAG_WOOD)
            m.limb(0.9f, 1.5f, hz, 0f, 2.68f, hz, 0.035f, 0.035f, dark, FLAG_WOOD)
        }
        // Cargo: a crate and a barrel, and a sack.
        m.box(-0.45f, 1.3f, -1.15f, 0.3f, 0.25f, 0.3f, 0f, 0x9C7449, FLAG_WOOD)
        m.prism(0.42f, 1.01f, -1.1f, 0.27f, 0.25f, 0.55f, 8, 0x7A5230, 0f, true, FLAG_WOOD)
        m.blob(0.05f, 1.2f, -0.2f, 0.3f, 0.22f, 0.25f, 0xB8A27A, 11, 0.15f, FLAG_PLASTER)
        // The pole the horses were hitched to, dropped on the ground: they bolted.
        m.limb(0f, 0.85f, 1.4f, 0f, 0.3f, 3.7f, 0.07f, 0.06f, dark, FLAG_WOOD)
        // Axles.
        m.limb(-0.95f, 0.62f, 0.85f, 0.95f, 0.62f, 0.85f, 0.05f, 0.05f, iron, FLAG_BLADE)
        m.limb(-0.95f, 0.62f, -1.05f, 0.95f, 0.62f, -1.05f, 0.05f, 0.05f, iron, FLAG_BLADE)
        // Four wheels: an eight-sided rim and four spokes each.
        for (sx in floatArrayOf(-0.97f, 0.97f)) for (wz in floatArrayOf(0.85f, -1.05f)) wheel(m, sx, 0.62f, wz, 0.62f, dark)
        // A lantern on a post, lit.
        m.limb(0.88f, 1.5f, 1.2f, 0.88f, 2.2f, 1.2f, 0.03f, 0.03f, iron, FLAG_BLADE)
        m.blob(0.88f, 2.3f, 1.2f, 0.11f, 0.14f, 0.11f, 0xFFC060, 7, 0f, FLAG_GLOW)
        // Arrows stuck in the side: it was attacked.
        m.limb(0.92f, 1.2f, 0.1f, 1.45f, 1.42f, 0.28f, 0.015f, 0.015f, 0x3A2A1A, FLAG_WOOD)
        m.limb(0.92f, 1.4f, -0.5f, 1.4f, 1.55f, -0.62f, 0.015f, 0.015f, 0x3A2A1A, FLAG_WOOD)
        m.box(1.45f, 1.42f, 0.28f, 0.04f, 0.04f, 0.015f, 0f, 0xB03030, FLAG_PLASTER)
        m.box(1.4f, 1.55f, -0.62f, 0.04f, 0.04f, 0.015f, 0f, 0xB03030, FLAG_PLASTER)
    }

    /** A spoked wheel standing on its edge: its axle runs along x. */
    private fun wheel(m: MeshBuilder, cx: Float, cy: Float, cz: Float, r: Float, rgb: Int) {
        val n = 8
        for (k in 0 until n) {
            val a0 = k * 6.2831855f / n
            val a1 = (k + 1) * 6.2831855f / n
            m.limb(cx, cy + r * cos(a0), cz + r * sin(a0), cx, cy + r * cos(a1), cz + r * sin(a1), 0.05f, 0.05f, rgb, FLAG_WOOD)
        }
        for (k in 0 until 4) {
            val a = k * 6.2831855f / 4f + 0.3f
            m.limb(cx, cy + r * cos(a), cz + r * sin(a), cx, cy - r * cos(a), cz - r * sin(a), 0.03f, 0.03f, rgb, FLAG_WOOD)
        }
        m.box(cx, cy, cz, 0.06f, 0.09f, 0.09f, 0f, 0x4A4E56, FLAG_BLADE)
    }

    /** A tall thin pillar of light over a carriage in trouble, so you can spot it from afar. */
    private fun buildBeacon(m: MeshBuilder) {
        m.limb(0f, 2.9f, 0f, 0f, 26f, 0f, 0.14f, 0.05f, 0xFF9A3A, FLAG_GLOW)
    }

    /** A frightened traveller with their hands up. */
    private fun buildTraveller(m: MeshBuilder) {
        val cloth = 0x3E6FA8
        m.box(-0.1f, 0.42f, 0f, 0.075f, 0.42f, 0.09f, 0f, 0x4A3A2A, FLAG_PLASTER)
        m.box(0.1f, 0.42f, 0f, 0.075f, 0.42f, 0.09f, 0f, 0x4A3A2A, FLAG_PLASTER)
        m.box(0f, 1.12f, 0f, 0.2f, 0.3f, 0.12f, 0f, cloth, FLAG_PLASTER)
        m.blob(0f, 1.62f, 0f, 0.14f, 0.16f, 0.14f, 0xE0B890, 3, 0f)
        m.box(0f, 1.74f, -0.02f, 0.15f, 0.06f, 0.15f, 0f, 0x4A2E1A, FLAG_PLASTER)
        m.limb(-0.22f, 1.35f, 0f, -0.2f, 1.85f, 0.1f, 0.05f, 0.045f, cloth, FLAG_PLASTER)
        m.limb(0.22f, 1.35f, 0f, 0.2f, 1.85f, 0.1f, 0.05f, 0.045f, cloth, FLAG_PLASTER)
    }

    companion object {
        /** Most carriages out on the roads at once. */
        private const val MAX_LIVE = 10
        /** Come this close and the monsters jump it. */
        private const val SPAWN_DIST = 55f
        /** Run this far off mid-fight and the attackers lose you. */
        private const val GIVE_UP_DIST = 150f
        /** A carriage nobody has come near this far away is moved somewhere closer. */
        private const val DROP_DIST = 800f
        private const val MIN_SPAWN_DIST = 90f
        private const val MAX_SPAWN_DIST = 600f
        /** Seconds before a saved carriage's spot can be used again. */
        private const val COOLDOWN = 600f
    }
}
