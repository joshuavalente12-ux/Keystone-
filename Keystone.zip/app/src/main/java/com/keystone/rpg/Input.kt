package com.keystone.rpg

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Keyboard, mouse and game controller support (Xbox and PlayStation pads both show up as
 * ordinary Android gamepads, so one code path covers them).
 *
 * The game watches which kind of input arrived last and switches [mode] to match: a touch on
 * the screen means TOUCH, a key or the mouse means KEYS, a pad button or stick means PAD.
 * The on-screen touch buttons are only drawn in TOUCH mode.
 *
 * Everything that reaches this object comes from MainActivity's dispatch overrides and the
 * 3D view's captured-pointer listener. Both run on the main thread; [tick] runs on the game thread.
 */
object InputHub {
    const val TOUCH = 0
    const val KEYS = 1
    const val PAD = 2

    // Panels GameScreen can open from here.
    const val P_BAG = 0
    const val P_MAP = 1
    const val P_QUESTS = 2
    const val P_BOOK = 3
    const val P_GRID = 4

    /** What the player is using right now. Compose reads this to show or hide the touch buttons. */
    var mode by mutableIntStateOf(TOUCH)

    /** Highlighted quick slot for keyboard and controller play. */
    var quickSel by mutableIntStateOf(0)

    /** True while a menu, dialogue or shop is up: game keys pause, the mouse cursor comes back. */
    var panelOpen by mutableStateOf(false)

    /** Bumped when the window regains focus, so pointer capture gets asked for again. */
    var focusTick by mutableIntStateOf(0)

    /** True only while GameScreen is on screen. Everywhere else (title screen, etc.) keys pass through untouched. */
    @Volatile var active = false
    @Volatile var game: Game? = null

    // Hooks GameScreen fills in so a key can open and close its panels.
    var closeTop: () -> Boolean = { false }
    var openPause: () -> Unit = {}
    var togglePanel: (Int) -> Unit = {}
    var toggleView: () -> Unit = {}
    var runBase: () -> Boolean = { false }

    private val down: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    @Volatile private var lx = 0f
    @Volatile private var ly = 0f
    @Volatile private var rx = 0f
    @Volatile private var ry = 0f
    @Volatile private var lt = 0f
    @Volatile private var rt = 0f
    @Volatile private var mouseLeft = false
    private var mouseRight = false
    private var rtHeld = false
    private var hatX = 0
    private var hatY = 0
    private var attackCd = 0f

    var mouseSens = 0.0025f
    private const val STICK_LOOK_X = 2.6f
    private const val STICK_LOOK_Y = 1.7f
    private const val KEY_LOOK_X = 1.9f
    private const val KEY_LOOK_Y = 1.3f

    // Pseudo key codes for things that aren't keys.
    private const val MOUSE_L = 2001
    private const val MOUSE_R = 2002
    private const val PAD_RT = 2003
    private const val PAD_OFFSET = 1000

    private fun isPad(e: KeyEvent): Boolean =
        (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            KeyEvent.isGamepadButton(e.keyCode)

    private fun isDpad(code: Int) =
        code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT

    /** Keys we use. Anything else (volume, back, text entry) is left alone. */
    private val USED: Set<Int> = setOf(
        KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_Q,
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT, KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_X,
        KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_5,
        KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_I, KeyEvent.KEYCODE_M, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K,
        KeyEvent.KEYCODE_G, KeyEvent.KEYCODE_B, KeyEvent.KEYCODE_V, KeyEvent.KEYCODE_ESCAPE,
        KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
        KeyEvent.KEYCODE_R, KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL,
        KeyEvent.KEYCODE_LEFT_BRACKET, KeyEvent.KEYCODE_RIGHT_BRACKET,
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR,
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
    )

    private fun switchMode(m: Int) {
        if (mode == m) return
        val was = mode
        mode = m
        if (m == TOUCH) {
            releaseAll()
            game?.let {
                it.moveX = 0f
                it.moveY = 0f
                it.runOn = runBase()
            }
        } else if (was == TOUCH) {
            // Let go of the touch stick so it can't keep pushing while keys take over.
            game?.let {
                it.moveX = 0f
                it.moveY = 0f
            }
        }
    }

    /** Forget every held key, button and stick. */
    fun releaseAll() {
        down.clear()
        lx = 0f
        ly = 0f
        rx = 0f
        ry = 0f
        lt = 0f
        rt = 0f
        mouseLeft = false
        mouseRight = false
        rtHeld = false
        hatX = 0
        hatY = 0
        attackCd = 0f
    }

    /** GameScreen calls this as menus and dialogues come and go. */
    fun setPanel(open: Boolean) {
        if (panelOpen == open) return
        panelOpen = open
        releaseAll()
    }

    /** A finger touched the screen: back to touch controls. */
    fun touched() {
        if (active) switchMode(TOUCH)
    }

    // ---------- Keys and gamepad buttons ----------

    fun onKey(e: KeyEvent): Boolean {
        if (!active) return false
        val pad = isPad(e)
        var code = e.keyCode
        if (code !in USED) return false
        if (pad && isDpad(code)) code += PAD_OFFSET
        val isDown = e.action == KeyEvent.ACTION_DOWN
        if (!isDown) {
            // Always let go of a key, even if a menu opened while it was held.
            down.remove(code)
            return true
        }
        val fresh = e.repeatCount == 0
        if (panelOpen) {
            if (fresh) pressInPanel(code)
            return true
        }
        switchMode(if (pad) PAD else KEYS)
        down.add(code)
        if (fresh) press(code)
        return true
    }

    /** With a menu up, only a few keys do anything: close it, or flip to another panel. */
    private fun pressInPanel(code: Int) {
        when (code) {
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_START -> {
                closeTop()
            }
            KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_I -> togglePanel(P_BAG)
            KeyEvent.KEYCODE_M, KeyEvent.KEYCODE_BUTTON_SELECT -> togglePanel(P_MAP)
            KeyEvent.KEYCODE_J -> togglePanel(P_QUESTS)
            KeyEvent.KEYCODE_K -> togglePanel(P_BOOK)
            KeyEvent.KEYCODE_G -> togglePanel(P_GRID)
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_BUTTON_A -> {
                // A story scene on screen: Enter, Space or A turns the page.
                val g = game
                if (g != null && g.story.scene != null) g.storyNext()
            }
        }
    }

    private fun press(code: Int) {
        val g = game ?: return
        when (code) {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_BUTTON_A -> g.jump()
            KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_BUTTON_X -> g.interact()
            KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_BUTTON_Y, MOUSE_R -> g.toggleLock()
            KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_BUTTON_B -> g.dodge()
            KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_DPAD_UP + PAD_OFFSET -> g.useQuick(quickSel)
            KeyEvent.KEYCODE_DPAD_LEFT + PAD_OFFSET -> quickSel = (quickSel + QUICK_SLOTS - 1) % QUICK_SLOTS
            KeyEvent.KEYCODE_DPAD_RIGHT + PAD_OFFSET -> quickSel = (quickSel + 1) % QUICK_SLOTS
            KeyEvent.KEYCODE_DPAD_DOWN + PAD_OFFSET -> togglePanel(P_BAG)
            KeyEvent.KEYCODE_1 -> quick(g, 0)
            KeyEvent.KEYCODE_2 -> quick(g, 1)
            KeyEvent.KEYCODE_3 -> quick(g, 2)
            KeyEvent.KEYCODE_4 -> quick(g, 3)
            KeyEvent.KEYCODE_5 -> quick(g, 4)
            KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_I -> togglePanel(P_BAG)
            KeyEvent.KEYCODE_M, KeyEvent.KEYCODE_BUTTON_SELECT -> togglePanel(P_MAP)
            KeyEvent.KEYCODE_J -> togglePanel(P_QUESTS)
            KeyEvent.KEYCODE_K -> togglePanel(P_BOOK)
            KeyEvent.KEYCODE_G -> togglePanel(P_GRID)
            KeyEvent.KEYCODE_B -> g.buildMode = !g.buildMode
            KeyEvent.KEYCODE_V, KeyEvent.KEYCODE_BUTTON_THUMBR -> toggleView()
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_START -> openPause()
            KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_R2, MOUSE_L, PAD_RT -> {
                if (g.buildMode) g.placePiece() else g.attack()
            }
            KeyEvent.KEYCODE_R -> if (g.buildMode) g.rotatePiece()
            KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL -> if (g.buildMode) g.removePiece()
            KeyEvent.KEYCODE_LEFT_BRACKET -> if (g.buildMode) cyclePiece(g, -1)
            KeyEvent.KEYCODE_RIGHT_BRACKET -> if (g.buildMode) cyclePiece(g, 1)
        }
    }

    private fun quick(g: Game, i: Int) {
        quickSel = i
        g.useQuick(i)
    }

    private fun cyclePiece(g: Game, step: Int) {
        val order = PieceType.ORDER
        val at = order.indexOf(g.buildType).let { if (it < 0) 0 else it }
        g.selectPiece(order[(at + step + order.size) % order.size])
    }

    // ---------- Sticks, triggers and the d-pad ----------

    private fun dead(v: Float): Float {
        val a = abs(v)
        if (a < 0.2f) return 0f
        val s = (a - 0.2f) / 0.8f
        return if (v < 0f) -s else s
    }

    fun onMotion(e: MotionEvent): Boolean {
        if (!active) return false
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.actionMasked == MotionEvent.ACTION_MOVE) {
            val nlx = dead(e.getAxisValue(MotionEvent.AXIS_X))
            val nly = dead(e.getAxisValue(MotionEvent.AXIS_Y))
            var nrx = dead(e.getAxisValue(MotionEvent.AXIS_Z))
            var nry = dead(e.getAxisValue(MotionEvent.AXIS_RZ))
            // Some pads report the right stick on RX/RY instead.
            if (nrx == 0f && nry == 0f) {
                nrx = dead(e.getAxisValue(MotionEvent.AXIS_RX))
                nry = dead(e.getAxisValue(MotionEvent.AXIS_RY))
            }
            val nlt = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
            val nrt = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            val nhx = Math.round(e.getAxisValue(MotionEvent.AXIS_HAT_X))
            val nhy = Math.round(e.getAxisValue(MotionEvent.AXIS_HAT_Y))

            val touchedSomething = nlx != 0f || nly != 0f || nrx != 0f || nry != 0f || nlt > 0.3f || nrt > 0.3f || nhx != 0 || nhy != 0
            if (panelOpen) {
                // Keep the sticks zeroed so nothing is pushing when the menu closes.
                lx = 0f; ly = 0f; rx = 0f; ry = 0f; lt = 0f; rt = 0f
                rtHeld = false
                hatX = nhx
                hatY = nhy
                return true
            }
            if (touchedSomething) switchMode(PAD)
            lx = nlx; ly = nly; rx = nrx; ry = nry; lt = nlt; rt = nrt

            if (nrt > 0.5f && !rtHeld) {
                rtHeld = true
                press(PAD_RT)
            } else if (nrt < 0.3f) {
                rtHeld = false
            }
            // The d-pad on most pads is an axis, not four keys.
            if (nhx != hatX) {
                if (nhx < 0) press(KeyEvent.KEYCODE_DPAD_LEFT + PAD_OFFSET)
                if (nhx > 0) press(KeyEvent.KEYCODE_DPAD_RIGHT + PAD_OFFSET)
            }
            if (nhy != hatY) {
                if (nhy < 0) press(KeyEvent.KEYCODE_DPAD_UP + PAD_OFFSET)
                if (nhy > 0) press(KeyEvent.KEYCODE_DPAD_DOWN + PAD_OFFSET)
            }
            hatX = nhx
            hatY = nhy
            return true
        }
        if (e.isFromSource(InputDevice.SOURCE_MOUSE)) {
            // A mouse moved over the game: switch to keyboard-and-mouse so the cursor gets captured.
            val a = e.actionMasked
            if (!panelOpen && (a == MotionEvent.ACTION_HOVER_MOVE || a == MotionEvent.ACTION_SCROLL)) switchMode(KEYS)
        }
        return false
    }

    // ---------- Mouse (captured pointer) ----------

    /** Events from the 3D view once it has captured the mouse. */
    fun onCaptured(e: MotionEvent): Boolean {
        if (!active) return false
        val g = game ?: return true
        if (panelOpen) return true
        switchMode(KEYS)
        if (e.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)) {
            when (e.actionMasked) {
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> {
                    var dx = e.x
                    var dy = e.y
                    for (h in 0 until e.historySize) {
                        dx += e.getHistoricalX(h)
                        dy += e.getHistoricalY(h)
                    }
                    g.addLook(dx * mouseSens, dy * mouseSens)
                }
                MotionEvent.ACTION_SCROLL -> {
                    val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                    if (v > 0f) quickSel = (quickSel + QUICK_SLOTS - 1) % QUICK_SLOTS
                    if (v < 0f) quickSel = (quickSel + 1) % QUICK_SLOTS
                }
            }
        }
        val b = e.buttonState
        val left = (b and MotionEvent.BUTTON_PRIMARY) != 0
        val right = (b and MotionEvent.BUTTON_SECONDARY) != 0
        if (left && !mouseLeft) press(MOUSE_L)
        mouseLeft = left
        if (right && !mouseRight) press(MOUSE_R)
        mouseRight = right
        return true
    }

    // ---------- Per-frame (game thread) ----------

    /** Turns held keys and sticks into walking, looking and repeated attacks. Does nothing in touch mode. */
    fun tick(g: Game, dt: Float) {
        if (!active || mode == TOUCH) return
        if (panelOpen) {
            g.moveX = 0f
            g.moveY = 0f
            g.runOn = runBase()
            return
        }
        // Walking: WASD plus the left stick. Up on screen (negative Y) is forward.
        var mx = lx
        var my = ly
        if (down.contains(KeyEvent.KEYCODE_D)) mx += 1f
        if (down.contains(KeyEvent.KEYCODE_A)) mx -= 1f
        if (down.contains(KeyEvent.KEYCODE_S)) my += 1f
        if (down.contains(KeyEvent.KEYCODE_W)) my -= 1f
        val len = hypot(mx, my)
        if (len > 1f) {
            mx /= len
            my /= len
        }
        g.moveX = mx
        g.moveY = my

        // Running: Shift, or hold the left trigger or bumper.
        val runHeld = down.contains(KeyEvent.KEYCODE_SHIFT_LEFT) || down.contains(KeyEvent.KEYCODE_SHIFT_RIGHT) ||
            lt > 0.5f || down.contains(KeyEvent.KEYCODE_BUTTON_L1) || down.contains(KeyEvent.KEYCODE_BUTTON_L2)
        g.runOn = runHeld || runBase()

        // Looking: right stick (curved so small pushes are gentle) and the arrow keys.
        var lookX = rx * abs(rx) * STICK_LOOK_X
        var lookY = ry * abs(ry) * STICK_LOOK_Y
        if (down.contains(KeyEvent.KEYCODE_DPAD_RIGHT)) lookX += KEY_LOOK_X
        if (down.contains(KeyEvent.KEYCODE_DPAD_LEFT)) lookX -= KEY_LOOK_X
        if (down.contains(KeyEvent.KEYCODE_DPAD_DOWN)) lookY += KEY_LOOK_Y
        if (down.contains(KeyEvent.KEYCODE_DPAD_UP)) lookY -= KEY_LOOK_Y
        if (lookX != 0f || lookY != 0f) g.addLook(lookX * dt, lookY * dt)

        // Holding an attack control keeps swinging.
        val attackHeld = mouseLeft || rt > 0.5f || down.contains(KeyEvent.KEYCODE_Z) ||
            down.contains(KeyEvent.KEYCODE_ENTER) || down.contains(KeyEvent.KEYCODE_BUTTON_R1) ||
            down.contains(KeyEvent.KEYCODE_BUTTON_R2)
        if (attackHeld && !g.buildMode) {
            attackCd -= dt
            if (attackCd <= 0f) {
                g.attack()
                attackCd = 0.15f
            }
        } else {
            attackCd = 0f
        }
    }
}
