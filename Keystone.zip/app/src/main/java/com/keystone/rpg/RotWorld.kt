package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow

// The Grain Rot's own land: a second map reached through the rot-gate. It is a square about
// 1.5 km a side, sitting in the middle of the same terrain grid and ringed by mountains.
// Only open grass, hills and a few mountain ranges so far; people and monsters come later.

/** Side of the playable square, in metres. */
internal const val ROT_SIDE = 1500f

/** Where the square starts on the grid (both x and z). */
internal const val ROT_ORIGIN = (WORLD_SIZE - ROT_SIDE) / 2f

/** The gate on this side of the crossing, and where you step out of it. */
internal const val ROT_SPAWN_X = ROT_ORIGIN + ROT_SIDE / 2f
internal const val ROT_GATE_Z = ROT_ORIGIN + 170f
internal const val ROT_SPAWN_Z = ROT_GATE_Z + 8f
internal const val ROT_SPAWN_YAW = 0f

/** Height of the flat green meadow round the gate. */
private const val ROT_FLAT_Y = 8f

/** How far you are inside the edge of the playable square (negative outside it). */
internal fun rotEdge(x: Float, z: Float): Float {
    val a = minOf(x - ROT_ORIGIN, ROT_ORIGIN + ROT_SIDE - x)
    val b = minOf(z - ROT_ORIGIN, ROT_ORIGIN + ROT_SIDE - z)
    return minOf(a, b)
}

/** Fills in what's at (x, z): all meadow, no roads or rivers, mountains round the edge and in ranges. */
internal fun rotProbe(x: Float, z: Float, seed: Int, p: Probe) {
    p.zone = Zone.MEADOW
    for (k in p.regionDist.indices) p.regionDist[k] = 0f
    p.trail = 999f
    p.site = 999f
    p.siteCenter = 999f
    p.siteKind = -1
    p.siteIndex = -1
    p.mesa = 0f
    p.river = 999f
    val edge = rotEdge(x, z)
    val ring = ((110f - edge + (valueNoise(x / 80f, z / 80f, seed + 3) - 0.5f) * 40f) / 45f).coerceIn(0f, 1f)
    val n2 = 0.65f * valueNoise(x / 520f, z / 520f, seed + 60) + 0.35f * valueNoise(x / 190f, z / 190f, seed + 63)
    val ridge = 1f - abs(n2 * 2f - 1f)
    val away = smooth(90f, 220f, hypot(x - ROT_SPAWN_X, z - ROT_GATE_Z))
    val range = smooth(0.9f, 0.96f, ridge) * away
    p.mountain = max(ring, range)
}

/** Ground height: gentle green hills, flat by the gate, mountains where [rotProbe] says so. */
internal fun rotHeight(x: Float, z: Float, seed: Int, p: Probe): Float {
    val hills = (valueNoise(x / 220f, z / 220f, seed + 11) - 0.5f) * 22f +
        (valueNoise(x / 70f, z / 70f, seed + 12) - 0.5f) * 7f +
        (valueNoise(x / 25f, z / 25f, seed + 13) - 0.5f) * 1.5f
    var h = 9f + hills * 0.5f
    val flat = 1f - smooth(25f, 70f, hypot(x - ROT_SPAWN_X, z - ROT_GATE_Z - 4f))
    h += (ROT_FLAT_Y - h) * flat
    if (p.mountain > 0f) {
        val crag = 1f - abs(valueNoise(x / 35f, z / 35f, seed + 41) * 2f - 1f)
        h += p.mountain.pow(1.3f) * (40f + 60f * valueNoise(x / 60f, z / 60f, seed + 40)) + 25f * p.mountain * crag
    }
    return h
}
