package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow

// The Grain Rot's own land: a second map reached through the rot-gate. It is a square about
// 1.5 km a side, sitting in the middle of the same terrain grid and ringed by mountains.
// Only open grass, hills and a few mountain ranges so far; people and monsters come later.

/** Side of the playable square, in metres. */
internal const val ROT_SIDE = 1500f

/** Where the square starts on the grid (both x and z). */
internal const val ROT_ORIGIN = (WORLD_SIZE - ROT_SIDE) / 2f

/** The gate on this side of the crossing, and where you step out of it. */
internal const val ROT_SPAWN_X = ROT_ORIGIN + ROT_SIDE / 2f
internal const val ROT_GATE_Z = ROT_ORIGIN + 170f
internal const val ROT_SPAWN_Z = ROT_GATE_Z + 8f
internal const val ROT_SPAWN_YAW = 0f

/** The castle on the rock mountain, bottom-left of the map: its middle, and how high its flat top is. */
internal const val ROT_CASTLE_X = ROT_ORIGIN + 330f
internal const val ROT_CASTLE_Z = ROT_ORIGIN + 1170f
internal const val ROT_CASTLE_Y = 58f

/** The big waterfall beside the castle: the way it leaves the mountain, and where its pool is. */
internal const val ROT_FALLS_ANGLE = 0.35f
internal const val ROT_FALLS_DIST = 116f
internal const val ROT_FALLS_TOP = 66f
internal const val ROT_FALLS_BOTTOM = 112f

/** The dirt arena (the purple circle): its middle, the radius of bare dirt, and how high its floor is. */
internal const val ROT_ARENA_X = ROT_ORIGIN + (940 - 15) * (ROT_SIDE / 1165f)
internal const val ROT_ARENA_Z = ROT_ORIGIN + (410 - 15) * (ROT_SIDE / 1165f)
internal const val ROT_ARENA_R = 100f
private const val ROT_ARENA_Y = 9f

/** Height of the flat green meadow round the gate. */
private const val ROT_FLAT_Y = 8f

/** One pixel of Josh's map drawing, in metres (the drawn square is 1165 px across). */
private const val PX_M = ROT_SIDE / 1165f

/** Turns a list of (px, py) pairs read off the map drawing into world (x, z) pairs. */
private fun roadLine(vararg px: Int): FloatArray {
    val out = FloatArray(px.size)
    var i = 0
    while (i + 1 < px.size) {
        out[i] = ROT_ORIGIN + (px[i] - 15) * PX_M
        out[i + 1] = ROT_ORIGIN + (px[i + 1] - 15) * PX_M
        i += 2
    }
    return out
}

/**
 * The dirt roads, as drawn: down from the gate through the villages, one branch to the castle
 * (bottom-left) and one toward the bottom-right, plus short roads between the villages and one
 * out to the arena. Each is a list of x, z pairs.
 */
private val ROT_ROADS: Array<FloatArray> = run {
    val gx = ROT_SPAWN_X - ROT_CASTLE_X
    val gz = ROT_GATE_Z - ROT_CASTLE_Z
    val gl = hypot(gx, gz)
    val toCastle = roadLine(598, 145, 596, 200, 612, 245, 606, 360, 575, 450, 540, 525, 440, 640, 340, 780) +
        floatArrayOf(ROT_CASTLE_X + gx / gl * 50f, ROT_CASTLE_Z + gz / gl * 50f)
    arrayOf(
        toCastle,
        roadLine(540, 525, 620, 600, 700, 670, 720, 740, 790, 790, 870, 860, 925, 935),
        roadLine(448, 185, 455, 225, 540, 218, 612, 245),
        roadLine(448, 345, 452, 225),
        roadLine(748, 185, 712, 212, 612, 245),
        roadLine(670, 320, 625, 262, 612, 245),
        roadLine(748, 185, 800, 260, 880, 340, 940, 410),
    )
}

/** Distance from (x, z) to the nearest dirt road. */
internal fun rotTrailDist(x: Float, z: Float): Float {
    var best = 1e9f
    for (road in ROT_ROADS) {
        var i = 0
        while (i + 3 < road.size) {
            val x0 = road[i]
            val z0 = road[i + 1]
            val dx = road[i + 2] - x0
            val dz = road[i + 3] - z0
            val len2 = dx * dx + dz * dz
            val t = (((x - x0) * dx + (z - z0) * dz) / len2).coerceIn(0f, 1f)
            val d = hypot(x - (x0 + dx * t), z - (z0 + dz * t))
            if (d < best) best = d
            i += 2
        }
    }
    return best
}

/** How far you are inside the edge of the playable square (negative outside it). */
internal fun rotEdge(x: Float, z: Float): Float {
    val a = minOf(x - ROT_ORIGIN, ROT_ORIGIN + ROT_SIDE - x)
    val b = minOf(z - ROT_ORIGIN, ROT_ORIGIN + ROT_SIDE - z)
    return minOf(a, b)
}

/** Fills in what's at (x, z): all meadow, no roads or rivers, mountains round the edge and in ranges. */
internal fun rotProbe(x: Float, z: Float, seed: Int, p: Probe) {
    p.zone = Zone.MEADOW
    for (k in p.regionDist.indices) p.regionDist[k] = 0f
    val da = hypot(x - ROT_ARENA_X, z - ROT_ARENA_Z)
    p.trail = minOf(rotTrailDist(x, z), maxOf(0f, da - ROT_ARENA_R))
    p.site = 999f
    p.siteCenter = 999f
    p.siteKind = -1
    p.siteIndex = -1
    p.mesa = 0f
    p.river = 999f
    val edge = rotEdge(x, z)
    val ring = ((110f - edge + (valueNoise(x / 80f, z / 80f, seed + 3) - 0.5f) * 40f) / 45f).coerceIn(0f, 1f)
    val n2 = 0.65f * valueNoise(x / 520f, z / 520f, seed + 60) + 0.35f * valueNoise(x / 190f, z / 190f, seed + 63)
    val ridge = 1f - abs(n2 * 2f - 1f)
    val away = smooth(90f, 220f, hypot(x - ROT_SPAWN_X, z - ROT_GATE_Z))
    val range = smooth(0.9f, 0.96f, ridge) * away
    // No mountains in or close round the arena.
    p.mountain = max(ring, range) * smooth(110f, 170f, da)
}

/** Ground height: gentle green hills, flat by the gate, mountains where [rotProbe] says so. */
internal fun rotHeight(x: Float, z: Float, seed: Int, p: Probe): Float {
    val hills = (valueNoise(x / 220f, z / 220f, seed + 11) - 0.5f) * 22f +
        (valueNoise(x / 70f, z / 70f, seed + 12) - 0.5f) * 7f +
        (valueNoise(x / 25f, z / 25f, seed + 13) - 0.5f) * 1.5f
    var h = 9f + hills * 0.5f
    val flat = 1f - smooth(25f, 70f, hypot(x - ROT_SPAWN_X, z - ROT_GATE_Z - 4f))
    h += (ROT_FLAT_Y - h) * flat
    if (p.mountain > 0f) {
        val crag = 1f - abs(valueNoise(x / 35f, z / 35f, seed + 41) * 2f - 1f)
        h += p.mountain.pow(1.3f) * (40f + 60f * valueNoise(x / 60f, z / 60f, seed + 40)) + 25f * p.mountain * crag
    }

    // The arena floor: flat and level, blending into the hills round it.
    val arenaD = hypot(x - ROT_ARENA_X, z - ROT_ARENA_Z)
    h += (ROT_ARENA_Y - h) * (1f - smooth(110f, 150f, arenaD))

    // The castle mountain: a big rocky hill with a flat grassy top, and one sheer face for the falls.
    val cdx = x - ROT_CASTLE_X
    val cdz = z - ROT_CASTLE_Z
    val dc = hypot(cdx, cdz)
    if (dc < 320f) {
        var ang = atan2(cdz, cdx) - ROT_FALLS_ANGLE
        while (ang > 3.1415927f) ang -= 6.2831855f
        while (ang < -3.1415927f) ang += 6.2831855f
        val gentle = 1f - smooth(70f, 300f, dc)
        val steep = 1f - smooth(72f, ROT_FALLS_BOTTOM, dc)
        val cs = 1f - smooth(0.12f, 0.34f, abs(ang))
        val w = gentle + (steep - gentle) * cs
        h += (ROT_CASTLE_Y - h) * w
        // Rough, rocky slopes (the top stays flat).
        h += (valueNoise(x / 22f, z / 22f, seed + 51) - 0.5f) * 12f * (4f * w * (1f - w))
    }
    // The pool the falls drop into.
    val fpx = ROT_CASTLE_X + cos(ROT_FALLS_ANGLE) * ROT_FALLS_DIST
    val fpz = ROT_CASTLE_Z + sin(ROT_FALLS_ANGLE) * ROT_FALLS_DIST
    val pool = 1f - smooth(10f, 26f, hypot(x - fpx, z - fpz))
    h += (-3f - h) * pool
    return h
}
