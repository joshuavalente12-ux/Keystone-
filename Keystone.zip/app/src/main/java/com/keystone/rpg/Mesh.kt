package com.keystone.rpg

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Bytes per vertex: x, y, z as floats, then r, g, b, flag as bytes, then the
 * surface direction (normal) as three signed bytes plus one spare.
 * Colours are the plain, unlit colour of the material: lighting happens per pixel.
 */
const val STRIDE = 20

/**
 * The 4th colour byte tells the shaders what the surface is made of, so each one
 * gets its own texture (bark, leaves, shingles, snow sparkle and so on).
 */
const val FLAG_WATER = 40
const val FLAG_FIRE = 70
const val FLAG_FIRE_TIP = 75
const val FLAG_HEARTH_TIP = 74
const val FLAG_CANDLE_TIP = 73
const val FLAG_GLOW = 130
const val FLAG_BLADE_TIP = 160
const val FLAG_BLADE = 161
const val FLAG_LEAF = 180
const val FLAG_BARK = 195
const val FLAG_WOOD = 200
const val FLAG_STONE = 205
const val FLAG_PLASTER = 215
const val FLAG_ROOF = 222
const val FLAG_GRASS = 231
const val FLAG_BOULDER = 234
const val FLAG_ROCK = 236
const val FLAG_DIRT = 240
const val FLAG_SAND = 246
const val FLAG_SNOW = 250
const val FLAG_SOLID = 255

// Sunlight comes from high up in the top-left (towards the starting corner).
const val SUN_X = -0.458f
const val SUN_Y = 0.815f
const val SUN_Z = -0.356f

private const val TAU = 6.2831855f

/** Collects coloured, sun-lit triangles into a buffer ready for the graphics card. */
class MeshBuilder(initialVertices: Int = 8192) {
    private var buf: ByteBuffer =
        ByteBuffer.allocateDirect(initialVertices * STRIDE).order(ByteOrder.nativeOrder())
    var vertexCount = 0
        private set

    /**
     * High detail: round, finely divided shapes for creatures and the hero, which are
     * seen up close. Off for the world, where the chunky low-poly look is cheaper.
     */
    var hd = false

    private fun ensure(vertices: Int) {
        if (buf.remaining() >= vertices * STRIDE) return
        var cap = buf.capacity() * 2
        while (cap - buf.position() < vertices * STRIDE) cap *= 2
        val bigger = ByteBuffer.allocateDirect(cap).order(ByteOrder.nativeOrder())
        buf.flip()
        bigger.put(buf)
        buf = bigger
    }

    // Normal used by vertex() when the caller doesn't give one per corner.
    private var nX = 0f
    private var nY = 1f
    private var nZ = 0f

    private fun packN(v: Float): Byte = (v * 127f).toInt().coerceIn(-127, 127).toByte()

    private fun vertex(x: Float, y: Float, z: Float, r: Int, g: Int, b: Int, flag: Int) {
        vertexN(x, y, z, r, g, b, flag, nX, nY, nZ)
    }

    private fun vertexN(x: Float, y: Float, z: Float, r: Int, g: Int, b: Int, flag: Int, nx: Float, ny: Float, nz: Float) {
        buf.putFloat(x)
        buf.putFloat(y)
        buf.putFloat(z)
        buf.put(r.toByte())
        buf.put(g.toByte())
        buf.put(b.toByte())
        buf.put(flag.toByte())
        // Normals are packed into bytes, so they must be unit length first.
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 1e-6f) {
            buf.put(packN(nx / l))
            buf.put(packN(ny / l))
            buf.put(packN(nz / l))
        } else {
            buf.put(0.toByte())
            buf.put(127.toByte())
            buf.put(0.toByte())
        }
        buf.put(0.toByte())
        vertexCount++
    }

    private fun up() {
        nX = 0f
        nY = 1f
        nZ = 0f
    }

    /** A triangle with its own surface direction at each corner, for smooth, rounded shading. */
    fun triN(
        ax: Float, ay: Float, az: Float, anx: Float, any: Float, anz: Float,
        bx: Float, by: Float, bz: Float, bnx: Float, bny: Float, bnz: Float,
        cx: Float, cy: Float, cz: Float, cnx: Float, cny: Float, cnz: Float,
        rgb: Int, flag: Int,
    ) {
        ensure(3)
        val r = (rgb shr 16) and 255
        val g = (rgb shr 8) and 255
        val b = rgb and 255
        vertexN(ax, ay, az, r, g, b, flag, anx, any, anz)
        vertexN(bx, by, bz, r, g, b, flag, bnx, bny, bnz)
        vertexN(cx, cy, cz, r, g, b, flag, cnx, cny, cnz)
    }

    /** Like [triN], with its own colour at each corner so shading blends smoothly. */
    fun triNC(
        ax: Float, ay: Float, az: Float, anx: Float, any: Float, anz: Float, ca: Int,
        bx: Float, by: Float, bz: Float, bnx: Float, bny: Float, bnz: Float, cb: Int,
        cx: Float, cy: Float, cz: Float, cnx: Float, cny: Float, cnz: Float, cc: Int,
        flag: Int,
    ) {
        ensure(3)
        vertexN(ax, ay, az, (ca shr 16) and 255, (ca shr 8) and 255, ca and 255, flag, anx, any, anz)
        vertexN(bx, by, bz, (cb shr 16) and 255, (cb shr 8) and 255, cb and 255, flag, bnx, bny, bnz)
        vertexN(cx, cy, cz, (cc shr 16) and 255, (cc shr 8) and 255, cc and 255, flag, cnx, cny, cnz)
    }

    /** Terrain triangle: per-corner colour and per-corner normal. */
    fun rawTriN(
        ax: Float, ay: Float, az: Float, ca: Int, an: Int,
        bx: Float, by: Float, bz: Float, cb: Int, bn: Int,
        cx: Float, cy: Float, cz: Float, cc: Int, cn: Int,
        flag: Int, nrm: FloatArray,
    ) {
        ensure(3)
        vertexN(ax, ay, az, (ca shr 16) and 255, (ca shr 8) and 255, ca and 255, flag, nrm[an * 3], nrm[an * 3 + 1], nrm[an * 3 + 2])
        vertexN(bx, by, bz, (cb shr 16) and 255, (cb shr 8) and 255, cb and 255, flag, nrm[bn * 3], nrm[bn * 3 + 1], nrm[bn * 3 + 2])
        vertexN(cx, cy, cz, (cc shr 16) and 255, (cc shr 8) and 255, cc and 255, flag, nrm[cn * 3], nrm[cn * 3 + 1], nrm[cn * 3 + 2])
    }

    /**
     * One triangle. Its brightness comes from which way it faces the sun. The facing
     * is worked out to point away from (ox, oy, oz), the middle of the object it
     * belongs to, so the order of the corners doesn't matter.
     */
    fun tri(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        rgb: Int, flag: Int,
        ox: Float, oy: Float, oz: Float,
    ) {
        ensure(3)
        val ux = bx - ax
        val uy = by - ay
        val uz = bz - az
        val vx = cx - ax
        val vy = cy - ay
        val vz = cz - az
        var nx = uy * vz - uz * vy
        var ny = uz * vx - ux * vz
        var nz = ux * vy - uy * vx
        val len = sqrt(nx * nx + ny * ny + nz * nz)
        if (len > 1e-6f) {
            nx /= len
            ny /= len
            nz /= len
        }
        val mx = (ax + bx + cx) / 3f - ox
        val my = (ay + by + cy) / 3f - oy
        val mz = (az + bz + cz) / 3f - oz
        if (nx * mx + ny * my + nz * mz < 0f) {
            nx = -nx
            ny = -ny
            nz = -nz
        }
        nX = nx
        nY = ny
        nZ = nz
        val r = (rgb shr 16) and 255
        val g = (rgb shr 8) and 255
        val b = rgb and 255
        vertex(ax, ay, az, r, g, b, flag)
        vertex(bx, by, bz, r, g, b, flag)
        vertex(cx, cy, cz, r, g, b, flag)
    }

    /** A triangle with its own colour at each corner, facing upward. */
    fun rawTri(
        ax: Float, ay: Float, az: Float, ca: Int,
        bx: Float, by: Float, bz: Float, cb: Int,
        cx: Float, cy: Float, cz: Float, cc: Int,
        flag: Int,
    ) {
        ensure(3)
        // Faces upward (these are ground patches).
        val ux = bx - ax
        val uy = by - ay
        val uz = bz - az
        val vx = cx - ax
        val vy = cy - ay
        val vz = cz - az
        var fx = uy * vz - uz * vy
        var fy = uz * vx - ux * vz
        var fz = ux * vy - uy * vx
        val fl = sqrt(fx * fx + fy * fy + fz * fz)
        if (fl > 1e-6f) {
            fx /= fl
            fy /= fl
            fz /= fl
        } else {
            fx = 0f
            fy = 1f
            fz = 0f
        }
        if (fy < 0f) {
            fx = -fx
            fy = -fy
            fz = -fz
        }
        nX = fx
        nY = fy
        nZ = fz
        vertex(ax, ay, az, (ca shr 16) and 255, (ca shr 8) and 255, ca and 255, flag)
        vertex(bx, by, bz, (cb shr 16) and 255, (cb shr 8) and 255, cb and 255, flag)
        vertex(cx, cy, cz, (cc shr 16) and 255, (cc shr 8) and 255, cc and 255, flag)
    }

    /** One blade of grass. Its tip sways in the wind. */
    fun blade(x: Float, y: Float, z: Float, height: Float, dirX: Float, dirZ: Float, base: Int, tip: Int) {
        ensure(3)
        up()
        val w = 0.06f
        vertex(x - dirZ * w, y, z + dirX * w, (base shr 16) and 255, (base shr 8) and 255, base and 255, FLAG_BLADE)
        vertex(x + dirZ * w, y, z - dirX * w, (base shr 16) and 255, (base shr 8) and 255, base and 255, FLAG_BLADE)
        vertex(
            x + dirX * height * 0.3f, y + height, z + dirZ * height * 0.3f,
            (tip shr 16) and 255, (tip shr 8) and 255, tip and 255, FLAG_BLADE_TIP,
        )
    }

    /** A four-cornered face, as two triangles. */
    fun quad(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        dx: Float, dy: Float, dz: Float,
        rgb: Int, flag: Int,
        ox: Float, oy: Float, oz: Float,
    ) {
        tri(ax, ay, az, bx, by, bz, cx, cy, cz, rgb, flag, ox, oy, oz)
        tri(ax, ay, az, cx, cy, cz, dx, dy, dz, rgb, flag, ox, oy, oz)
    }

    /** A four-cornered face with a normal at each corner. */
    fun smoothQuad(
        ax: Float, ay: Float, az: Float, anx: Float, any: Float, anz: Float,
        bx: Float, by: Float, bz: Float, bnx: Float, bny: Float, bnz: Float,
        cx: Float, cy: Float, cz: Float, cnx: Float, cny: Float, cnz: Float,
        dx: Float, dy: Float, dz: Float, dnx: Float, dny: Float, dnz: Float,
        rgb: Int, flag: Int,
    ) {
        triN(ax, ay, az, anx, any, anz, bx, by, bz, bnx, bny, bnz, cx, cy, cz, cnx, cny, cnz, rgb, flag)
        triN(ax, ay, az, anx, any, anz, cx, cy, cz, cnx, cny, cnz, dx, dy, dz, dnx, dny, dnz, rgb, flag)
    }

    /**
     * An upright column with [sides] faces, [r0] wide at the bottom and [r1] at the
     * top. [cap] adds a lid.
     */
    fun prism(
        x: Float, y0: Float, z: Float, r0: Float, r1: Float, height: Float,
        sides: Int, rgb: Int, rot: Float, cap: Boolean, flag: Int = FLAG_SOLID,
    ) {
        val y1 = y0 + height
        val oy = y0 + height * 0.5f
        for (k in 0 until sides) {
            val a0 = rot + k * TAU / sides
            val a1 = rot + (k + 1) * TAU / sides
            val c0 = cos(a0)
            val s0 = sin(a0)
            val c1 = cos(a1)
            val s1 = sin(a1)
            if (sides >= 6) {
                // Round column: normals point straight out from the axis, tilted by the taper.
                val tilt = (r0 - r1) / height
                smoothQuad(
                    x + c0 * r0, y0, z + s0 * r0, c0, tilt, s0,
                    x + c1 * r0, y0, z + s1 * r0, c1, tilt, s1,
                    x + c1 * r1, y1, z + s1 * r1, c1, tilt, s1,
                    x + c0 * r1, y1, z + s0 * r1, c0, tilt, s0,
                    rgb, flag,
                )
            } else {
                quad(
                    x + c0 * r0, y0, z + s0 * r0,
                    x + c1 * r0, y0, z + s1 * r0,
                    x + c1 * r1, y1, z + s1 * r1,
                    x + c0 * r1, y1, z + s0 * r1,
                    rgb, flag, x, oy, z,
                )
            }
            if (cap) {
                tri(x, y1, z, x + c0 * r1, y1, z + s0 * r1, x + c1 * r1, y1, z + s1 * r1, rgb, flag, x, oy, z)
            }
        }
    }

    /** A cone standing on the ground at height [y0]. */
    fun cone(
        x: Float, y0: Float, z: Float, r: Float, height: Float, sides: Int, rgb: Int, rot: Float,
        flag: Int = FLAG_SOLID,
    ) {
        val top = y0 + height
        val oy = y0 + height * 0.3f
        for (k in 0 until sides) {
            val a0 = rot + k * TAU / sides
            val a1 = rot + (k + 1) * TAU / sides
            if (sides >= 6 && height > 0f) {
                val ny = r / height
                val am = (a0 + a1) * 0.5f
                triN(
                    x, top, z, cos(am), ny, sin(am),
                    x + cos(a0) * r, y0, z + sin(a0) * r, cos(a0), ny, sin(a0),
                    x + cos(a1) * r, y0, z + sin(a1) * r, cos(a1), ny, sin(a1),
                    rgb, flag,
                )
            } else {
                tri(
                    x, top, z,
                    x + cos(a0) * r, y0, z + sin(a0) * r,
                    x + cos(a1) * r, y0, z + sin(a1) * r,
                    rgb, flag, x, oy, z,
                )
            }
        }
    }

    /** A pointed crystal: a cone up and a short cone down, tilted a little. */
    fun spike(
        x: Float, y0: Float, z: Float, r: Float, height: Float, tiltX: Float, tiltZ: Float,
        rgb: Int, flag: Int,
    ) {
        // Soft things (ears, fur tufts) get rounded; crystals stay sharp and faceted.
        if (hd && flag == FLAG_FUR) {
            hdSpike(x, y0, z, r, height, tiltX, tiltZ, rgb, flag)
            return
        }
        val mid = y0 + height * 0.25f
        val tx = x + tiltX * height
        val tz = z + tiltZ * height
        val top = y0 + height
        for (k in 0 until 4) {
            val a0 = k * TAU / 4f + 0.4f
            val a1 = (k + 1) * TAU / 4f + 0.4f
            val x0 = x + tiltX * height * 0.25f + cos(a0) * r
            val z0 = z + tiltZ * height * 0.25f + sin(a0) * r
            val x1 = x + tiltX * height * 0.25f + cos(a1) * r
            val z1 = z + tiltZ * height * 0.25f + sin(a1) * r
            val shade = if (k % 2 == 0) rgb else mixRgb(rgb, 0xFFFFFF, 0.35f)
            tri(tx, top, tz, x0, mid, z0, x1, mid, z1, shade, flag, x, mid, z)
            tri(x, y0, z, x0, mid, z0, x1, mid, z1, shade, flag, x, mid, z)
        }
    }

    /** A lumpy ball, used for tree crowns and rocks. [seed] makes each one different. */
    fun blob(
        x: Float, y: Float, z: Float, rx: Float, ry: Float, rz: Float,
        rgb: Int, seed: Int, lumpiness: Float, flag: Int = FLAG_SOLID,
    ) {
        if (hd) {
            hdBlob(x, y, z, rx, ry, rz, rgb, seed, lumpiness, flag)
            return
        }
        val px = FloatArray(12)
        val py = FloatArray(12)
        val pz = FloatArray(12)
        for (k in 0 until 12) {
            val j = 1f + (hash(k, seed, 77) - 0.5f) * 2f * lumpiness
            px[k] = x + ICO_X[k] * rx * j
            py[k] = y + ICO_Y[k] * ry * j
            pz[k] = z + ICO_Z[k] * rz * j
        }
        for (f in 0 until 20) {
            val a = ICO_F[f * 3]
            val b = ICO_F[f * 3 + 1]
            val c = ICO_F[f * 3 + 2]
            val col = shadeRgb(rgb, 0.93f + 0.14f * hash(f, seed, 78))
            // Smooth normals from the ellipsoid, so crowns and rocks look round.
            triN(
                px[a], py[a], pz[a], ICO_X[a] / rx, ICO_Y[a] / ry, ICO_Z[a] / rz,
                px[b], py[b], pz[b], ICO_X[b] / rx, ICO_Y[b] / ry, ICO_Z[b] / rz,
                px[c], py[c], pz[c], ICO_X[c] / rx, ICO_Y[c] / ry, ICO_Z[c] / rz,
                col, flag,
            )
        }
    }

    /**
     * A boulder: a chipped lump of stone with flat broken faces, sitting half buried.
     * Built from a once-split icosahedron (80 faces), knocked about by random bumps
     * and a few flat cuts, then drawn with hard facet edges so it reads as rock.
     */
    fun rock(
        x: Float, y: Float, z: Float, rx: Float, ry: Float, rz: Float,
        rgb: Int, seed: Int, flag: Int = FLAG_BOULDER,
    ) {
        val cap = 42
        val ux = FloatArray(cap)
        val uy = FloatArray(cap)
        val uz = FloatArray(cap)
        for (k in 0 until 12) {
            ux[k] = ICO_X[k]
            uy[k] = ICO_Y[k]
            uz[k] = ICO_Z[k]
        }
        var count = 12
        val mid = IntArray(12 * 12) { -1 }
        fun midpoint(a: Int, b: Int): Int {
            val key = if (a < b) a * 12 + b else b * 12 + a
            if (mid[key] >= 0) return mid[key]
            var mx = ux[a] + ux[b]
            var my = uy[a] + uy[b]
            var mz = uz[a] + uz[b]
            val l = sqrt(mx * mx + my * my + mz * mz)
            mx /= l
            my /= l
            mz /= l
            ux[count] = mx
            uy[count] = my
            uz[count] = mz
            mid[key] = count
            return count++
        }
        val faces = IntArray(80 * 3)
        var fi = 0
        for (f in 0 until 20) {
            val a = ICO_F[f * 3]
            val b = ICO_F[f * 3 + 1]
            val c = ICO_F[f * 3 + 2]
            val ab = midpoint(a, b)
            val bc = midpoint(b, c)
            val ca = midpoint(c, a)
            for (t in intArrayOf(a, ab, ca, ab, b, bc, ca, bc, c, ab, bc, ca)) faces[fi++] = t
        }
        // A few flat breaks, like faces where the stone split off.
        val cutX = FloatArray(4)
        val cutY = FloatArray(4)
        val cutZ = FloatArray(4)
        val cutD = FloatArray(4)
        for (c in 0 until 4) {
            val ang = hash(c, seed, 95) * TAU
            val up = hash(c, seed, 96) * 1.4f - 0.4f
            val l = sqrt(1f + up * up)
            cutX[c] = cos(ang) / l
            cutY[c] = up / l
            cutZ[c] = sin(ang) / l
            cutD[c] = 0.6f + 0.25f * hash(c, seed, 97)
        }
        val px = FloatArray(count)
        val py = FloatArray(count)
        val pz = FloatArray(count)
        val floorY = y - 0.3f * ry
        for (k in 0 until count) {
            var r = 0.84f + 0.3f * hash(k, seed, 91)
            for (c in 0 until 4) {
                val d = ux[k] * cutX[c] + uy[k] * cutY[c] + uz[k] * cutZ[c]
                if (d * r > cutD[c]) r = cutD[c] / d
            }
            px[k] = x + ux[k] * r * rx
            py[k] = max(floorY, y + uy[k] * r * ry)
            pz[k] = z + uz[k] * r * rz
        }
        for (f in 0 until 80) {
            val a = faces[f * 3]
            var b = faces[f * 3 + 1]
            var c = faces[f * 3 + 2]
            var e1x = px[b] - px[a]
            var e1y = py[b] - py[a]
            var e1z = pz[b] - pz[a]
            var e2x = px[c] - px[a]
            var e2y = py[c] - py[a]
            var e2z = pz[c] - pz[a]
            var nx = e1y * e2z - e1z * e2y
            var ny = e1z * e2x - e1x * e2z
            var nz = e1x * e2y - e1y * e2x
            val l = sqrt(nx * nx + ny * ny + nz * nz)
            if (l < 1e-6f) continue
            nx /= l
            ny /= l
            nz /= l
            // Face outwards.
            val cx = (px[a] + px[b] + px[c]) / 3f - x
            val cy = (py[a] + py[b] + py[c]) / 3f - y
            val cz = (pz[a] + pz[b] + pz[c]) / 3f - z
            if (nx * cx + ny * cy + nz * cz < 0f) {
                nx = -nx
                ny = -ny
                nz = -nz
                val t = b
                b = c
                c = t
            }
            val col = shadeRgb(rgb, 0.86f + 0.22f * hash(f, seed, 93))
            triN(
                px[a], py[a], pz[a], nx, ny, nz,
                px[b], py[b], pz[b], nx, ny, nz,
                px[c], py[c], pz[c], nx, ny, nz,
                col, flag,
            )
        }
    }

    /** A box turned [angle] radians around the vertical. */
    fun box(
        x: Float, y: Float, z: Float, halfAlong: Float, halfUp: Float, halfAcross: Float,
        angle: Float, rgb: Int, flag: Int = FLAG_SOLID,
    ) {
        // Tiny boxes on creatures are eyes: make them round.
        if (hd && angle == 0f && halfAlong < 0.07f && halfUp < 0.07f && halfAcross < 0.07f) {
            hdBlob(x, y, z, halfAlong * 1.15f, halfUp * 1.15f, halfAcross * 1.15f, rgb, 5, 0f, flag)
            return
        }
        val ax = cos(angle) * halfAlong
        val az = sin(angle) * halfAlong
        val cx = -sin(angle) * halfAcross
        val cz = cos(angle) * halfAcross
        val y0 = y - halfUp
        val y1 = y + halfUp
        // Corners: along -/+, across -/+.
        val x00 = x - ax - cx
        val z00 = z - az - cz
        val x10 = x + ax - cx
        val z10 = z + az - cz
        val x11 = x + ax + cx
        val z11 = z + az + cz
        val x01 = x - ax + cx
        val z01 = z - az + cz
        quad(x00, y1, z00, x10, y1, z10, x11, y1, z11, x01, y1, z01, rgb, flag, x, y, z)
        quad(x00, y0, z00, x10, y0, z10, x11, y0, z11, x01, y0, z01, rgb, flag, x, y, z)
        quad(x00, y0, z00, x10, y0, z10, x10, y1, z10, x00, y1, z00, rgb, flag, x, y, z)
        quad(x10, y0, z10, x11, y0, z11, x11, y1, z11, x10, y1, z10, rgb, flag, x, y, z)
        quad(x11, y0, z11, x01, y0, z01, x01, y1, z01, x11, y1, z11, rgb, flag, x, y, z)
        quad(x01, y0, z01, x00, y0, z00, x00, y1, z00, x01, y1, z01, rgb, flag, x, y, z)
    }

    /** A four-sided pole between two points: branches, leaning trunks, logs. */
    fun limb(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        r0: Float, r1: Float, rgb: Int, flag: Int,
    ) {
        if (hd) {
            hdLimb(x0, y0, z0, x1, y1, z1, r0, r1, rgb, flag)
            return
        }
        var dx = x1 - x0
        var dy = y1 - y0
        var dz = z1 - z0
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len < 1e-4f) return
        dx /= len
        dy /= len
        dz /= len
        // Two directions at right angles to the pole.
        var ux: Float
        var uy: Float
        var uz: Float
        if (abs(dy) < 0.9f) {
            ux = dz
            uy = 0f
            uz = -dx
        } else {
            ux = 0f
            uy = -dz
            uz = dy
        }
        val ul = sqrt(ux * ux + uy * uy + uz * uz)
        ux /= ul
        uy /= ul
        uz /= ul
        val vx = dy * uz - dz * uy
        val vy = dz * ux - dx * uz
        val vz = dx * uy - dy * ux
        for (k in 0 until 4) {
            val a0 = k * TAU / 4f
            val a1 = (k + 1) * TAU / 4f
            val c0 = cos(a0)
            val s0 = sin(a0)
            val c1 = cos(a1)
            val s1 = sin(a1)
            // Round-looking pole: each corner's normal points straight out from the axis.
            val n0x = ux * c0 + vx * s0
            val n0y = uy * c0 + vy * s0
            val n0z = uz * c0 + vz * s0
            val n1x = ux * c1 + vx * s1
            val n1y = uy * c1 + vy * s1
            val n1z = uz * c1 + vz * s1
            smoothQuad(
                x0 + n0x * r0, y0 + n0y * r0, z0 + n0z * r0, n0x, n0y, n0z,
                x0 + n1x * r0, y0 + n1y * r0, z0 + n1z * r0, n1x, n1y, n1z,
                x1 + n1x * r1, y1 + n1y * r1, z1 + n1z * r1, n1x, n1y, n1z,
                x1 + n0x * r1, y1 + n0y * r1, z1 + n0z * r1, n0x, n0y, n0z,
                rgb, flag,
            )
        }
    }

    /** One tongue of fire. Its tip dances. */
    fun flame(x: Float, y: Float, z: Float, width: Float, height: Float, angle: Float, base: Int, tip: Int) {
        ensure(6)
        up()
        val ax = cos(angle) * width
        val az = sin(angle) * width
        val tipFlag = when {
            height < 0.2f -> FLAG_CANDLE_TIP
            height < 0.8f -> FLAG_HEARTH_TIP
            else -> FLAG_FIRE_TIP
        }
        for (side in 0 until 2) {
            val sx = if (side == 0) ax else -az
            val sz = if (side == 0) az else ax
            vertex(x - sx, y, z - sz, (base shr 16) and 255, (base shr 8) and 255, base and 255, FLAG_FIRE)
            vertex(x + sx, y, z + sz, (base shr 16) and 255, (base shr 8) and 255, base and 255, FLAG_FIRE)
            vertex(x, y + height, z, (tip shr 16) and 255, (tip shr 8) and 255, tip and 255, tipFlag)
        }
    }

    /** A fern frond: a narrow leaf from the root out to a swaying tip. */
    fun frond(x: Float, y: Float, z: Float, dirX: Float, dirZ: Float, len: Float, lift: Float, base: Int, tip: Int) {
        ensure(6)
        up()
        val w = len * 0.16f
        val mx = x + dirX * len * 0.5f
        val my = y + lift
        val mz = z + dirZ * len * 0.5f
        val tx = x + dirX * len
        val ty = y + lift * 0.6f
        val tz = z + dirZ * len
        val br = (base shr 16) and 255
        val bg = (base shr 8) and 255
        val bb = base and 255
        val tr = (tip shr 16) and 255
        val tg = (tip shr 8) and 255
        val tb = tip and 255
        vertex(x, y, z, br, bg, bb, FLAG_BLADE)
        vertex(mx - dirZ * w, my, mz + dirX * w, br, bg, bb, FLAG_BLADE)
        vertex(tx, ty, tz, tr, tg, tb, FLAG_BLADE_TIP)
        vertex(x, y, z, br, bg, bb, FLAG_BLADE)
        vertex(tx, ty, tz, tr, tg, tb, FLAG_BLADE_TIP)
        vertex(mx + dirZ * w, my, mz - dirX * w, br, bg, bb, FLAG_BLADE)
    }

    /**
     * A smooth, finely divided ellipsoid. Bigger ones get more triangles. Lumps are a
     * gentle wave over the surface (never cracks), the underside is a shade lighter
     * like real animals, and there is a faint mottling so it doesn't look like plastic.
     */
    fun hdBlob(
        x: Float, y: Float, z: Float, rx: Float, ry: Float, rz: Float,
        rgb: Int, seed: Int, lumpiness: Float, flag: Int, maxLevel: Int = 2,
    ) {
        val big = max(rx, max(ry, rz))
        val sph = if (big >= 0.2f && maxLevel >= 2) HD_SPHERE_2 else if (big >= 0.025f && maxLevel >= 1) HD_SPHERE_1 else HD_SPHERE_0
        val n = sph.x.size
        val px = FloatArray(n)
        val py = FloatArray(n)
        val pz = FloatArray(n)
        val col = IntArray(n)
        val sa = seed * 0.37f
        val sb = seed * 0.71f
        val sc = seed * 1.13f
        for (k in 0 until n) {
            val ux = sph.x[k]
            val uy = sph.y[k]
            val uz = sph.z[k]
            val wave = sin(ux * 3.1f + sa) * sin(uy * 2.7f + sb) * sin(uz * 2.9f + sc)
            val j = 1f + lumpiness * wave * 1.6f
            px[k] = x + ux * rx * j
            py[k] = y + uy * ry * j
            pz[k] = z + uz * rz * j
            val mottle = sin(ux * 9.0f + sb) * sin(uz * 8.0f + sa) * sin(uy * 7.0f + sc)
            col[k] = shadeRgb(rgb, 1f - uy * 0.07f + mottle * 0.035f)
        }
        val f = sph.f
        var t = 0
        while (t < f.size) {
            val a = f[t]
            val b = f[t + 1]
            val c = f[t + 2]
            triNC(
                px[a], py[a], pz[a], sph.x[a] / rx, sph.y[a] / ry, sph.z[a] / rz, col[a],
                px[b], py[b], pz[b], sph.x[b] / rx, sph.y[b] / ry, sph.z[b] / rz, col[b],
                px[c], py[c], pz[c], sph.x[c] / rx, sph.y[c] / ry, sph.z[c] / rz, col[c],
                flag,
            )
            t += 3
        }
    }

    /** A round, ten-sided tube between two points, with rounded ends so joints look whole. */
    fun hdLimb(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        r0: Float, r1: Float, rgb: Int, flag: Int,
    ) {
        var dx = x1 - x0
        var dy = y1 - y0
        var dz = z1 - z0
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len < 1e-4f) return
        dx /= len
        dy /= len
        dz /= len
        var ux: Float
        var uy: Float
        var uz: Float
        if (abs(dy) < 0.9f) {
            ux = dz
            uy = 0f
            uz = -dx
        } else {
            ux = 0f
            uy = -dz
            uz = dy
        }
        val ul = sqrt(ux * ux + uy * uy + uz * uz)
        ux /= ul
        uy /= ul
        uz /= ul
        val vx = dy * uz - dz * uy
        val vy = dz * ux - dx * uz
        val vz = dx * uy - dy * ux
        // A tapering tube's surface leans back towards the thin end.
        val lean = (r0 - r1) / len
        val sides = 10
        val c0col = shadeRgb(rgb, 1.02f)
        val c1col = shadeRgb(rgb, 0.97f)
        for (k in 0 until sides) {
            val a0 = k * TAU / sides
            val a1 = (k + 1) * TAU / sides
            val c0 = cos(a0)
            val s0 = sin(a0)
            val c1 = cos(a1)
            val s1 = sin(a1)
            val n0x = ux * c0 + vx * s0
            val n0y = uy * c0 + vy * s0
            val n0z = uz * c0 + vz * s0
            val n1x = ux * c1 + vx * s1
            val n1y = uy * c1 + vy * s1
            val n1z = uz * c1 + vz * s1
            val ax = x0 + n0x * r0
            val ay = y0 + n0y * r0
            val az = z0 + n0z * r0
            val bx = x0 + n1x * r0
            val by = y0 + n1y * r0
            val bz = z0 + n1z * r0
            val cx = x1 + n1x * r1
            val cy = y1 + n1y * r1
            val cz = z1 + n1z * r1
            val ex = x1 + n0x * r1
            val ey = y1 + n0y * r1
            val ez = z1 + n0z * r1
            val m0x = n0x + dx * lean
            val m0y = n0y + dy * lean
            val m0z = n0z + dz * lean
            val m1x = n1x + dx * lean
            val m1y = n1y + dy * lean
            val m1z = n1z + dz * lean
            triNC(ax, ay, az, m0x, m0y, m0z, c0col, bx, by, bz, m1x, m1y, m1z, c0col, cx, cy, cz, m1x, m1y, m1z, c1col, flag)
            triNC(ax, ay, az, m0x, m0y, m0z, c0col, cx, cy, cz, m1x, m1y, m1z, c1col, ex, ey, ez, m0x, m0y, m0z, c1col, flag)
        }
        if (r0 > 0.012f) hdBlob(x0, y0, z0, r0, r0, r0, c0col, 3, 0f, flag, if (r0 >= 0.06f) 1 else 0)
        if (r1 > 0.012f) hdBlob(x1, y1, z1, r1, r1, r1, c1col, 4, 0f, flag, if (r1 >= 0.06f) 1 else 0)
    }

    /** A soft, rounded point: ears and tufts. Eight sides with smooth shading. */
    fun hdSpike(
        x: Float, y0: Float, z: Float, r: Float, height: Float, tiltX: Float, tiltZ: Float,
        rgb: Int, flag: Int,
    ) {
        val mid = y0 + height * 0.25f
        val tx = x + tiltX * height
        val tz = z + tiltZ * height
        val top = y0 + height
        val bx = x + tiltX * height * 0.25f
        val bz = z + tiltZ * height * 0.25f
        val tipCol = shadeRgb(rgb, 0.9f)
        val baseCol = shadeRgb(rgb, 1.04f)
        val sides = 8
        for (k in 0 until sides) {
            val a0 = k * TAU / sides
            val a1 = (k + 1) * TAU / sides
            val am = (a0 + a1) * 0.5f
            val x0 = bx + cos(a0) * r
            val z0 = bz + sin(a0) * r
            val x1 = bx + cos(a1) * r
            val z1 = bz + sin(a1) * r
            triNC(
                tx, top, tz, cos(am), 0.4f, sin(am), tipCol,
                x0, mid, z0, cos(a0), 0.3f, sin(a0), rgb,
                x1, mid, z1, cos(a1), 0.3f, sin(a1), rgb,
                flag,
            )
            triNC(
                x, y0, z, cos(am), -0.8f, sin(am), baseCol,
                x0, mid, z0, cos(a0), 0.3f, sin(a0), rgb,
                x1, mid, z1, cos(a1), 0.3f, sin(a1), rgb,
                flag,
            )
        }
    }

    /** Finishes the mesh; the buffer is ready to hand to the graphics card. */
    fun finish(): ByteBuffer {
        buf.flip()
        return buf
    }
}

// A 20-sided ball.
private const val ICO_T = 1.618034f
private const val ICO_L = 1.9021131f
private val ICO_X = floatArrayOf(-1f, 1f, -1f, 1f, 0f, 0f, 0f, 0f, ICO_T, ICO_T, -ICO_T, -ICO_T).map { it / ICO_L }.toFloatArray()
private val ICO_Y = floatArrayOf(ICO_T, ICO_T, -ICO_T, -ICO_T, -1f, 1f, -1f, 1f, 0f, 0f, 0f, 0f).map { it / ICO_L }.toFloatArray()
private val ICO_Z = floatArrayOf(0f, 0f, 0f, 0f, ICO_T, ICO_T, -ICO_T, -ICO_T, -1f, 1f, -1f, 1f).map { it / ICO_L }.toFloatArray()
private val ICO_F = intArrayOf(
    0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11,
    1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8,
    3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9,
    4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1,
)

/** A unit sphere made by splitting an icosahedron's faces: corners and triangles. */
private class HdSphere(val x: FloatArray, val y: FloatArray, val z: FloatArray, val f: IntArray)

private fun makeHdSphere(levels: Int): HdSphere {
    val xs = ArrayList<Float>()
    val ys = ArrayList<Float>()
    val zs = ArrayList<Float>()
    for (k in 0 until 12) {
        xs.add(ICO_X[k])
        ys.add(ICO_Y[k])
        zs.add(ICO_Z[k])
    }
    var faces = ICO_F.copyOf()
    for (level in 0 until levels) {
        val cache = HashMap<Long, Int>()
        val next = IntArray(faces.size * 4)
        var o = 0
        var i = 0
        while (i < faces.size) {
            val corner = IntArray(3)
            corner[0] = faces[i]
            corner[1] = faces[i + 1]
            corner[2] = faces[i + 2]
            val mids = IntArray(3)
            for (e in 0 until 3) {
                val a = corner[e]
                val b = corner[(e + 1) % 3]
                val key = if (a < b) a.toLong() * 100000L + b else b.toLong() * 100000L + a
                val known = cache[key]
                if (known != null) {
                    mids[e] = known
                } else {
                    var mx = (xs[a] + xs[b]) * 0.5f
                    var my = (ys[a] + ys[b]) * 0.5f
                    var mz = (zs[a] + zs[b]) * 0.5f
                    val l = sqrt(mx * mx + my * my + mz * mz)
                    mx /= l
                    my /= l
                    mz /= l
                    xs.add(mx)
                    ys.add(my)
                    zs.add(mz)
                    val idx = xs.size - 1
                    cache[key] = idx
                    mids[e] = idx
                }
            }
            // mids[0] = a-b, mids[1] = b-c, mids[2] = c-a
            next[o++] = corner[0]; next[o++] = mids[0]; next[o++] = mids[2]
            next[o++] = corner[1]; next[o++] = mids[1]; next[o++] = mids[0]
            next[o++] = corner[2]; next[o++] = mids[2]; next[o++] = mids[1]
            next[o++] = mids[0]; next[o++] = mids[1]; next[o++] = mids[2]
            i += 3
        }
        faces = next
    }
    return HdSphere(xs.toFloatArray(), ys.toFloatArray(), zs.toFloatArray(), faces)
}

private val HD_SPHERE_0 = makeHdSphere(0)
private val HD_SPHERE_1 = makeHdSphere(1)
private val HD_SPHERE_2 = makeHdSphere(2)
