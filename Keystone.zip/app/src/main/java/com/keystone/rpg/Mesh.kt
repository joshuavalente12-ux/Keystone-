package com.keystone.rpg

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Bytes per vertex: x, y, z as floats, then r, g, b, flag as bytes. */
const val STRIDE = 16

/** The 4th colour byte tells the shader what kind of surface this is. */
const val FLAG_SOLID = 255
const val FLAG_GLOW = 150
const val FLAG_WATER = 40

// Sunlight comes from high up in the top-left (towards the starting corner).
private const val SUN_X = -0.458f
private const val SUN_Y = 0.815f
private const val SUN_Z = -0.356f

private const val TAU = 6.2831855f

/** Collects coloured, sun-lit triangles into a buffer ready for the graphics card. */
class MeshBuilder(initialVertices: Int = 8192) {
    private var buf: ByteBuffer =
        ByteBuffer.allocateDirect(initialVertices * STRIDE).order(ByteOrder.nativeOrder())
    var vertexCount = 0
        private set

    private fun ensure(vertices: Int) {
        if (buf.remaining() >= vertices * STRIDE) return
        var cap = buf.capacity() * 2
        while (cap - buf.position() < vertices * STRIDE) cap *= 2
        val bigger = ByteBuffer.allocateDirect(cap).order(ByteOrder.nativeOrder())
        buf.flip()
        bigger.put(buf)
        buf = bigger
    }

    private fun vertex(x: Float, y: Float, z: Float, r: Int, g: Int, b: Int, flag: Int) {
        buf.putFloat(x)
        buf.putFloat(y)
        buf.putFloat(z)
        buf.put(r.toByte())
        buf.put(g.toByte())
        buf.put(b.toByte())
        buf.put(flag.toByte())
        vertexCount++
    }

    /**
     * One triangle. Its brightness comes from which way it faces the sun. The facing
     * is worked out to point away from (ox, oy, oz), the middle of the object it
     * belongs to, so the order of the corners doesn't matter.
     */
    fun tri(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        rgb: Int, flag: Int,
        ox: Float, oy: Float, oz: Float,
    ) {
        ensure(3)
        val ux = bx - ax
        val uy = by - ay
        val uz = bz - az
        val vx = cx - ax
        val vy = cy - ay
        val vz = cz - az
        var nx = uy * vz - uz * vy
        var ny = uz * vx - ux * vz
        var nz = ux * vy - uy * vx
        val len = sqrt(nx * nx + ny * ny + nz * nz)
        if (len > 1e-6f) {
            nx /= len
            ny /= len
            nz /= len
        }
        val mx = (ax + bx + cx) / 3f - ox
        val my = (ay + by + cy) / 3f - oy
        val mz = (az + bz + cz) / 3f - oz
        if (nx * mx + ny * my + nz * mz < 0f) {
            nx = -nx
            ny = -ny
            nz = -nz
        }
        val shade = if (flag == FLAG_SOLID) {
            0.52f + 0.58f * max(0f, nx * SUN_X + ny * SUN_Y + nz * SUN_Z) + 0.06f * ny
        } else {
            1f
        }
        val r = (((rgb shr 16) and 255) * shade).toInt().coerceIn(0, 255)
        val g = (((rgb shr 8) and 255) * shade).toInt().coerceIn(0, 255)
        val b = ((rgb and 255) * shade).toInt().coerceIn(0, 255)
        vertex(ax, ay, az, r, g, b, flag)
        vertex(bx, by, bz, r, g, b, flag)
        vertex(cx, cy, cz, r, g, b, flag)
    }

    /** A four-cornered face, as two triangles. */
    fun quad(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        dx: Float, dy: Float, dz: Float,
        rgb: Int, flag: Int,
        ox: Float, oy: Float, oz: Float,
    ) {
        tri(ax, ay, az, bx, by, bz, cx, cy, cz, rgb, flag, ox, oy, oz)
        tri(ax, ay, az, cx, cy, cz, dx, dy, dz, rgb, flag, ox, oy, oz)
    }

    /**
     * An upright column with [sides] faces, [r0] wide at the bottom and [r1] at the
     * top. [cap] adds a lid.
     */
    fun prism(
        x: Float, y0: Float, z: Float, r0: Float, r1: Float, height: Float,
        sides: Int, rgb: Int, rot: Float, cap: Boolean, flag: Int = FLAG_SOLID,
    ) {
        val y1 = y0 + height
        val oy = y0 + height * 0.5f
        for (k in 0 until sides) {
            val a0 = rot + k * TAU / sides
            val a1 = rot + (k + 1) * TAU / sides
            val c0 = cos(a0)
            val s0 = sin(a0)
            val c1 = cos(a1)
            val s1 = sin(a1)
            quad(
                x + c0 * r0, y0, z + s0 * r0,
                x + c1 * r0, y0, z + s1 * r0,
                x + c1 * r1, y1, z + s1 * r1,
                x + c0 * r1, y1, z + s0 * r1,
                rgb, flag, x, oy, z,
            )
            if (cap) {
                tri(x, y1, z, x + c0 * r1, y1, z + s0 * r1, x + c1 * r1, y1, z + s1 * r1, rgb, flag, x, oy, z)
            }
        }
    }

    /** A cone standing on the ground at height [y0]. */
    fun cone(
        x: Float, y0: Float, z: Float, r: Float, height: Float, sides: Int, rgb: Int, rot: Float,
        flag: Int = FLAG_SOLID,
    ) {
        val top = y0 + height
        val oy = y0 + height * 0.3f
        for (k in 0 until sides) {
            val a0 = rot + k * TAU / sides
            val a1 = rot + (k + 1) * TAU / sides
            tri(
                x, top, z,
                x + cos(a0) * r, y0, z + sin(a0) * r,
                x + cos(a1) * r, y0, z + sin(a1) * r,
                rgb, flag, x, oy, z,
            )
        }
    }

    /** A pointed crystal: a cone up and a short cone down, tilted a little. */
    fun spike(
        x: Float, y0: Float, z: Float, r: Float, height: Float, tiltX: Float, tiltZ: Float,
        rgb: Int, flag: Int,
    ) {
        val mid = y0 + height * 0.25f
        val tx = x + tiltX * height
        val tz = z + tiltZ * height
        val top = y0 + height
        for (k in 0 until 4) {
            val a0 = k * TAU / 4f + 0.4f
            val a1 = (k + 1) * TAU / 4f + 0.4f
            val x0 = x + tiltX * height * 0.25f + cos(a0) * r
            val z0 = z + tiltZ * height * 0.25f + sin(a0) * r
            val x1 = x + tiltX * height * 0.25f + cos(a1) * r
            val z1 = z + tiltZ * height * 0.25f + sin(a1) * r
            val shade = if (k % 2 == 0) rgb else mixRgb(rgb, 0xFFFFFF, 0.35f)
            tri(tx, top, tz, x0, mid, z0, x1, mid, z1, shade, flag, x, mid, z)
            tri(x, y0, z, x0, mid, z0, x1, mid, z1, shade, flag, x, mid, z)
        }
    }

    /** A lumpy ball, used for tree crowns and rocks. [seed] makes each one different. */
    fun blob(
        x: Float, y: Float, z: Float, rx: Float, ry: Float, rz: Float,
        rgb: Int, seed: Int, lumpiness: Float,
    ) {
        val px = FloatArray(12)
        val py = FloatArray(12)
        val pz = FloatArray(12)
        for (k in 0 until 12) {
            val j = 1f + (hash(k, seed, 77) - 0.5f) * 2f * lumpiness
            px[k] = x + ICO_X[k] * rx * j
            py[k] = y + ICO_Y[k] * ry * j
            pz[k] = z + ICO_Z[k] * rz * j
        }
        for (f in 0 until 20) {
            val a = ICO_F[f * 3]
            val b = ICO_F[f * 3 + 1]
            val c = ICO_F[f * 3 + 2]
            val col = shadeRgb(rgb, 0.93f + 0.14f * hash(f, seed, 78))
            tri(px[a], py[a], pz[a], px[b], py[b], pz[b], px[c], py[c], pz[c], col, FLAG_SOLID, x, y, z)
        }
    }

    /** A box turned [angle] radians around the vertical. */
    fun box(
        x: Float, y: Float, z: Float, halfAlong: Float, halfUp: Float, halfAcross: Float,
        angle: Float, rgb: Int,
    ) {
        val ax = cos(angle) * halfAlong
        val az = sin(angle) * halfAlong
        val cx = -sin(angle) * halfAcross
        val cz = cos(angle) * halfAcross
        val y0 = y - halfUp
        val y1 = y + halfUp
        // Corners: along -/+, across -/+.
        val x00 = x - ax - cx
        val z00 = z - az - cz
        val x10 = x + ax - cx
        val z10 = z + az - cz
        val x11 = x + ax + cx
        val z11 = z + az + cz
        val x01 = x - ax + cx
        val z01 = z - az + cz
        quad(x00, y1, z00, x10, y1, z10, x11, y1, z11, x01, y1, z01, rgb, FLAG_SOLID, x, y, z)
        quad(x00, y0, z00, x10, y0, z10, x11, y0, z11, x01, y0, z01, rgb, FLAG_SOLID, x, y, z)
        quad(x00, y0, z00, x10, y0, z10, x10, y1, z10, x00, y1, z00, rgb, FLAG_SOLID, x, y, z)
        quad(x10, y0, z10, x11, y0, z11, x11, y1, z11, x10, y1, z10, rgb, FLAG_SOLID, x, y, z)
        quad(x11, y0, z11, x01, y0, z01, x01, y1, z01, x11, y1, z11, rgb, FLAG_SOLID, x, y, z)
        quad(x01, y0, z01, x00, y0, z00, x00, y1, z00, x01, y1, z01, rgb, FLAG_SOLID, x, y, z)
    }

    /** Finishes the mesh; the buffer is ready to hand to the graphics card. */
    fun finish(): ByteBuffer {
        buf.flip()
        return buf
    }
}

// A 20-sided ball.
private const val ICO_T = 1.618034f
private const val ICO_L = 1.9021131f
private val ICO_X = floatArrayOf(-1f, 1f, -1f, 1f, 0f, 0f, 0f, 0f, ICO_T, ICO_T, -ICO_T, -ICO_T).map { it / ICO_L }.toFloatArray()
private val ICO_Y = floatArrayOf(ICO_T, ICO_T, -ICO_T, -ICO_T, -1f, 1f, -1f, 1f, 0f, 0f, 0f, 0f).map { it / ICO_L }.toFloatArray()
private val ICO_Z = floatArrayOf(0f, 0f, 0f, 0f, ICO_T, ICO_T, -ICO_T, -ICO_T, -1f, 1f, -1f, 1f).map { it / ICO_L }.toFloatArray()
private val ICO_F = intArrayOf(
    0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11,
    1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8,
    3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9,
    4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1,
)
