package com.keystone.rpg

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** What a person does. */
object NpcRole {
    const val VILLAGER = 0
    const val TRADER = 1
    const val QUEST = 2
    const val GUARD = 3
    const val LORD = 4
    val TITLES = arrayOf("Villager", "Trader", "Elder", "Guard", "Lord of the Castle")
}

/** How each piece of a person moves (the same joints as the hero). */
object NpcPart {
    const val PELVIS = 0
    const val TORSO = 1
    const val HEAD = 2
    const val ARM_L = 3
    const val ARM_R = 4
    const val FORE_L = 5
    const val FORE_R = 6
    const val THIGH_L = 7
    const val THIGH_R = 8
    const val SHIN_L = 9
    const val SHIN_R = 10
    const val HELD = 11
}

/** What someone looks like: skin, hair, clothes and anything they carry. */
private class Look(
    val skin: Int, val hair: Int, val top: Int, val bottom: Int, val boots: Int,
    /** 0 short, 1 long, 2 bun, 3 bald. */
    val hairStyle: Int,
    val beard: Boolean,
    /** 0 none, 1 straw hat, 2 leather hat, 3 helmet, 4 crown, 5 fur hood, 6 head wrap, 7 head scarf. */
    val hat: Int,
    val hatColor: Int,
    /** 0 trousers, 1 knee-length skirt or tunic, 2 robe to the ankles. */
    val robe: Int,
    /** 0 none, 1 apron, 2 vest, 3 armour with a tabard, 4 cape, 5 sash, 6 fur trim. */
    val extra: Int,
    val extraColor: Int,
    /** 0 nothing, 1 staff, 2 spear. */
    val held: Int,
    val female: Boolean,
)

private val LOOKS = arrayOf(
    // 0 farmer
    Look(0xC8977A, 0x5A3A22, 0x8A9A5A, 0x6A5238, 0x3A2616, 0, false, 1, 0xD8B86A, 0, 0, 0, 0, false),
    // 1 village woman
    Look(0xE0B090, 0x8A4A22, 0xB85A4A, 0x7A3A34, 0x3A2616, 1, false, 0, 0, 1, 1, 0xE8E0CC, 0, true),
    // 2 village man
    Look(0xA87458, 0x2A1E14, 0x4A6A9A, 0x4A3A2A, 0x2A1E14, 0, true, 0, 0, 0, 0, 0, 0, false),
    // 3 village woman in a head scarf
    Look(0x8A5A3E, 0x1E1410, 0xD8C090, 0x5A6A3A, 0x3A2616, 2, false, 7, 0xC83A2A, 1, 0, 0, 0, true),
    // 4 old man
    Look(0xD8A888, 0xCCCCC8, 0x7A6A4A, 0x5A4A3A, 0x3A2616, 0, true, 0, 0, 1, 5, 0x5A3A22, 0, false),
    // 5 trader
    Look(0xC8977A, 0x3A2A1A, 0xE0D0B0, 0x4A3A2A, 0x2A1E14, 0, true, 2, 0x4A3020, 0, 2, 0x6A2A6A, 0, false),
    // 6 elder with a staff
    Look(0xD0A080, 0xE8E8E4, 0x2A4A7A, 0x2A4A7A, 0x3A2616, 1, true, 0, 0, 2, 5, 0xC8A040, 1, false),
    // 7 guard with a spear
    Look(0xB88868, 0x3A2A1A, 0x8A9098, 0x5A5A60, 0x2A2A2E, 0, false, 3, 0x9AA0A8, 0, 3, 0x9A2A24, 2, false),
    // 8 lord in a crown and cape
    Look(0xD8A888, 0x4A2A1A, 0x7A1A2A, 0x7A1A2A, 0x2A1E14, 0, true, 4, 0xFFC940, 2, 4, 0x5A0A14, 0, false),
    // 9 desert villager
    Look(0x9A6A4A, 0x1E1410, 0xD8C8A0, 0xC8B890, 0x7A5A3A, 0, true, 6, 0xE8DCC0, 1, 5, 0xB83A2A, 0, false),
    // 10 snow villager in a fur-trimmed coat
    Look(0xE0B8A0, 0x6A4A2A, 0x6A5A4A, 0x4A3A2A, 0x2A1E14, 1, false, 5, 0xF0EEE8, 1, 6, 0xF0EEE8, 0, true),
)

private const val LOOK_ELDER = 6
private const val LOOK_TRADER = 5
private const val LOOK_GUARD = 7
private const val LOOK_LORD = 8
private const val LOOK_OLD = 4

private val MALE = arrayOf(
    "Bram", "Aldric", "Tomas", "Gareth", "Hollis", "Edric", "Rowan", "Silas", "Corwin", "Dunstan",
    "Fenwick", "Osric", "Jory", "Merric", "Tobin", "Alaric", "Cedric", "Wendel", "Harlan", "Piers",
)
private val FEMALE = arrayOf(
    "Elsie", "Mara", "Wren", "Isolde", "Tamsin", "Brynn", "Ada", "Liora", "Nell", "Maren", "Sabine", "Hester",
)

/** A person living in the world. */
class Npc(
    val id: Int, val name: String, val role: Int, val look: Int, val place: Int, val zone: Zone,
    val homeX: Float, val homeZ: Float, val homeYaw: Float,
    /** How far from home they stroll (0 = they stay at their post). */
    val wander: Float,
) {
    var x = homeX
    var z = homeZ
    var y = 0f
    var yaw = homeYaw
    var goX = homeX
    var goZ = homeZ
    var walking = false
    var timer = 1f
    var speed = 0f
    var phase = 0f
    /** Turned to face you, because you're close. */
    var facing = false
    /** Near enough to you to be moved and drawn. */
    var awake = false
    /** A trader's goods, made the first time you look. */
    var stock: ArrayList<Item>? = null
    /** Marker over their head: 0 none, 1 has work for you, 2 has something to hand in. */
    @Volatile var mark = 0
    /** Sitting down (the lord on his throne): they stay put at [seatY] instead of standing on the floor. */
    var sitting = false
    var seatY = 0f
    /** Called over by something they've seen (the opening cinematic): walk to [goX], [goZ], then stand and look at you. */
    @Volatile var gather = false
    /** Who they are in the main story (see [StoryRole]); 0 for everyone else. */
    @Volatile var storyRole = 0

    /** "Elder Rowan", "Bram", "Lord Aldric"... */
    val title: String get() = if (storyRole == StoryRole.WIZARD) "The Wizard" else if (storyRole == StoryRole.ELDER) "The Elder" else if (storyRole == StoryRole.VILLAGER) "The Villager" else if (storyRole == StoryRole.RECLUSE) "The Recluse" else if (storyRole == StoryRole.ROGER) "The Elder" else when (role) {
        NpcRole.QUEST -> "Elder $name"
        NpcRole.LORD -> "Lord $name"
        NpcRole.GUARD -> "Guard $name"
        else -> name
    }
    /** What they are, under their name. */
    val subtitle: String get() = if (storyRole == StoryRole.WIZARD) "Wizard of ${PLACES[place].name}" else when (role) {
        NpcRole.TRADER -> "Trader of ${PLACES[place].name}"
        NpcRole.QUEST -> "Elder of ${PLACES[place].name}"
        NpcRole.LORD -> "Lord of ${PLACES[place].name}"
        NpcRole.GUARD -> "Guard of ${PLACES[place].name}"
        else -> "Lives in ${PLACES[place].name}"
    }
}

/**
 * Everyone living in the world: villagers strolling round each town, a trader at every
 * market stall, elders by the notice boards who have work for you, guards on the castle
 * gates and a lord in every keep. Only people near you move or are drawn.
 */
class People(private val world: World) {
    val npcs = ArrayList<Npc>()
    /** One set of body pieces for each look. */
    val models: Array<List<CreaturePart>> = Array(LOOKS.size) { buildPerson(LOOKS[it]) }
    /** Floating markers over people's heads: gold for new work, blue-green for work to hand in. */
    val markNew: CreaturePart = marker(0xFFC940)
    val markDone: CreaturePart = marker(0x5AE0C0)
    /** Every mesh, for uploading to the graphics card. */
    val meshes: List<CreaturePart> get() = models.flatMap { it } + listOf(markNew, markDone)

    private val tmp = Placed()
    private val probe = Probe()
    private val rnd = java.util.Random(4242)

    init {
        place()
    }

    // ---------- Who lives where ----------

    private fun place() {
        val p = Probe()
        for ((idx, pl) in PLACES.withIndex()) {
            world.probe(pl.x, pl.z, p)
            val zone = p.zone
            val first = world.siteFront[idx]
            when (pl.kind) {
                Site.TOWN -> {
                    world.stallSpot[idx]?.let { s ->
                        add(NpcRole.TRADER, LOOK_TRADER, idx, zone, s[0] - s[2] * 1.1f, s[1] - s[3] * 1.1f, atan2(s[2], s[3]), 0f)
                    }
                    world.boardSpot[idx]?.let { b ->
                        // Beside the notice board, a little in front of it.
                        val sx = b[0] + b[2] * 1.3f + b[3] * 1.4f
                        val sz = b[1] + b[3] * 1.3f - b[2] * 1.4f
                        // Greenhollow's elder is the story's Elder: a plain old man, not the staff-bearing wizard.
                        add(NpcRole.QUEST, if (idx == 0) LOOK_OLD else LOOK_ELDER, idx, zone, sx, sz, atan2(b[2], b[3]), 0f)
                        if (idx == 0) npcs.last().storyRole = StoryRole.ELDER
                    }
                    for (k in 0 until 4) {
                        val a = rnd.nextFloat() * 6.2831855f
                        val r = 5f + rnd.nextFloat() * 9f
                        add(NpcRole.VILLAGER, villagerLook(zone), idx, zone, pl.x + cos(a) * r, pl.z + sin(a) * r, rnd.nextFloat() * 6.28f, 15f, pl.x, pl.z)
                    }
                }
                Site.CAMP -> {
                    // The trader stands behind the counter of the camp's trading post.
                    val s = world.stallSpot[idx]
                    val a1 = if (s != null) atan2(-s[3], -s[2]) else first + 0.6f + 0.628f
                    val a2 = a1 + 2.513f
                    if (s != null) {
                        add(NpcRole.TRADER, LOOK_TRADER, idx, zone, s[0] - s[2] * 1.1f, s[1] - s[3] * 1.1f, atan2(s[2], s[3]), 0f)
                    } else {
                        add(NpcRole.TRADER, LOOK_TRADER, idx, zone, pl.x + cos(a1) * 3.4f, pl.z + sin(a1) * 3.4f, atan2(-cos(a1), -sin(a1)), 0f)
                    }
                    add(NpcRole.QUEST, LOOK_OLD, idx, zone, pl.x + cos(a2) * 3.4f, pl.z + sin(a2) * 3.4f, atan2(-cos(a2), -sin(a2)), 0f)
                    val a3 = a2 + 2.513f
                    add(NpcRole.VILLAGER, villagerLook(zone), idx, zone, pl.x + cos(a3) * 3.6f, pl.z + sin(a3) * 3.6f, 0f, 4f, pl.x, pl.z)
                }
                Site.CASTLE -> {
                    val fx = cos(first)
                    val fz = sin(first)
                    for (side in intArrayOf(-1, 1)) {
                        val u = side * 4.8f
                        val w = CURTAIN + 3.5f
                        add(NpcRole.GUARD, LOOK_GUARD, idx, zone, castleX(pl.x, fx, fz, u, w), castleZ(pl.z, fx, fz, u, w), atan2(fx, fz), 0f)
                    }
                    val tu = CASTLE_STALL_U + 1.1f
                    add(
                        NpcRole.TRADER, LOOK_TRADER, idx, zone,
                        castleX(pl.x, fx, fz, tu, CASTLE_STALL_W), castleZ(pl.z, fx, fz, tu, CASTLE_STALL_W), atan2(-fz, fx), 0f,
                    )
                    // The lord sits on his throne at the far end of the keep's great hall, facing the door.
                    val lw = -KEEP_BACK + THRONE_W
                    add(NpcRole.LORD, LOOK_LORD, idx, zone, castleX(pl.x, fx, fz, 0f, lw), castleZ(pl.z, fx, fz, 0f, lw), atan2(fx, fz), 0f)
                    val keepX = castleX(pl.x, fx, fz, 0f, -KEEP_BACK)
                    val keepZ = castleZ(pl.z, fx, fz, 0f, -KEEP_BACK)
                    npcs.last().sitting = true
                    // Seat height, less how far the hips sit above the feet, so he rests on the cushion.
                    npcs.last().seatY = world.terrainAt(keepX, keepZ) + THRONE_SEAT_Y - 0.82f
                    for (k in 0 until 3) {
                        val u = -8f + k * 8f
                        val w = 22f + (k % 2) * 4f
                        add(
                            NpcRole.VILLAGER, villagerLook(zone), idx, zone, castleX(pl.x, fx, fz, u, w), castleZ(pl.z, fx, fz, u, w),
                            rnd.nextFloat() * 6.28f, 9f, castleX(pl.x, fx, fz, 0f, 24f), castleZ(pl.z, fx, fz, 0f, 24f),
                        )
                    }
                }
            }
        }
        // The wizard of Greenhollow, a few steps off the square: where the story begins. Added last so nobody else's number changes.
        run {
            val gh = PLACES[0]
            world.probe(gh.x, gh.z, p)
            // Inside his house, if it was built; otherwise a few steps off the square.
            val h = world.wizardHouse
            val wx = if (h != null) castleX(h[0], h[2], h[3], WIZARD_U, WIZARD_W) else gh.x + 7f
            val wz = if (h != null) castleZ(h[1], h[2], h[3], WIZARD_U, WIZARD_W) else gh.z + 5f
            add(NpcRole.VILLAGER, LOOK_ELDER, 0, p.zone, wx, wz, if (h != null) atan2(h[2], h[3]) else 3.9f, 0f)
            npcs.last().storyRole = StoryRole.WIZARD
        }
        // Chapter Two: the villager you'll save lives in Thornwick, and the man who sits alone lives in Fernhollow.
        run {
            for (pair in listOf(Pair(5, StoryRole.VILLAGER), Pair(24, StoryRole.RECLUSE), Pair(9, StoryRole.ROGER))) {
                val pl = PLACES[pair.first]
                world.probe(pl.x, pl.z, p)
                val h = world.homes[pair.first]
                val sx = if (h != null) castleX(h[0], h[2], h[3], WIZARD_U, WIZARD_W) else pl.x + 6f
                val sz = if (h != null) castleZ(h[1], h[2], h[3], WIZARD_U, WIZARD_W) else pl.z + 5f
                add(NpcRole.VILLAGER, if (pair.second == StoryRole.VILLAGER) 2 else if (pair.second == StoryRole.RECLUSE) 0 else LOOK_OLD, pair.first, p.zone, sx, sz, if (h != null) atan2(h[2], h[3]) else 0f, 0f)
                npcs.last().storyRole = pair.second
            }
        }
        for (n in npcs) {
            // Start everyone on the ground floor, never on a roof or upper storey above them.
            n.y = if (n.sitting) n.seatY else world.groundAt(n.x, n.z, world.terrainAt(n.x, n.z) + 1.2f)
        }
    }

    private fun villagerLook(zone: Zone): Int = when (zone) {
        Zone.DESERT -> if (rnd.nextFloat() < 0.6f) 9 else rnd.nextInt(4)
        Zone.SNOW -> if (rnd.nextFloat() < 0.6f) 10 else rnd.nextInt(4)
        else -> rnd.nextInt(5)
    }

    private fun add(
        role: Int, look: Int, place: Int, zone: Zone, x: Float, z: Float, yaw: Float, wander: Float,
        homeX: Float = x, homeZ: Float = z,
    ) {
        val names = if (LOOKS[look].female) FEMALE else MALE
        val name = names[(npcs.size * 7 + place * 3) % names.size]
        val n = Npc(npcs.size, name, role, look, place, zone, homeX, homeZ, yaw, wander)
        n.x = x
        n.z = z
        npcs.add(n)
    }

    /** The quest giver or lord standing at [place], or null. */
    fun giverAt(place: Int): Npc? = npcs.firstOrNull { it.place == place && (it.role == NpcRole.QUEST || it.role == NpcRole.LORD) }

    // ---------- Moving about ----------

    fun update(dt: Float, px: Float, pz: Float) {
        for (n in npcs) {
            val d = hypot(n.x - px, n.z - pz)
            n.awake = d < 140f
            if (!n.awake) continue
            if (n.sitting) {
                // Stays seated facing the hall; only his head and hands move when you come to talk.
                n.facing = d < 4.5f
                n.speed = 0f
                n.walking = false
                n.yaw = n.homeYaw
                n.y = n.seatY
                continue
            }
            var want = n.yaw
            n.facing = d < 4.5f
            if (n.gather) {
                // Hurrying over to the spot they were sent to, then turning to look at you.
                val dx = n.goX - n.x
                val dz = n.goZ - n.z
                val left = hypot(dx, dz)
                if (left > 0.3f) {
                    want = atan2(dx, dz)
                    n.speed = min(1.7f, n.speed + dt * 3f)
                    val step = min(left, n.speed * dt)
                    n.x += sin(n.yaw) * step
                    n.z += cos(n.yaw) * step
                } else {
                    want = atan2(px - n.x, pz - n.z)
                    n.speed = max(0f, n.speed - dt * 5f)
                }
                n.walking = false
            } else if (n.facing) {
                // Stop and turn to look at you.
                n.walking = false
                want = atan2(px - n.x, pz - n.z)
                n.speed = max(0f, n.speed - dt * 4f)
            } else if (n.wander > 0f) {
                if (!n.walking) {
                    n.speed = max(0f, n.speed - dt * 4f)
                    n.timer -= dt
                    if (n.timer <= 0f) {
                        val a = rnd.nextFloat() * 6.2831855f
                        val r = rnd.nextFloat() * n.wander
                        val gx = n.homeX + cos(a) * r
                        val gz = n.homeZ + sin(a) * r
                        if (!blocked(gx, gz)) {
                            n.goX = gx
                            n.goZ = gz
                            n.walking = true
                        } else {
                            n.timer = 0.4f
                        }
                    }
                } else {
                    val dx = n.goX - n.x
                    val dz = n.goZ - n.z
                    val left = hypot(dx, dz)
                    want = atan2(dx, dz)
                    n.speed = min(1.2f, n.speed + dt * 3f)
                    val nx = n.x + sin(n.yaw) * n.speed * dt
                    val nz = n.z + cos(n.yaw) * n.speed * dt
                    if (left < 0.5f || blocked(nx, nz) || hypot(nx - px, nz - pz) < 1.0f) {
                        n.walking = false
                        n.timer = 3f + rnd.nextFloat() * 7f
                    } else {
                        n.x = nx
                        n.z = nz
                    }
                }
            } else {
                want = n.homeYaw
            }
            var dy = want - n.yaw
            while (dy > 3.1415927f) dy -= 6.2831855f
            while (dy < -3.1415927f) dy += 6.2831855f
            n.yaw += dy * min(1f, dt * 5f)
            n.phase += dt * n.speed * 4.6f
            n.y += (world.groundAt(n.x, n.z, n.y + 0.6f) - n.y) * min(1f, dt * 12f)
        }
    }

    private fun blocked(x: Float, z: Float): Boolean {
        if (world.isBlocked(x, z, probe)) return true
        if (world.terrainAt(x, z) < 0f) return true
        return world.hitsObstacle(x, z, 0.4f, tmp, probe)
    }

    /** True if a body of radius [r] at (px, pz) would walk into someone. */
    fun blocks(px: Float, pz: Float, r: Float): Boolean {
        for (n in npcs) {
            if (!n.awake) continue
            val rr = r + 0.32f
            val dx = px - n.x
            val dz = pz - n.z
            if (dx * dx + dz * dz < rr * rr) return true
        }
        return false
    }

    /** The nearest person within [range] metres you can talk to, or null. */
    fun nearest(px: Float, pz: Float, feet: Float, range: Float): Npc? {
        var best: Npc? = null
        var bd = range
        for (n in npcs) {
            if (!n.awake || abs(n.y - feet) > 1.6f) continue
            val d = hypot(n.x - px, n.z - pz)
            if (d < bd) {
                bd = d
                best = n
            }
        }
        return best
    }

    // ---------- Posing ----------

    fun pose(n: Npc, part: CreaturePart, time: Float, out: FloatArray) {
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, n.x, n.y, n.z)
        Matrix.rotateM(out, 0, n.yaw * 57.29578f, 0f, 1f, 0f)
        Matrix.scaleM(out, 0, 0.94f, 0.94f, 0.94f)
        apply(n, part, out, time)
    }

    /** The marker over someone's head, bobbing and turning. */
    fun poseMarker(n: Npc, time: Float, out: FloatArray) {
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, n.x, n.y + 2.35f + sin(time * 2.4f + n.id) * 0.08f, n.z)
        Matrix.rotateM(out, 0, time * 90f, 0f, 1f, 0f)
    }

    private fun apply(n: Npc, part: CreaturePart, out: FloatArray, time: Float) {
        val parent = part.parent
        if (parent != null) apply(n, parent, out, time)
        Matrix.translateM(out, 0, part.px, part.py, part.pz)
        val m = (n.speed / 1.2f).coerceIn(0f, 1f)
        val ph = n.phase
        val holds = LOOKS[n.look].held != 0
        val talks = n.facing && n.role != NpcRole.VILLAGER && n.role != NpcRole.GUARD
        val seed = n.id * 1.7f
        when (part.kind) {
            NpcPart.PELVIS -> Matrix.rotateM(out, 0, deg(sin(ph) * 0.1f * m), 0f, 1f, 0f)
            NpcPart.TORSO -> Matrix.rotateM(out, 0, deg(0.05f * m + sin(time * 1.7f + seed) * 0.012f), 1f, 0f, 0f)
            NpcPart.HEAD -> {
                val look = if (n.facing) 0f else sin(time * 0.4f + seed) * 0.35f * (1f - m)
                Matrix.rotateM(out, 0, deg(look), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(sin(time * 0.3f + seed * 2f) * 0.05f + (if (talks) sin(time * 3f) * 0.04f else 0f)), 1f, 0f, 0f)
            }
            NpcPart.ARM_L -> {
                val el = if (holds) 0f else -sin(ph) * 0.45f * m + sin(time * 1.7f + seed) * 0.02f
                Matrix.rotateM(out, 0, deg(el), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(-0.08f), 0f, 0f, 1f)
            }
            NpcPart.ARM_R -> {
                val el = if (talks) -0.55f + sin(time * 2.2f + seed) * 0.25f else -sin(ph + 3.1415927f) * 0.45f * m
                Matrix.rotateM(out, 0, deg(el), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(0.08f), 0f, 0f, 1f)
            }
            NpcPart.FORE_L -> Matrix.rotateM(out, 0, deg(if (holds) -1.5708f else -(0.25f + 0.3f * m)), 1f, 0f, 0f)
            NpcPart.FORE_R -> Matrix.rotateM(out, 0, deg(if (talks) -(0.9f + sin(time * 2.2f + seed) * 0.25f) else -(0.25f + 0.3f * m)), 1f, 0f, 0f)
            NpcPart.THIGH_L, NpcPart.THIGH_R -> {
                if (n.sitting) {
                    // Thighs forward along the seat, knees a little apart.
                    val spread = if (part.kind == NpcPart.THIGH_L) -0.08f else 0.08f
                    Matrix.rotateM(out, 0, deg(-1.3f), 1f, 0f, 0f)
                    Matrix.rotateM(out, 0, deg(spread), 0f, 1f, 0f)
                } else {
                    val off = if (part.kind == NpcPart.THIGH_L) 0f else 3.1415927f
                    Matrix.rotateM(out, 0, deg(sin(ph + off) * 0.5f * m), 1f, 0f, 0f)
                }
            }
            NpcPart.SHIN_L, NpcPart.SHIN_R -> {
                if (n.sitting) {
                    // Knees bent, lower legs straight down to the floor.
                    Matrix.rotateM(out, 0, deg(1.3f), 1f, 0f, 0f)
                } else {
                    val off = if (part.kind == NpcPart.SHIN_L) 0f else 3.1415927f
                    Matrix.rotateM(out, 0, deg(0.05f + max(0f, -cos(ph + off)) * 0.9f * m), 1f, 0f, 0f)
                }
            }
            else -> {}
        }
    }

    private fun deg(r: Float): Float = r * 57.29578f

    // ---------- Building the bodies ----------

    private fun marker(rgb: Int): CreaturePart {
        val m = MeshBuilder(1024)
        m.spike(0f, 0f, 0f, 0.16f, 0.3f, 0f, 0f, rgb, FLAG_GLOW)
        m.spike(0f, 0f, 0f, 0.16f, -0.22f, 0f, 0f, rgb, FLAG_GLOW)
        return CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
    }

    private fun buildPerson(lk: Look): List<CreaturePart> {
        val parts = ArrayList<CreaturePart>()
        fun part(kind: Int, px: Float, py: Float, pz: Float, parent: CreaturePart?, draw: (MeshBuilder) -> Unit): CreaturePart {
            val m = MeshBuilder(4096)
            m.hd = true
            draw(m)
            val cp = CreaturePart(kind, px, py, pz, 0f, m.finish(), m.vertexCount, parent)
            parts.add(cp)
            return cp
        }
        val skin = lk.skin
        val top = lk.top
        val sleeve = if (lk.robe == 2) lk.top else top
        val pelvis = part(NpcPart.PELVIS, 0f, 1.0f, 0f, null) { m ->
            m.blob(0f, -0.03f, 0f, 0.17f, 0.12f, 0.125f, lk.bottom, 1, 0.02f, FLAG_FUR)
            m.blob(0f, 0.07f, 0f, 0.172f, 0.03f, 0.126f, shadeRgb(lk.bottom, 0.6f), 2, 0f, FLAG_FUR)
            when (lk.robe) {
                1 -> m.prism(0f, -0.52f, 0f, 0.27f, 0.19f, 0.6f, 12, top, 0f, false, FLAG_FUR)
                2 -> m.prism(0f, -0.93f, 0f, 0.3f, 0.19f, 1.01f, 12, top, 0f, false, FLAG_FUR)
            }
            if (lk.extra == 1) m.box(0f, -0.25f, 0.2f, 0.16f, 0.28f, 0.015f, 0f, lk.extraColor, FLAG_FUR)
            if (lk.extra == 5) m.blob(0f, 0.08f, 0f, 0.18f, 0.035f, 0.135f, lk.extraColor, 3, 0f, FLAG_FUR)
            if (lk.extra == 3) m.prism(0f, -0.45f, 0f, 0.2f, 0.18f, 0.5f, 8, lk.extraColor, 0f, false, FLAG_FUR)
        }
        val torso = part(NpcPart.TORSO, 0f, 0.1f, 0f, pelvis) { m ->
            m.blob(0f, 0.08f, 0f, 0.158f, 0.13f, 0.108f, top, 11, 0.03f, FLAG_FUR)
            m.blob(0f, 0.28f, 0.004f, 0.19f, if (lk.female) 0.16f else 0.165f, 0.118f, top, 12, 0.03f, FLAG_FUR)
            m.blob(0f, 0.41f, -0.005f, 0.215f, 0.07f, 0.105f, top, 13, 0.02f, FLAG_FUR)
            m.limb(0f, 0.42f, 0f, 0f, 0.57f, 0.012f, 0.056f, 0.05f, skin, FLAG_FUR)
            when (lk.extra) {
                2 -> for (s in intArrayOf(-1, 1)) m.box(s * 0.09f, 0.24f, 0.11f, 0.06f, 0.2f, 0.02f, 0f, lk.extraColor, FLAG_FUR)
                3 -> {
                    // Mail shirt and a tabard over it.
                    m.blob(0f, 0.3f, 0f, 0.2f, 0.18f, 0.125f, lk.top, 14, 0.01f, FLAG_SOLID)
                    m.box(0f, 0.2f, 0.125f, 0.12f, 0.26f, 0.012f, 0f, lk.extraColor, FLAG_FUR)
                    m.box(0f, 0.2f, -0.125f, 0.12f, 0.26f, 0.012f, 0f, lk.extraColor, FLAG_FUR)
                    for (s in intArrayOf(-1, 1)) m.blob(s * 0.2f, 0.42f, 0f, 0.09f, 0.06f, 0.09f, lk.top, 15 + s, 0f, FLAG_SOLID)
                }
                4 -> {
                    // A cape hanging from the shoulders down the back.
                    m.limb(0f, 0.45f, -0.12f, 0f, -0.75f, -0.2f, 0.2f, 0.28f, lk.extraColor, FLAG_FUR)
                    m.blob(0f, 0.44f, 0f, 0.23f, 0.05f, 0.13f, 0xC8A040, 16, 0f, FLAG_SOLID)
                }
                5 -> m.limb(-0.16f, 0.42f, 0.05f, 0.16f, 0.08f, 0.1f, 0.025f, 0.025f, lk.extraColor, FLAG_FUR)
                6 -> m.blob(0f, 0.43f, 0f, 0.23f, 0.06f, 0.14f, lk.extraColor, 17, 0.1f, FLAG_FUR)
            }
        }
        part(NpcPart.HEAD, 0f, 0.56f, 0.01f, torso) { m ->
            m.blob(0f, 0.13f, 0.01f, 0.1f, 0.12f, 0.11f, skin, 21, 0f, FLAG_FUR)
            m.blob(0f, 0.05f, 0.03f, 0.085f, 0.07f, 0.085f, skin, 22, 0f, FLAG_FUR)
            m.blob(0f, 0.105f, 0.12f, 0.017f, 0.032f, 0.022f, shadeRgb(skin, 0.97f), 24, 0f, FLAG_FUR)
            m.blob(0f, 0.058f, 0.114f, 0.026f, 0.006f, 0.007f, 0x8A4A40, 27, 0f, FLAG_FUR)
            for (side in intArrayOf(-1, 1)) {
                val ex = side * 0.038f
                m.blob(ex, 0.14f, 0.107f, 0.017f, 0.011f, 0.012f, 0xF0EDE6, 30 + side, 0f, FLAG_SOLID)
                m.blob(ex, 0.14f, 0.117f, 0.0085f, 0.0085f, 0.004f, 0x3A2816, 32 + side, 0f, FLAG_SOLID)
                m.blob(ex, 0.163f, 0.117f, 0.023f, 0.006f, 0.008f, lk.hair, 34 + side, 0f, FLAG_FUR)
                m.blob(side * 0.1f, 0.12f, 0.005f, 0.015f, 0.03f, 0.022f, shadeRgb(skin, 0.96f), 36 + side, 0f, FLAG_FUR)
            }
            val hidden = lk.hat == 3 || lk.hat == 5 || lk.hat == 6
            if (!hidden && lk.hairStyle != 3) {
                m.blob(0f, 0.16f, -0.012f, 0.108f, 0.105f, 0.118f, lk.hair, 40, 0.02f, FLAG_FUR)
                m.blob(0f, 0.1f, -0.035f, 0.097f, 0.09f, 0.09f, lk.hair, 41, 0.02f, FLAG_FUR)
                when (lk.hairStyle) {
                    1 -> m.limb(0f, 0.14f, -0.07f, 0f, -0.14f, -0.1f, 0.1f, 0.075f, lk.hair, FLAG_FUR)
                    2 -> m.blob(0f, 0.2f, -0.12f, 0.055f, 0.055f, 0.055f, lk.hair, 42, 0.05f, FLAG_FUR)
                }
            }
            if (lk.beard) {
                m.blob(0f, 0.074f, 0.11f, 0.035f, 0.009f, 0.013f, lk.hair, 50, 0f, FLAG_FUR)
                m.blob(0f, 0.02f, 0.085f, 0.07f, 0.05f, 0.05f, lk.hair, 51, 0.08f, FLAG_FUR)
                if (lk.robe == 2 || lk.hair == 0xCCCCC8) m.blob(0f, -0.04f, 0.09f, 0.045f, 0.07f, 0.04f, lk.hair, 52, 0.08f, FLAG_FUR)
            }
            when (lk.hat) {
                1 -> {
                    m.prism(0f, 0.2f, 0f, 0.26f, 0.26f, 0.02f, 14, lk.hatColor, 0f, true, FLAG_GRASS)
                    m.prism(0f, 0.22f, 0f, 0.11f, 0.08f, 0.1f, 10, lk.hatColor, 0f, true, FLAG_GRASS)
                }
                2 -> {
                    m.prism(0f, 0.2f, 0f, 0.18f, 0.18f, 0.02f, 12, lk.hatColor, 0f, true, FLAG_FUR)
                    m.prism(0f, 0.21f, 0f, 0.105f, 0.09f, 0.1f, 10, lk.hatColor, 0f, true, FLAG_FUR)
                }
                3 -> {
                    m.blob(0f, 0.17f, 0f, 0.118f, 0.12f, 0.125f, lk.hatColor, 60, 0f, FLAG_SOLID)
                    m.box(0f, 0.12f, 0.12f, 0.012f, 0.05f, 0.01f, 0f, lk.hatColor, FLAG_SOLID)
                }
                4 -> {
                    m.prism(0f, 0.2f, 0f, 0.1f, 0.105f, 0.05f, 10, lk.hatColor, 0f, false, FLAG_GLOW)
                    for (k in 0 until 5) {
                        val a = k * 1.2566371f
                        m.spike(cos(a) * 0.1f, 0.25f, sin(a) * 0.1f, 0.018f, 0.05f, 0f, 0f, lk.hatColor, FLAG_GLOW)
                    }
                }
                5 -> m.blob(0f, 0.14f, -0.02f, 0.13f, 0.14f, 0.13f, lk.hatColor, 61, 0.15f, FLAG_FUR)
                6 -> {
                    m.blob(0f, 0.17f, -0.01f, 0.118f, 0.1f, 0.122f, lk.hatColor, 62, 0.05f, FLAG_FUR)
                    m.limb(0f, 0.12f, -0.1f, 0f, -0.05f, -0.12f, 0.05f, 0.04f, lk.hatColor, FLAG_FUR)
                }
                7 -> m.blob(0f, 0.18f, -0.02f, 0.112f, 0.09f, 0.12f, lk.hatColor, 63, 0.03f, FLAG_FUR)
            }
        }
        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            val upper = part(if (side < 0) NpcPart.ARM_L else NpcPart.ARM_R, s * 0.215f, 0.41f, 0f, torso) { m ->
                m.blob(0f, 0f, 0f, 0.07f, 0.07f, 0.07f, sleeve, 70 + side, 0.02f, FLAG_FUR)
                m.limb(0f, -0.01f, 0f, s * 0.015f, -0.26f, 0f, 0.06f, 0.052f, sleeve, FLAG_FUR)
            }
            val fore = part(if (side < 0) NpcPart.FORE_L else NpcPart.FORE_R, s * 0.015f, -0.27f, 0f, upper) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.14f, 0.005f, 0.05f, 0.045f, sleeve, FLAG_FUR)
                m.limb(0f, -0.12f, 0.005f, 0f, -0.24f, 0.01f, 0.038f, 0.031f, skin, FLAG_FUR)
                m.blob(0f, -0.3f, 0.012f, 0.022f, 0.052f, 0.042f, skin, 72 + side, 0f, FLAG_FUR)
            }
            if (side < 0 && lk.held != 0) {
                part(NpcPart.HELD, 0f, -0.3f, 0.012f, fore) { m ->
                    if (lk.held == 1) {
                        m.limb(0f, 0f, -0.95f, 0f, 0f, 0.9f, 0.025f, 0.03f, 0x6A4A2A, FLAG_WOOD)
                        m.blob(0f, 0f, 0.98f, 0.06f, 0.06f, 0.06f, 0x6AC8FF, 80, 0f, FLAG_GLOW)
                    } else {
                        m.limb(0f, 0f, -0.95f, 0f, 0f, 1.35f, 0.022f, 0.022f, 0x5A3E22, FLAG_WOOD)
                        m.limb(0f, 0f, 1.33f, 0f, 0f, 1.65f, 0.045f, 0.002f, 0xC0C6CE, FLAG_SOLID)
                    }
                }
            }
            val thigh = part(if (side < 0) NpcPart.THIGH_L else NpcPart.THIGH_R, s * 0.095f, -0.04f, 0f, pelvis) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.43f, 0.01f, 0.08f, 0.06f, lk.bottom, FLAG_FUR)
            }
            part(if (side < 0) NpcPart.SHIN_L else NpcPart.SHIN_R, 0f, -0.44f, 0.01f, thigh) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.3f, -0.01f, 0.058f, 0.046f, lk.bottom, FLAG_FUR)
                m.limb(0f, -0.26f, -0.01f, 0f, -0.46f, -0.01f, 0.05f, 0.046f, lk.boots, FLAG_FUR)
                m.blob(0f, -0.487f, 0.045f, 0.05f, 0.035f, 0.11f, lk.boots, 90 + side, 0f, FLAG_FUR)
            }
        }
        return parts
    }
}

private val CHATTER = arrayOf(
    "Keep to the roads after dark. Monsters won't come into town, but out there...",
    "They say a great beast guards every region. Beat it and the old seal breaks.",
    "Found gems out in the wilds? The trader will pay good gold for them.",
    "Search the bodies of anything you bring down. Monsters carry all sorts.",
    "The elder always has work for someone brave. Look for the notice board.",
    "There are caves cut into the mountainsides. Treasure inside, if you've the nerve.",
    "Lovely day for it, isn't it? Whatever it is you're doing.",
)

private val ZONE_CHATTER = mapOf(
    Zone.MEADOW to "Gorvak the Moss King sleeps in a ring of standing stones east of here. Nobody who went looking came back.",
    Zone.FOREST to "The Hollow Elder was a tree once. Now it walks, and the woods whisper its name.",
    Zone.SNOW to "Wrap up warm. The blizzards up here can freeze a man solid where he stands.",
    Zone.DESERT to "Drink when you can, rest in the shade. The Sunscar takes the careless.",
    Zone.CAVES to "The crystals hum at night. I try not to listen to what they say.",
)

/** Something [n] says when you talk to them. [k] picks which. */
fun npcLine(n: Npc, k: Int): String = when (n.role) {
    NpcRole.TRADER -> "Welcome, welcome! The finest goods in ${n.zone.title}. Have a look, and I'll buy anything you don't need."
    NpcRole.GUARD -> if (k % 2 == 0) "Move along, traveller. The castle is safe while we stand watch." else "The lord is inside the keep, if you have business with them."
    NpcRole.QUEST, NpcRole.LORD -> "I've nothing more for you just now. Thank you, truly, for all you've done."
    else -> if (k % 3 == 0) ZONE_CHATTER.getValue(n.zone) else CHATTER[(k + n.id) % CHATTER.size]
}
