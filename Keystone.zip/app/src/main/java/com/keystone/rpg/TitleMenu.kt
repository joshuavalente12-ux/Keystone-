package com.keystone.rpg

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The Activity behind a Compose context (Play Games needs one). */
internal tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * The title screen: the still shot, the game's name, Google Play Games status, and the
 * menu: Play, New Game, Load, Save and Settings. Saving and loading use your Google
 * account's cloud save; without one you're a guest and the game saves on the phone.
 */
@Composable
fun TitleScreen(
    ready: Boolean,
    hasSave: Boolean,
    onPlay: () -> Unit,
    onNewGame: () -> Unit,
    onSaveLoaded: () -> Unit,
) {
    val ctx = LocalContext.current
    val activity = ctx.findActivity()
    var notice by remember { mutableStateOf("") }
    var confirmNew by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var autoFight by remember {
        mutableStateOf(ctx.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("auto_fight", false))
    }
    val signedIn = PlayGamesManager.status == PlayGamesManager.Status.SIGNED_IN

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF050807))) {
        TitleScene(Modifier.fillMaxSize())
        Column(
            modifier = Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 28.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Keystone", color = Palette.gold, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Explore the wilds. Find the keys. Open up the world.",
                    color = Color(0xFFCFE3D6),
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Google Play Games: signed in, still checking, or playing as a guest.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (PlayGamesManager.status) {
                            PlayGamesManager.Status.CHECKING -> "Connecting to Google Play Games\u2026"
                            PlayGamesManager.Status.SIGNED_IN ->
                                "Signed in" + if (PlayGamesManager.playerName.isNotEmpty()) " as ${PlayGamesManager.playerName}" else ""
                            PlayGamesManager.Status.SIGNED_OUT -> "Playing as guest \u00B7 saves stay on this phone"
                        },
                        color = Color(0xFFB9D4C2),
                        fontSize = 13.sp,
                    )
                    if (PlayGamesManager.status == PlayGamesManager.Status.SIGNED_OUT && activity != null) {
                        TextButton(onClick = { PlayGamesManager.signIn(activity) }) {
                            Text("Sign in", color = Palette.gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
                Text(
                    if (notice.isEmpty()) " " else notice,
                    color = Palette.gold,
                    fontSize = 13.sp,
                    modifier = Modifier.height(20.dp),
                )
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onPlay,
                        enabled = ready,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Palette.gold,
                            contentColor = Color(0xFF1E2A22),
                            disabledContainerColor = Palette.gold.copy(alpha = 0.35f),
                            disabledContentColor = Color(0xFF1E2A22),
                        ),
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.width(190.dp).height(52.dp),
                    ) {
                        Text(if (ready) "Play" else "Building\u2026", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    }
                    MenuButton("New Game", ready) { if (hasSave) confirmNew = true else onNewGame() }
                    MenuButton("Load", true) {
                        if (activity == null) return@MenuButton
                        PlayGamesManager.loadFromCloud(activity) { ok, msg ->
                            notice = msg
                            if (ok) onSaveLoaded()
                        }
                    }
                    MenuButton("Save", true) {
                        if (activity == null) return@MenuButton
                        PlayGamesManager.saveToCloud(activity) { _, msg -> notice = msg }
                    }
                    MenuButton("Settings", true) {
                        Sound.load(ctx)
                        settingsOpen = true
                    }
                }
                if (!signedIn && PlayGamesManager.status == PlayGamesManager.Status.SIGNED_OUT) {
                    Text(
                        "Save and Load use your Google account's cloud save.",
                        color = Color(0xFF8FA99A),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }
        if (confirmNew) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    modifier = Modifier
                        .width(380.dp)
                        .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                        .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Start a new game?", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "This erases the save on this phone: your items, gold, level and quests. A cloud save, if you have one, is kept.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { confirmNew = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3644), contentColor = Color.White),
                        ) { Text("Cancel", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = {
                                confirmNew = false
                                onNewGame()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB03A3A), contentColor = Color.White),
                        ) { Text("Erase and start", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
        if (settingsOpen) {
            SettingsPanel(
                autoFight = autoFight,
                onAutoFight = {
                    autoFight = it
                    ctx.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).edit().putBoolean("auto_fight", it).apply()
                },
                onClose = { settingsOpen = false },
            )
        }
    }
}

@Composable
private fun MenuButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xCC1E2A22),
            contentColor = Color(0xFFE8F2EA),
            disabledContainerColor = Color(0x661E2A22),
            disabledContentColor = Color(0x88E8F2EA),
        ),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.height(48.dp).border(1.dp, Palette.gold.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
    ) {
        Text(label, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
