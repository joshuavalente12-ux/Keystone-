package com.keystone.rpg

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.sin

private val scratch = Path()

/** Draws the part of the world around the player. [s] is one tile in pixels. */
fun DrawScope.drawWorld(game: Game, s: Float) {
    val world = game.world
    val viewW = size.width / s
    val viewH = size.height / s
    val camX = game.x.coerceIn(viewW / 2f, world.size - viewW / 2f)
    val camY = game.y.coerceIn(viewH / 2f, world.size - viewH / 2f)
    val left = camX - viewW / 2f
    val top = camY - viewH / 2f
    val x0 = floor(left).toInt() - 1
    val x1 = ceil(left + viewW).toInt() + 1
    val y0 = floor(top).toInt() - 1
    val y1 = ceil(top + viewH).toInt() + 2
    val time = game.time

    // Pass 1: flat ground.
    for (ty in y0..y1) {
        val py = (ty - top) * s
        for (tx in x0..x1) {
            drawGround(world, tx, ty, (tx - left) * s, py, s, time)
        }
    }

    // Pass 2: tall things, row by row, so nearer rows overlap farther ones.
    val playerRow = floor(game.y).toInt()
    val playerX = (game.x - left) * s
    val playerY = (game.y - top) * s
    for (ty in y0..y1) {
        val py = (ty - top) * s
        for (tx in x0..x1) {
            drawObject(world, tx, ty, (tx - left) * s, py, s, time)
        }
        if (ty == playerRow) drawHero(game, playerX, playerY, s)
    }

    // Zone atmosphere.
    when (game.zone) {
        Zone.CAVES -> drawRect(
            brush = Brush.radialGradient(
                0f to Color.Transparent,
                0.45f to Color(0x44000000),
                1f to Color(0xDD000000),
                center = Offset(playerX, playerY),
                radius = s * 6.5f,
            ),
        )
        Zone.SNOW -> drawSnowfall(time, s)
        else -> Unit
    }
}

private fun DrawScope.drawGround(
    world: World, tx: Int, ty: Int, px: Float, py: Float, s: Float, time: Float,
) {
    val t = world.tile(tx, ty)
    val zone = world.zoneIndex(tx, ty)
    val v = world.variation(tx, ty)
    val base = Palette.ground(t, zone)
    val shaded = if (v > 0.5f) lerp(base, Color.White, (v - 0.5f) * 0.12f)
    else lerp(base, Color.Black, (0.5f - v) * 0.12f)
    drawRect(color = shaded, topLeft = Offset(px, py), size = Size(s + 1f, s + 1f))

    when (t) {
        T.FLOWERS -> {
            val c = if (v > 0.5f) Palette.flowerYellow else Palette.flowerPink
            drawCircle(color = c, radius = s * 0.07f, center = Offset(px + s * 0.3f, py + s * 0.35f))
            drawCircle(color = Palette.flowerWhite, radius = s * 0.06f, center = Offset(px + s * 0.66f, py + s * 0.58f))
            drawCircle(color = c, radius = s * 0.05f, center = Offset(px + s * 0.42f, py + s * 0.76f))
        }
        T.WATER -> {
            val wave = sin(time * 2f + tx * 0.9f + ty * 0.6f)
            drawRoundRect(
                color = Palette.waterLight,
                topLeft = Offset(px + s * (0.25f + wave * 0.1f), py + s * 0.42f),
                size = Size(s * 0.34f, s * 0.07f),
                cornerRadius = CornerRadius(s * 0.035f),
            )
        }
        T.ICE -> drawLine(
            color = Color.White.copy(alpha = 0.6f),
            start = Offset(px + s * 0.2f, py + s * 0.7f),
            end = Offset(px + s * 0.55f, py + s * 0.35f),
            strokeWidth = s * 0.05f,
        )
        T.PATH -> if (v > 0.72f) {
            drawCircle(
                color = lerp(base, Color.Black, 0.15f),
                radius = s * 0.05f,
                center = Offset(px + s * v, py + s * (1.2f - v)),
            )
        }
        T.GATE -> {
            val cx = px + s * 0.5f
            val cy = py + s * 0.5f
            scratch.reset()
            scratch.moveTo(cx, cy - s * 0.22f)
            scratch.lineTo(cx + s * 0.15f, cy)
            scratch.lineTo(cx, cy + s * 0.22f)
            scratch.lineTo(cx - s * 0.15f, cy)
            scratch.close()
            drawPath(scratch, color = Palette.gold.copy(alpha = 0.85f))
        }
        else -> Unit
    }
}

private fun DrawScope.drawObject(
    world: World, tx: Int, ty: Int, px: Float, py: Float, s: Float, time: Float,
) {
    val v = world.variation(tx, ty)
    val zone = world.zoneIndex(tx, ty)
    when (world.tile(tx, ty)) {
        T.TREE -> drawTree(px, py, s, v, zone == Zone.FOREST.ordinal)
        T.PINE -> drawPine(px, py, s)
        T.CACTUS -> drawCactus(px, py, s)
        T.BOULDER -> drawBoulder(px, py, s)
        T.CRYSTAL -> drawCrystal(px, py, s, time, v)
        T.MOUNTAIN -> {
            val topColor = if (zone == Zone.SNOW.ordinal) Palette.mountainSnowTop else Palette.mountainTop
            drawBlock(px, py, s, topColor, Palette.mountainSide, 0.4f, v)
        }
        T.CAVE_WALL -> drawBlock(px, py, s, Palette.caveTop, Palette.caveSide, 0.3f, v)
        else -> Unit
    }
}

private fun DrawScope.drawShadow(px: Float, py: Float, s: Float, width: Float) {
    drawOval(
        color = Palette.shadow,
        topLeft = Offset(px + s * (0.5f - width / 2f), py + s * 0.66f),
        size = Size(s * width, s * 0.26f),
    )
}

private fun DrawScope.drawTree(px: Float, py: Float, s: Float, v: Float, dark: Boolean) {
    val cx = px + s * 0.5f
    drawShadow(px, py, s, 0.8f)
    drawRect(color = Palette.trunk, topLeft = Offset(cx - s * 0.07f, py + s * 0.4f), size = Size(s * 0.14f, s * 0.38f))
    val r = s * (0.44f + v * 0.06f)
    val cy = py + s * 0.28f
    drawCircle(color = if (dark) Palette.treeDark else Palette.tree, radius = r, center = Offset(cx, cy))
    drawCircle(
        color = if (dark) Palette.treeDarkHi else Palette.treeHi,
        radius = r * 0.45f,
        center = Offset(cx - r * 0.3f, cy - r * 0.3f),
    )
}

private fun DrawScope.drawPine(px: Float, py: Float, s: Float) {
    val cx = px + s * 0.5f
    drawShadow(px, py, s, 0.7f)
    drawRect(color = Palette.trunk, topLeft = Offset(cx - s * 0.06f, py + s * 0.6f), size = Size(s * 0.12f, s * 0.2f))
    scratch.reset()
    scratch.moveTo(cx, py - s * 0.45f)
    scratch.lineTo(px + s * 0.9f, py + s * 0.72f)
    scratch.lineTo(px + s * 0.1f, py + s * 0.72f)
    scratch.close()
    drawPath(scratch, color = Palette.pine)
    scratch.reset()
    scratch.moveTo(cx, py - s * 0.45f)
    scratch.lineTo(cx + s * 0.13f, py - s * 0.07f)
    scratch.lineTo(cx - s * 0.13f, py - s * 0.07f)
    scratch.close()
    drawPath(scratch, color = Color.White)
}

private fun DrawScope.drawCactus(px: Float, py: Float, s: Float) {
    val cx = px + s * 0.5f
    val c = Palette.cactus
    drawShadow(px, py, s, 0.5f)
    drawRoundRect(color = c, topLeft = Offset(cx - s * 0.11f, py + s * 0.05f), size = Size(s * 0.22f, s * 0.75f), cornerRadius = CornerRadius(s * 0.11f))
    // Left arm
    drawRoundRect(color = c, topLeft = Offset(cx - s * 0.33f, py + s * 0.25f), size = Size(s * 0.12f, s * 0.3f), cornerRadius = CornerRadius(s * 0.06f))
    drawRect(color = c, topLeft = Offset(cx - s * 0.3f, py + s * 0.45f), size = Size(s * 0.22f, s * 0.09f))
    // Right arm
    drawRoundRect(color = c, topLeft = Offset(cx + s * 0.21f, py + s * 0.15f), size = Size(s * 0.12f, s * 0.28f), cornerRadius = CornerRadius(s * 0.06f))
    drawRect(color = c, topLeft = Offset(cx + s * 0.08f, py + s * 0.34f), size = Size(s * 0.22f, s * 0.09f))
}

private fun DrawScope.drawBoulder(px: Float, py: Float, s: Float) {
    drawShadow(px, py, s, 0.9f)
    drawOval(color = Palette.boulder, topLeft = Offset(px + s * 0.06f, py + s * 0.12f), size = Size(s * 0.88f, s * 0.7f))
    drawOval(color = Palette.boulderHi, topLeft = Offset(px + s * 0.22f, py + s * 0.2f), size = Size(s * 0.36f, s * 0.2f))
}

private fun DrawScope.drawCrystal(px: Float, py: Float, s: Float, time: Float, v: Float) {
    val cx = px + s * 0.5f
    val cy = py + s * 0.45f
    val glow = 0.22f + 0.12f * sin(time * 3f + v * 10f)
    drawCircle(color = Palette.crystal.copy(alpha = glow), radius = s * 0.5f, center = Offset(cx, cy))
    scratch.reset()
    scratch.moveTo(cx, cy - s * 0.35f)
    scratch.lineTo(cx + s * 0.16f, cy)
    scratch.lineTo(cx, cy + s * 0.3f)
    scratch.lineTo(cx - s * 0.16f, cy)
    scratch.close()
    drawPath(scratch, color = Palette.crystal)
    drawCircle(color = Palette.crystalHi, radius = s * 0.05f, center = Offset(cx - s * 0.04f, cy - s * 0.1f))
}

/** A raised block: a top face lifted by [h] tiles, with a darker front face below. */
private fun DrawScope.drawBlock(
    px: Float, py: Float, s: Float, topColor: Color, sideColor: Color, h: Float, v: Float,
) {
    drawRect(color = sideColor, topLeft = Offset(px, py + s * (1f - h)), size = Size(s + 1f, s * h + 1f))
    drawRect(color = topColor, topLeft = Offset(px, py - s * h), size = Size(s + 1f, s + 1f))
    if (v > 0.62f) {
        drawCircle(
            color = lerp(topColor, Color.White, 0.25f),
            radius = s * 0.07f,
            center = Offset(px + s * (0.25f + (v - 0.62f)), py + s * (0.1f - h)),
        )
    }
}

private fun DrawScope.drawHero(game: Game, px: Float, py: Float, s: Float) {
    val bob = if (game.moving) abs(sin(game.walkTime * 12f)) * s * 0.06f else 0f
    drawOval(
        color = Palette.shadow,
        topLeft = Offset(px - s * 0.28f, py + s * 0.1f),
        size = Size(s * 0.56f, s * 0.2f),
    )
    val cy = py - s * 0.12f - bob
    val fx = game.faceX
    val fy = game.faceY
    // Scarf on the back, so you can tell which way the hero faces.
    drawCircle(color = Palette.gold, radius = s * 0.1f, center = Offset(px - fx * s * 0.24f, cy - fy * s * 0.24f))
    drawCircle(color = Color.White, radius = s * 0.34f, center = Offset(px, cy))
    drawCircle(color = Palette.hero, radius = s * 0.29f, center = Offset(px, cy))
    if (fy > -0.6f) {
        val ex = px + fx * s * 0.12f
        val ey = cy + fy * s * 0.12f
        val perpX = -fy * s * 0.09f
        val perpY = fx * s * 0.09f
        drawCircle(color = Palette.heroEye, radius = s * 0.05f, center = Offset(ex + perpX, ey + perpY))
        drawCircle(color = Palette.heroEye, radius = s * 0.05f, center = Offset(ex - perpX, ey - perpY))
    }
}

private fun DrawScope.drawSnowfall(time: Float, s: Float) {
    val w = size.width
    val h = size.height
    for (i in 0 until 60) {
        val fallSpeed = s * (0.8f + hash(i, 3, 7) * 1.2f)
        val fx = hash(i, 1, 7) * w + sin(time * 0.8f + i) * s * 0.4f
        val fy = (hash(i, 2, 7) * h + time * fallSpeed) % h
        drawCircle(
            color = Color.White.copy(alpha = 0.85f),
            radius = s * (0.03f + hash(i, 4, 7) * 0.05f),
            center = Offset(fx, fy),
        )
    }
}
