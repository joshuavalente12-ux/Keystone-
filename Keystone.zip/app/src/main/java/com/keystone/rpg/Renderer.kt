package com.keystone.rpg

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

private const val LOAD_RADIUS = 600f
private const val UNLOAD_RADIUS = 780f
private const val CHUNK_HALF_DIAG = 136f

private const val VERTEX_SHADER = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform float uTime;
uniform float uFogStart;
uniform float uFogEnd;
attribute vec3 aPos;
attribute vec4 aColor;
varying vec3 vColor;
varying float vFog;
void main() {
    vec3 p = aPos;
    vec3 col = aColor.rgb;
    float fogMul = 1.0;
    if (aColor.a < 0.3) {
        p.y += sin(uTime * 1.6 + aPos.x * 0.35 + aPos.z * 0.25) * 0.12;
        col *= 0.92 + 0.1 * sin(uTime * 2.0 + aPos.x * 0.5 - aPos.z * 0.4);
    } else if (aColor.a < 0.8) {
        fogMul = 0.35;
    }
    float d = distance(aPos, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0) * fogMul;
    vColor = col;
    gl_Position = uMvp * vec4(p, 1.0);
}
"""

private const val FRAGMENT_SHADER = """
precision mediump float;
uniform vec3 uFogColor;
varying vec3 vColor;
varying float vFog;
void main() {
    gl_FragColor = vec4(mix(vColor, uFogColor, vFog), 1.0);
}
"""

/** Sky/fog colour and how far you can see, per zone. */
private val FOG = mapOf(
    Zone.MEADOW to floatArrayOf(0.62f, 0.78f, 0.93f, 120f, 560f),
    Zone.FOREST to floatArrayOf(0.55f, 0.69f, 0.74f, 60f, 380f),
    Zone.DESERT to floatArrayOf(0.94f, 0.83f, 0.64f, 110f, 560f),
    Zone.SNOW to floatArrayOf(0.85f, 0.89f, 0.95f, 40f, 320f),
    Zone.CAVES to floatArrayOf(0.14f, 0.11f, 0.2f, 15f, 170f),
)

/** Draws the 3D world from the hero's eyes. Runs on its own drawing thread. */
class WorldRenderer(private val game: Game) : GLSurfaceView.Renderer {
    private val world = game.world
    private val builder = ChunkBuilder(world)

    private class Gpu(val buffer: Int, val count: Int)

    private val chunks = HashMap<Int, Gpu>()
    private val ids = IntArray(1)

    private var program = 0
    private var aPos = 0
    private var aColor = 0
    private var uMvp = 0
    private var uCam = 0
    private var uTime = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uFogColor = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private var lastNanos = 0L

    private val fog = FOG.getValue(Zone.MEADOW).copyOf()

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // A fresh surface means anything we uploaded before is gone.
        chunks.clear()
        program = buildProgram()
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uCam = GLES20.glGetUniformLocation(program, "uCam")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uFogStart = GLES20.glGetUniformLocation(program, "uFogStart")
        uFogEnd = GLES20.glGetUniformLocation(program, "uFogEnd")
        uFogColor = GLES20.glGetUniformLocation(program, "uFogColor")
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        lastNanos = 0L
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / max(1, height).toFloat()
        Matrix.perspectiveM(proj, 0, 64f, aspect, 0.25f, 900f)
    }

    override fun onDrawFrame(unused: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNanos = now
        game.update(dt)

        // Ease the sky and fog towards the current zone's look.
        val target = FOG.getValue(game.currentZone)
        val k = (dt * 1.2f).coerceAtMost(1f)
        for (i in 0 until 5) fog[i] += (target[i] - fog[i]) * k

        GLES20.glClearColor(fog[0], fog[1], fog[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val ex = game.x
        val ey = game.eyeY
        val ez = game.z
        val cp = cos(game.pitch)
        val fx = cp * sin(game.yaw)
        val fy = sin(game.pitch)
        val fz = cp * cos(game.yaw)
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + fx, ey + fy, ez + fz, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        streamChunks(ex, ez)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(uCam, ex, ey, ez)
        GLES20.glUniform1f(uTime, game.time)
        GLES20.glUniform1f(uFogStart, fog[3])
        GLES20.glUniform1f(uFogEnd, fog[4])
        GLES20.glUniform3f(uFogColor, fog[0], fog[1], fog[2])
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aColor)

        // Horizontal facing, for skipping chunks behind us.
        val hx = sin(game.yaw)
        val hz = cos(game.yaw)
        val viewLimit = fog[4] + CHUNK_HALF_DIAG
        for ((key, gpu) in chunks) {
            val ccx = ((key % CHUNKS) + 0.5f) * CHUNK_M
            val ccz = ((key / CHUNKS) + 0.5f) * CHUNK_M
            val dx = ccx - ex
            val dz = ccz - ez
            if (hypot(dx, dz) > viewLimit) continue
            if (dx * hx + dz * hz < -CHUNK_HALF_DIAG) continue
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gpu.buffer)
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, 0)
            GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_UNSIGNED_BYTE, true, STRIDE, 12)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, gpu.count)
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    /** Uploads freshly built chunks, asks for missing nearby ones, drops far-away ones. */
    private fun streamChunks(ex: Float, ez: Float) {
        for (n in 0 until 3) {
            val built = builder.done.poll() ?: break
            builder.uploaded(built.key)
            val data = built.data
            if (data == null || built.vertexCount == 0 || chunks.containsKey(built.key)) continue
            GLES20.glGenBuffers(1, ids, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, built.vertexCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            chunks[built.key] = Gpu(ids[0], built.vertexCount)
        }

        val pcx = floor(ex / CHUNK_M).toInt()
        val pcz = floor(ez / CHUNK_M).toInt()
        val reach = (LOAD_RADIUS / CHUNK_M).toInt() + 1
        for (ring in 0..reach) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(kotlin.math.abs(dx), kotlin.math.abs(dz)) != ring) continue
                    val cx = pcx + dx
                    val cz = pcz + dz
                    if (cx < 0 || cz < 0 || cx >= CHUNKS || cz >= CHUNKS) continue
                    val key = cz * CHUNKS + cx
                    if (chunks.containsKey(key) || builder.isPending(key)) continue
                    val d = hypot((cx + 0.5f) * CHUNK_M - ex, (cz + 0.5f) * CHUNK_M - ez)
                    if (d < LOAD_RADIUS) builder.request(key)
                }
            }
        }

        val it = chunks.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val key = e.key
            val d = hypot(((key % CHUNKS) + 0.5f) * CHUNK_M - ex, ((key / CHUNKS) + 0.5f) * CHUNK_M - ez)
            if (d > UNLOAD_RADIUS) {
                ids[0] = e.value.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
                it.remove()
            }
        }
    }

    private fun buildProgram(): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Link failed: " + GLES20.glGetProgramInfoLog(prog))
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Shader failed: " + GLES20.glGetShaderInfoLog(shader))
        }
        return shader
    }
}
