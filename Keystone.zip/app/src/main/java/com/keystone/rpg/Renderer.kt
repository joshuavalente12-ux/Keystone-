package com.keystone.rpg

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

private const val LOAD_RADIUS = 600f
private const val UNLOAD_RADIUS = 780f
private const val CHUNK_HALF_DIAG = 136f
private const val PARTICLES = 2200

private const val VERTEX_SHADER = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform float uTime;
uniform float uFogStart;
uniform float uFogEnd;
attribute vec3 aPos;
attribute vec4 aColor;
varying vec3 vColor;
varying float vFog;
varying vec3 vPos;
varying float vId;
void main() {
    vec3 p = aPos;
    float id = floor(aColor.a * 255.0 + 0.5);
    float fogMul = 1.0;
    if (id < 50.0) {
        // Water: gentle swell.
        p.y += sin(uTime * 1.6 + aPos.x * 0.35 + aPos.z * 0.25) * 0.08
             + sin(uTime * 2.3 - aPos.x * 0.6 + aPos.z * 0.45) * 0.04;
    } else if (id < 80.0) {
        // Fire: the tips of the flames dance about.
        if (id > 72.0) {
            p.x += sin(uTime * 9.0 + aPos.z * 7.0) * 0.14;
            p.z += cos(uTime * 7.3 + aPos.x * 7.0) * 0.14;
            p.y += sin(uTime * 11.0 + aPos.x * 5.0) * 0.25;
        }
        fogMul = 0.3;
    } else if (id < 140.0) {
        fogMul = 0.35;
    } else if (id < 163.0) {
        // Grass and fern tips sway in the wind.
        if (id < 160.5) {
            float w = sin(uTime * 1.3 + aPos.x * 0.05 + aPos.z * 0.04) * 0.5 + 0.7;
            p.x += sin(uTime * 2.2 + aPos.x * 0.7 + aPos.z * 0.3) * 0.1 * w;
            p.z += cos(uTime * 1.9 + aPos.z * 0.6 + aPos.x * 0.2) * 0.08 * w;
        }
    } else if (id < 186.0) {
        // Leaves rustle a little.
        p.x += sin(uTime * 1.7 + aPos.y * 1.3 + aPos.z * 0.5) * 0.05;
        p.z += cos(uTime * 1.5 + aPos.y * 1.1 + aPos.x * 0.5) * 0.05;
    }
    float d = distance(aPos, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0) * fogMul;
    vColor = aColor.rgb;
    vPos = p;
    vId = id;
    gl_Position = uMvp * vec4(p, 1.0);
}
"""

private const val FRAGMENT_SHADER = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 uFogColor;
uniform vec3 uEye;
uniform vec3 uSunDir;
uniform float uSunPower;
uniform float uClock;
varying vec3 vColor;
varying float vFog;
varying vec3 vPos;
varying float vId;

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    return noise(p) * 0.5 + noise(p * 2.03) * 0.3 + noise(p * 4.1) * 0.2;
}

void main() {
    vec3 col = vColor;
    float id = vId;
    vec3 P = vPos;
    float dist = distance(P, uEye);
    float near = 1.0 - smoothstep(35.0, 180.0, dist);

    if (id < 50.0) {
        // Water: rippled surface that mirrors the sky and glitters in the sun.
        vec3 v = normalize(uEye - P);
        vec2 w1 = vec2(noise(P.xz * 0.45 + vec2(uClock * 0.35, uClock * 0.1)),
                       noise(P.xz * 0.45 + vec2(-uClock * 0.2, uClock * 0.3) + 17.0));
        vec2 w2 = vec2(noise(P.xz * 1.6 + vec2(uClock * 0.8, 0.0)),
                       noise(P.xz * 1.6 + vec2(0.0, -uClock * 0.7) + 31.0));
        vec2 slope = (w1 - 0.5) * 0.5 + (w2 - 0.5) * 0.25 * near;
        vec3 nrm = normalize(vec3(slope.x, 1.0, slope.y));
        float fres = 0.04 + 0.96 * pow(1.0 - clamp(dot(v, nrm), 0.0, 1.0), 4.0);
        vec3 sky = mix(uFogColor, uFogColor * vec3(0.75, 0.88, 1.1), 0.5);
        col = mix(col, sky, clamp(fres * 1.2, 0.0, 0.85));
        vec3 r = reflect(-v, nrm);
        float spec = pow(max(dot(r, uSunDir), 0.0), 120.0) * 1.6 + pow(max(dot(r, uSunDir), 0.0), 18.0) * 0.12;
        col += vec3(1.0, 0.95, 0.85) * spec * uSunPower;
    } else if (id < 80.0) {
        // Fire: bright, flickering, hotter at the bottom.
        float fl = 0.75 + 0.5 * noise(vec2(P.y * 4.0 - uClock * 6.0, (P.x + P.z) * 5.0));
        col = col * fl * 1.35;
    } else if (id < 140.0) {
        col *= 1.0 + 0.1 * sin(uClock * 2.0 + P.x + P.z);
    } else if (near > 0.0) {
        if (id < 163.0) {
            // Grass blades, fern fronds, flower stems: darker near the root.
            col *= 0.9 + 0.2 * noise(P.xz * 6.0);
        } else if (id < 186.0) {
            // Leaves: clusters of light and dark foliage.
            float n = noise(P.xz * 2.4 + P.y * 1.9) * 0.6 + noise(P.xz * 7.0 - P.y * 5.0) * 0.4;
            col *= mix(1.0, 0.72 + 0.56 * n, near);
        } else if (id < 197.0) {
            // Bark: rough vertical ridges.
            float n = noise(vec2((P.x + P.z) * 9.0, P.y * 1.2)) * 0.7 + noise(vec2((P.x - P.z) * 20.0, P.y * 3.0)) * 0.3;
            col *= mix(1.0, 0.62 + 0.62 * n, near);
        } else if (id < 202.0) {
            // Wood: long grain lines.
            float n = noise(vec2(P.y * 22.0 + (P.x + P.z) * 0.8, (P.x - P.z) * 1.5));
            col *= mix(1.0, 0.8 + 0.34 * n, near);
        } else if (id < 209.0) {
            // Worked stone: speckles and the odd crack.
            float n = fbm(P.xz * 1.6 + P.y * 1.3);
            float crack = 1.0 - smoothstep(0.0, 0.035, abs(noise(P.xz * 0.9 + vec2(P.y * 0.9)) - 0.5));
            col *= mix(1.0, (0.78 + 0.44 * n) * (1.0 - 0.35 * crack), near);
        } else if (id < 219.0) {
            // Plaster and cloth: fine, slightly uneven.
            float n = noise(P.xz * 3.5 + P.y * 3.5) * 0.6 + noise(P.xz * 12.0 + P.y * 11.0) * 0.4;
            col *= mix(1.0, 0.9 + 0.2 * n, near);
        } else if (id < 226.0) {
            // Roof shingles in staggered rows.
            float row = P.y * 3.4;
            float fr = fract(row);
            float tile = floor((P.x + P.z) * 1.7 + floor(row) * 0.5);
            float h = hash(vec2(tile, floor(row)));
            col *= mix(1.0, (0.82 + 0.3 * h) * (1.0 - 0.4 * smoothstep(0.78, 1.0, fr)), near);
        } else if (id < 233.0) {
            // Grass ground: patchy, with dry spots and fine blades.
            float n = fbm(P.xz * 0.5) * 0.6 + noise(P.xz * 9.0) * 0.4;
            float dry = smoothstep(0.55, 0.8, noise(P.xz * 0.07));
            col = mix(col, col * vec3(1.18, 1.08, 0.72), dry * 0.55);
            col *= mix(1.0, 0.78 + 0.44 * n, near);
        } else if (id < 238.0) {
            // Rock: layered bands with rough detail.
            float strata = sin(P.y * 1.4 + noise(P.xz * 0.15) * 5.0);
            float n = fbm(vec2(P.x + P.z, P.y) * 0.9) * 0.6 + noise(P.xz * 3.0 + P.y) * 0.4;
            col *= mix(1.0, 0.8 + 0.08 * strata + 0.3 * n, near);
        } else if (id < 243.0) {
            // Dirt and roads: pebbles and dusty patches.
            vec2 cell = floor(P.xz * 3.0);
            vec2 f = fract(P.xz * 3.0) - 0.5;
            float peb = step(0.78, hash(cell)) * (1.0 - smoothstep(0.12, 0.28, length(f)));
            float n = fbm(P.xz * 1.3);
            col *= mix(1.0, (0.82 + 0.32 * n) * (1.0 - 0.28 * peb) + 0.1 * peb * hash(cell + 3.0), near);
        } else if (id < 248.0) {
            // Sand: wind ripples.
            float rip = sin((P.x * 0.9 + P.z * 0.4) * 2.4 + noise(P.xz * 0.25) * 6.0);
            col *= mix(1.0, 0.94 + 0.06 * rip + 0.1 * (noise(P.xz * 7.0) - 0.5), near);
        } else if (id < 253.0) {
            // Snow: soft drifts that sparkle as you move.
            col *= mix(1.0, 0.94 + 0.1 * noise(P.xz * 0.6), near);
            vec2 cell = floor(P.xz * 7.0 + P.y * 3.0);
            float h = hash(cell);
            float tw = sin(uClock * 1.5 + h * 60.0 + (uEye.x + uEye.z) * 0.8);
            col += vec3(0.6, 0.65, 0.7) * step(0.985, h) * max(tw, 0.0) * near * uSunPower;
        } else {
            col *= mix(1.0, 0.94 + 0.12 * noise(P.xz * 4.0 + P.y * 3.0), near);
        }
    }

    // A touch of warmth and contrast, then the haze of distance.
    col = clamp(col, 0.0, 1.5);
    col = mix(col, col * col * (3.0 - 2.0 * col), 0.22);
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(l), col, 1.1);
    gl_FragColor = vec4(mix(col, uFogColor, vFog), 1.0);
}
"""

private const val SKY_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
attribute vec3 aDir;
varying vec3 vDir;
void main() {
    vDir = aDir;
    gl_Position = uMvp * vec4(uCam + aDir * 800.0, 1.0);
}
"""

private const val SKY_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSun;
uniform float uSunPower;
uniform float uSkyTime;
uniform float uCirrus;
varying vec3 vDir;

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

void main() {
    vec3 d = normalize(vDir);
    float t = clamp(d.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(t, 0.5));
    // Bright haze low down, and light scattered around the sun.
    col = mix(col, uHorizon * 1.06, pow(1.0 - t, 10.0) * 0.6);
    float s = max(dot(d, uSun), 0.0);
    col += vec3(1.0, 0.88, 0.68) * pow(s, 5.0) * 0.16 * uSunPower;
    col += vec3(1.0, 0.95, 0.82) * pow(s, 90.0) * 0.45 * uSunPower;
    col += vec3(1.0, 0.98, 0.92) * pow(s, 1200.0) * 3.0 * uSunPower;
    // Thin high clouds drifting across the sky.
    if (d.y > 0.03) {
        vec2 uv = d.xz / (d.y + 0.15) * 1.6 + vec2(uSkyTime * 0.012, uSkyTime * 0.004);
        float c = noise(uv) * 0.55 + noise(uv * 2.7 + 3.1) * 0.3 + noise(uv * 6.3 + 7.7) * 0.15;
        c = smoothstep(0.5, 0.85, c) * smoothstep(0.03, 0.3, d.y) * uCirrus;
        vec3 cloud = mix(vec3(0.92, 0.94, 0.98), vec3(1.0, 0.97, 0.9), s);
        col = mix(col, cloud, c * 0.7);
    }
    gl_FragColor = vec4(col, 1.0);
}
"""

private const val PARTICLE_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform vec3 uOrigin;
uniform float uTime;
uniform float uPx;
uniform float uMode;
attribute vec3 aSeed;
varying float vAlpha;
void main() {
    vec3 p;
    float size;
    if (uMode < 0.5) {
        // Snow: falls and drifts in a box that always surrounds you.
        vec3 box = vec3(56.0, 30.0, 56.0);
        p = aSeed * box;
        p.y -= uTime * (1.1 + aSeed.x * 1.1);
        p.x += uTime * 0.6 + sin(uTime * 0.8 + aSeed.z * 30.0) * 0.9;
        p.z += cos(uTime * 0.6 + aSeed.x * 25.0) * 0.9;
        vec3 o = uCam - box * 0.5;
        p = o + mod(p - o, box);
        size = 0.07 + aSeed.y * 0.06;
        vAlpha = 0.9;
    } else {
        // Smoke: puffs rise, spread and fade.
        float life = fract(aSeed.y + uTime * 0.11);
        float ang = aSeed.x * 6.2831;
        float r = (0.15 + life * 1.6) * aSeed.z;
        p = uOrigin + vec3(cos(ang) * r + sin(uTime * 0.4 + aSeed.x * 9.0) * life * 1.5,
                           0.6 + life * 10.0,
                           sin(ang) * r + life * 1.2);
        size = 0.5 + life * 2.2;
        vAlpha = (1.0 - life) * smoothstep(0.0, 0.1, life) * 0.4;
    }
    gl_Position = uMvp * vec4(p, 1.0);
    gl_PointSize = clamp(uPx * size / max(gl_Position.w, 0.1), 1.0, 90.0);
}
"""

private const val PARTICLE_FRAGMENT = """
precision mediump float;
uniform vec3 uTint;
uniform float uStrength;
varying float vAlpha;
void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = dot(c, c);
    if (d > 0.25) discard;
    float a = vAlpha * uStrength * (1.0 - d * 4.0);
    gl_FragColor = vec4(uTint, a);
}
"""

/**
 * Look of each zone: horizon/fog colour (3), fog start, fog end,
 * sky colour straight up (3), sun strength, snowfall, high cloud.
 */
private val LOOK = mapOf(
    Zone.MEADOW to floatArrayOf(0.72f, 0.83f, 0.94f, 130f, 560f, 0.24f, 0.48f, 0.86f, 1f, 0f, 0.8f),
    Zone.FOREST to floatArrayOf(0.62f, 0.73f, 0.77f, 60f, 380f, 0.30f, 0.46f, 0.64f, 0.75f, 0f, 1f),
    Zone.DESERT to floatArrayOf(0.95f, 0.86f, 0.70f, 120f, 560f, 0.38f, 0.58f, 0.86f, 1.2f, 0f, 0.35f),
    Zone.SNOW to floatArrayOf(0.84f, 0.88f, 0.93f, 35f, 300f, 0.58f, 0.66f, 0.78f, 0.55f, 1f, 1f),
    Zone.CAVES to floatArrayOf(0.14f, 0.11f, 0.20f, 15f, 170f, 0.05f, 0.04f, 0.08f, 0f, 0f, 0f),
)

/** Picks a screen setup with a fine depth buffer if the phone has one, so distant things don't flicker. */
class DepthConfigChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (depth in intArrayOf(24, 16)) {
            val attribs = intArrayOf(
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depth,
                EGL10.EGL_RENDERABLE_TYPE, 4, // OpenGL ES 2
                EGL10.EGL_NONE,
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (egl.eglChooseConfig(display, attribs, configs, 1, count) && count[0] > 0) {
                val c = configs[0]
                if (c != null) return c
            }
        }
        throw IllegalArgumentException("No suitable screen setup found")
    }
}

/** Draws the 3D world from the hero's eyes. Runs on its own drawing thread. */
class WorldRenderer(private val game: Game) : GLSurfaceView.Renderer {
    private val world = game.world
    private val builder = ChunkBuilder(world)

    private class Gpu(val buffer: Int, val count: Int)

    private val chunks = HashMap<Int, Gpu>()
    private val ids = IntArray(1)

    private var program = 0
    private var aPos = 0
    private var aColor = 0
    private var uMvp = 0
    private var uCam = 0
    private var uTime = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uFogColor = 0
    private var uEye = 0
    private var uSunDir = 0
    private var uSunPower = 0
    private var uClock = 0

    private var skyProgram = 0
    private var skyDir = 0
    private var skyMvp = 0
    private var skyCam = 0
    private var skyHorizon = 0
    private var skyZenith = 0
    private var skySun = 0
    private var skySunPower = 0
    private var skyTime = 0
    private var skyCirrus = 0

    private var partProgram = 0
    private var partSeed = 0
    private var partMvp = 0
    private var partCam = 0
    private var partOrigin = 0
    private var partTime = 0
    private var partPx = 0
    private var partMode = 0
    private var partTint = 0
    private var partStrength = 0
    private var partBuffer = 0
    private var pixelScale = 500f
    private val fires = ArrayList<FloatArray>()
    private var skyBuffer = 0
    private var skyCount = 0

    private var cloudBuffer = 0
    private var cloudCount = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private var lastNanos = 0L

    private val look = LOOK.getValue(Zone.MEADOW).copyOf()

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // A fresh surface means anything we uploaded before is gone.
        chunks.clear()
        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uCam = GLES20.glGetUniformLocation(program, "uCam")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uFogStart = GLES20.glGetUniformLocation(program, "uFogStart")
        uFogEnd = GLES20.glGetUniformLocation(program, "uFogEnd")
        uFogColor = GLES20.glGetUniformLocation(program, "uFogColor")
        uEye = GLES20.glGetUniformLocation(program, "uEye")
        uSunDir = GLES20.glGetUniformLocation(program, "uSunDir")
        uSunPower = GLES20.glGetUniformLocation(program, "uSunPower")
        uClock = GLES20.glGetUniformLocation(program, "uClock")

        skyProgram = buildProgram(SKY_VERTEX, SKY_FRAGMENT)
        skyDir = GLES20.glGetAttribLocation(skyProgram, "aDir")
        skyMvp = GLES20.glGetUniformLocation(skyProgram, "uMvp")
        skyCam = GLES20.glGetUniformLocation(skyProgram, "uCam")
        skyHorizon = GLES20.glGetUniformLocation(skyProgram, "uHorizon")
        skyZenith = GLES20.glGetUniformLocation(skyProgram, "uZenith")
        skySun = GLES20.glGetUniformLocation(skyProgram, "uSun")
        skySunPower = GLES20.glGetUniformLocation(skyProgram, "uSunPower")
        skyTime = GLES20.glGetUniformLocation(skyProgram, "uSkyTime")
        skyCirrus = GLES20.glGetUniformLocation(skyProgram, "uCirrus")

        partProgram = buildProgram(PARTICLE_VERTEX, PARTICLE_FRAGMENT)
        partSeed = GLES20.glGetAttribLocation(partProgram, "aSeed")
        partMvp = GLES20.glGetUniformLocation(partProgram, "uMvp")
        partCam = GLES20.glGetUniformLocation(partProgram, "uCam")
        partOrigin = GLES20.glGetUniformLocation(partProgram, "uOrigin")
        partTime = GLES20.glGetUniformLocation(partProgram, "uTime")
        partPx = GLES20.glGetUniformLocation(partProgram, "uPx")
        partMode = GLES20.glGetUniformLocation(partProgram, "uMode")
        partTint = GLES20.glGetUniformLocation(partProgram, "uTint")
        partStrength = GLES20.glGetUniformLocation(partProgram, "uStrength")
        buildParticles()
        buildSky()
        buildClouds()

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        lastNanos = 0L
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / max(1, height).toFloat()
        val fovY = if (aspect > 1f) 56f else 64f
        Matrix.perspectiveM(proj, 0, fovY, aspect, 0.25f, 1600f)
        // How many pixels one metre covers at one metre away, for sizing snowflakes.
        pixelScale = height * 0.5f * proj[5]
    }

    override fun onDrawFrame(unused: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNanos = now
        game.update(dt)

        // Ease the sky and fog towards the current zone's look.
        val target = LOOK.getValue(game.currentZone)
        val k = (dt * 1.2f).coerceAtMost(1f)
        for (i in look.indices) look[i] += (target[i] - look[i]) * k

        GLES20.glClearColor(look[0], look[1], look[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val ex = game.x
        val ey = game.eyeY
        val ez = game.z
        val cp = cos(game.pitch)
        val fx = cp * sin(game.yaw)
        val fy = sin(game.pitch)
        val fz = cp * cos(game.yaw)
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + fx, ey + fy, ez + fz, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        drawSky(ex, ey, ez)
        streamChunks(ex, ez)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(uCam, ex, ey, ez)
        GLES20.glUniform3f(uEye, ex, ey, ez)
        GLES20.glUniform1f(uTime, game.time)
        GLES20.glUniform1f(uClock, game.time)
        GLES20.glUniform1f(uFogStart, look[3])
        GLES20.glUniform1f(uFogEnd, look[4])
        GLES20.glUniform3f(uFogColor, look[0], look[1], look[2])
        GLES20.glUniform3f(uSunDir, SUN_X, SUN_Y, SUN_Z)
        GLES20.glUniform1f(uSunPower, look[8])
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aColor)

        // Horizontal facing, for skipping chunks behind us.
        val hx = sin(game.yaw)
        val hz = cos(game.yaw)
        val viewLimit = look[4] + CHUNK_HALF_DIAG
        for ((key, gpu) in chunks) {
            val ccx = ((key % CHUNKS) + 0.5f) * CHUNK_M
            val ccz = ((key / CHUNKS) + 0.5f) * CHUNK_M
            val dx = ccx - ex
            val dz = ccz - ez
            if (hypot(dx, dz) > viewLimit) continue
            if (dx * hx + dz * hz < -CHUNK_HALF_DIAG) continue
            drawBuffer(gpu.buffer, gpu.count)
        }

        // Clouds drift slowly across the sky. They fade out much further away than the ground.
        if (look[8] > 0.05f && cloudCount > 0) {
            GLES20.glUniform1f(uFogStart, 300f)
            GLES20.glUniform1f(uFogEnd, 1500f)
            val drift = (game.time * 2.5f) % WORLD_SIZE
            for (copy in 0..1) {
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, drift - copy * WORLD_SIZE, 0f, 0f)
                Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
                Matrix.multiplyMM(mvp, 0, proj, 0, tmp, 0)
                GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
                GLES20.glUniform3f(uCam, ex - (drift - copy * WORLD_SIZE), ey, ez)
                drawBuffer(cloudBuffer, cloudCount)
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        drawParticles(ex, ey, ez)
    }

    /** Falling snow in Frostpeak, and smoke rising from campfires nearby. */
    private fun drawParticles(ex: Float, ey: Float, ez: Float) {
        val snow = look[9]
        var anyFire = false
        for (f in fires) if (hypot(f[0] - ex, f[2] - ez) < 140f) anyFire = true
        if (snow < 0.02f && !anyFire) return
        GLES20.glUseProgram(partProgram)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        GLES20.glUniformMatrix4fv(partMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(partCam, ex, ey, ez)
        GLES20.glUniform1f(partTime, game.time)
        GLES20.glUniform1f(partPx, pixelScale)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, partBuffer)
        GLES20.glEnableVertexAttribArray(partSeed)
        GLES20.glVertexAttribPointer(partSeed, 3, GLES20.GL_FLOAT, false, 12, 0)
        if (snow >= 0.02f) {
            GLES20.glUniform1f(partMode, 0f)
            GLES20.glUniform3f(partTint, 1f, 1f, 1f)
            GLES20.glUniform1f(partStrength, snow)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, PARTICLES)
        }
        GLES20.glUniform1f(partMode, 1f)
        GLES20.glUniform3f(partTint, 0.55f, 0.55f, 0.56f)
        GLES20.glUniform1f(partStrength, 1f)
        for (f in fires) {
            if (hypot(f[0] - ex, f[2] - ez) > 140f) continue
            GLES20.glUniform3f(partOrigin, f[0], f[1], f[2])
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 70)
        }
        GLES20.glDisableVertexAttribArray(partSeed)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun buildParticles() {
        val buf = ByteBuffer.allocateDirect(PARTICLES * 12).order(ByteOrder.nativeOrder())
        for (k in 0 until PARTICLES) {
            buf.putFloat(hash(k, 1, 555))
            buf.putFloat(hash(k, 2, 555))
            buf.putFloat(hash(k, 3, 555))
        }
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        partBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, partBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, PARTICLES * 12, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        fires.clear()
        for (lm in world.landmarks) {
            if (lm.kind == Kind.FIRE) fires.add(floatArrayOf(lm.x, world.terrainAt(lm.x, lm.z), lm.z))
        }
        // Chimneys smoke too.
        for (st in world.structures) {
            for (sm in st.smoke) fires.add(floatArrayOf(sm[0], sm[1] - 0.6f, sm[2]))
        }
    }

    private fun drawBuffer(buffer: Int, count: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffer)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, 0)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_UNSIGNED_BYTE, true, STRIDE, 12)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }

    private fun drawSky(ex: Float, ey: Float, ez: Float) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(skyProgram)
        GLES20.glUniformMatrix4fv(skyMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(skyCam, ex, ey, ez)
        GLES20.glUniform3f(skyHorizon, look[0], look[1], look[2])
        GLES20.glUniform3f(skyZenith, look[5], look[6], look[7])
        GLES20.glUniform3f(skySun, SUN_X, SUN_Y, SUN_Z)
        GLES20.glUniform1f(skySunPower, look[8])
        GLES20.glUniform1f(skyTime, game.time)
        GLES20.glUniform1f(skyCirrus, look[10])
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glEnableVertexAttribArray(skyDir)
        GLES20.glVertexAttribPointer(skyDir, 3, GLES20.GL_FLOAT, false, 12, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, skyCount)
        GLES20.glDisableVertexAttribArray(skyDir)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    /** A dome of directions around the camera, coloured by the sky shader. */
    private fun buildSky() {
        val around = 24
        val rings = 8
        val data = ArrayList<Float>()
        fun dir(ring: Int, seg: Int) {
            val elev = -0.3f + (ring.toFloat() / rings) * (1.5707964f + 0.3f)
            val az = seg.toFloat() / around * 6.2831855f
            data.add(cos(elev) * cos(az))
            data.add(sin(elev))
            data.add(cos(elev) * sin(az))
        }
        for (r in 0 until rings) {
            for (sgm in 0 until around) {
                dir(r, sgm)
                dir(r, sgm + 1)
                dir(r + 1, sgm + 1)
                dir(r, sgm)
                dir(r + 1, sgm + 1)
                dir(r + 1, sgm)
            }
        }
        val buf = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
        for (v in data) buf.putFloat(v)
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        skyBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        skyCount = data.size / 3
    }

    /** Puffy low-poly clouds scattered high over the whole map. */
    private fun buildClouds() {
        val m = MeshBuilder(4096)
        for (c in 0 until 40) {
            val cx = hash(c, 1, 321) * WORLD_SIZE
            val cz = hash(c, 2, 321) * WORLD_SIZE
            val cy = 190f + hash(c, 3, 321) * 90f
            val size = 14f + hash(c, 4, 321) * 16f
            val puffs = 3 + (hash(c, 5, 321) * 3f).toInt()
            for (pf in 0 until puffs) {
                val ox = (hash(c, 10 + pf, 322) - 0.5f) * size * 2.2f
                val oz = (hash(c, 20 + pf, 322) - 0.5f) * size * 1.2f
                val r = size * (0.6f + 0.5f * hash(c, 30 + pf, 322))
                m.blob(cx + ox, cy, cz + oz, r, r * 0.45f, r * 0.8f, 0xF4F6FA, c * 13 + pf, 0.18f)
            }
        }
        val data = m.finish()
        cloudCount = m.vertexCount
        GLES20.glGenBuffers(1, ids, 0)
        cloudBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cloudBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, cloudCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    /** Uploads freshly built chunks, asks for missing nearby ones, drops far-away ones. */
    private fun streamChunks(ex: Float, ez: Float) {
        for (n in 0 until 3) {
            val built = builder.done.poll() ?: break
            builder.uploaded(built.key)
            val data = built.data
            if (data == null || built.vertexCount == 0 || chunks.containsKey(built.key)) continue
            GLES20.glGenBuffers(1, ids, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, built.vertexCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            chunks[built.key] = Gpu(ids[0], built.vertexCount)
        }

        val pcx = floor(ex / CHUNK_M).toInt()
        val pcz = floor(ez / CHUNK_M).toInt()
        val reach = (LOAD_RADIUS / CHUNK_M).toInt() + 1
        for (ring in 0..reach) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(abs(dx), abs(dz)) != ring) continue
                    val cx = pcx + dx
                    val cz = pcz + dz
                    if (cx < 0 || cz < 0 || cx >= CHUNKS || cz >= CHUNKS) continue
                    val key = cz * CHUNKS + cx
                    if (chunks.containsKey(key) || builder.isPending(key)) continue
                    val d = hypot((cx + 0.5f) * CHUNK_M - ex, (cz + 0.5f) * CHUNK_M - ez)
                    if (d < LOAD_RADIUS) builder.request(key)
                }
            }
        }

        val it = chunks.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val key = e.key
            val d = hypot(((key % CHUNKS) + 0.5f) * CHUNK_M - ex, ((key / CHUNKS) + 0.5f) * CHUNK_M - ez)
            if (d > UNLOAD_RADIUS) {
                ids[0] = e.value.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
                it.remove()
            }
        }
    }

    private fun buildProgram(vsSource: String, fsSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Link failed: " + GLES20.glGetProgramInfoLog(prog))
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Shader failed: " + GLES20.glGetShaderInfoLog(shader))
        }
        return shader
    }
}
