package com.keystone.rpg

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

private const val LOAD_RADIUS = 600f
private const val UNLOAD_RADIUS = 780f
private const val CHUNK_HALF_DIAG = 136f
private const val SKY_RADIUS = 800f

private const val VERTEX_SHADER = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform float uTime;
uniform float uFogStart;
uniform float uFogEnd;
attribute vec3 aPos;
attribute vec4 aColor;
varying vec3 vColor;
varying float vFog;
varying vec3 vPos;
varying float vFlag;
void main() {
    vec3 p = aPos;
    vec3 col = aColor.rgb;
    float fogMul = 1.0;
    float f = aColor.a;
    if (f < 0.3) {
        p.y += sin(uTime * 1.6 + aPos.x * 0.35 + aPos.z * 0.25) * 0.12;
    } else if (f < 0.65) {
        fogMul = 0.35;
    } else if (f < 0.8) {
        p.x += sin(uTime * 2.2 + aPos.x * 0.7 + aPos.z * 0.3) * 0.09;
        p.z += cos(uTime * 1.9 + aPos.z * 0.6 + aPos.x * 0.2) * 0.07;
    }
    float d = distance(aPos, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0) * fogMul;
    vColor = col;
    vPos = p;
    vFlag = f;
    gl_Position = uMvp * vec4(p, 1.0);
}
"""

private const val FRAGMENT_SHADER = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 uFogColor;
uniform vec3 uEye;
uniform vec3 uSunDir;
uniform float uSunPower;
uniform float uClock;
varying vec3 vColor;
varying float vFog;
varying vec3 vPos;
varying float vFlag;

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
    vec3 col = vColor;
    float dist = distance(vPos, uEye);
    if (vFlag > 0.8 && vFlag < 0.95) {
        // Fine detail on the ground so it doesn't look flat up close.
        float n = noise(vPos.xz * 0.9) * 0.6 + noise(vPos.xz * 3.3) * 0.4;
        float amount = 1.0 - smoothstep(40.0, 160.0, dist);
        col *= 1.0 + (n - 0.5) * 0.3 * amount;
    } else if (vFlag < 0.3) {
        // Water: reflects the sky at low angles and sparkles in the sun.
        vec3 v = normalize(uEye - vPos);
        float fres = pow(1.0 - clamp(v.y, 0.0, 1.0), 3.0);
        col = mix(col, uFogColor * 1.05, fres * 0.7);
        vec2 w = vec2(noise(vPos.xz * 0.7 + vec2(uClock * 0.7, 0.0)),
                      noise(vPos.xz * 0.7 + vec2(0.0, uClock * 0.55)));
        vec3 nrm = normalize(vec3((w.x - 0.5) * 0.4, 1.0, (w.y - 0.5) * 0.4));
        vec3 r = reflect(-v, nrm);
        float spec = pow(max(dot(r, uSunDir), 0.0), 60.0);
        col += vec3(1.0, 0.95, 0.85) * spec * uSunPower;
    }
    gl_FragColor = vec4(mix(col, uFogColor, vFog), 1.0);
}
"""

private const val SKY_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
attribute vec3 aDir;
varying vec3 vDir;
void main() {
    vDir = aDir;
    gl_Position = uMvp * vec4(uCam + aDir * 800.0, 1.0);
}
"""

private const val SKY_FRAGMENT = """
precision mediump float;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSun;
uniform float uSunPower;
varying vec3 vDir;
void main() {
    vec3 d = normalize(vDir);
    float t = clamp(d.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(t, 0.55));
    float s = max(dot(d, uSun), 0.0);
    col += vec3(1.0, 0.95, 0.8) * (pow(s, 500.0) * 1.8 + pow(s, 10.0) * 0.22) * uSunPower;
    gl_FragColor = vec4(col, 1.0);
}
"""

/**
 * Look of each zone: horizon/fog colour (3), fog start, fog end,
 * sky colour straight up (3), sun strength.
 */
private val LOOK = mapOf(
    Zone.MEADOW to floatArrayOf(0.70f, 0.82f, 0.93f, 130f, 560f, 0.26f, 0.50f, 0.86f, 1f),
    Zone.FOREST to floatArrayOf(0.60f, 0.72f, 0.76f, 60f, 380f, 0.30f, 0.46f, 0.62f, 0.7f),
    Zone.DESERT to floatArrayOf(0.95f, 0.85f, 0.68f, 120f, 560f, 0.40f, 0.60f, 0.86f, 1.2f),
    Zone.SNOW to floatArrayOf(0.86f, 0.90f, 0.95f, 40f, 320f, 0.56f, 0.66f, 0.80f, 0.6f),
    Zone.CAVES to floatArrayOf(0.14f, 0.11f, 0.20f, 15f, 170f, 0.05f, 0.04f, 0.08f, 0f),
)

/** Picks a screen setup with a fine depth buffer if the phone has one, so distant things don't flicker. */
class DepthConfigChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (depth in intArrayOf(24, 16)) {
            val attribs = intArrayOf(
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depth,
                EGL10.EGL_RENDERABLE_TYPE, 4, // OpenGL ES 2
                EGL10.EGL_NONE,
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (egl.eglChooseConfig(display, attribs, configs, 1, count) && count[0] > 0) {
                val c = configs[0]
                if (c != null) return c
            }
        }
        throw IllegalArgumentException("No suitable screen setup found")
    }
}

/** Draws the 3D world from the hero's eyes. Runs on its own drawing thread. */
class WorldRenderer(private val game: Game) : GLSurfaceView.Renderer {
    private val world = game.world
    private val builder = ChunkBuilder(world)

    private class Gpu(val buffer: Int, val count: Int)

    private val chunks = HashMap<Int, Gpu>()
    private val ids = IntArray(1)

    private var program = 0
    private var aPos = 0
    private var aColor = 0
    private var uMvp = 0
    private var uCam = 0
    private var uTime = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uFogColor = 0
    private var uEye = 0
    private var uSunDir = 0
    private var uSunPower = 0
    private var uClock = 0

    private var skyProgram = 0
    private var skyDir = 0
    private var skyMvp = 0
    private var skyCam = 0
    private var skyHorizon = 0
    private var skyZenith = 0
    private var skySun = 0
    private var skySunPower = 0
    private var skyBuffer = 0
    private var skyCount = 0

    private var cloudBuffer = 0
    private var cloudCount = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private var lastNanos = 0L

    private val look = LOOK.getValue(Zone.MEADOW).copyOf()

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // A fresh surface means anything we uploaded before is gone.
        chunks.clear()
        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uCam = GLES20.glGetUniformLocation(program, "uCam")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uFogStart = GLES20.glGetUniformLocation(program, "uFogStart")
        uFogEnd = GLES20.glGetUniformLocation(program, "uFogEnd")
        uFogColor = GLES20.glGetUniformLocation(program, "uFogColor")
        uEye = GLES20.glGetUniformLocation(program, "uEye")
        uSunDir = GLES20.glGetUniformLocation(program, "uSunDir")
        uSunPower = GLES20.glGetUniformLocation(program, "uSunPower")
        uClock = GLES20.glGetUniformLocation(program, "uClock")

        skyProgram = buildProgram(SKY_VERTEX, SKY_FRAGMENT)
        skyDir = GLES20.glGetAttribLocation(skyProgram, "aDir")
        skyMvp = GLES20.glGetUniformLocation(skyProgram, "uMvp")
        skyCam = GLES20.glGetUniformLocation(skyProgram, "uCam")
        skyHorizon = GLES20.glGetUniformLocation(skyProgram, "uHorizon")
        skyZenith = GLES20.glGetUniformLocation(skyProgram, "uZenith")
        skySun = GLES20.glGetUniformLocation(skyProgram, "uSun")
        skySunPower = GLES20.glGetUniformLocation(skyProgram, "uSunPower")
        buildSky()
        buildClouds()

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        lastNanos = 0L
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / max(1, height).toFloat()
        val fovY = if (aspect > 1f) 56f else 64f
        Matrix.perspectiveM(proj, 0, fovY, aspect, 0.25f, 1600f)
    }

    override fun onDrawFrame(unused: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNanos = now
        game.update(dt)

        // Ease the sky and fog towards the current zone's look.
        val target = LOOK.getValue(game.currentZone)
        val k = (dt * 1.2f).coerceAtMost(1f)
        for (i in look.indices) look[i] += (target[i] - look[i]) * k

        GLES20.glClearColor(look[0], look[1], look[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val ex = game.x
        val ey = game.eyeY
        val ez = game.z
        val cp = cos(game.pitch)
        val fx = cp * sin(game.yaw)
        val fy = sin(game.pitch)
        val fz = cp * cos(game.yaw)
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + fx, ey + fy, ez + fz, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        drawSky(ex, ey, ez)
        streamChunks(ex, ez)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(uCam, ex, ey, ez)
        GLES20.glUniform3f(uEye, ex, ey, ez)
        GLES20.glUniform1f(uTime, game.time)
        GLES20.glUniform1f(uClock, game.time)
        GLES20.glUniform1f(uFogStart, look[3])
        GLES20.glUniform1f(uFogEnd, look[4])
        GLES20.glUniform3f(uFogColor, look[0], look[1], look[2])
        GLES20.glUniform3f(uSunDir, SUN_X, SUN_Y, SUN_Z)
        GLES20.glUniform1f(uSunPower, look[8])
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aColor)

        // Horizontal facing, for skipping chunks behind us.
        val hx = sin(game.yaw)
        val hz = cos(game.yaw)
        val viewLimit = look[4] + CHUNK_HALF_DIAG
        for ((key, gpu) in chunks) {
            val ccx = ((key % CHUNKS) + 0.5f) * CHUNK_M
            val ccz = ((key / CHUNKS) + 0.5f) * CHUNK_M
            val dx = ccx - ex
            val dz = ccz - ez
            if (hypot(dx, dz) > viewLimit) continue
            if (dx * hx + dz * hz < -CHUNK_HALF_DIAG) continue
            drawBuffer(gpu.buffer, gpu.count)
        }

        // Clouds drift slowly across the sky. They fade out much further away than the ground.
        if (look[8] > 0.05f && cloudCount > 0) {
            GLES20.glUniform1f(uFogStart, 300f)
            GLES20.glUniform1f(uFogEnd, 1500f)
            val drift = (game.time * 2.5f) % WORLD_SIZE
            for (copy in 0..1) {
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, drift - copy * WORLD_SIZE, 0f, 0f)
                Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
                Matrix.multiplyMM(mvp, 0, proj, 0, tmp, 0)
                GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
                GLES20.glUniform3f(uCam, ex - (drift - copy * WORLD_SIZE), ey, ez)
                drawBuffer(cloudBuffer, cloudCount)
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    private fun drawBuffer(buffer: Int, count: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffer)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, 0)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_UNSIGNED_BYTE, true, STRIDE, 12)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }

    private fun drawSky(ex: Float, ey: Float, ez: Float) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(skyProgram)
        GLES20.glUniformMatrix4fv(skyMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(skyCam, ex, ey, ez)
        GLES20.glUniform3f(skyHorizon, look[0], look[1], look[2])
        GLES20.glUniform3f(skyZenith, look[5], look[6], look[7])
        GLES20.glUniform3f(skySun, SUN_X, SUN_Y, SUN_Z)
        GLES20.glUniform1f(skySunPower, look[8])
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glEnableVertexAttribArray(skyDir)
        GLES20.glVertexAttribPointer(skyDir, 3, GLES20.GL_FLOAT, false, 12, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, skyCount)
        GLES20.glDisableVertexAttribArray(skyDir)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    /** A dome of directions around the camera, coloured by the sky shader. */
    private fun buildSky() {
        val around = 24
        val rings = 8
        val data = ArrayList<Float>()
        fun dir(ring: Int, seg: Int) {
            val elev = -0.3f + (ring.toFloat() / rings) * (1.5707964f + 0.3f)
            val az = seg.toFloat() / around * 6.2831855f
            data.add(cos(elev) * cos(az))
            data.add(sin(elev))
            data.add(cos(elev) * sin(az))
        }
        for (r in 0 until rings) {
            for (sgm in 0 until around) {
                dir(r, sgm)
                dir(r, sgm + 1)
                dir(r + 1, sgm + 1)
                dir(r, sgm)
                dir(r + 1, sgm + 1)
                dir(r + 1, sgm)
            }
        }
        val buf = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
        for (v in data) buf.putFloat(v)
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        skyBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        skyCount = data.size / 3
    }

    /** Puffy low-poly clouds scattered high over the whole map. */
    private fun buildClouds() {
        val m = MeshBuilder(4096)
        for (c in 0 until 40) {
            val cx = hash(c, 1, 321) * WORLD_SIZE
            val cz = hash(c, 2, 321) * WORLD_SIZE
            val cy = 190f + hash(c, 3, 321) * 90f
            val size = 14f + hash(c, 4, 321) * 16f
            val puffs = 3 + (hash(c, 5, 321) * 3f).toInt()
            for (pf in 0 until puffs) {
                val ox = (hash(c, 10 + pf, 322) - 0.5f) * size * 2.2f
                val oz = (hash(c, 20 + pf, 322) - 0.5f) * size * 1.2f
                val r = size * (0.6f + 0.5f * hash(c, 30 + pf, 322))
                m.blob(cx + ox, cy, cz + oz, r, r * 0.45f, r * 0.8f, 0xF4F6FA, c * 13 + pf, 0.18f)
            }
        }
        val data = m.finish()
        cloudCount = m.vertexCount
        GLES20.glGenBuffers(1, ids, 0)
        cloudBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cloudBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, cloudCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    /** Uploads freshly built chunks, asks for missing nearby ones, drops far-away ones. */
    private fun streamChunks(ex: Float, ez: Float) {
        for (n in 0 until 3) {
            val built = builder.done.poll() ?: break
            builder.uploaded(built.key)
            val data = built.data
            if (data == null || built.vertexCount == 0 || chunks.containsKey(built.key)) continue
            GLES20.glGenBuffers(1, ids, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, built.vertexCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            chunks[built.key] = Gpu(ids[0], built.vertexCount)
        }

        val pcx = floor(ex / CHUNK_M).toInt()
        val pcz = floor(ez / CHUNK_M).toInt()
        val reach = (LOAD_RADIUS / CHUNK_M).toInt() + 1
        for (ring in 0..reach) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(abs(dx), abs(dz)) != ring) continue
                    val cx = pcx + dx
                    val cz = pcz + dz
                    if (cx < 0 || cz < 0 || cx >= CHUNKS || cz >= CHUNKS) continue
                    val key = cz * CHUNKS + cx
                    if (chunks.containsKey(key) || builder.isPending(key)) continue
                    val d = hypot((cx + 0.5f) * CHUNK_M - ex, (cz + 0.5f) * CHUNK_M - ez)
                    if (d < LOAD_RADIUS) builder.request(key)
                }
            }
        }

        val it = chunks.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val key = e.key
            val d = hypot(((key % CHUNKS) + 0.5f) * CHUNK_M - ex, ((key / CHUNKS) + 0.5f) * CHUNK_M - ez)
            if (d > UNLOAD_RADIUS) {
                ids[0] = e.value.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
                it.remove()
            }
        }
    }

    private fun buildProgram(vsSource: String, fsSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Link failed: " + GLES20.glGetProgramInfoLog(prog))
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Shader failed: " + GLES20.glGetShaderInfoLog(shader))
        }
        return shader
    }
}
