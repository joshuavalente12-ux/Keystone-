package com.keystone.rpg

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

private const val LOAD_RADIUS = 600f
private const val UNLOAD_RADIUS = 780f
private const val CHUNK_HALF_DIAG = 136f
private const val PARTICLES = 2200

private const val VERTEX_SHADER = """
// Keystone PBR - vertex shader
// Target: OpenGL ES 2.0 / GLSL ES 1.00 (works on every Android GPU).
//
// Vertex layout (20 bytes):
//   aPos    3 x float                  world position
//   aColor  4 x unsigned byte, normalized: rgb = UNLIT albedo (sRGB), a = material id / 255
//   aNormal 4 x signed byte,   normalized: xyz = smooth vertex normal (w unused, padding)
//
// Lighting is no longer baked into aColor: the fragment shader does it all.

uniform mat4 uMvp;
uniform vec3 uCam;
uniform float uTime;
uniform float uFogStart;
uniform float uFogEnd;

attribute vec3 aPos;
attribute vec4 aColor;
attribute vec3 aNormal;

varying vec3 vAlbedo;   // linear albedo
varying vec3 vNormal;   // world-space normal (unnormalized after interpolation)
varying vec3 vPos;      // world position (fragment shader reads it at highp)
varying float vId;      // material id 0..255
varying float vFog;     // 0 = clear, 1 = fully fogged

void main() {
    vec3 p = aPos;
    float id = floor(aColor.a * 255.0 + 0.5);
    float fogMul = 1.0;

    // Cheap vertex animation, chosen by material id.
    if (id < 50.0) {
        // Water swell.
        p.y += sin(uTime * 1.6 + aPos.x * 0.35 + aPos.z * 0.25) * 0.08
             + sin(uTime * 2.3 - aPos.x * 0.6 + aPos.z * 0.45) * 0.04;
    } else if (id < 80.0) {
        // Flame tips: 75 = campfire, 74 = hearth/torch, 73 = candle.
        float amp = id > 74.5 ? 1.0 : (id > 73.5 ? 0.2 : 0.025);
        if (id > 72.5) {
            p.x += sin(uTime * 9.0 + aPos.z * 7.0) * 0.14 * amp;
            p.z += cos(uTime * 7.3 + aPos.x * 7.0) * 0.14 * amp;
            p.y += sin(uTime * 11.0 + aPos.x * 5.0) * 0.25 * amp;
        }
        fogMul = 0.3;
    } else if (id < 140.0) {
        fogMul = 0.35;                     // glowing things cut through haze
    } else if (id < 160.5) {
        // Grass and fern tips sway.
        float w = sin(uTime * 1.3 + aPos.x * 0.05 + aPos.z * 0.04) * 0.5 + 0.7;
        p.x += sin(uTime * 2.2 + aPos.x * 0.7 + aPos.z * 0.3) * 0.1 * w;
        p.z += cos(uTime * 1.9 + aPos.z * 0.6 + aPos.x * 0.2) * 0.08 * w;
    } else if (id > 175.0 && id < 186.0) {
        // Leaves rustle.
        p.x += sin(uTime * 1.7 + aPos.y * 1.3 + aPos.z * 0.5) * 0.05;
        p.z += cos(uTime * 1.5 + aPos.y * 1.1 + aPos.x * 0.5) * 0.05;
    }

    vAlbedo = aColor.rgb * aColor.rgb;     // sRGB -> linear (gamma 2.0 approximation, no pow)
    vNormal = aNormal;
    vPos = p;
    vId = id;
    float d = distance(aPos, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0) * fogMul;
    gl_Position = uMvp * vec4(p, 1.0);
}
"""

private const val FRAGMENT_SHADER = """
// Keystone PBR - fragment shader
// Target: OpenGL ES 2.0 / GLSL ES 1.00 + GL_OES_standard_derivatives
// (the extension is supported by effectively every Android GPU; without it the
// shader still runs, just without bump detail).
//
// What it does, per pixel:
//   * picks roughness / metalness / bump height for the material procedurally
//     (no textures at all: zero texture bandwidth, which is what mobile GPUs hate most)
//   * perturbs the normal from that height using screen-space derivatives
//     (Mikkelsen "bump mapping unparametrized surfaces", so no tangents are needed)
//   * lights it with a GGX / Smith / Schlick BRDF tuned for fp16
//   * adds image-based-style ambient from an analytic sky (no cubemap) using
//     Karis' mobile EnvBRDF approximation
//   * tone maps (ACES fit), then applies distance fog
//
// Mobile performance notes:
//   * Everything is mediump except world position and noise input, which need
//     highp because the world is ~3 km across (fp16 would shimmer).
//   * All derivative calls happen OUTSIDE the material branches (uniform control
//     flow), which is required for correct results on tiled mobile GPUs.
//   * Detail (bump, noise octaves) fades out with distance; far pixels are cheap.
//   * pow() is only used where unavoidable; Fresnel uses multiplies.
//   * Roughness is clamped to 0.089 so the GGX lobe can't overflow fp16.

#extension GL_OES_standard_derivatives : enable

#ifdef GL_FRAGMENT_PRECISION_HIGH
#define HP highp
#else
#define HP mediump
#endif
precision mediump float;

uniform HP vec3 uEye;       // camera position
uniform vec3 uSunDir;       // normalized, pointing TOWARDS the sun
uniform vec3 uSunColor;     // linear sun colour * intensity (e.g. vec3(3.2, 3.0, 2.7))
uniform vec3 uSkyZenith;    // linear sky colour straight up
uniform vec3 uSkyHorizon;   // linear sky colour at the horizon
uniform vec3 uGroundBounce; // linear light bounced up from the ground
uniform vec3 uFogColor;     // DISPLAY-space fog colour (matches the sky dome)
uniform float uClock;       // seconds, for water / fire / sparkle
uniform float uShadow;      // 1 = lit; hook for a shadow-map term later
uniform float uExposure;    // overall brightness before tone mapping

varying vec3 vAlbedo;
varying vec3 vNormal;
varying HP vec3 vPos;
varying float vId;
varying float vFog;

const float PI = 3.14159265;
const float MIN_ROUGH = 0.089;

// ------------------------------------------------------------------ noise

float hash(HP vec2 p) {
    HP vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise(HP vec2 p) {
    HP vec2 i = floor(p);
    vec2 f = fract(p);                       // small, fine at mediump
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Octaves are skipped when "detail" is low, so distant pixels pay for one lookup.
float fbm(HP vec2 p, float detail) {
    float n = noise(p) * 0.55;
    if (detail > 0.0) n += (noise(p * 2.03) * 0.3 + noise(p * 4.1) * 0.15) * detail;
    else n += 0.225;
    return n;
}

// ------------------------------------------------------------------ BRDF

// GGX normal distribution. Uses |N x H|^2 instead of 1 - NoH^2, which loses all
// precision in fp16 for shiny surfaces (trick from Filament).
float D_GGX(float alpha, float NoH, vec3 n, vec3 h) {
    vec3 NxH = cross(n, h);
    float oneMinusNoH2 = dot(NxH, NxH);
    float a = NoH * alpha;
    float k = alpha / (oneMinusNoH2 + a * a);
    return min(k * k * (1.0 / PI), 65504.0);
}

// Height-correlated Smith visibility, fast approximation (Hammon).
float V_SmithFast(float alpha, float NoV, float NoL) {
    return 0.5 / max(mix(2.0 * NoL * NoV, NoL + NoV, alpha), 1e-4);
}

vec3 F_Schlick(vec3 f0, float VoH) {
    float x = 1.0 - VoH;
    float x2 = x * x;
    return f0 + (1.0 - f0) * (x2 * x2 * x);
}

// Split-sum environment BRDF, analytic fit for mobile (Karis 2014). No LUT texture.
vec3 EnvBRDFApprox(vec3 specColor, float rough, float NoV) {
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
    const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = rough * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NoV)) * r.x + r.y;
    vec2 AB = vec2(-1.04, 1.04) * a004 + r.zw;
    return specColor * AB.x + AB.y;
}

// Analytic sky radiance in direction d, blurred towards its average by roughness.
vec3 skyRadiance(vec3 d, float rough) {
    float up = clamp(d.y, 0.0, 1.0);
    vec3 sky = mix(uSkyHorizon, uSkyZenith, sqrt(up));
    vec3 below = uGroundBounce;
    vec3 sharp = d.y >= 0.0 ? sky : mix(uSkyHorizon, below, clamp(-d.y * 4.0, 0.0, 1.0));
    vec3 avg = (uSkyHorizon + uSkyZenith) * 0.5;
    return mix(sharp, avg, rough * rough);
}

vec3 acesFit(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

// ------------------------------------------------------------------ main

void main() {
    HP vec3 P = vPos;
    vec3 V = normalize(uEye - P);
    float dist = distance(P, uEye);
    HP vec3 fpx = dFdx(P);
    HP vec3 fpy = dFdy(P);
    float foot = float(max(length(fpx), length(fpy)));  // metres per pixel
    float near = (1.0 - smoothstep(30.0, 150.0, dist)) * (1.0 - smoothstep(0.012, 0.05, foot));

    vec3 Ng = vNormal;
    float nLen = dot(Ng, Ng);
    Ng = nLen > 1e-4 ? Ng * inversesqrt(nLen) : vec3(0.0, 1.0, 0.0);
    if (dot(Ng, V) < 0.0) Ng = -Ng;                      // double-sided leaves, planks, quads

    // Horizontal texture axis along a wall, so vertical surfaces get proper
    // 2D patterns without UVs or tangents.
    HP vec2 uvWall = vec2(abs(Ng.x) > abs(Ng.z) ? P.z : P.x, P.y);
    HP vec2 uv = abs(Ng.y) > 0.7 ? P.xz : uvWall;

    // ---- Material parameters (defaults = generic painted object).
    vec3 albedo = vAlbedo;
    float rough = 0.55;
    float metal = 0.0;
    HP float h = 0.0;       // procedural height, in metres (highp: its screen derivatives are tiny up close)
    float bump = 0.0;       // how strongly h tilts the normal
    float wrap = 0.0;       // light wrapping round the terminator (soft materials)
    float transl = 0.0;     // light shining through from behind (leaves, grass)
    float f0Base = 0.04;    // dielectric reflectance at normal incidence
    vec3 emissive = vec3(0.0);
    float emit = 0.0;       // 1 = pure emissive, lighting skipped in the mix

    float id = vId;
    if (id < 50.0) {
        // Water: dark body, very smooth, normal from two scrolling wave layers.
        HP vec2 q = P.xz;
        h = noise(q * 0.45 + vec2(uClock * 0.35, uClock * 0.1)) * 0.12
          + noise(q * 1.6 + vec2(-uClock * 0.6, uClock * 0.5)) * 0.04 * near;
        bump = 1.0;
        albedo = vAlbedo * 0.3;             // shallow turquoise to deep blue, darkened
        rough = 0.06;
        f0Base = 0.02;
    } else if (id < 80.0) {
        float fl = 0.75 + 0.5 * noise(vec2(P.y * 4.0 - uClock * 6.0, (P.x + P.z) * 5.0));
        emissive = albedo * fl * 4.0;
        emit = 1.0;
    } else if (id < 140.0) {
        emissive = albedo * (2.2 + 0.25 * sin(uClock * 2.0 + P.x + P.z));
        emit = 1.0;
    } else if (id < 163.0) {
        // Grass blades and fern fronds.
        rough = 0.75;
        wrap = 0.5;
        transl = 0.5;
        albedo *= 0.9 + 0.2 * noise(P.xz * 6.0);
    } else if (id < 186.0) {
        // Leaves: clumps of light and dark foliage, lit through from behind.
        float n = noise(P.xz * 2.4 + P.y * 1.9) * 0.6 + noise(P.xz * 7.0 - P.y * 5.0) * 0.4 * near;
        albedo *= 0.7 + 0.6 * n;
        h = n * 0.15;
        bump = 0.6;
        rough = 0.6;
        wrap = 0.4;
        transl = 0.7;
    } else if (id < 197.0) {
        // Bark: deep vertical ridges.
        float r = noise(vec2(uvWall.x * 9.0, P.y * 1.2)) * 0.7 + noise(vec2(uvWall.x * 20.0, P.y * 3.0)) * 0.3 * near;
        h = r * 0.05;
        bump = 1.0;
        albedo *= 0.6 + 0.6 * r;
        rough = 0.9;
    } else if (id < 202.0) {
        // Planks: long grain plus a groove between boards.
        float g = noise(vec2(P.y * 22.0 + uv.x * 0.8, uv.x * 1.5 + uv.y * 0.3));
        float board = fract(uv.y * 4.0);
        float groove = smoothstep(0.0, 0.06, board) * smoothstep(1.0, 0.94, board);
        h = g * 0.004 + groove * 0.01;
        bump = 1.0;
        albedo *= (0.78 + 0.36 * g) * (0.75 + 0.25 * groove);
        rough = 0.6 + 0.15 * (1.0 - g);
    } else if (id < 209.0) {
        // Dressed stone: staggered blocks with bevelled edges and dark mortar.
        HP vec2 b = uv * vec2(1.4, 2.4);
        b.x += floor(b.y) * 0.5;
        vec2 f = fract(b);
        vec2 e = min(f, 1.0 - f);
        float edge = smoothstep(0.0, 0.08, min(e.x * 0.6, e.y));
        float blockTone = hash(floor(b));
        float n = fbm(uv * 2.2, near);
        h = edge * 0.03 + n * 0.01;
        bump = 1.0;
        albedo *= mix(0.45, (0.8 + 0.3 * blockTone) * (0.8 + 0.4 * n), edge);
        rough = mix(0.95, 0.72, edge);
    } else if (id < 219.0) {
        // Plaster and cloth: fine unevenness.
        float n = noise(uv * 3.5) * 0.6 + noise(uv * 12.0) * 0.4 * near;
        h = n * 0.004;
        bump = 1.0;
        albedo *= 0.9 + 0.2 * n;
        rough = 0.92;
        wrap = 0.15;
    } else if (id < 226.0) {
        // Roof shingles: each row overlaps the one below, so it steps.
        HP float row = P.y * 3.4;
        float fr = fract(row);
        float tile = hash(vec2(floor((P.x + P.z) * 1.7 + floor(row) * 0.5), floor(row)));
        h = fr * 0.03;
        bump = 1.0;
        albedo *= (0.8 + 0.3 * tile) * (1.0 - 0.35 * smoothstep(0.8, 1.0, fr));
        rough = 0.65 + 0.2 * tile;
    } else if (id < 233.0) {
        // Grass-covered ground: patchy with dry spots.
        float n = fbm(P.xz * 0.5, near);
        float fine = noise(P.xz * 9.0) * near;
        float dry = smoothstep(0.55, 0.8, noise(P.xz * 0.07));
        albedo = mix(albedo, albedo * vec3(1.18, 1.08, 0.72), dry * 0.55);
        albedo *= 0.78 + 0.3 * n + 0.14 * fine;
        h = n * 0.08 + fine * 0.02;
        bump = 1.0;
        rough = 0.95;
        wrap = 0.2;
    } else if (id < 238.0) {
        // Rock: layered strata with rough breaks.
        float strata = sin(P.y * 1.4 + noise(P.xz * 0.15) * 5.0);
        float n = fbm(uvWall * 0.9, near);
        h = strata * 0.06 + n * 0.12;
        bump = 1.2;
        albedo *= 0.78 + 0.08 * strata + 0.34 * n;
        rough = 0.78 + 0.15 * n;
    } else if (id < 243.0) {
        // Dirt tracks: dusty with scattered pebbles.
        HP vec2 c = floor(P.xz * 3.0);
        vec2 f = fract(P.xz * 3.0) - 0.5;
        float peb = step(0.78, hash(c)) * (1.0 - smoothstep(0.12, 0.28, length(f))) * near;
        float n = fbm(P.xz * 1.3, near);
        h = n * 0.03 + peb * 0.03;
        bump = 1.0;
        albedo *= (0.82 + 0.32 * n) * (1.0 - 0.25 * peb) + 0.1 * peb * hash(c + 3.0);
        rough = 0.95 - 0.25 * peb;
    } else if (id < 248.0) {
        // Sand: wind ripples, plus the odd grain that catches the sun.
        float rip = sin((P.x * 0.9 + P.z * 0.4) * 2.4 + noise(P.xz * 0.25) * 6.0);
        h = rip * 0.02;
        bump = 1.0;
        albedo *= 0.95 + 0.05 * rip;
        rough = 0.85;
        float grain = step(0.992, hash(floor(P.xz * 12.0)));
        rough = mix(rough, 0.15, grain * near);
    } else if (id < 253.0) {
        // Snow: soft drifts, light scatters inside it, glittering crystals.
        float n = noise(P.xz * 0.6);
        h = n * 0.05;
        bump = 0.7;
        albedo *= 0.94 + 0.08 * n;
        wrap = 0.45;
        float crystal = step(0.985, hash(floor(P.xz * 7.0 + P.y * 3.0)));
        rough = mix(0.5, 0.08, crystal * near);
    } else if (id < 254.5) {
        // Metal (iron gates, armour, blades): brushed, with scratches.
        float s = noise(vec2(uv.x * 40.0, uv.y * 2.0)) * near;
        metal = 1.0;
        rough = 0.3 + 0.25 * s;
        h = s * 0.0015;
        bump = 1.0;
    } else {
        albedo *= 0.94 + 0.12 * noise(uv * 4.0) * near;
    }

    // ---- Procedural normal mapping (outside all branches: uniform control flow).
    vec3 N = Ng;
#ifdef GL_OES_standard_derivatives
    {
        // Pixel-sized derivatives are ~1e-3 m up close, and their products
        // (~1e-6) vanish in 16-bit floats, which blew the normal up to white.
        // Rescale everything to unit size first so nothing underflows.
        HP vec3 dPdx = dFdx(P);
        HP vec3 dPdy = dFdy(P);
        HP float dhx = dFdx(h);
        HP float dhy = dFdy(h);
        HP float m = max(max(abs(dPdx.x), abs(dPdx.y)), max(abs(dPdx.z), max(abs(dPdy.x), max(abs(dPdy.y), abs(dPdy.z)))));
        if (m > 1e-7) {
            HP float inv = 1.0 / m;
            vec3 sx = vec3(dPdx * inv);
            vec3 sy = vec3(dPdy * inv);
            float hx = float(dhx * inv);
            float hy = float(dhy * inv);
            vec3 r1 = cross(sy, Ng);
            vec3 r2 = cross(Ng, sx);
            float det = dot(sx, r1);
            vec3 surfGrad = sign(det) * (hx * r1 + hy * r2);
            float k = bump * near * 0.6;
            vec3 nn = abs(det) * Ng - surfGrad * k;
            float nl = dot(nn, nn);
            if (nl > 1e-6) N = nn * inversesqrt(nl);
        }
    }
#endif

    // ---- Direct sun light.
    vec3 L = uSunDir;
    vec3 H = normalize(V + L);
    float NoV = abs(dot(N, V)) + 1e-4;
    float NoLraw = dot(N, L);
    float NoL = clamp(NoLraw, 0.0, 1.0);
    float NoH = clamp(dot(N, H), 0.0, 1.0);
    float VoH = clamp(dot(V, H), 0.0, 1.0);

    rough = max(rough, MIN_ROUGH);
    float alpha = rough * rough;
    vec3 f0 = mix(vec3(f0Base), albedo, metal);
    vec3 diffuseColor = albedo * (1.0 - metal);

    float D = D_GGX(alpha, NoH, N, H);
    float Vis = V_SmithFast(alpha, NoV, NoL);
    vec3 F = F_Schlick(f0, VoH);
    vec3 spec = D * Vis * F;

    // Wrapped diffuse for soft materials, and light through thin leaves.
    float NoLwrap = clamp((NoLraw + wrap) / (1.0 + wrap), 0.0, 1.0);
    vec3 diff = diffuseColor * (1.0 / PI) * NoLwrap * (1.0 - F);
    float back = clamp(dot(V, -L), 0.0, 1.0);
    back *= back;
    vec3 through = diffuseColor * transl * back * back * clamp(-NoLraw + 0.3, 0.0, 1.0);

    vec3 direct = (diff * PI + spec * PI * NoL + through) * uSunColor * uShadow;

    // ---- Ambient: analytic sky instead of a cubemap.
    float hemi = N.y * 0.5 + 0.5;
    vec3 ambDiffuse = diffuseColor * mix(uGroundBounce, (uSkyHorizon + uSkyZenith) * 0.5, hemi);
    vec3 R = reflect(-V, N);
    // Stop bump-mapped normals reflecting the sky from below the real surface.
    float horizon = clamp(1.0 + dot(R, Ng), 0.0, 1.0);
    vec3 ambSpec = EnvBRDFApprox(f0, rough, NoV) * skyRadiance(R, rough) * horizon * horizon;
    // Rough, upward-facing crevices see less sky: cheap specular occlusion.
    float occ = mix(0.6, 1.0, hemi);
    vec3 ambient = (ambDiffuse + ambSpec) * occ;

    vec3 lit = direct + ambient;
    vec3 color = mix(lit, emissive, emit);

    // ---- Tone map, back to display space, then haze.
    color = acesFit(color * uExposure);
    color = sqrt(color);                   // linear -> display (matches the gamma 2 input)
    gl_FragColor = vec4(mix(color, uFogColor, vFog), 1.0);
}
"""

/** Plain sun-and-fog shading, used only if a phone can't compile the PBR shader. */
private const val FALLBACK_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform float uFogStart;
uniform float uFogEnd;
attribute vec3 aPos;
attribute vec4 aColor;
attribute vec3 aNormal;
varying vec3 vColor;
varying float vFog;
void main() {
    vec3 n = aNormal;
    float l = dot(n, n);
    n = l > 1e-4 ? n * inversesqrt(l) : vec3(0.0, 1.0, 0.0);
    float id = floor(aColor.a * 255.0 + 0.5);
    float sun = max(dot(n, vec3(-0.458, 0.815, -0.356)), 0.0);
    float lit = id < 140.0 ? 1.0 : 0.5 + 0.6 * sun + 0.06 * n.y;
    vColor = aColor.rgb * lit;
    float d = distance(aPos, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    gl_Position = uMvp * vec4(aPos, 1.0);
}
"""

private const val FALLBACK_FRAGMENT = """
precision mediump float;
uniform vec3 uFogColor;
varying vec3 vColor;
varying float vFog;
void main() {
    gl_FragColor = vec4(mix(vColor, uFogColor, vFog), 1.0);
}
"""

private const val SKY_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
attribute vec3 aDir;
varying vec3 vDir;
void main() {
    vDir = aDir;
    gl_Position = uMvp * vec4(uCam + aDir * 800.0, 1.0);
}
"""

private const val SKY_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSun;
uniform float uSunPower;
uniform float uSkyTime;
uniform float uCirrus;
varying vec3 vDir;

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

void main() {
    vec3 d = normalize(vDir);
    float t = clamp(d.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(t, 0.5));
    // Bright haze low down, and light scattered around the sun.
    col = mix(col, uHorizon * 1.06, pow(1.0 - t, 10.0) * 0.6);
    float s = max(dot(d, uSun), 0.0);
    col += vec3(1.0, 0.88, 0.68) * pow(s, 5.0) * 0.16 * uSunPower;
    col += vec3(1.0, 0.95, 0.82) * pow(s, 90.0) * 0.45 * uSunPower;
    col += vec3(1.0, 0.98, 0.92) * pow(s, 1200.0) * 3.0 * uSunPower;
    // Thin high clouds drifting across the sky.
    if (d.y > 0.03) {
        vec2 uv = d.xz / (d.y + 0.15) * 1.6 + vec2(uSkyTime * 0.012, uSkyTime * 0.004);
        float c = noise(uv) * 0.55 + noise(uv * 2.7 + 3.1) * 0.3 + noise(uv * 6.3 + 7.7) * 0.15;
        c = smoothstep(0.5, 0.85, c) * smoothstep(0.03, 0.3, d.y) * uCirrus;
        vec3 cloud = mix(vec3(0.92, 0.94, 0.98), vec3(1.0, 0.97, 0.9), s);
        col = mix(col, cloud, c * 0.7);
    }
    gl_FragColor = vec4(col, 1.0);
}
"""

private const val PARTICLE_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform vec3 uOrigin;
uniform float uTime;
uniform float uPx;
uniform float uMode;
attribute vec3 aSeed;
varying float vAlpha;
void main() {
    vec3 p;
    float size;
    if (uMode < 0.5) {
        // Snow: falls and drifts in a box that always surrounds you.
        vec3 box = vec3(56.0, 30.0, 56.0);
        p = aSeed * box;
        p.y -= uTime * (1.1 + aSeed.x * 1.1);
        p.x += uTime * 0.6 + sin(uTime * 0.8 + aSeed.z * 30.0) * 0.9;
        p.z += cos(uTime * 0.6 + aSeed.x * 25.0) * 0.9;
        vec3 o = uCam - box * 0.5;
        p = o + mod(p - o, box);
        size = 0.07 + aSeed.y * 0.06;
        vAlpha = 0.9;
    } else {
        // Smoke: puffs rise, spread and fade.
        float life = fract(aSeed.y + uTime * 0.11);
        float ang = aSeed.x * 6.2831;
        float r = (0.15 + life * 1.6) * aSeed.z;
        p = uOrigin + vec3(cos(ang) * r + sin(uTime * 0.4 + aSeed.x * 9.0) * life * 1.5,
                           0.6 + life * 10.0,
                           sin(ang) * r + life * 1.2);
        size = 0.5 + life * 2.2;
        vAlpha = (1.0 - life) * smoothstep(0.0, 0.1, life) * 0.4;
    }
    gl_Position = uMvp * vec4(p, 1.0);
    gl_PointSize = clamp(uPx * size / max(gl_Position.w, 0.1), 1.0, 90.0);
}
"""

private const val PARTICLE_FRAGMENT = """
precision mediump float;
uniform vec3 uTint;
uniform float uStrength;
varying float vAlpha;
void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = dot(c, c);
    if (d > 0.25) discard;
    float a = vAlpha * uStrength * (1.0 - d * 4.0);
    gl_FragColor = vec4(uTint, a);
}
"""

/**
 * Look of each zone: horizon/fog colour (3), fog start, fog end,
 * sky colour straight up (3), sun strength, snowfall, high cloud.
 */
private val LOOK = mapOf(
    Zone.MEADOW to floatArrayOf(0.72f, 0.83f, 0.94f, 130f, 560f, 0.24f, 0.48f, 0.86f, 1f, 0f, 0.8f),
    Zone.FOREST to floatArrayOf(0.62f, 0.73f, 0.77f, 60f, 380f, 0.30f, 0.46f, 0.64f, 0.75f, 0f, 1f),
    Zone.DESERT to floatArrayOf(0.95f, 0.86f, 0.70f, 120f, 560f, 0.38f, 0.58f, 0.86f, 1.2f, 0f, 0.35f),
    Zone.SNOW to floatArrayOf(0.84f, 0.88f, 0.93f, 35f, 300f, 0.58f, 0.66f, 0.78f, 0.55f, 1f, 1f),
    Zone.CAVES to floatArrayOf(0.14f, 0.11f, 0.20f, 15f, 170f, 0.05f, 0.04f, 0.08f, 0f, 0f, 0f),
)

/** Picks a screen setup with a fine depth buffer if the phone has one, so distant things don't flicker. */
class DepthConfigChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (depth in intArrayOf(24, 16)) {
            val attribs = intArrayOf(
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depth,
                EGL10.EGL_RENDERABLE_TYPE, 4, // OpenGL ES 2
                EGL10.EGL_NONE,
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (egl.eglChooseConfig(display, attribs, configs, 1, count) && count[0] > 0) {
                val c = configs[0]
                if (c != null) return c
            }
        }
        throw IllegalArgumentException("No suitable screen setup found")
    }
}

/** Draws the 3D world from the hero's eyes. Runs on its own drawing thread. */
class WorldRenderer(private val game: Game) : GLSurfaceView.Renderer {
    private val world = game.world
    private val builder = ChunkBuilder(world)

    private class Gpu(val buffer: Int, val count: Int)

    private val chunks = HashMap<Int, Gpu>()
    private val ids = IntArray(1)

    private var program = 0
    private var aPos = 0
    private var aColor = 0
    private var aNormal = -1
    private var uSunColor = -1
    private var uSkyZenith = -1
    private var uSkyHorizon = -1
    private var uGroundBounce = -1
    private var uShadow = -1
    private var uExposure = -1
    private var uMvp = 0
    private var uCam = 0
    private var uTime = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uFogColor = 0
    private var uEye = 0
    private var uSunDir = 0
    private var uSunPower = 0
    private var uClock = 0

    private var skyProgram = 0
    private var skyDir = 0
    private var skyMvp = 0
    private var skyCam = 0
    private var skyHorizon = 0
    private var skyZenith = 0
    private var skySun = 0
    private var skySunPower = 0
    private var skyTime = 0
    private var skyCirrus = 0

    private var partProgram = 0
    private var partSeed = 0
    private var partMvp = 0
    private var partCam = 0
    private var partOrigin = 0
    private var partTime = 0
    private var partPx = 0
    private var partMode = 0
    private var partTint = 0
    private var partStrength = 0
    private var partBuffer = 0
    private var pixelScale = 500f
    private val fires = ArrayList<FloatArray>()
    private var skyBuffer = 0
    private var skyCount = 0

    private var cloudBuffer = 0
    private var cloudCount = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private var lastNanos = 0L

    private val look = LOOK.getValue(Zone.MEADOW).copyOf()

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // A fresh surface means anything we uploaded before is gone.
        chunks.clear()
        // The realistic (PBR) shader, or plain shading if this phone can't build it.
        program = tryProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        if (program == 0) program = buildProgram(FALLBACK_VERTEX, FALLBACK_FRAGMENT)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        uSunColor = GLES20.glGetUniformLocation(program, "uSunColor")
        uSkyZenith = GLES20.glGetUniformLocation(program, "uSkyZenith")
        uSkyHorizon = GLES20.glGetUniformLocation(program, "uSkyHorizon")
        uGroundBounce = GLES20.glGetUniformLocation(program, "uGroundBounce")
        uShadow = GLES20.glGetUniformLocation(program, "uShadow")
        uExposure = GLES20.glGetUniformLocation(program, "uExposure")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uCam = GLES20.glGetUniformLocation(program, "uCam")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uFogStart = GLES20.glGetUniformLocation(program, "uFogStart")
        uFogEnd = GLES20.glGetUniformLocation(program, "uFogEnd")
        uFogColor = GLES20.glGetUniformLocation(program, "uFogColor")
        uEye = GLES20.glGetUniformLocation(program, "uEye")
        uSunDir = GLES20.glGetUniformLocation(program, "uSunDir")
        uSunPower = GLES20.glGetUniformLocation(program, "uSunPower")
        uClock = GLES20.glGetUniformLocation(program, "uClock")

        skyProgram = buildProgram(SKY_VERTEX, SKY_FRAGMENT)
        skyDir = GLES20.glGetAttribLocation(skyProgram, "aDir")
        skyMvp = GLES20.glGetUniformLocation(skyProgram, "uMvp")
        skyCam = GLES20.glGetUniformLocation(skyProgram, "uCam")
        skyHorizon = GLES20.glGetUniformLocation(skyProgram, "uHorizon")
        skyZenith = GLES20.glGetUniformLocation(skyProgram, "uZenith")
        skySun = GLES20.glGetUniformLocation(skyProgram, "uSun")
        skySunPower = GLES20.glGetUniformLocation(skyProgram, "uSunPower")
        skyTime = GLES20.glGetUniformLocation(skyProgram, "uSkyTime")
        skyCirrus = GLES20.glGetUniformLocation(skyProgram, "uCirrus")

        partProgram = buildProgram(PARTICLE_VERTEX, PARTICLE_FRAGMENT)
        partSeed = GLES20.glGetAttribLocation(partProgram, "aSeed")
        partMvp = GLES20.glGetUniformLocation(partProgram, "uMvp")
        partCam = GLES20.glGetUniformLocation(partProgram, "uCam")
        partOrigin = GLES20.glGetUniformLocation(partProgram, "uOrigin")
        partTime = GLES20.glGetUniformLocation(partProgram, "uTime")
        partPx = GLES20.glGetUniformLocation(partProgram, "uPx")
        partMode = GLES20.glGetUniformLocation(partProgram, "uMode")
        partTint = GLES20.glGetUniformLocation(partProgram, "uTint")
        partStrength = GLES20.glGetUniformLocation(partProgram, "uStrength")
        buildParticles()
        buildSky()
        buildClouds()

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        lastNanos = 0L
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / max(1, height).toFloat()
        val fovY = if (aspect > 1f) 56f else 64f
        Matrix.perspectiveM(proj, 0, fovY, aspect, 0.25f, 1600f)
        // How many pixels one metre covers at one metre away, for sizing snowflakes.
        pixelScale = height * 0.5f * proj[5]
    }

    override fun onDrawFrame(unused: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNanos = now
        game.update(dt)

        // Ease the sky and fog towards the current zone's look.
        val target = LOOK.getValue(game.currentZone)
        val k = (dt * 1.2f).coerceAtMost(1f)
        for (i in look.indices) look[i] += (target[i] - look[i]) * k

        GLES20.glClearColor(look[0], look[1], look[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val ex = game.x
        val ey = game.eyeY
        val ez = game.z
        val cp = cos(game.pitch)
        val fx = cp * sin(game.yaw)
        val fy = sin(game.pitch)
        val fz = cp * cos(game.yaw)
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + fx, ey + fy, ez + fz, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        drawSky(ex, ey, ez)
        streamChunks(ex, ez)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(uCam, ex, ey, ez)
        GLES20.glUniform3f(uEye, ex, ey, ez)
        GLES20.glUniform1f(uTime, game.time)
        GLES20.glUniform1f(uClock, game.time)
        GLES20.glUniform1f(uFogStart, look[3])
        GLES20.glUniform1f(uFogEnd, look[4])
        GLES20.glUniform3f(uFogColor, look[0], look[1], look[2])
        GLES20.glUniform3f(uSunDir, SUN_X, SUN_Y, SUN_Z)
        GLES20.glUniform1f(uSunPower, look[8])
        // Light for the PBR shader, all in linear colour (display colour squared).
        val sunI = 0.75f + 0.45f * look[8]
        GLES20.glUniform3f(uSunColor, 1.0f * sunI, 0.95f * sunI, 0.86f * sunI)
        val skyK = 0.7f
        GLES20.glUniform3f(
            uSkyHorizon,
            max(look[0] * look[0], 0.03f) * skyK, max(look[1] * look[1], 0.03f) * skyK, max(look[2] * look[2], 0.04f) * skyK,
        )
        GLES20.glUniform3f(
            uSkyZenith,
            max(look[5] * look[5], 0.03f) * skyK, max(look[6] * look[6], 0.03f) * skyK, max(look[7] * look[7], 0.04f) * skyK,
        )
        GLES20.glUniform3f(uGroundBounce, 0.10f * sunI, 0.09f * sunI, 0.07f * sunI)
        GLES20.glUniform1f(uShadow, 1f)
        GLES20.glUniform1f(uExposure, 0.65f)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aColor)
        if (aNormal >= 0) GLES20.glEnableVertexAttribArray(aNormal)

        // Horizontal facing, for skipping chunks behind us.
        val hx = sin(game.yaw)
        val hz = cos(game.yaw)
        val viewLimit = look[4] + CHUNK_HALF_DIAG
        for ((key, gpu) in chunks) {
            val ccx = ((key % CHUNKS) + 0.5f) * CHUNK_M
            val ccz = ((key / CHUNKS) + 0.5f) * CHUNK_M
            val dx = ccx - ex
            val dz = ccz - ez
            if (hypot(dx, dz) > viewLimit) continue
            if (dx * hx + dz * hz < -CHUNK_HALF_DIAG) continue
            drawBuffer(gpu.buffer, gpu.count)
        }

        // Clouds drift slowly across the sky. They fade out much further away than the ground.
        if (look[8] > 0.05f && cloudCount > 0) {
            GLES20.glUniform1f(uFogStart, 300f)
            GLES20.glUniform1f(uFogEnd, 1500f)
            val drift = (game.time * 2.5f) % WORLD_SIZE
            for (copy in 0..1) {
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, drift - copy * WORLD_SIZE, 0f, 0f)
                Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
                Matrix.multiplyMM(mvp, 0, proj, 0, tmp, 0)
                GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
                GLES20.glUniform3f(uCam, ex - (drift - copy * WORLD_SIZE), ey, ez)
                drawBuffer(cloudBuffer, cloudCount)
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        if (aNormal >= 0) GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glDisableVertexAttribArray(aColor)
        GLES20.glDisableVertexAttribArray(aPos)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        drawParticles(ex, ey, ez)
    }

    /** Falling snow in Frostpeak, and smoke rising from campfires nearby. */
    private fun drawParticles(ex: Float, ey: Float, ez: Float) {
        val snow = look[9]
        var anyFire = false
        for (f in fires) if (hypot(f[0] - ex, f[2] - ez) < 140f) anyFire = true
        if (snow < 0.02f && !anyFire) return
        GLES20.glUseProgram(partProgram)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        GLES20.glUniformMatrix4fv(partMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(partCam, ex, ey, ez)
        GLES20.glUniform1f(partTime, game.time)
        GLES20.glUniform1f(partPx, pixelScale)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, partBuffer)
        GLES20.glEnableVertexAttribArray(partSeed)
        GLES20.glVertexAttribPointer(partSeed, 3, GLES20.GL_FLOAT, false, 12, 0)
        if (snow >= 0.02f) {
            GLES20.glUniform1f(partMode, 0f)
            GLES20.glUniform3f(partTint, 1f, 1f, 1f)
            GLES20.glUniform1f(partStrength, snow)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, PARTICLES)
        }
        GLES20.glUniform1f(partMode, 1f)
        GLES20.glUniform3f(partTint, 0.55f, 0.55f, 0.56f)
        GLES20.glUniform1f(partStrength, 1f)
        for (f in fires) {
            if (hypot(f[0] - ex, f[2] - ez) > 140f) continue
            GLES20.glUniform3f(partOrigin, f[0], f[1], f[2])
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 70)
        }
        GLES20.glDisableVertexAttribArray(partSeed)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun buildParticles() {
        val buf = ByteBuffer.allocateDirect(PARTICLES * 12).order(ByteOrder.nativeOrder())
        for (k in 0 until PARTICLES) {
            buf.putFloat(hash(k, 1, 555))
            buf.putFloat(hash(k, 2, 555))
            buf.putFloat(hash(k, 3, 555))
        }
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        partBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, partBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, PARTICLES * 12, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        fires.clear()
        for (lm in world.landmarks) {
            if (lm.kind == Kind.FIRE) fires.add(floatArrayOf(lm.x, world.terrainAt(lm.x, lm.z), lm.z))
        }
        // Chimneys smoke too.
        for (st in world.structures) {
            for (sm in st.smoke) fires.add(floatArrayOf(sm[0], sm[1] - 0.6f, sm[2]))
        }
    }

    private fun drawBuffer(buffer: Int, count: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffer)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, 0)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_UNSIGNED_BYTE, true, STRIDE, 12)
        if (aNormal >= 0) GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_BYTE, true, STRIDE, 16)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }

    private fun drawSky(ex: Float, ey: Float, ez: Float) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(skyProgram)
        GLES20.glUniformMatrix4fv(skyMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(skyCam, ex, ey, ez)
        GLES20.glUniform3f(skyHorizon, look[0], look[1], look[2])
        GLES20.glUniform3f(skyZenith, look[5], look[6], look[7])
        GLES20.glUniform3f(skySun, SUN_X, SUN_Y, SUN_Z)
        GLES20.glUniform1f(skySunPower, look[8])
        GLES20.glUniform1f(skyTime, game.time)
        GLES20.glUniform1f(skyCirrus, look[10])
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glEnableVertexAttribArray(skyDir)
        GLES20.glVertexAttribPointer(skyDir, 3, GLES20.GL_FLOAT, false, 12, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, skyCount)
        GLES20.glDisableVertexAttribArray(skyDir)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    /** A dome of directions around the camera, coloured by the sky shader. */
    private fun buildSky() {
        val around = 24
        val rings = 8
        val data = ArrayList<Float>()
        fun dir(ring: Int, seg: Int) {
            val elev = -0.3f + (ring.toFloat() / rings) * (1.5707964f + 0.3f)
            val az = seg.toFloat() / around * 6.2831855f
            data.add(cos(elev) * cos(az))
            data.add(sin(elev))
            data.add(cos(elev) * sin(az))
        }
        for (r in 0 until rings) {
            for (sgm in 0 until around) {
                dir(r, sgm)
                dir(r, sgm + 1)
                dir(r + 1, sgm + 1)
                dir(r, sgm)
                dir(r + 1, sgm + 1)
                dir(r + 1, sgm)
            }
        }
        val buf = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
        for (v in data) buf.putFloat(v)
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        skyBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        skyCount = data.size / 3
    }

    /** Puffy low-poly clouds scattered high over the whole map. */
    private fun buildClouds() {
        val m = MeshBuilder(4096)
        for (c in 0 until 40) {
            val cx = hash(c, 1, 321) * WORLD_SIZE
            val cz = hash(c, 2, 321) * WORLD_SIZE
            val cy = 190f + hash(c, 3, 321) * 90f
            val size = 14f + hash(c, 4, 321) * 16f
            val puffs = 3 + (hash(c, 5, 321) * 3f).toInt()
            for (pf in 0 until puffs) {
                val ox = (hash(c, 10 + pf, 322) - 0.5f) * size * 2.2f
                val oz = (hash(c, 20 + pf, 322) - 0.5f) * size * 1.2f
                val r = size * (0.6f + 0.5f * hash(c, 30 + pf, 322))
                m.blob(cx + ox, cy, cz + oz, r, r * 0.45f, r * 0.8f, 0xF4F6FA, c * 13 + pf, 0.18f)
            }
        }
        val data = m.finish()
        cloudCount = m.vertexCount
        GLES20.glGenBuffers(1, ids, 0)
        cloudBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cloudBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, cloudCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    /** Uploads freshly built chunks, asks for missing nearby ones, drops far-away ones. */
    private fun streamChunks(ex: Float, ez: Float) {
        for (n in 0 until 3) {
            val built = builder.done.poll() ?: break
            builder.uploaded(built.key)
            val data = built.data
            if (data == null || built.vertexCount == 0 || chunks.containsKey(built.key)) continue
            GLES20.glGenBuffers(1, ids, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, built.vertexCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            chunks[built.key] = Gpu(ids[0], built.vertexCount)
        }

        val pcx = floor(ex / CHUNK_M).toInt()
        val pcz = floor(ez / CHUNK_M).toInt()
        val reach = (LOAD_RADIUS / CHUNK_M).toInt() + 1
        for (ring in 0..reach) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(abs(dx), abs(dz)) != ring) continue
                    val cx = pcx + dx
                    val cz = pcz + dz
                    if (cx < 0 || cz < 0 || cx >= CHUNKS || cz >= CHUNKS) continue
                    val key = cz * CHUNKS + cx
                    if (chunks.containsKey(key) || builder.isPending(key)) continue
                    val d = hypot((cx + 0.5f) * CHUNK_M - ex, (cz + 0.5f) * CHUNK_M - ez)
                    if (d < LOAD_RADIUS) builder.request(key)
                }
            }
        }

        val it = chunks.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val key = e.key
            val d = hypot(((key % CHUNKS) + 0.5f) * CHUNK_M - ex, ((key / CHUNKS) + 0.5f) * CHUNK_M - ez)
            if (d > UNLOAD_RADIUS) {
                ids[0] = e.value.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
                it.remove()
            }
        }
    }

    /** Builds a shader program, or returns 0 if this phone can't compile or link it. */
    private fun tryProgram(vsSource: String, fsSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(vs, GLES20.GL_COMPILE_STATUS, ok, 0)
        val vsOk = ok[0] != 0
        GLES20.glGetShaderiv(fs, GLES20.GL_COMPILE_STATUS, ok, 0)
        val fsOk = ok[0] != 0
        if (!vsOk || !fsOk) {
            GLES20.glDeleteShader(vs)
            GLES20.glDeleteShader(fs)
            return 0
        }
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "PBR link failed: " + GLES20.glGetProgramInfoLog(prog))
            GLES20.glDeleteProgram(prog)
            return 0
        }
        return prog
    }

    private fun buildProgram(vsSource: String, fsSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Link failed: " + GLES20.glGetProgramInfoLog(prog))
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Shader failed: " + GLES20.glGetShaderInfoLog(shader))
        }
        return shader
    }
}
