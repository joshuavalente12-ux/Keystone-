package com.keystone.rpg

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private const val LOAD_RADIUS = 600f
private const val UNLOAD_RADIUS = 780f
private const val CHUNK_HALF_DIAG = 136f
private const val PARTICLES = 2200

private const val VERTEX_SHADER = """
// Keystone PBR - vertex shader
// Target: OpenGL ES 2.0 / GLSL ES 1.00 (works on every Android GPU).
//
// Vertex layout (20 bytes):
//   aPos    3 x float                  world position
//   aColor  4 x unsigned byte, normalized: rgb = UNLIT albedo (sRGB), a = material id / 255
//   aNormal 4 x signed byte,   normalized: xyz = smooth vertex normal (w unused, padding)
//
// Lighting is no longer baked into aColor: the fragment shader does it all.

uniform mat4 uMvp;
uniform mat4 uModel;    // identity for the world; places and poses creatures
uniform vec3 uCam;
uniform float uTime;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uWind;    // 0 = still, 1+ = gale

attribute vec3 aPos;
attribute vec4 aColor;
attribute vec3 aNormal;

varying vec3 vAlbedo;   // linear albedo
varying vec3 vNormal;   // world-space normal (unnormalized after interpolation)
varying vec3 vPos;      // world position (fragment shader reads it at highp)
varying float vId;      // material id 0..255
varying float vFog;     // 0 = clear, 1 = fully fogged

void main() {
    vec3 p = (uModel * vec4(aPos, 1.0)).xyz;
    float id = floor(aColor.a * 255.0 + 0.5);
    float fogMul = 1.0;

    // Cheap vertex animation, chosen by material id.
    if (id < 50.0) {
        // Water swell.
        p.y += sin(uTime * 1.6 + aPos.x * 0.35 + aPos.z * 0.25) * 0.08
             + sin(uTime * 2.3 - aPos.x * 0.6 + aPos.z * 0.45) * 0.04;
    } else if (id < 80.0) {
        // Flame tips: 75 = campfire, 74 = hearth/torch, 73 = candle.
        float amp = id > 74.5 ? 1.0 : (id > 73.5 ? 0.2 : 0.025);
        if (id > 72.5) {
            p.x += sin(uTime * 9.0 + aPos.z * 7.0) * 0.14 * amp;
            p.z += cos(uTime * 7.3 + aPos.x * 7.0) * 0.14 * amp;
            p.y += sin(uTime * 11.0 + aPos.x * 5.0) * 0.25 * amp;
        }
        fogMul = 0.3;
    } else if (id < 140.0) {
        fogMul = 0.35;                     // glowing things cut through haze
    } else if (id < 160.5) {
        // Grass and fern tips sway.
        float w = (sin(uTime * 1.3 + aPos.x * 0.05 + aPos.z * 0.04) * 0.5 + 0.7) * (0.6 + uWind * 1.4);
        p.x += sin(uTime * 2.2 + aPos.x * 0.7 + aPos.z * 0.3) * 0.1 * w;
        p.z += cos(uTime * 1.9 + aPos.z * 0.6 + aPos.x * 0.2) * 0.08 * w;
    } else if (id > 175.0 && id < 186.0) {
        // Leaves rustle.
        p.x += sin(uTime * 1.7 + aPos.y * 1.3 + aPos.z * 0.5) * 0.05 * (0.6 + uWind * 1.4);
        p.z += cos(uTime * 1.5 + aPos.y * 1.1 + aPos.x * 0.5) * 0.05 * (0.6 + uWind * 1.4);
    }

    vAlbedo = aColor.rgb * aColor.rgb;     // sRGB -> linear (gamma 2.0 approximation, no pow)
    vNormal = (uModel * vec4(aNormal, 0.0)).xyz;
    vPos = p;
    vId = id;
    float d = distance(p, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0) * fogMul;
    gl_Position = uMvp * vec4(p, 1.0);
}
"""

private const val FRAGMENT_SHADER = """
// Keystone PBR - fragment shader
// Target: OpenGL ES 2.0 / GLSL ES 1.00 + GL_OES_standard_derivatives
// (the extension is supported by effectively every Android GPU; without it the
// shader still runs, just without bump detail).
//
// What it does, per pixel:
//   * picks roughness / metalness / bump height for the material procedurally
//     (no textures at all: zero texture bandwidth, which is what mobile GPUs hate most)
//   * perturbs the normal from that height using screen-space derivatives
//     (Mikkelsen "bump mapping unparametrized surfaces", so no tangents are needed)
//   * lights it with a GGX / Smith / Schlick BRDF tuned for fp16
//   * adds image-based-style ambient from an analytic sky (no cubemap) using
//     Karis' mobile EnvBRDF approximation
//   * tone maps (ACES fit), then applies distance fog
//
// Mobile performance notes:
//   * Everything is mediump except world position and noise input, which need
//     highp because the world is ~3 km across (fp16 would shimmer).
//   * All derivative calls happen OUTSIDE the material branches (uniform control
//     flow), which is required for correct results on tiled mobile GPUs.
//   * Detail (bump, noise octaves) fades out with distance; far pixels are cheap.
//   * pow() is only used where unavoidable; Fresnel uses multiplies.
//   * Roughness is clamped to 0.089 so the GGX lobe can't overflow fp16.

#extension GL_OES_standard_derivatives : enable

#ifdef GL_FRAGMENT_PRECISION_HIGH
#define HP highp
#else
#define HP mediump
#endif
precision mediump float;

uniform HP vec3 uEye;       // camera position
uniform vec3 uSunDir;       // normalized, pointing TOWARDS the sun
uniform vec3 uSunColor;     // linear sun colour * intensity (e.g. vec3(3.2, 3.0, 2.7))
uniform vec3 uSkyZenith;    // linear sky colour straight up
uniform vec3 uSkyHorizon;   // linear sky colour at the horizon
uniform vec3 uGroundBounce; // linear light bounced up from the ground
uniform vec3 uFogColor;     // DISPLAY-space fog colour (matches the sky dome)
uniform float uClock;       // seconds, for water / fire / sparkle
uniform float uShadow;      // 1 = lit; hook for a shadow-map term later
uniform float uExposure;    // overall brightness before tone mapping
uniform float uWet;         // 0 = dry, 1 = soaked by rain
uniform HP vec4 uLamps[6];  // torches and fires: position, brightness (0 = off)

varying vec3 vAlbedo;
varying vec3 vNormal;
varying HP vec3 vPos;
varying float vId;
varying float vFog;

const float PI = 3.14159265;
const float MIN_ROUGH = 0.089;

// ------------------------------------------------------------------ noise

float hash(HP vec2 p) {
    HP vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise(HP vec2 p) {
    HP vec2 i = floor(p);
    vec2 f = fract(p);                       // small, fine at mediump
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Octaves are skipped when "detail" is low, so distant pixels pay for one lookup.
float fbm(HP vec2 p, float detail) {
    float n = noise(p) * 0.55;
    if (detail > 0.0) n += (noise(p * 2.03) * 0.3 + noise(p * 4.1) * 0.15) * detail;
    else n += 0.225;
    return n;
}

// ------------------------------------------------------------------ BRDF

// GGX normal distribution. Uses |N x H|^2 instead of 1 - NoH^2, which loses all
// precision in fp16 for shiny surfaces (trick from Filament).
float D_GGX(float alpha, float NoH, vec3 n, vec3 h) {
    vec3 NxH = cross(n, h);
    float oneMinusNoH2 = dot(NxH, NxH);
    float a = NoH * alpha;
    float k = alpha / (oneMinusNoH2 + a * a);
    return min(k * k * (1.0 / PI), 65504.0);
}

// Height-correlated Smith visibility, fast approximation (Hammon).
float V_SmithFast(float alpha, float NoV, float NoL) {
    return 0.5 / max(mix(2.0 * NoL * NoV, NoL + NoV, alpha), 1e-4);
}

vec3 F_Schlick(vec3 f0, float VoH) {
    float x = 1.0 - VoH;
    float x2 = x * x;
    return f0 + (1.0 - f0) * (x2 * x2 * x);
}

// Split-sum environment BRDF, analytic fit for mobile (Karis 2014). No LUT texture.
vec3 EnvBRDFApprox(vec3 specColor, float rough, float NoV) {
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
    const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = rough * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NoV)) * r.x + r.y;
    vec2 AB = vec2(-1.04, 1.04) * a004 + r.zw;
    return specColor * AB.x + AB.y;
}

// Analytic sky radiance in direction d, blurred towards its average by roughness.
vec3 skyRadiance(vec3 d, float rough) {
    float up = clamp(d.y, 0.0, 1.0);
    vec3 sky = mix(uSkyHorizon, uSkyZenith, sqrt(up));
    vec3 below = uGroundBounce;
    vec3 sharp = d.y >= 0.0 ? sky : mix(uSkyHorizon, below, clamp(-d.y * 4.0, 0.0, 1.0));
    vec3 avg = (uSkyHorizon + uSkyZenith) * 0.5;
    return mix(sharp, avg, rough * rough);
}

vec3 acesFit(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

// ------------------------------------------------------------------ main

void main() {
    HP vec3 P = vPos;
    vec3 V = normalize(uEye - P);
    float dist = distance(P, uEye);
    HP vec3 fpx = dFdx(P);
    HP vec3 fpy = dFdy(P);
    float foot = float(max(length(fpx), length(fpy)));  // metres per pixel
    float near = (1.0 - smoothstep(30.0, 150.0, dist)) * (1.0 - smoothstep(0.012, 0.05, foot));

    vec3 Ng = vNormal;
    float nLen = dot(Ng, Ng);
    Ng = nLen > 1e-4 ? Ng * inversesqrt(nLen) : vec3(0.0, 1.0, 0.0);
    if (dot(Ng, V) < 0.0) Ng = -Ng;                      // double-sided leaves, planks, quads

    // Horizontal texture axis along a wall, so vertical surfaces get proper
    // 2D patterns without UVs or tangents.
    HP vec2 uvWall = vec2(abs(Ng.x) > abs(Ng.z) ? P.z : P.x, P.y);
    HP vec2 uv = abs(Ng.y) > 0.7 ? P.xz : uvWall;

    // ---- Material parameters (defaults = generic painted object).
    vec3 albedo = vAlbedo;
    float rough = 0.55;
    float metal = 0.0;
    HP float h = 0.0;       // procedural height, in metres (highp: its screen derivatives are tiny up close)
    float bump = 0.0;       // how strongly h tilts the normal
    float wrap = 0.0;       // light wrapping round the terminator (soft materials)
    float transl = 0.0;     // light shining through from behind (leaves, grass)
    float f0Base = 0.04;    // dielectric reflectance at normal incidence
    vec3 emissive = vec3(0.0);
    float emit = 0.0;       // 1 = pure emissive, lighting skipped in the mix

    float id = vId;
    if (id < 50.0) {
        // Water: dark body, very smooth, normal from two scrolling wave layers.
        HP vec2 q = P.xz;
        h = noise(q * 0.45 + vec2(uClock * 0.35, uClock * 0.1)) * 0.12
          + noise(q * 1.6 + vec2(-uClock * 0.6, uClock * 0.5)) * 0.04 * near;
        bump = 1.0;
        albedo = vAlbedo * 0.3;             // shallow turquoise to deep blue, darkened
        rough = 0.06;
        f0Base = 0.02;
    } else if (id < 80.0) {
        float fl = 0.75 + 0.5 * noise(vec2(P.y * 4.0 - uClock * 6.0, (P.x + P.z) * 5.0));
        emissive = albedo * fl * 4.0;
        emit = 1.0;
    } else if (id < 140.0) {
        emissive = albedo * (2.2 + 0.25 * sin(uClock * 2.0 + P.x + P.z));
        emit = 1.0;
    } else if (id < 163.0) {
        // Grass blades and fern fronds.
        rough = 0.75;
        wrap = 0.5;
        transl = 0.5;
        albedo *= 0.9 + 0.2 * noise(P.xz * 6.0);
    } else if (id < 186.0) {
        // Leaves: clumps of light and dark foliage, lit through from behind.
        float n = noise(P.xz * 2.4 + P.y * 1.9) * 0.6 + noise(P.xz * 7.0 - P.y * 5.0) * 0.4 * near;
        albedo *= 0.7 + 0.6 * n;
        h = n * 0.15;
        bump = 0.6;
        rough = 0.6;
        wrap = 0.4;
        transl = 0.7;
    } else if (id < 197.0) {
        // Bark: deep vertical ridges.
        float r = noise(vec2(uvWall.x * 9.0, P.y * 1.2)) * 0.7 + noise(vec2(uvWall.x * 20.0, P.y * 3.0)) * 0.3 * near;
        h = r * 0.05;
        bump = 1.0;
        albedo *= 0.6 + 0.6 * r;
        rough = 0.9;
    } else if (id < 202.0) {
        // Planks: long grain plus a groove between boards.
        float g = noise(vec2(P.y * 22.0 + uv.x * 0.8, uv.x * 1.5 + uv.y * 0.3));
        float board = fract(uv.y * 4.0);
        float groove = smoothstep(0.0, 0.06, board) * smoothstep(1.0, 0.94, board);
        h = g * 0.004 + groove * 0.01;
        bump = 1.0;
        albedo *= (0.78 + 0.36 * g) * (0.75 + 0.25 * groove);
        rough = 0.6 + 0.15 * (1.0 - g);
    } else if (id < 209.0) {
        // Dressed stone: staggered blocks with bevelled edges and dark mortar.
        HP vec2 b = uv * vec2(1.4, 2.4);
        b.x += floor(b.y) * 0.5;
        vec2 f = fract(b);
        vec2 e = min(f, 1.0 - f);
        float edge = smoothstep(0.0, 0.08, min(e.x * 0.6, e.y));
        float blockTone = hash(floor(b));
        float n = fbm(uv * 2.2, near);
        h = edge * 0.03 + n * 0.01;
        bump = 1.0;
        albedo *= mix(0.45, (0.8 + 0.3 * blockTone) * (0.8 + 0.4 * n), edge);
        rough = mix(0.95, 0.72, edge);
    } else if (id < 219.0) {
        // Plaster and cloth: fine unevenness.
        float n = noise(uv * 3.5) * 0.6 + noise(uv * 12.0) * 0.4 * near;
        h = n * 0.004;
        bump = 1.0;
        albedo *= 0.9 + 0.2 * n;
        rough = 0.92;
        wrap = 0.15;
    } else if (id < 226.0) {
        // Roof shingles: each row overlaps the one below, so it steps.
        HP float row = P.y * 3.4;
        float fr = fract(row);
        float tile = hash(vec2(floor((P.x + P.z) * 1.7 + floor(row) * 0.5), floor(row)));
        h = fr * 0.03;
        bump = 1.0;
        albedo *= (0.8 + 0.3 * tile) * (1.0 - 0.35 * smoothstep(0.8, 1.0, fr));
        rough = 0.65 + 0.2 * tile;
    } else if (id < 233.0) {
        // Grass-covered ground: patchy with dry spots.
        float n = fbm(P.xz * 0.5, near);
        float fine = noise(P.xz * 9.0) * near;
        float dry = smoothstep(0.55, 0.8, noise(P.xz * 0.07));
        albedo = mix(albedo, albedo * vec3(1.18, 1.08, 0.72), dry * 0.55);
        albedo *= 0.78 + 0.3 * n + 0.14 * fine;
        h = n * 0.08 + fine * 0.02;
        bump = 1.0;
        rough = 0.95;
        wrap = 0.2;
    } else if (id < 238.0) {
        // Rock: weathered stone with cracks, dark crevices and lichen on top.
        // 236 = cliffs and mountainsides (layered), 234 = loose boulders.
        float cliff = step(235.0, id);
        float strata = sin(P.y * 1.4 + noise(P.xz * 0.15) * 5.0) * cliff;
        float n = fbm(uv * 0.9, near);
        float cr = 1.0 - abs(noise(uv * 1.7 + P.y * 0.35) * 2.0 - 1.0);
        float crack = smoothstep(0.9, 0.98, cr) * near;
        float lich = smoothstep(0.6, 0.72, noise(P.xz * 1.1 + P.y * 0.7)) * smoothstep(0.45, 0.85, Ng.y);
        h = strata * 0.06 + n * 0.12 - crack * 0.05;
        bump = 1.2;
        albedo *= (0.74 + 0.08 * strata + 0.4 * n) * (1.0 - 0.5 * crack);
        albedo = mix(albedo, albedo * vec3(0.8, 0.95, 0.62) + vec3(0.015, 0.02, 0.0), lich * 0.55);
        rough = 0.8 + 0.12 * n;
    } else if (id < 243.0) {
        // Dirt tracks: dusty with scattered pebbles.
        HP vec2 c = floor(P.xz * 3.0);
        vec2 f = fract(P.xz * 3.0) - 0.5;
        float peb = step(0.78, hash(c)) * (1.0 - smoothstep(0.12, 0.28, length(f))) * near;
        float n = fbm(P.xz * 1.3, near);
        h = n * 0.03 + peb * 0.03;
        bump = 1.0;
        albedo *= (0.82 + 0.32 * n) * (1.0 - 0.25 * peb) + 0.1 * peb * hash(c + 3.0);
        rough = 0.95 - 0.25 * peb;
    } else if (id < 248.0) {
        // Sand: wind ripples, plus the odd grain that catches the sun.
        float rip = sin((P.x * 0.9 + P.z * 0.4) * 2.4 + noise(P.xz * 0.25) * 6.0);
        h = rip * 0.02;
        bump = 1.0;
        albedo *= 0.95 + 0.05 * rip;
        rough = 0.85;
        float grain = step(0.992, hash(floor(P.xz * 12.0)));
        rough = mix(rough, 0.15, grain * near);
    } else if (id < 253.0) {
        // Snow: soft drifts, light scatters inside it, glittering crystals.
        float n = noise(P.xz * 0.6);
        h = n * 0.05;
        bump = 0.7;
        albedo *= 0.94 + 0.08 * n;
        wrap = 0.45;
        float crystal = step(0.985, hash(floor(P.xz * 7.0 + P.y * 3.0)));
        rough = mix(0.5, 0.08, crystal * near);
    } else if (id < 253.5) {
        // Fur and feathers: soft, matte, light wraps gently round the body.
        rough = 0.82;
        wrap = 0.3;
        f0Base = 0.03;
    } else if (id < 254.5) {
        // Metal (iron gates, armour, blades): brushed, with scratches.
        float s = noise(vec2(uv.x * 40.0, uv.y * 2.0)) * near;
        metal = 1.0;
        rough = 0.3 + 0.25 * s;
        h = s * 0.0015;
        bump = 1.0;
    } else {
        albedo *= 0.94 + 0.12 * noise(uv * 4.0) * near;
    }

    // ---- Rain soaks outdoor surfaces: darker and shinier. Floors, walls and plaster stay dry.
    float wetK = (id > 140.0 && id < 248.0 && (id < 197.0 || id > 219.0)) ? uWet : 0.0;
    albedo *= 1.0 - 0.35 * wetK;
    rough = mix(rough, rough * 0.4, wetK);

    // ---- Procedural normal mapping (outside all branches: uniform control flow).
    vec3 N = Ng;
#ifdef GL_OES_standard_derivatives
    {
        // Pixel-sized derivatives are ~1e-3 m up close, and their products
        // (~1e-6) vanish in 16-bit floats, which blew the normal up to white.
        // Rescale everything to unit size first so nothing underflows.
        HP vec3 dPdx = dFdx(P);
        HP vec3 dPdy = dFdy(P);
        HP float dhx = dFdx(h);
        HP float dhy = dFdy(h);
        HP float m = max(max(abs(dPdx.x), abs(dPdx.y)), max(abs(dPdx.z), max(abs(dPdy.x), max(abs(dPdy.y), abs(dPdy.z)))));
        if (m > 1e-7) {
            HP float inv = 1.0 / m;
            vec3 sx = vec3(dPdx * inv);
            vec3 sy = vec3(dPdy * inv);
            float hx = float(dhx * inv);
            float hy = float(dhy * inv);
            vec3 r1 = cross(sy, Ng);
            vec3 r2 = cross(Ng, sx);
            float det = dot(sx, r1);
            vec3 surfGrad = sign(det) * (hx * r1 + hy * r2);
            float k = bump * near * 0.6;
            vec3 nn = abs(det) * Ng - surfGrad * k;
            float nl = dot(nn, nn);
            if (nl > 1e-6) N = nn * inversesqrt(nl);
        }
    }
#endif

    // ---- Direct sun light.
    vec3 L = uSunDir;
    vec3 H = normalize(V + L);
    float NoV = abs(dot(N, V)) + 1e-4;
    float NoLraw = dot(N, L);
    float NoL = clamp(NoLraw, 0.0, 1.0);
    float NoH = clamp(dot(N, H), 0.0, 1.0);
    float VoH = clamp(dot(V, H), 0.0, 1.0);

    rough = max(rough, MIN_ROUGH);
    float alpha = rough * rough;
    vec3 f0 = mix(vec3(f0Base), albedo, metal);
    vec3 diffuseColor = albedo * (1.0 - metal);

    float D = D_GGX(alpha, NoH, N, H);
    float Vis = V_SmithFast(alpha, NoV, NoL);
    vec3 F = F_Schlick(f0, VoH);
    vec3 spec = D * Vis * F;

    // Wrapped diffuse for soft materials, and light through thin leaves.
    float NoLwrap = clamp((NoLraw + wrap) / (1.0 + wrap), 0.0, 1.0);
    vec3 diff = diffuseColor * (1.0 / PI) * NoLwrap * (1.0 - F);
    float back = clamp(dot(V, -L), 0.0, 1.0);
    back *= back;
    vec3 through = diffuseColor * transl * back * back * clamp(-NoLraw + 0.3, 0.0, 1.0);

    vec3 direct = (diff * PI + spec * PI * NoL + through) * uSunColor * uShadow;

    // ---- Ambient: analytic sky instead of a cubemap.
    float hemi = N.y * 0.5 + 0.5;
    vec3 ambDiffuse = diffuseColor * mix(uGroundBounce, (uSkyHorizon + uSkyZenith) * 0.5, hemi);
    vec3 R = reflect(-V, N);
    // Stop bump-mapped normals reflecting the sky from below the real surface.
    float horizon = clamp(1.0 + dot(R, Ng), 0.0, 1.0);
    vec3 ambSpec = EnvBRDFApprox(f0, rough, NoV) * skyRadiance(R, rough) * horizon * horizon;
    // Rough, upward-facing crevices see less sky: cheap specular occlusion.
    float occ = mix(0.6, 1.0, hemi);
    vec3 ambient = (ambDiffuse + ambSpec) * occ;

    // ---- Torchlight and firelight: warm, falling away over about a dozen metres.
    vec3 lamp = vec3(0.0);
    for (int i = 0; i < 6; i++) {
        HP vec4 Lp = uLamps[i];
        if (Lp.w > 0.0) {
            HP vec3 dl = Lp.xyz - P;
            HP float dd = dot(dl, dl);
            if (dd < 400.0) {
                float fall = float(Lp.w / (1.0 + dd * 0.3)) * clamp(1.0 - float(dd) / 400.0, 0.0, 1.0);
                vec3 ld = vec3(dl * inversesqrt(max(dd, 1e-4)));
                float nl = clamp(dot(N, ld) * 0.75 + 0.25, 0.0, 1.0);
                lamp += vec3(fall * nl);
            }
        }
    }
    float flick = 0.92 + 0.08 * sin(uClock * 13.0) * sin(uClock * 7.3 + 1.0);

    vec3 lit = direct + ambient + diffuseColor * lamp * vec3(3.0, 1.55, 0.6) * flick;
    vec3 color = mix(lit, emissive, emit);

    // ---- Tone map, back to display space, then haze.
    color = acesFit(color * uExposure);
    color = sqrt(color);                   // linear -> display (matches the gamma 2 input)
    gl_FragColor = vec4(mix(color, uFogColor, vFog), 1.0);
}
"""

/** Plain sun-and-fog shading, used only if a phone can't compile the PBR shader. */
private const val FALLBACK_VERTEX = """
uniform mat4 uMvp;
uniform mat4 uModel;
uniform vec3 uCam;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uLight;
attribute vec3 aPos;
attribute vec4 aColor;
attribute vec3 aNormal;
varying vec3 vColor;
varying float vFog;
void main() {
    vec3 n = (uModel * vec4(aNormal, 0.0)).xyz;
    vec3 wp = (uModel * vec4(aPos, 1.0)).xyz;
    float l = dot(n, n);
    n = l > 1e-4 ? n * inversesqrt(l) : vec3(0.0, 1.0, 0.0);
    float id = floor(aColor.a * 255.0 + 0.5);
    float sun = max(dot(n, vec3(-0.458, 0.815, -0.356)), 0.0);
    float lit = id < 140.0 ? 1.0 : (0.5 + 0.6 * sun + 0.06 * n.y) * uLight;
    vColor = aColor.rgb * lit;
    float d = distance(wp, uCam);
    vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    gl_Position = uMvp * vec4(wp, 1.0);
}
"""

private const val FALLBACK_FRAGMENT = """
precision mediump float;
uniform vec3 uFogColor;
varying vec3 vColor;
varying float vFog;
void main() {
    gl_FragColor = vec4(mix(vColor, uFogColor, vFog), 1.0);
}
"""

private const val SKY_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
attribute vec3 aDir;
varying vec3 vDir;
void main() {
    vDir = aDir;
    gl_Position = uMvp * vec4(uCam + aDir * 800.0, 1.0);
}
"""

private const val SKY_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSun;
uniform float uSunPower;
uniform float uSkyTime;
uniform float uCirrus;
uniform vec3 uMoon;
uniform float uStars;   // 0 = none, 1 = clear night sky
uniform float uDay;     // brightness of the clouds
varying vec3 vDir;

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

void main() {
    vec3 d = normalize(vDir);
    float t = clamp(d.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(t, 0.5));
    // Bright haze low down, and light scattered around the sun.
    col = mix(col, uHorizon * 1.06, pow(1.0 - t, 10.0) * 0.6);
    float s = max(dot(d, uSun), 0.0);
    col += vec3(1.0, 0.88, 0.68) * pow(s, 5.0) * 0.16 * uSunPower;
    col += vec3(1.0, 0.95, 0.82) * pow(s, 90.0) * 0.45 * uSunPower;
    col += vec3(1.0, 0.98, 0.92) * pow(s, 1200.0) * 3.0 * uSunPower;
    // Thin high clouds drifting across the sky.
    if (d.y > 0.03) {
        vec2 uv = d.xz / (d.y + 0.15) * 1.6 + vec2(uSkyTime * 0.012, uSkyTime * 0.004);
        float c = noise(uv) * 0.55 + noise(uv * 2.7 + 3.1) * 0.3 + noise(uv * 6.3 + 7.7) * 0.15;
        c = smoothstep(0.5, 0.85, c) * smoothstep(0.03, 0.3, d.y) * uCirrus;
        vec3 cloud = mix(vec3(0.92, 0.94, 0.98), vec3(1.0, 0.97, 0.9), s) * (0.1 + 0.9 * uDay);
        col = mix(col, cloud, c * 0.7);
    }
    // Night: a field of twinkling stars, and the moon with a soft halo.
    if (uStars > 0.01 && d.y > 0.0) {
        vec2 g = d.xz / (d.y + 0.25) * 90.0;
        vec2 cell = floor(g);
        float h = hash(cell);
        float r = length(fract(g) - 0.5 - (vec2(hash(cell + 7.1), hash(cell + 3.3)) - 0.5) * 0.6);
        float star = step(0.982, h) * smoothstep(0.11, 0.0, r);
        star *= 0.55 + 0.45 * sin(uSkyTime * (2.0 + h * 3.0) + h * 60.0);
        col += vec3(0.85, 0.9, 1.0) * star * uStars * smoothstep(0.02, 0.25, d.y) * (0.5 + 0.5 * step(0.995, h));
    }
    if (uStars > 0.01) {
        float m = dot(d, uMoon);
        float disc = smoothstep(0.99955, 0.99975, m);
        col += vec3(0.5, 0.6, 0.8) * pow(max(m, 0.0), 60.0) * 0.12 * uStars;
        col = mix(col, vec3(0.9, 0.92, 0.98), disc * uStars);
    }
    gl_FragColor = vec4(col, 1.0);
}
"""

private const val PARTICLE_VERTEX = """
uniform mat4 uMvp;
uniform vec3 uCam;
uniform vec3 uOrigin;
uniform float uTime;
uniform float uPx;
uniform float uMode;
uniform vec2 uDrift;
attribute vec3 aSeed;
varying float vAlpha;
varying float vShape;
void main() {
    vec3 p;
    float size;
    vShape = 0.0;
    if (uMode < 0.5) {
        // Snow: falls and drifts in a box that always surrounds you.
        vec3 box = vec3(56.0, 30.0, 56.0);
        p = aSeed * box;
        p.y -= uTime * (1.1 + aSeed.x * 1.1);
        p.x += sin(uTime * 0.8 + aSeed.z * 30.0) * 0.9 + uDrift.x;
        p.z += cos(uTime * 0.6 + aSeed.x * 25.0) * 0.9 + uDrift.y;
        vec3 o = uCam - box * 0.5;
        p = o + mod(p - o, box);
        size = 0.07 + aSeed.y * 0.06;
        vAlpha = 0.9;
    } else if (uMode < 1.5) {
        // Smoke: puffs rise, spread and fade.
        float life = fract(aSeed.y + uTime * 0.11);
        float ang = aSeed.x * 6.2831;
        float r = (0.15 + life * 1.6) * aSeed.z;
        p = uOrigin + vec3(cos(ang) * r + sin(uTime * 0.4 + aSeed.x * 9.0) * life * 1.5,
                           0.6 + life * 10.0,
                           sin(ang) * r + life * 1.2);
        size = 0.5 + life * 2.2;
        vAlpha = (1.0 - life) * smoothstep(0.0, 0.1, life) * 0.4;
    } else if (uMode < 2.5) {
        // Rain: fast falling streaks.
        vec3 box = vec3(44.0, 26.0, 44.0);
        p = aSeed * box;
        p.y -= uTime * (15.0 + aSeed.x * 5.0);
        p.xz += uDrift;
        vec3 o = uCam - box * 0.5;
        p = o + mod(p - o, box);
        size = 0.55 + aSeed.z * 0.25;
        vAlpha = 0.33;
        vShape = 1.0;
    } else if (uMode < 3.5) {
        // Blowing dust or low mist: big soft puffs carried on the wind.
        vec3 box = vec3(70.0, 14.0, 70.0);
        p = aSeed * box;
        p.xz += uDrift * (0.7 + aSeed.y * 0.6);
        p.y += sin(uTime * 0.7 + aSeed.x * 20.0) * 1.2;
        vec3 o = uCam - vec3(box.x * 0.5, 5.0, box.z * 0.5);
        p = o + mod(p - o, box);
        size = 0.9 + aSeed.z * 1.6;
        vAlpha = 0.16;
    } else if (uMode < 4.5) {
        // Dust devil: a whirling funnel of sand, wider at the top.
        float life = fract(aSeed.y + uTime * 0.18);
        float hgt = life * 22.0;
        float r = 0.5 + hgt * 0.3 + aSeed.z * 1.2;
        float ang = aSeed.x * 6.2831 + uTime * (4.5 - life * 2.5);
        float lean = sin(uTime * 0.5 + aSeed.x) * 0.8;
        p = uOrigin + vec3(cos(ang) * r + lean * life * 3.0, hgt, sin(ang) * r);
        size = 0.35 + life * 1.3;
        vAlpha = smoothstep(0.0, 0.08, life) * (1.0 - life) * 0.55;
    } else {
        // Kicked up by a footstep: a small cloud that spreads, rises a little and settles.
        // uDrift.x = age (0..1), uDrift.y = size.
        float age = uDrift.x;
        float ang = aSeed.x * 6.2831;
        float r = (0.1 + age * 0.8) * (0.3 + aSeed.z) * uDrift.y;
        p = uOrigin + vec3(cos(ang) * r, 0.04 + age * (0.25 + aSeed.y * 0.45) * uDrift.y, sin(ang) * r);
        size = (0.14 + age * 0.5) * uDrift.y;
        vAlpha = (1.0 - age) * (1.0 - age) * smoothstep(0.0, 0.05, age) * 0.6;
    }
    gl_Position = uMvp * vec4(p, 1.0);
    gl_PointSize = clamp(uPx * size / max(gl_Position.w, 0.1), 1.0, 90.0);
}
"""

private const val PARTICLE_FRAGMENT = """
precision mediump float;
uniform vec3 uTint;
uniform float uStrength;
varying float vAlpha;
varying float vShape;
void main() {
    vec2 c = gl_PointCoord - 0.5;
    float a;
    if (vShape > 0.5) {
        // A thin upright streak for rain.
        float w = abs(c.x) * 22.0;
        if (w > 1.0) discard;
        a = (1.0 - w) * (1.0 - abs(c.y) * 2.0);
    } else {
        float d = dot(c, c);
        if (d > 0.25) discard;
        a = 1.0 - d * 4.0;
    }
    gl_FragColor = vec4(uTint, vAlpha * uStrength * a);
}
"""

/**
 * Look of each zone: horizon/fog colour (3), fog start, fog end,
 * sky colour straight up (3), sun strength, snowfall, high cloud.
 */
private val LOOK = mapOf(
    Zone.MEADOW to floatArrayOf(0.72f, 0.83f, 0.94f, 130f, 560f, 0.24f, 0.48f, 0.86f, 1f, 0f, 0.8f),
    Zone.FOREST to floatArrayOf(0.62f, 0.73f, 0.77f, 60f, 380f, 0.30f, 0.46f, 0.64f, 0.75f, 0f, 1f),
    Zone.DESERT to floatArrayOf(0.95f, 0.86f, 0.70f, 120f, 560f, 0.38f, 0.58f, 0.86f, 1.2f, 0f, 0.35f),
    Zone.SNOW to floatArrayOf(0.84f, 0.88f, 0.93f, 35f, 300f, 0.58f, 0.66f, 0.78f, 0.55f, 1f, 1f),
    Zone.CAVES to floatArrayOf(0.14f, 0.11f, 0.20f, 15f, 170f, 0.05f, 0.04f, 0.08f, 0f, 0f, 0f),
)

/** Picks a screen setup with a fine depth buffer if the phone has one, so distant things don't flicker. */
class DepthConfigChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (depth in intArrayOf(24, 16)) {
            val attribs = intArrayOf(
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depth,
                EGL10.EGL_RENDERABLE_TYPE, 4, // OpenGL ES 2
                EGL10.EGL_NONE,
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (egl.eglChooseConfig(display, attribs, configs, 1, count) && count[0] > 0) {
                val c = configs[0]
                if (c != null) return c
            }
        }
        throw IllegalArgumentException("No suitable screen setup found")
    }
}

/** Draws the 3D world from the hero's eyes. Runs on its own drawing thread. */
class WorldRenderer(private val game: Game) : GLSurfaceView.Renderer {
    private val world = game.world
    private val builder = ChunkBuilder(world)

    private class Gpu(val buffer: Int, val count: Int)

    private val chunks = HashMap<Int, Gpu>()
    /** Chunks waiting to be built again. */
    private val rebuild = HashSet<Int>()
    private val ids = IntArray(1)

    private var program = 0
    private var aPos = 0
    private var aColor = 0
    private var aNormal = -1
    private var uSunColor = -1
    private var uSkyZenith = -1
    private var uSkyHorizon = -1
    private var uGroundBounce = -1
    private var uShadow = -1
    private var uExposure = -1
    private var uMvp = 0
    private var uCam = 0
    private var uTime = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uFogColor = 0
    private var uEye = 0
    private var uSunDir = 0
    private var uSunPower = 0
    private var uClock = 0
    private var uWet = -1
    private var uLamps = -1
    private val noLamps = FloatArray(Game.LAMPS * 4)
    private var uWind = -1
    private var uLight = -1
    private var uModel = -1
    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val partModel = FloatArray(16)
    private val fauna = game.fauna
    /** The hero as you made them, wearing what you wear: rebuilt whenever either changes. */
    private var hero = Hero(game.look.copy(), game.loot.wornItems())
    private var heroKey = ""
    private var heroCheck = 0
    private val cam = FloatArray(7)
    private val treasure = game.treasure
    private var caveBuffer = 0
    private var caveUploaded = -1
    private var caveVerts = 0

    private var skyProgram = 0
    private var skyDir = 0
    private var skyMvp = 0
    private var skyCam = 0
    private var skyHorizon = 0
    private var skyZenith = 0
    private var skySun = 0
    private var skySunPower = 0
    private var skyTime = 0
    private var skyCirrus = 0
    private var skyMoon = -1
    private var skyStars = -1
    private var skyDay = -1

    private var partProgram = 0
    private var partSeed = 0
    private var partMvp = 0
    private var partCam = 0
    private var partOrigin = 0
    private var partTime = 0
    private var partPx = 0
    private var partMode = 0
    private var partTint = 0
    private var partStrength = 0
    private var partDrift = -1
    private var partBuffer = 0
    private var pixelScale = 500f
    private val fires = ArrayList<FloatArray>()
    private var skyBuffer = 0
    private var skyCount = 0

    private var cloudBuffer = 0
    private var cloudCount = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private var lastNanos = 0L

    private val look = FloatArray(ATM)
    private val target = FloatArray(ATM)
    private var lookReady = false

    // Wind-blown offsets for snow, rain, dust and mist (each wrapped to its box size).
    private var snowDx = 0f
    private var snowDz = 0f
    private var rainDx = 0f
    private var dustDx = 0f
    private var dustDz = 0f
    private var mistDx = 0f
    private var mistDz = 0f

    // Dust devils roaming Sunscar: x, z, age (-1 = none), heading.
    private val devils = Array(3) { floatArrayOf(0f, 0f, -1f, 0f) }
    private val rnd = Random(4242)

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // A fresh surface means anything we uploaded before is gone.
        chunks.clear()
        // The realistic (PBR) shader, or plain shading if this phone can't build it.
        program = tryProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        if (program == 0) program = buildProgram(FALLBACK_VERTEX, FALLBACK_FRAGMENT)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        uSunColor = GLES20.glGetUniformLocation(program, "uSunColor")
        uSkyZenith = GLES20.glGetUniformLocation(program, "uSkyZenith")
        uSkyHorizon = GLES20.glGetUniformLocation(program, "uSkyHorizon")
        uGroundBounce = GLES20.glGetUniformLocation(program, "uGroundBounce")
        uShadow = GLES20.glGetUniformLocation(program, "uShadow")
        uExposure = GLES20.glGetUniformLocation(program, "uExposure")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uCam = GLES20.glGetUniformLocation(program, "uCam")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uFogStart = GLES20.glGetUniformLocation(program, "uFogStart")
        uFogEnd = GLES20.glGetUniformLocation(program, "uFogEnd")
        uFogColor = GLES20.glGetUniformLocation(program, "uFogColor")
        uEye = GLES20.glGetUniformLocation(program, "uEye")
        uSunDir = GLES20.glGetUniformLocation(program, "uSunDir")
        uSunPower = GLES20.glGetUniformLocation(program, "uSunPower")
        uClock = GLES20.glGetUniformLocation(program, "uClock")
        uWet = GLES20.glGetUniformLocation(program, "uWet")
        uLamps = GLES20.glGetUniformLocation(program, "uLamps")
        uWind = GLES20.glGetUniformLocation(program, "uWind")
        uLight = GLES20.glGetUniformLocation(program, "uLight")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        val allParts = ArrayList<CreaturePart>()
        for (sp in fauna.species) allParts.addAll(sp.parts)
        allParts.addAll(hero.parts)
        allParts.addAll(treasure.meshes)
        allParts.addAll(game.people.meshes)
        allParts.addAll(game.borders.meshes)
        allParts.addAll(game.base.meshes)
        caveUploaded = -1
        caveBuffer = 0
        for (part in allParts) {
            part.data.position(0)
            GLES20.glGenBuffers(1, ids, 0)
            part.buffer = ids[0]
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, part.buffer)
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, part.count * STRIDE, part.data, GLES20.GL_STATIC_DRAW)
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        skyProgram = buildProgram(SKY_VERTEX, SKY_FRAGMENT)
        skyDir = GLES20.glGetAttribLocation(skyProgram, "aDir")
        skyMvp = GLES20.glGetUniformLocation(skyProgram, "uMvp")
        skyCam = GLES20.glGetUniformLocation(skyProgram, "uCam")
        skyHorizon = GLES20.glGetUniformLocation(skyProgram, "uHorizon")
        skyZenith = GLES20.glGetUniformLocation(skyProgram, "uZenith")
        skySun = GLES20.glGetUniformLocation(skyProgram, "uSun")
        skySunPower = GLES20.glGetUniformLocation(skyProgram, "uSunPower")
        skyTime = GLES20.glGetUniformLocation(skyProgram, "uSkyTime")
        skyCirrus = GLES20.glGetUniformLocation(skyProgram, "uCirrus")
        skyMoon = GLES20.glGetUniformLocation(skyProgram, "uMoon")
        skyStars = GLES20.glGetUniformLocation(skyProgram, "uStars")
        skyDay = GLES20.glGetUniformLocation(skyProgram, "uDay")

        partProgram = buildProgram(PARTICLE_VERTEX, PARTICLE_FRAGMENT)
        partSeed = GLES20.glGetAttribLocation(partProgram, "aSeed")
        partMvp = GLES20.glGetUniformLocation(partProgram, "uMvp")
        partCam = GLES20.glGetUniformLocation(partProgram, "uCam")
        partOrigin = GLES20.glGetUniformLocation(partProgram, "uOrigin")
        partTime = GLES20.glGetUniformLocation(partProgram, "uTime")
        partPx = GLES20.glGetUniformLocation(partProgram, "uPx")
        partMode = GLES20.glGetUniformLocation(partProgram, "uMode")
        partTint = GLES20.glGetUniformLocation(partProgram, "uTint")
        partStrength = GLES20.glGetUniformLocation(partProgram, "uStrength")
        partDrift = GLES20.glGetUniformLocation(partProgram, "uDrift")
        buildParticles()
        buildSky()
        buildClouds()

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        lastNanos = 0L
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / max(1, height).toFloat()
        val fovY = if (aspect > 1f) 56f else 64f
        Matrix.perspectiveM(proj, 0, fovY, aspect, 0.25f, 1600f)
        // How many pixels one metre covers at one metre away, for sizing snowflakes.
        pixelScale = height * 0.5f * proj[5]
    }

    override fun onDrawFrame(unused: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNanos = now
        game.update(dt)
        refreshHero()

        // Ease the sky, fog, light and weather towards what this region wants right now.
        game.weather.target(game.currentZone, LOOK.getValue(game.currentZone), target)
        if (!lookReady) {
            target.copyInto(look)
            lookReady = true
        }
        val k = (dt * 1.2f).coerceAtMost(1f)
        for (i in look.indices) look[i] += (target[i] - look[i]) * k
        val flash = game.weather.flash
        val wind = look[21]
        snowDx = (snowDx + (0.6f + max(0f, wind - 0.45f) * 14f) * dt) % 56f
        snowDz = (snowDz + max(0f, wind - 0.45f) * 4f * dt) % 56f
        rainDx = (rainDx + wind * 2f * dt) % 44f
        dustDx = (dustDx + (2f + wind * 12f) * dt) % 70f
        dustDz = (dustDz + (0.6f + wind * 3f) * dt) % 70f
        mistDx = (mistDx + 0.7f * dt) % 70f
        mistDz = (mistDz + 0.3f * dt) % 70f
        updateDevils(dt)

        GLES20.glClearColor(
            min(1f, look[0] + flash * 0.35f), min(1f, look[1] + flash * 0.37f), min(1f, look[2] + flash * 0.42f), 1f,
        )
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        // First person, or over the shoulder in third person.
        game.camera(dt, cam)
        val ex = cam[0]
        val ey = cam[1]
        val ez = cam[2]
        Matrix.setLookAtM(view, 0, ex, ey, ez, cam[3], cam[4], cam[5], 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        // Inside a cave: a world of its own.
        if (game.inCave >= 0) {
            drawCave(ex, ey, ez)
            return
        }

        drawSky(ex, ey, ez)
        streamChunks(ex, ez)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, identity, 0)
        GLES20.glUniform3f(uCam, ex, ey, ez)
        GLES20.glUniform3f(uEye, ex, ey, ez)
        GLES20.glUniform1f(uTime, game.time)
        GLES20.glUniform1f(uClock, game.time)
        GLES20.glUniform1f(uFogStart, look[3])
        GLES20.glUniform1f(uFogEnd, look[4])
        GLES20.glUniform3f(uFogColor, look[0], look[1], look[2])
        val dl = sqrt(look[11] * look[11] + look[12] * look[12] + look[13] * look[13]).coerceAtLeast(1e-4f)
        GLES20.glUniform3f(uSunDir, look[11] / dl, look[12] / dl, look[13] / dl)
        GLES20.glUniform1f(uSunPower, look[8])
        // Light for the PBR shader, all in linear colour (display colour squared).
        GLES20.glUniform3f(uSunColor, look[14], look[15], look[16])
        val skyK = 0.7f * (1f + flash * 6f)
        GLES20.glUniform3f(
            uSkyHorizon,
            max(look[0] * look[0], 0.03f) * skyK, max(look[1] * look[1], 0.03f) * skyK, max(look[2] * look[2], 0.04f) * skyK,
        )
        GLES20.glUniform3f(
            uSkyZenith,
            max(look[5] * look[5], 0.03f) * skyK, max(look[6] * look[6], 0.03f) * skyK, max(look[7] * look[7], 0.04f) * skyK,
        )
        GLES20.glUniform3f(uGroundBounce, 0.105f * look[14], 0.095f * look[15], 0.08f * look[16])
        GLES20.glUniform1f(uShadow, 1f)
        GLES20.glUniform1f(uExposure, look[19])
        GLES20.glUniform1f(uWet, look[18])
        if (uLamps >= 0) GLES20.glUniform4fv(uLamps, Game.LAMPS, game.lamps, 0)
        GLES20.glUniform1f(uWind, wind)
        GLES20.glUniform1f(uLight, ((look[14] + look[15] + look[16]) * 0.4f + 0.2f).coerceIn(0.2f, 1.2f))
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aColor)
        if (aNormal >= 0) GLES20.glEnableVertexAttribArray(aNormal)

        // Horizontal facing, for skipping chunks behind us.
        val hx = sin(game.yaw)
        val hz = cos(game.yaw)
        val viewLimit = look[4] + CHUNK_HALF_DIAG
        for ((key, gpu) in chunks) {
            val ccx = ((key % CHUNKS) + 0.5f) * CHUNK_M
            val ccz = ((key / CHUNKS) + 0.5f) * CHUNK_M
            val dx = ccx - ex
            val dz = ccz - ez
            if (hypot(dx, dz) > viewLimit) continue
            if (dx * hx + dz * hz < -CHUNK_HALF_DIAG) continue
            drawBuffer(gpu.buffer, gpu.count)
        }

        // Hidden cave mouths and treasure chests.
        for (cv in treasure.caves) {
            val dx = cv.x - ex
            val dz = cv.z - ez
            if (dx * dx + dz * dz > 320f * 320f) continue
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, cv.x, cv.y, cv.z)
            Matrix.rotateM(partModel, 0, Math.toDegrees(cv.yaw.toDouble()).toFloat(), 0f, 1f, 0f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            val em = treasure.entrances[cv.zone.ordinal]
            drawBuffer(em.buffer, em.count)
        }
        for (ch in treasure.chests) {
            if (ch.cave >= 0) continue
            val dx = ch.x - ex
            val dz = ch.z - ez
            if (dx * dx + dz * dz > 160f * 160f) continue
            drawChest(ch)
        }

        // Everything you've built: finished pieces solid, unfinished ones as bare timber frames.
        drawBase(ex, ez)

        // The brick wall between regions, and its one gateway.
        Matrix.setIdentityM(partModel, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
        drawBuffer(game.borders.wallMesh.buffer, game.borders.wallMesh.count)
        for (g in game.borders.gateMeshes) drawBuffer(g.buffer, g.count)

        // Boss lairs: rings of standing stones.
        for (i in treasure.lairs.indices) {
            val dx = treasure.lairX[i] - ex
            val dz = treasure.lairZ[i] - ez
            if (dx * dx + dz * dz > 420f * 420f) continue
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, treasure.lairX[i], treasure.lairY[i], treasure.lairZ[i])
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            val lm = treasure.lairs[i]
            drawBuffer(lm.buffer, lm.count)
        }

        // Things monsters dropped: bobbing and turning so they catch your eye.
        for (d in game.drops) {
            val dx = d.x - ex
            val dz = d.z - ez
            if (dx * dx + dz * dz > 120f * 120f) continue
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, d.x, d.y + 0.15f + sin(d.age * 2.5f) * 0.1f, d.z)
            Matrix.rotateM(partModel, 0, d.age * 90f, 0f, 1f, 0f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            val dm = treasure.drops[d.item.rarity.coerceIn(0, 4)]
            drawBuffer(dm.buffer, dm.count)
        }

        // Animals and birds, each piece posed by its own matrix.
        val creatureLimit = min(look[4], 170f)
        for (group in arrayOf(fauna.animals, fauna.birds, fauna.foes, fauna.bosses, fauna.caveFoes, fauna.worldBosses)) {
            for (c in group) {
                if (!c.active) continue
                val dx = c.x - ex
                val dz = c.z - ez
                val dist = hypot(dx, dz)
                if (dist > creatureLimit + (if (c.boss >= 0 || c.wb >= 0) 60f else 0f)) continue
                if (dist > 8f && dx * hx + dz * hz < -4f) continue
                for (part in fauna.species[c.sp].parts) {
                    fauna.pose(c, part, game.time, partModel)
                    GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                    drawBuffer(part.buffer, part.count)
                }
            }
        }
        // Villagers, traders, elders, guards and lords, with a marker over anyone who has work for you.
        val people = game.people
        for (n in people.npcs) {
            if (!n.awake) continue
            val dx = n.x - ex
            val dz = n.z - ez
            val dist = hypot(dx, dz)
            if (dist > 120f) continue
            if (dist > 8f && dx * hx + dz * hz < -4f) continue
            for (part in people.models[n.look]) {
                people.pose(n, part, game.time, partModel)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                drawBuffer(part.buffer, part.count)
            }
            if (n.mark != 0) {
                people.poseMarker(n, game.time, partModel)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                val mk = if (n.mark == 2) people.markDone else people.markNew
                drawBuffer(mk.buffer, mk.count)
            }
        }
        // The hero, in third person.
        if (cam[6] > 0.5f) {
            for (part in hero.parts) {
                if (!hero.visible(game, part)) continue
                hero.pose(game, part, partModel)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                drawBuffer(part.buffer, part.count)
            }
        }
        // Thrown kunai, flying point first and spinning.
        val kn = game.kunai
        for (i in 0 until Game.KUNAI_MAX) {
            val o = i * 7
            if (kn[o + 6] < 0f) continue
            val vx = kn[o + 3]
            val vy = kn[o + 4]
            val vz = kn[o + 5]
            val flat = hypot(vx, vz)
            val kyaw = Math.toDegrees(kotlin.math.atan2(vx, vz).toDouble()).toFloat()
            val kpitch = Math.toDegrees(kotlin.math.atan2(vy, flat).toDouble()).toFloat()
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, kn[o], kn[o + 1], kn[o + 2])
            Matrix.rotateM(partModel, 0, kyaw, 0f, 1f, 0f)
            Matrix.rotateM(partModel, 0, 90f - kpitch, 1f, 0f, 0f)
            val mk = game.missileKind[i]
            val part = when (mk) {
                WeaponClass.BOW -> hero.arrow
                WeaponClass.STAFF, WeaponClass.WAND -> hero.bolt
                else -> hero.kunai
            }
            val isBolt = mk == WeaponClass.STAFF || mk == WeaponClass.WAND
            if (!isBolt) Matrix.rotateM(partModel, 0, kn[o + 6] * 1400f, 0f, 1f, 0f)
            Matrix.scaleM(partModel, 0, KUNAI_FLY_SCALE, KUNAI_FLY_SCALE, KUNAI_FLY_SCALE)
            if (!isBolt) Matrix.translateM(partModel, 0, 0f, -0.3f, 0f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            drawBuffer(part.buffer, part.count)
        }
        GLES20.glUniformMatrix4fv(uModel, 1, false, identity, 0)

        // Clouds drift slowly across the sky. They fade out much further away than the ground.
        if (look[10] > 0.05f && cloudCount > 0) {
            GLES20.glUniform1f(uFogStart, 300f)
            GLES20.glUniform1f(uFogEnd, 1500f)
            val drift = (game.time * 2.5f) % WORLD_SIZE
            for (copy in 0..1) {
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, drift - copy * WORLD_SIZE, 0f, 0f)
                Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
                Matrix.multiplyMM(mvp, 0, proj, 0, tmp, 0)
                GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
                GLES20.glUniform3f(uCam, ex - (drift - copy * WORLD_SIZE), ey, ez)
                drawBuffer(cloudBuffer, cloudCount)
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        if (aNormal >= 0) GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glDisableVertexAttribArray(aColor)
        GLES20.glDisableVertexAttribArray(aPos)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        drawParticles(ex, ey, ez)
    }

    /** What the hero looks like and wears, as one string: when it changes, the hero is rebuilt. */
    private fun heroSignature(): String {
        val sb = StringBuilder(game.look.encode())
        for (it in game.loot.wornItems()) {
            sb.append('|')
            if (it != null) sb.append(it.tier).append(':').append(it.rarity)
        }
        return sb.toString()
    }

    /** Rebuilds the hero's meshes (on this drawing thread) after a new look or a change of gear. */
    private fun refreshHero() {
        if (++heroCheck < 15) return
        heroCheck = 0
        val key = heroSignature()
        if (key == heroKey) return
        heroKey = key
        val fresh = Hero(game.look.copy(), game.loot.wornItems())
        for (part in fresh.parts) {
            part.data.position(0)
            GLES20.glGenBuffers(1, ids, 0)
            part.buffer = ids[0]
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, part.buffer)
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, part.count * STRIDE, part.data, GLES20.GL_STATIC_DRAW)
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        val old = hero
        hero = fresh
        for (part in old.parts) {
            if (part.buffer != 0) {
                ids[0] = part.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
                part.buffer = 0
            }
        }
    }

    /** Your buildings, and the glowing outline of the piece you're about to place. */
    private fun drawBase(ex: Float, ez: Float) {
        val base = game.base
        for (pc in base.pieces) {
            val ax = pc.anchorX
            val az = pc.anchorZ
            val dx = ax - ex
            val dz = az - ez
            if (dx * dx + dz * dz > 200f * 200f) continue
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, ax, pc.y, az)
            Matrix.rotateM(partModel, 0, pc.angleDeg, 0f, 1f, 0f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            // A gable under a roof's high side is a half-height strip of wall.
            val strip = gableStrip(pc.type, pc.o)
            val look = if (!strip) pc.type else if (pc.type == PieceType.STONE_GABLE) PieceType.STONE_WALL else PieceType.WALL
            if (strip) {
                Matrix.scaleM(partModel, 0, 1f, 0.5f, 1f)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            }
            if (!pc.built) {
                val fm = base.frameMesh[look]
                drawBuffer(fm.buffer, fm.count)
                continue
            }
            if (pc.type == PieceType.FOUNDATION) {
                drawBuffer(base.deck.buffer, base.deck.count)
                Matrix.scaleM(partModel, 0, 1f, pc.depth, 1f)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            }
            val sm = base.solidMesh[look]
            drawBuffer(sm.buffer, sm.count)
            if (pc.type == PieceType.DOORWAY) {
                // Hinged at one jamb (local x=0 before the piece's own rotation above), swinging
                // open as pc.doorAngle eases towards Base.DOOR_OPEN_DEG.
                Matrix.translateM(partModel, 0, -1.0f, 0f, 0f)
                Matrix.rotateM(partModel, 0, pc.doorAngle, 0f, 1f, 0f)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                drawBuffer(base.doorLeaf.buffer, base.doorLeaf.count)
            }
        }
        val g = game.ghost
        if (game.buildMode && g.show) {
            val ax = if (PieceType.isFree(g.type)) g.fx else pieceAnchorX(g.type, g.gi, g.o)
            val az = if (PieceType.isFree(g.type)) g.fz else pieceAnchorZ(g.type, g.gk, g.o)
            val ang = pieceAngle(g.type, g.o)
            val strip = gableStrip(g.type, g.o)
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, ax, g.y + 0.02f, az)
            Matrix.rotateM(partModel, 0, ang, 0f, 1f, 0f)
            if (strip) Matrix.scaleM(partModel, 0, 1f, 0.5f, 1f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            val look = if (strip) PieceType.WALL else g.type
            val gm = if (g.ok) base.ghostOk[look] else base.ghostBad[look]
            drawBuffer(gm.buffer, gm.count)
        }
        Matrix.setIdentityM(partModel, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
    }

    /** One chest, with its lid swung open as far as it's got. */
    private fun drawChest(ch: Chest) {
        val body = if (ch.rich) treasure.richBody else treasure.chestBody
        val lid = if (ch.rich) treasure.richLid else treasure.chestLid
        Matrix.setIdentityM(partModel, 0)
        Matrix.translateM(partModel, 0, ch.x, ch.y, ch.z)
        Matrix.rotateM(partModel, 0, Math.toDegrees(ch.yaw.toDouble()).toFloat(), 0f, 1f, 0f)
        GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
        drawBuffer(body.buffer, body.count)
        Matrix.translateM(partModel, 0, 0f, 0.56f, -0.31f)
        Matrix.rotateM(partModel, 0, -ch.openT * 105f, 1f, 0f, 0f)
        GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
        drawBuffer(lid.buffer, lid.count)
    }

    /**
     * Inside a cave: no sky, weather or wildlife. Dim, warm light as if from torches, dark
     * fog in the distance, glowing crystals, the cave's chests and the hero.
     */
    private fun drawCave(ex: Float, ey: Float, ez: Float) {
        if (caveUploaded != game.caveMeshId) {
            val data = game.caveData
            if (data != null) {
                if (caveBuffer != 0) {
                    ids[0] = caveBuffer
                    GLES20.glDeleteBuffers(1, ids, 0)
                }
                data.position(0)
                GLES20.glGenBuffers(1, ids, 0)
                caveBuffer = ids[0]
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, caveBuffer)
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, game.caveCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
                caveVerts = game.caveCount
                caveUploaded = game.caveMeshId
            }
        }
        GLES20.glClearColor(0.02f, 0.018f, 0.028f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, identity, 0)
        GLES20.glUniform3f(uCam, ex, ey, ez)
        GLES20.glUniform3f(uEye, ex, ey, ez)
        GLES20.glUniform1f(uTime, game.time)
        GLES20.glUniform1f(uClock, game.time)
        GLES20.glUniform1f(uFogStart, 20f)
        GLES20.glUniform1f(uFogEnd, 110f)
        GLES20.glUniform3f(uFogColor, 0.02f, 0.018f, 0.028f)
        GLES20.glUniform3f(uSunDir, 0.25f, 0.93f, 0.27f)
        GLES20.glUniform1f(uSunPower, 0f)
        GLES20.glUniform3f(uSunColor, 0.55f, 0.46f, 0.36f)
        GLES20.glUniform3f(uSkyHorizon, 0.09f, 0.08f, 0.1f)
        GLES20.glUniform3f(uSkyZenith, 0.07f, 0.065f, 0.09f)
        GLES20.glUniform3f(uGroundBounce, 0.05f, 0.04f, 0.035f)
        GLES20.glUniform1f(uShadow, 1f)
        GLES20.glUniform1f(uExposure, 1.5f)
        GLES20.glUniform1f(uWet, 0f)
        if (uLamps >= 0) GLES20.glUniform4fv(uLamps, Game.LAMPS, noLamps, 0)
        GLES20.glUniform1f(uWind, 0f)
        GLES20.glUniform1f(uLight, 0.45f)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aColor)
        if (aNormal >= 0) GLES20.glEnableVertexAttribArray(aNormal)
        if (caveBuffer != 0 && caveVerts > 0) drawBuffer(caveBuffer, caveVerts)
        for (ch in treasure.chests) if (ch.cave == game.inCave) drawChest(ch)
        // Iron ore veins round the walls (the ones you haven't mined out).
        treasure.caves.getOrNull(game.inCave)?.let { cv ->
            for ((vi, o) in cv.ores.withIndex()) {
                if (game.base.oreMined(cv.id * 64 + vi)) continue
                Matrix.setIdentityM(partModel, 0)
                Matrix.translateM(partModel, 0, cv.x + o[0], cv.floorAt(o[0], o[1]) - 0.08f, cv.z + o[1])
                Matrix.rotateM(partModel, 0, o[3], 0f, 1f, 0f)
                Matrix.scaleM(partModel, 0, o[2], o[2], o[2])
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                drawBuffer(treasure.ore.buffer, treasure.ore.count)
            }
        }
        // The cave's own monsters (goblins, skeletons, spiders, witches...).
        for (c in fauna.caveFoes) {
            if (!c.active) continue
            if (hypot(c.x - ex, c.z - ez) > 110f) continue
            for (part in fauna.species[c.sp].parts) {
                fauna.pose(c, part, game.time, partModel)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                drawBuffer(part.buffer, part.count)
            }
        }
        // A relic you've been sent for, waiting in the deepest chamber.
        val here = treasure.caves.getOrNull(game.inCave)
        if (here != null && game.quests.relicWanted(here.id)) {
            Matrix.setIdentityM(partModel, 0)
            Matrix.translateM(partModel, 0, here.relicX, here.relicY, here.relicZ)
            Matrix.rotateM(partModel, 0, game.time * 40f, 0f, 1f, 0f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
            drawBuffer(treasure.relic.buffer, treasure.relic.count)
        }
        if (cam[6] > 0.5f) {
            for (part in hero.parts) {
                if (!hero.visible(game, part)) continue
                hero.pose(game, part, partModel)
                GLES20.glUniformMatrix4fv(uModel, 1, false, partModel, 0)
                drawBuffer(part.buffer, part.count)
            }
        }
        GLES20.glUniformMatrix4fv(uModel, 1, false, identity, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        if (aNormal >= 0) GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glDisableVertexAttribArray(aColor)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    /** Dust devils wander Sunscar during dust storms, and one comes out when the night wind picks up. */
    private fun updateDevils(dt: Float) {
        val inDesert = game.currentZone == Zone.DESERT
        val w = game.weather
        val want = if (!inDesert) 0 else if (w.dustStorm > 0.3f) 3 else if (w.night > 0.5f) 1 else 0
        for (i in devils.indices) {
            val d = devils[i]
            if (d[2] < 0f) {
                if (i >= want) continue
                val a = rnd.nextFloat() * 6.2831855f
                val r = 55f + rnd.nextFloat() * 80f
                d[0] = (game.x + cos(a) * r).coerceIn(10f, WORLD_SIZE - 10f)
                d[1] = (game.z + sin(a) * r).coerceIn(10f, WORLD_SIZE - 10f)
                d[2] = 0f
                d[3] = rnd.nextFloat() * 6.2831855f
                continue
            }
            d[2] += dt
            d[3] += (rnd.nextFloat() - 0.5f) * dt * 1.5f
            d[0] += cos(d[3]) * 3.5f * dt
            d[1] += sin(d[3]) * 3.5f * dt
            val far = hypot(d[0] - game.x, d[1] - game.z) > 200f
            if ((i >= want || far) && d[2] < 42f) d[2] = 42f
            if (d[2] > 45f) d[2] = -1f
        }
    }

    /** Snow, rain, blowing dust, mist, dust devils, and smoke rising from campfires nearby. */
    private fun drawParticles(ex: Float, ey: Float, ez: Float) {
        GLES20.glUseProgram(partProgram)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        GLES20.glUniformMatrix4fv(partMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(partCam, ex, ey, ez)
        GLES20.glUniform1f(partTime, game.time)
        GLES20.glUniform1f(partPx, pixelScale)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, partBuffer)
        GLES20.glEnableVertexAttribArray(partSeed)
        GLES20.glVertexAttribPointer(partSeed, 3, GLES20.GL_FLOAT, false, 12, 0)

        // Particles are lit by the same light as everything else, so they dim at night.
        val bright = ((look[14] + look[15] + look[16]) * 0.45f + 0.18f + game.weather.flash).coerceIn(0.18f, 1f)
        val snow = look[9]
        if (snow >= 0.02f) {
            GLES20.glUniform1f(partMode, 0f)
            GLES20.glUniform2f(partDrift, snowDx, snowDz)
            GLES20.glUniform3f(partTint, bright, bright, bright)
            GLES20.glUniform1f(partStrength, snow)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, PARTICLES)
        }
        val rain = if (game.indoors) 0f else look[18]
        if (rain >= 0.02f) {
            GLES20.glUniform1f(partMode, 2f)
            GLES20.glUniform2f(partDrift, rainDx, 0f)
            val rb = 0.25f + 0.75f * bright
            GLES20.glUniform3f(partTint, 0.72f * rb, 0.77f * rb, 0.85f * rb)
            GLES20.glUniform1f(partStrength, rain)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, PARTICLES)
        }
        val dust = look[20]
        if (dust >= 0.02f) {
            GLES20.glUniform1f(partMode, 3f)
            GLES20.glUniform2f(partDrift, dustDx, dustDz)
            GLES20.glUniform3f(partTint, 0.80f * bright, 0.64f * bright, 0.44f * bright)
            GLES20.glUniform1f(partStrength, dust * 1.6f)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 900)
        }
        val mist = look[22]
        if (mist >= 0.02f) {
            GLES20.glUniform1f(partMode, 3f)
            GLES20.glUniform2f(partDrift, mistDx, mistDz)
            GLES20.glUniform3f(
                partTint,
                min(1f, look[0] * 1.5f + 0.05f), min(1f, look[1] * 1.5f + 0.05f), min(1f, look[2] * 1.5f + 0.06f),
            )
            GLES20.glUniform1f(partStrength, mist)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 900)
        }
        var anyDevil = false
        for (d in devils) if (d[2] >= 0f) anyDevil = true
        if (anyDevil) {
            GLES20.glUniform1f(partMode, 4f)
            GLES20.glUniform3f(partTint, 0.74f * bright, 0.60f * bright, 0.42f * bright)
            for (d in devils) {
                val age = d[2]
                if (age < 0f) continue
                val fade = smooth(0f, 3f, age) * (1f - smooth(42f, 45f, age))
                if (fade < 0.01f) continue
                GLES20.glUniform1f(partStrength, fade)
                GLES20.glUniform3f(partOrigin, d[0], world.terrainAt(d[0], d[1]) - 0.5f, d[1])
                GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 450)
            }
        }
        // Dust, sand, snow and splashes from your own feet.
        GLES20.glUniform1f(partMode, 5f)
        GLES20.glUniform1f(partStrength, 1f)
        val pf = game.puffs
        for (i in 0 until Game.PUFFS) {
            val o = i * 6
            val age = pf[o + 3]
            if (age >= 1f) continue
            when (pf[o + 4].toInt()) {
                Game.PUFF_DIRT -> GLES20.glUniform3f(partTint, 0.56f * bright, 0.45f * bright, 0.33f * bright)
                Game.PUFF_SAND -> GLES20.glUniform3f(partTint, 0.86f * bright, 0.74f * bright, 0.54f * bright)
                Game.PUFF_SNOW -> GLES20.glUniform3f(partTint, 0.95f * bright, 0.97f * bright, 1.0f * bright)
                Game.PUFF_STONE -> GLES20.glUniform3f(partTint, 0.62f * bright, 0.6f * bright, 0.57f * bright)
                Game.PUFF_WATER -> GLES20.glUniform3f(partTint, 0.82f * bright, 0.9f * bright, 0.97f * bright)
                Game.PUFF_HIT -> GLES20.glUniform3f(partTint, 1.0f * bright, 0.93f * bright, 0.8f * bright)
                // The seal round a locked region glows by itself, day or night.
                Game.PUFF_SEAL -> GLES20.glUniform3f(partTint, 0.85f, 0.5f, 1.0f)
                else -> GLES20.glUniform3f(partTint, 0.45f * bright, 0.55f * bright, 0.3f * bright)
            }
            GLES20.glUniform2f(partDrift, age, pf[o + 5])
            GLES20.glUniform3f(partOrigin, pf[o], pf[o + 1], pf[o + 2])
            GLES20.glDrawArrays(GLES20.GL_POINTS, (i * 61) % 2000, 16)
        }
        GLES20.glUniform1f(partMode, 1f)
        GLES20.glUniform3f(partTint, 0.55f * bright, 0.55f * bright, 0.56f * bright)
        GLES20.glUniform1f(partStrength, 1f)
        for (f in fires) {
            if (hypot(f[0] - ex, f[2] - ez) > 140f) continue
            GLES20.glUniform3f(partOrigin, f[0], f[1], f[2])
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 70)
        }
        GLES20.glDisableVertexAttribArray(partSeed)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun buildParticles() {
        val buf = ByteBuffer.allocateDirect(PARTICLES * 12).order(ByteOrder.nativeOrder())
        for (k in 0 until PARTICLES) {
            buf.putFloat(hash(k, 1, 555))
            buf.putFloat(hash(k, 2, 555))
            buf.putFloat(hash(k, 3, 555))
        }
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        partBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, partBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, PARTICLES * 12, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        fires.clear()
        for (lm in world.landmarks) {
            if (lm.kind == Kind.FIRE) fires.add(floatArrayOf(lm.x, world.terrainAt(lm.x, lm.z), lm.z))
        }
        // Chimneys smoke too.
        for (st in world.structures) {
            for (sm in st.smoke) fires.add(floatArrayOf(sm[0], sm[1] - 0.6f, sm[2]))
        }
    }

    private fun drawBuffer(buffer: Int, count: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffer)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, 0)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_UNSIGNED_BYTE, true, STRIDE, 12)
        if (aNormal >= 0) GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_BYTE, true, STRIDE, 16)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }

    private fun drawSky(ex: Float, ey: Float, ez: Float) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(skyProgram)
        GLES20.glUniformMatrix4fv(skyMvp, 1, false, mvp, 0)
        GLES20.glUniform3f(skyCam, ex, ey, ez)
        val flash = game.weather.flash
        GLES20.glUniform3f(skyHorizon, look[0] + flash * 0.35f, look[1] + flash * 0.37f, look[2] + flash * 0.42f)
        GLES20.glUniform3f(skyZenith, look[5] + flash * 0.25f, look[6] + flash * 0.27f, look[7] + flash * 0.32f)
        val sun = game.weather.sun
        val moon = game.weather.moon
        // Regions without a day keep the sun where it always was.
        if (game.currentZone == Zone.FOREST || game.currentZone == Zone.CAVES) {
            GLES20.glUniform3f(skySun, SUN_X, SUN_Y, SUN_Z)
        } else {
            GLES20.glUniform3f(skySun, sun[0], sun[1], sun[2])
        }
        GLES20.glUniform1f(skySunPower, look[8])
        GLES20.glUniform1f(skyTime, game.time)
        GLES20.glUniform1f(skyCirrus, look[10])
        GLES20.glUniform3f(skyMoon, moon[0], moon[1], moon[2])
        GLES20.glUniform1f(skyStars, look[17])
        GLES20.glUniform1f(skyDay, ((look[14] + look[15] + look[16]) * 0.4f).coerceIn(0f, 1f))
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glEnableVertexAttribArray(skyDir)
        GLES20.glVertexAttribPointer(skyDir, 3, GLES20.GL_FLOAT, false, 12, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, skyCount)
        GLES20.glDisableVertexAttribArray(skyDir)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDepthMask(true)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    /** A dome of directions around the camera, coloured by the sky shader. */
    private fun buildSky() {
        val around = 24
        val rings = 8
        val data = ArrayList<Float>()
        fun dir(ring: Int, seg: Int) {
            val elev = -0.3f + (ring.toFloat() / rings) * (1.5707964f + 0.3f)
            val az = seg.toFloat() / around * 6.2831855f
            data.add(cos(elev) * cos(az))
            data.add(sin(elev))
            data.add(cos(elev) * sin(az))
        }
        for (r in 0 until rings) {
            for (sgm in 0 until around) {
                dir(r, sgm)
                dir(r, sgm + 1)
                dir(r + 1, sgm + 1)
                dir(r, sgm)
                dir(r + 1, sgm + 1)
                dir(r + 1, sgm)
            }
        }
        val buf = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
        for (v in data) buf.putFloat(v)
        buf.flip()
        GLES20.glGenBuffers(1, ids, 0)
        skyBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        skyCount = data.size / 3
    }

    /** Puffy low-poly clouds scattered high over the whole map. */
    private fun buildClouds() {
        val m = MeshBuilder(4096)
        for (c in 0 until 40) {
            val cx = hash(c, 1, 321) * WORLD_SIZE
            val cz = hash(c, 2, 321) * WORLD_SIZE
            val cy = 190f + hash(c, 3, 321) * 90f
            val size = 14f + hash(c, 4, 321) * 16f
            val puffs = 3 + (hash(c, 5, 321) * 3f).toInt()
            for (pf in 0 until puffs) {
                val ox = (hash(c, 10 + pf, 322) - 0.5f) * size * 2.2f
                val oz = (hash(c, 20 + pf, 322) - 0.5f) * size * 1.2f
                val r = size * (0.6f + 0.5f * hash(c, 30 + pf, 322))
                m.blob(cx + ox, cy, cz + oz, r, r * 0.45f, r * 0.8f, 0xF4F6FA, c * 13 + pf, 0.18f)
            }
        }
        val data = m.finish()
        cloudCount = m.vertexCount
        GLES20.glGenBuffers(1, ids, 0)
        cloudBuffer = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cloudBuffer)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, cloudCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    /** Uploads freshly built chunks, asks for missing nearby ones, drops far-away ones. */
    private fun streamChunks(ex: Float, ez: Float) {
        // Something changed in these (a tree came down, or grew back): build them again.
        while (true) {
            val key = world.dirtyChunks.poll() ?: break
            rebuild.add(key)
        }
        if (rebuild.isNotEmpty()) {
            val it0 = rebuild.iterator()
            while (it0.hasNext()) {
                val key = it0.next()
                if (!chunks.containsKey(key)) {
                    it0.remove()
                    continue
                }
                // Wait for any build already underway, which may have started before the change.
                if (builder.isPending(key)) continue
                builder.request(key)
                it0.remove()
            }
        }
        for (n in 0 until 3) {
            val built = builder.done.poll() ?: break
            builder.uploaded(built.key)
            val data = built.data
            if (data == null || built.vertexCount == 0) continue
            // A rebuilt chunk replaces the old one.
            chunks.remove(built.key)?.let { old ->
                ids[0] = old.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
            }
            GLES20.glGenBuffers(1, ids, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, built.vertexCount * STRIDE, data, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            chunks[built.key] = Gpu(ids[0], built.vertexCount)
        }

        val pcx = floor(ex / CHUNK_M).toInt()
        val pcz = floor(ez / CHUNK_M).toInt()
        val reach = (LOAD_RADIUS / CHUNK_M).toInt() + 1
        for (ring in 0..reach) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(abs(dx), abs(dz)) != ring) continue
                    val cx = pcx + dx
                    val cz = pcz + dz
                    if (cx < 0 || cz < 0 || cx >= CHUNKS || cz >= CHUNKS) continue
                    val key = cz * CHUNKS + cx
                    if (chunks.containsKey(key) || builder.isPending(key)) continue
                    val d = hypot((cx + 0.5f) * CHUNK_M - ex, (cz + 0.5f) * CHUNK_M - ez)
                    if (d < LOAD_RADIUS) builder.request(key)
                }
            }
        }

        val it = chunks.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val key = e.key
            val d = hypot(((key % CHUNKS) + 0.5f) * CHUNK_M - ex, ((key / CHUNKS) + 0.5f) * CHUNK_M - ez)
            if (d > UNLOAD_RADIUS) {
                ids[0] = e.value.buffer
                GLES20.glDeleteBuffers(1, ids, 0)
                it.remove()
            }
        }
    }

    /** Builds a shader program, or returns 0 if this phone can't compile or link it. */
    private fun tryProgram(vsSource: String, fsSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(vs, GLES20.GL_COMPILE_STATUS, ok, 0)
        val vsOk = ok[0] != 0
        GLES20.glGetShaderiv(fs, GLES20.GL_COMPILE_STATUS, ok, 0)
        val fsOk = ok[0] != 0
        if (!vsOk || !fsOk) {
            GLES20.glDeleteShader(vs)
            GLES20.glDeleteShader(fs)
            return 0
        }
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "PBR link failed: " + GLES20.glGetProgramInfoLog(prog))
            GLES20.glDeleteProgram(prog)
            return 0
        }
        return prog
    }

    private fun buildProgram(vsSource: String, fsSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Link failed: " + GLES20.glGetProgramInfoLog(prog))
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            android.util.Log.e("Keystone", "Shader failed: " + GLES20.glGetShaderInfoLog(shader))
        }
        return shader
    }
}
