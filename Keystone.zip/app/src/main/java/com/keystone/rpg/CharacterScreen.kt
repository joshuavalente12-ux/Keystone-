package com.keystone.rpg

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Make your hero: skin, hair, face, ears, nose, eyes, beard and build, with a picture that
 * changes as you go. Comes before choosing a weapon. [onDone] once it's saved.
 */
@Composable
fun CharacterScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val look = remember { HeroLook.load(ctx) }
    var version by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().background(Color(0xFF0B1210))) {
        Row(Modifier.fillMaxSize().safeDrawingPadding().padding(10.dp)) {
            // The picture.
            Column(
                Modifier.weight(0.42f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("CREATE YOUR HERO", color = Palette.gold, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF16201C)),
                ) {
                    Canvas(Modifier.fillMaxSize().padding(8.dp)) {
                        if (version >= 0) drawLookPreview(look)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            look.randomize(java.util.Random(System.nanoTime()))
                            version++
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC1E2A24), contentColor = Palette.gold),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("\uD83C\uDFB2 Random", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            look.save(ctx)
                            onDone()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Continue \u25B6", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            // The choices: tap the arrows to step through each one.
            Column(
                Modifier
                    .weight(0.58f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF131A17))
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text(
                    "Tap the arrows to change each part. You can't change this later, so take your time.",
                    color = Color.White.copy(alpha = 0.55f),
                    fontSize = 11.sp,
                )
                Spacer(Modifier.height(4.dp))
                for (f in HeroLook.FIELDS.indices) {
                    val (label, names) = HeroLook.FIELDS[f]
                    val v = if (version >= 0) look.get(f) else 0
                    LookRow(
                        label = label,
                        value = names[v],
                        swatch = HeroLook.swatch(f, v),
                        onPrev = {
                            look.set(f, look.get(f) - 1)
                            version++
                        },
                        onNext = {
                            look.set(f, look.get(f) + 1)
                            version++
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun LookRow(label: String, value: String, swatch: Int?, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(88.dp))
        ArrowButton("\u25C0", onPrev)
        Row(
            Modifier
                .weight(1f)
                .height(36.dp)
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x22FFFFFF)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (swatch != null) {
                Box(
                    Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF000000L or (swatch.toLong() and 0xFFFFFFL)))
                        .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
        }
        ArrowButton("\u25B6", onNext)
    }
}

@Composable
private fun ArrowButton(glyph: String, onTap: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Palette.gold.copy(alpha = 0.85f))
            .pointerInput(Unit) { detectTapGestures { onTap() } },
        contentAlignment = Alignment.Center,
    ) {
        Text(glyph, color = Color(0xFF1E2A22), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
    }
}
