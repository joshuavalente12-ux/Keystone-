package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/** One short, straight stretch of the brick wall along a region border. */
private class WallSpan(val x: Float, val z: Float, val yaw: Float, val bi: Int)

/**
 * A brick wall runs along the border of every region, following the actual wobbly
 * line where the land changes hands, with one stone gateway through it for each
 * step up [ZONE_ORDER] — the only way across until that region's boss falls.
 */
class Borders(private val world: World) {
    /** Where each gate stands, and how many there are that were actually found. */
    val gateX = FloatArray(ZONE_ORDER.size - 1)
    val gateZ = FloatArray(ZONE_ORDER.size - 1)
    val gateYaw = FloatArray(ZONE_ORDER.size - 1)
    private val hasGateArr = BooleanArray(ZONE_ORDER.size - 1)
    fun hasGate(bi: Int): Boolean = bi in hasGateArr.indices && hasGateArr[bi]

    // The wall itself, oriented rectangles checked for collision (rotated into local space).
    private val wx = ArrayList<Float>()
    private val wz = ArrayList<Float>()
    private val wc = ArrayList<Float>()
    private val ws = ArrayList<Float>()
    private val biOf = ArrayList<Int>()
    // The stone piers either side of a gate are solid too, though the gap between them isn't.
    private val gpx = ArrayList<Float>()
    private val gpz = ArrayList<Float>()

    val wallMesh: CreaturePart
    val gateMeshes: Array<CreaturePart>

    companion object {
        private const val HALF_LEN = 3.55f
        private const val HALF_THICK = 0.55f
        private const val HEIGHT = 3.6f
        private const val GATE_CLEAR = 15f
        private const val GATE_HALF = 2.3f
    }

    init {
        val ranks = IntArray(GRID * GRID)
        for (idx in ranks.indices) ranks[idx] = zoneRank(Zone.entries[world.regionMap[idx].toInt()])

        val cand = Array(ZONE_ORDER.size - 1) { ArrayList<WallSpan>() }
        val bestTrail = FloatArray(ZONE_ORDER.size - 1) { 1e9f }
        val bestIdx = IntArray(ZONE_ORDER.size - 1) { -1 }
        val p = Probe()

        fun consider(bi: Int, x: Float, z: Float, yaw: Float) {
            val list = cand[bi]
            list.add(WallSpan(x, z, yaw, bi))
            world.probe(x, z, p)
            if (p.trail < bestTrail[bi]) {
                bestTrail[bi] = p.trail
                bestIdx[bi] = list.size - 1
            }
        }

        // A border belongs to whichever region it leads INTO (the higher rank): every place
        // Greenhollow touches Frostpeak directly needs the same gate as Whisperwood touching
        // Frostpeak does, since both require the same bosses beaten first. Not just neighbors
        // in ZONE_ORDER — any two differently-ranked regions that happen to share an edge.
        for (j in 0 until GRID) {
            for (i in 0 until GRID - 1) {
                val a = ranks[j * GRID + i]
                val b = ranks[j * GRID + i + 1]
                if (a != b) {
                    consider(max(a, b) - 1, (i + 1) * CELL, (j + 0.5f) * CELL, 1.5707964f)
                }
            }
        }
        for (j in 0 until GRID - 1) {
            for (i in 0 until GRID) {
                val a = ranks[j * GRID + i]
                val b = ranks[(j + 1) * GRID + i]
                if (a != b) {
                    consider(max(a, b) - 1, (i + 0.5f) * CELL, (j + 1) * CELL, 0f)
                }
            }
        }

        val gateMeshList = ArrayList<CreaturePart>()
        for (bi in cand.indices) {
            val list = cand[bi]
            val gi = bestIdx[bi]
            var gx = 0f
            var gz = 0f
            var gyaw = 0f
            if (gi >= 0) {
                val g = list[gi]
                gx = g.x
                gz = g.z
                gyaw = g.yaw
                gateX[bi] = gx
                gateZ[bi] = gz
                gateYaw[bi] = gyaw
                hasGateArr[bi] = true
                val c = cos(gyaw)
                val s = sin(gyaw)
                for (side in intArrayOf(-1, 1)) {
                    val off = (GATE_HALF + 0.55f) * side
                    gpx.add(gx + c * off)
                    gpz.add(gz + s * off)
                }
            }
            for (k in list.indices) {
                if (k == gi) continue
                val s = list[k]
                if (gi >= 0 && hypot(s.x - gx, s.z - gz) < GATE_CLEAR) continue
                wx.add(s.x)
                wz.add(s.z)
                wc.add(cos(s.yaw))
                ws.add(sin(s.yaw))
                biOf.add(bi)
            }
            gateMeshList.add(
                mesh(2048) { m -> if (hasGateArr[bi]) buildGate(m, gx, gz, gyaw, ZONE_ORDER[bi + 1]) },
            )
        }
        gateMeshes = gateMeshList.toTypedArray()
        wallMesh = mesh(49152) { m -> buildWall(m) }
    }

    private fun mesh(size: Int, build: (MeshBuilder) -> Unit): CreaturePart {
        val m = MeshBuilder(size)
        build(m)
        return CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
    }

    /** Every wall span and gate arch, for uploading to the graphics card. */
    val meshes: List<CreaturePart> get() = listOf(wallMesh) + gateMeshes.toList()

    private fun brick(bi: Int): Int {
        val zone = ZONE_ORDER[(bi + 1).coerceIn(0, ZONE_ORDER.size - 1)]
        val base = 0x8A6A52
        return when (zone) {
            Zone.MEADOW -> shadeRgb(base, 1.0f)
            Zone.FOREST -> shadeRgb(0x5A5648, 1.0f)
            Zone.SNOW -> shadeRgb(0x8892A0, 1.0f)
            Zone.DESERT -> shadeRgb(0xA88458, 1.0f)
            Zone.CAVES -> shadeRgb(0x585068, 1.0f)
        }
    }

    private fun buildWall(m: MeshBuilder) {
        for (k in wx.indices) {
            val x = wx[k]
            val z = wz[k]
            val yaw = kotlin.math.atan2(ws[k], wc[k])
            val h = world.terrainAt(x, z)
            val color = brick(biOf[k])
            m.box(x, h + HEIGHT * 0.5f, z, HALF_LEN, HEIGHT * 0.5f, HALF_THICK, yaw, color, FLAG_STONE)
            m.box(x, h + HEIGHT + 0.14f, z, HALF_LEN + 0.12f, 0.14f, HALF_THICK + 0.12f, yaw, shadeRgb(color, 1.18f), FLAG_STONE)
        }
    }

    /** A stone gateway through the wall: two piers and a lintel, wide enough to walk through. */
    private fun buildGate(m: MeshBuilder, x: Float, z: Float, yaw: Float, zone: Zone) {
        val c = cos(yaw)
        val s = sin(yaw)
        val h = world.terrainAt(x, z)
        val stone = when (zone) {
            Zone.MEADOW -> 0x8C8270
            Zone.FOREST -> 0x565246
            Zone.SNOW -> 0x9AA4B0
            Zone.DESERT -> 0xB08858
            Zone.CAVES -> 0x66607C
        }
        val pierH = 4.6f
        // The gap between the piers sits along the wall's own line (the tangent direction);
        // that's the width you walk through as you cross from one region into the next.
        for (side in intArrayOf(-1, 1)) {
            val off = (GATE_HALF + 0.55f) * side
            val px = x + c * off
            val pz = z + s * off
            m.box(px, h + pierH * 0.5f, pz, HALF_THICK + 0.35f, pierH * 0.5f, HALF_THICK + 0.35f, yaw, stone, FLAG_STONE)
            m.box(px, h + pierH + 0.3f, pz, HALF_THICK + 0.5f, 0.3f, HALF_THICK + 0.5f, yaw, shadeRgb(stone, 1.2f), FLAG_STONE)
        }
        // Lintel spanning the gap between the piers.
        m.box(x, h + pierH + 0.55f, z, GATE_HALF + 0.9f, 0.5f, HALF_THICK + 0.4f, yaw, stone, FLAG_STONE)
        // A carved keystone in the middle.
        m.box(x, h + pierH + 0.55f, z, 0.55f, 0.55f, HALF_THICK + 0.5f, yaw, shadeRgb(stone, 1.3f), FLAG_STONE)
    }

    /** True if a body of [r] at (x, z) would bump into the wall. */
    fun blocksWall(x: Float, z: Float, r: Float): Boolean {
        for (k in wx.indices) {
            val dx = x - wx[k]
            val dz = z - wz[k]
            if (dx * dx + dz * dz > (HALF_LEN + r + 2f) * (HALF_LEN + r + 2f)) continue
            // Rotate into the wall's own frame: along its length, and across its thickness.
            val cc = wc[k]
            val ss = ws[k]
            val along = dx * cc + dz * ss
            val across = -dx * ss + dz * cc
            if (abs(along) < HALF_LEN + r && abs(across) < HALF_THICK + r) return true
        }
        for (k in gpx.indices) {
            val dx = x - gpx[k]
            val dz = z - gpz[k]
            if (dx * dx + dz * dz < (HALF_THICK + 0.35f + r) * (HALF_THICK + 0.35f + r)) return true
        }
        return false
    }
}
