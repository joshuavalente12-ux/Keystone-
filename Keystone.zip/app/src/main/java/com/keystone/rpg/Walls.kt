package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Distance between points along a smoothed wall line. */
private const val SEG = 4f

/**
 * A brick wall runs along the border of every region: one smooth, continuous line that
 * hugs the ground, with a single stone gateway through it for each step up [ZONE_ORDER].
 * Gateways only ever join a region to the very next one, so you go 1, 2, 3, 4, 5.
 */
class Borders(private val world: World) {
    /** Where each gate stands (gate bi leads into ZONE_ORDER[bi + 1]). */
    val gateX = FloatArray(ZONE_ORDER.size - 1)
    val gateZ = FloatArray(ZONE_ORDER.size - 1)
    val gateYaw = FloatArray(ZONE_ORDER.size - 1)
    private val hasGateArr = BooleanArray(ZONE_ORDER.size - 1)
    fun hasGate(bi: Int): Boolean = bi in hasGateArr.indices && hasGateArr[bi]

    // Straight wall pieces, for collision: centre, direction, half length.
    private val px = ArrayList<Float>()
    private val pz = ArrayList<Float>()
    private val pc = ArrayList<Float>()
    private val ps = ArrayList<Float>()
    private val ph = ArrayList<Float>()
    // The stone piers either side of each gate are solid too.
    private val gpx = ArrayList<Float>()
    private val gpz = ArrayList<Float>()

    // Pieces sorted into a coarse grid so a step only checks the wall nearby.
    private val buckets: Array<IntArray>
    private val bucketsN: Int
    // Each gate's two pier positions: ax, az, bx, bz.
    private val gatePiers = Array(ZONE_ORDER.size - 1) { FloatArray(4) }

    val wallMesh: CreaturePart
    val gateMeshes: Array<CreaturePart>

    /** One unbroken run of border between two particular regions. */
    private class Chain(val lo: Int, val hi: Int, val xs: FloatArray, val zs: FloatArray) {
        val n get() = xs.size
        /** Point [s] metres along the chain (points are [SEG] apart). */
        fun at(s: Float, out: FloatArray) {
            val f = (s / SEG).coerceIn(0f, (n - 1).toFloat())
            val i = min(f.toInt(), n - 2)
            val t = f - i
            out[0] = xs[i] + (xs[i + 1] - xs[i]) * t
            out[1] = zs[i] + (zs[i + 1] - zs[i]) * t
        }
        val length get() = (n - 1) * SEG
    }

    companion object {
        private const val HALF_THICK = 0.55f
        private const val HEIGHT = 3.6f
        private const val SINK = 1.6f
        private const val GATE_HALF = 2.3f
        private const val PIER_OFF = GATE_HALF + 0.55f
        private const val BUCKET = 30f
    }

    init {
        val g1 = GRID + 1
        val ranks = IntArray(GRID * GRID)
        for (idx in ranks.indices) ranks[idx] = zoneRank(Zone.entries[world.regionMap[idx].toInt()])

        // Every edge between two differently-ranked cells, joining two grid corners,
        // filed under the pair of regions it separates.
        val edgesByPair = HashMap<Int, ArrayList<Long>>()
        fun addEdge(ra: Int, rb: Int, c0: Int, c1: Int) {
            val lo = min(ra, rb)
            val hi = max(ra, rb)
            edgesByPair.getOrPut(lo * 16 + hi) { ArrayList() }.add((c0.toLong() shl 32) or c1.toLong())
        }
        for (j in 0 until GRID) {
            for (i in 0 until GRID - 1) {
                val a = ranks[j * GRID + i]
                val b = ranks[j * GRID + i + 1]
                if (a != b) addEdge(a, b, j * g1 + (i + 1), (j + 1) * g1 + (i + 1))
            }
        }
        for (j in 0 until GRID - 1) {
            for (i in 0 until GRID) {
                val a = ranks[j * GRID + i]
                val b = ranks[(j + 1) * GRID + i]
                if (a != b) addEdge(a, b, (j + 1) * g1 + i, (j + 1) * g1 + (i + 1))
            }
        }

        // Link the edges up into chains, then smooth the grid's zig-zag into a flowing line.
        val chains = ArrayList<Chain>()
        for ((key, edges) in edgesByPair) {
            val lo = key / 16
            val hi = key % 16
            val adj = HashMap<Int, ArrayList<Int>>()
            for (e in edges.indices) {
                val c0 = (edges[e] shr 32).toInt()
                val c1 = (edges[e] and 0xFFFFFFFFL).toInt()
                adj.getOrPut(c0) { ArrayList() }.add(e)
                adj.getOrPut(c1) { ArrayList() }.add(e)
            }
            val used = BooleanArray(edges.size)
            fun other(e: Int, c: Int): Int {
                val c0 = (edges[e] shr 32).toInt()
                return if (c0 == c) (edges[e] and 0xFFFFFFFFL).toInt() else c0
            }
            fun walk(start: Int, firstEdge: Int): ArrayList<Int> {
                val pts = arrayListOf(start)
                var c = start
                var e = firstEdge
                while (true) {
                    used[e] = true
                    c = other(e, c)
                    pts.add(c)
                    val nexts = adj[c] ?: break
                    if (nexts.size != 2) break
                    e = nexts.firstOrNull { !used[it] } ?: break
                }
                return pts
            }
            val runs = ArrayList<ArrayList<Int>>()
            for ((c, list) in adj) {
                if (list.size == 2) continue
                for (e in list) if (!used[e]) runs.add(walk(c, e))
            }
            for (e in edges.indices) {
                if (used[e]) continue
                runs.add(walk((edges[e] shr 32).toInt(), e))
            }
            for (run in runs) {
                val ch = smooth(run, g1, lo, hi)
                if (ch != null) chains.add(ch)
            }
        }

        // One gateway per step up the order, only between a region and the very next one,
        // at the easiest crossing: close to a road, off the mountains, clear of rivers.
        val gateChain = IntArray(ZONE_ORDER.size - 1) { -1 }
        val gateS = FloatArray(ZONE_ORDER.size - 1)
        val p = Probe()
        for (bi in 0 until ZONE_ORDER.size - 1) {
            var best = Float.MAX_VALUE
            for (ci in chains.indices) {
                val ch = chains[ci]
                if (ch.lo != bi || ch.hi != bi + 1 || ch.length < 20f) continue
                var k = 3
                while (k < ch.n - 3) {
                    world.probe(ch.xs[k], ch.zs[k], p)
                    var score = p.trail + p.mountain * 400f
                    if (p.river < 10f) score += 600f
                    if (p.site < 20f) score += 300f
                    if (score < best) {
                        best = score
                        gateChain[bi] = ci
                        gateS[bi] = k * SEG
                    }
                    k++
                }
            }
        }

        // Cut the wall into short straight pieces, leaving the gap for each gate.
        val pieceA = ArrayList<FloatArray>()
        val pieceColor = ArrayList<Int>()
        val a = FloatArray(2)
        val b = FloatArray(2)
        for (ci in chains.indices) {
            val ch = chains[ci]
            val bi = gateChain.indexOf(ci)
            val gapA = if (bi >= 0) gateS[bi] - PIER_OFF else -1f
            val gapB = if (bi >= 0) gateS[bi] + PIER_OFF else -1f
            val color = brick(ch.hi - 1)
            for (k in 0 until ch.n - 1) {
                val s0 = k * SEG
                val s1 = s0 + SEG
                val spans = if (bi < 0 || s1 <= gapA || s0 >= gapB) {
                    listOf(s0 to s1)
                } else {
                    listOfNotNull(if (s0 < gapA) s0 to gapA else null, if (s1 > gapB) gapB to s1 else null)
                }
                for ((u0, u1) in spans) {
                    if (u1 - u0 < 0.05f) continue
                    ch.at(u0, a)
                    ch.at(u1, b)
                    pieceA.add(floatArrayOf(a[0], a[1], b[0], b[1]))
                    pieceColor.add(color)
                }
            }
            if (bi >= 0) {
                ch.at(gateS[bi] - PIER_OFF, a)
                ch.at(gateS[bi] + PIER_OFF, b)
                gpx.add(a[0]); gpz.add(a[1])
                gpx.add(b[0]); gpz.add(b[1])
                gatePiers[bi][0] = a[0]; gatePiers[bi][1] = a[1]
                gatePiers[bi][2] = b[0]; gatePiers[bi][3] = b[1]
                gateX[bi] = (a[0] + b[0]) * 0.5f
                gateZ[bi] = (a[1] + b[1]) * 0.5f
                gateYaw[bi] = atan2(b[1] - a[1], b[0] - a[0])
                hasGateArr[bi] = true
            }
        }

        for (pc0 in pieceA) {
            val dx = pc0[2] - pc0[0]
            val dz = pc0[3] - pc0[1]
            val len = hypot(dx, dz)
            if (len < 1e-3f) continue
            px.add((pc0[0] + pc0[2]) * 0.5f)
            pz.add((pc0[1] + pc0[3]) * 0.5f)
            pc.add(dx / len)
            ps.add(dz / len)
            ph.add(len * 0.5f)
        }

        val nb = (WORLD_SIZE / BUCKET).toInt() + 1
        val lists = Array(nb * nb) { ArrayList<Int>() }
        for (k in px.indices) {
            val r = ph[k] + HALF_THICK
            val bx0 = ((px[k] - r) / BUCKET).toInt().coerceIn(0, nb - 1)
            val bx1 = ((px[k] + r) / BUCKET).toInt().coerceIn(0, nb - 1)
            val bz0 = ((pz[k] - r) / BUCKET).toInt().coerceIn(0, nb - 1)
            val bz1 = ((pz[k] + r) / BUCKET).toInt().coerceIn(0, nb - 1)
            for (bz in bz0..bz1) for (bx in bx0..bx1) lists[bz * nb + bx].add(k)
        }
        buckets = Array(lists.size) { lists[it].toIntArray() }
        bucketsN = nb

        wallMesh = mesh(65536) { m ->
            for (k in pieceA.indices) {
                val q = pieceA[k]
                buildPiece(m, q[0], q[1], q[2], q[3], pieceColor[k])
            }
        }
        gateMeshes = Array(ZONE_ORDER.size - 1) { bi ->
            mesh(2048) { m ->
                if (hasGateArr[bi]) {
                    val g = gatePiers[bi]
                    buildGate(m, g[0], g[1], g[2], g[3], ZONE_ORDER[bi + 1])
                }
            }
        }
    }

    /** Turns a run of grid corners into an evenly spaced, smoothed line of points. */
    private fun smooth(run: List<Int>, g1: Int, lo: Int, hi: Int): Chain? {
        if (run.size < 2) return null
        val n = run.size
        val x = FloatArray(n) { (run[it] % g1) * CELL }
        val z = FloatArray(n) { (run[it] / g1) * CELL }
        // Two passes of a gentle average: the staircase becomes a slope, ends stay put.
        repeat(2) {
            val sx = x.copyOf()
            val sz = z.copyOf()
            for (i in 1 until n - 1) {
                var ax = 0f
                var az = 0f
                var w = 0
                for (d in -2..2) {
                    val j = (i + d).coerceIn(0, n - 1)
                    ax += sx[j]
                    az += sz[j]
                    w++
                }
                x[i] = ax / w
                z[i] = az / w
            }
        }
        // Resample to points exactly SEG metres apart along the line (the last gap may be shorter).
        var total = 0f
        for (i in 1 until n) total += hypot(x[i] - x[i - 1], z[i] - z[i - 1])
        if (total < 0.5f) return null
        val count = max(2, kotlin.math.ceil(total / SEG).toInt() + 1)
        val ox = FloatArray(count)
        val oz = FloatArray(count)
        var seg = 1
        var segStart = 0f
        var segLen = hypot(x[1] - x[0], z[1] - z[0])
        for (k in 0 until count) {
            val s = min(k * SEG, total)
            while (seg < n - 1 && segStart + segLen < s) {
                segStart += segLen
                seg++
                segLen = hypot(x[seg] - x[seg - 1], z[seg] - z[seg - 1])
            }
            val t = if (segLen > 1e-5f) ((s - segStart) / segLen).coerceIn(0f, 1f) else 0f
            ox[k] = x[seg - 1] + (x[seg] - x[seg - 1]) * t
            oz[k] = z[seg - 1] + (z[seg] - z[seg - 1]) * t
        }
        return Chain(lo, hi, ox, oz)
    }

    private fun mesh(size: Int, build: (MeshBuilder) -> Unit): CreaturePart {
        val m = MeshBuilder(size)
        build(m)
        return CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
    }

    /** Every wall piece and gate arch, for uploading to the graphics card. */
    val meshes: List<CreaturePart> get() = listOf(wallMesh) + gateMeshes.toList()

    private fun brick(bi: Int): Int {
        val zone = ZONE_ORDER[(bi + 1).coerceIn(0, ZONE_ORDER.size - 1)]
        return when (zone) {
            Zone.MEADOW -> 0x8A6A52
            Zone.FOREST -> 0x5A5648
            Zone.SNOW -> 0x8892A0
            Zone.DESERT -> 0xA88458
            Zone.CAVES -> 0x585068
        }
    }

    /**
     * One stretch of wall from (ax, az) to (bx, bz). Its top and bottom follow the ground
     * at each end, so it rises and falls with the hill with no gaps and no steps; its
     * foot is sunk well into the ground so it never floats where the land dips.
     */
    private fun buildPiece(m: MeshBuilder, ax0: Float, az0: Float, bx0: Float, bz0: Float, color: Int) {
        val dx = bx0 - ax0
        val dz = bz0 - az0
        val len = hypot(dx, dz)
        if (len < 1e-3f) return
        val ux = dx / len
        val uz = dz / len
        // Overlap a little into the neighbours so bends leave no cracks.
        val ext = 0.3f
        val ax = ax0 - ux * ext
        val az = az0 - uz * ext
        val bx = bx0 + ux * ext
        val bz = bz0 + uz * ext
        val ha = world.terrainAt(ax0, az0)
        val hb = world.terrainAt(bx0, bz0)
        val hm = world.terrainAt((ax0 + bx0) * 0.5f, (az0 + bz0) * 0.5f)
        val botA = min(ha, hm) - SINK
        val botB = min(hb, hm) - SINK
        val topA = ha + HEIGHT
        val topB = hb + HEIGHT
        slab(m, ax, az, bx, bz, ux, uz, HALF_THICK, botA, topA, botB, topB, color)
        // A slightly wider coping stone along the top.
        slab(m, ax, az, bx, bz, ux, uz, HALF_THICK + 0.12f, topA, topA + 0.28f, topB, topB + 0.28f, shadeRgb(color, 1.18f))
    }

    /** A sloping block: a box whose bottom and top can be at different heights at each end. */
    private fun slab(
        m: MeshBuilder, ax: Float, az: Float, bx: Float, bz: Float, ux: Float, uz: Float, half: Float,
        botA: Float, topA: Float, botB: Float, topB: Float, color: Int,
    ) {
        val nx = -uz * half
        val nz = ux * half
        val cx = (ax + bx) * 0.5f
        val cz = (az + bz) * 0.5f
        val cy = (botA + topA + botB + topB) * 0.25f
        // Corners: A/B end, left(+n)/right(-n) side, bottom/top.
        val alx = ax + nx; val alz = az + nz
        val arx = ax - nx; val arz = az - nz
        val blx = bx + nx; val blz = bz + nz
        val brx = bx - nx; val brz = bz - nz
        val f = FLAG_STONE
        // Two long faces.
        m.quad(alx, botA, alz, blx, botB, blz, blx, topB, blz, alx, topA, alz, color, f, cx, cy, cz)
        m.quad(arx, botA, arz, brx, botB, brz, brx, topB, brz, arx, topA, arz, color, f, cx, cy, cz)
        // Top.
        m.quad(alx, topA, alz, blx, topB, blz, brx, topB, brz, arx, topA, arz, color, f, cx, cy, cz)
        // Ends (seen at the gate and wherever the wall stops).
        m.quad(alx, botA, alz, arx, botA, arz, arx, topA, arz, alx, topA, alz, color, f, cx, cy, cz)
        m.quad(blx, botB, blz, brx, botB, brz, brx, topB, brz, blx, topB, blz, color, f, cx, cy, cz)
    }

    /** A stone gateway: two piers at the ends of the gap in the wall and a lintel across. */
    private fun buildGate(m: MeshBuilder, ax: Float, az: Float, bx: Float, bz: Float, zone: Zone) {
        val stone = when (zone) {
            Zone.MEADOW -> 0x8C8270
            Zone.FOREST -> 0x565246
            Zone.SNOW -> 0x9AA4B0
            Zone.DESERT -> 0xB08858
            Zone.CAVES -> 0x66607C
        }
        val yaw = atan2(bz - az, bx - ax)
        val ha = world.terrainAt(ax, az)
        val hb = world.terrainAt(bx, bz)
        val h = max(ha, hb)
        val pierTop = h + 4.6f
        val pr = HALF_THICK + 0.35f
        for ((qx, qz, qh) in listOf(Triple(ax, az, ha), Triple(bx, bz, hb))) {
            val bot = qh - SINK
            m.box(qx, (bot + pierTop) * 0.5f, qz, pr, (pierTop - bot) * 0.5f, pr, yaw, stone, FLAG_STONE)
            m.box(qx, pierTop + 0.3f, qz, pr + 0.15f, 0.3f, pr + 0.15f, yaw, shadeRgb(stone, 1.2f), FLAG_STONE)
        }
        val cx = (ax + bx) * 0.5f
        val cz = (az + bz) * 0.5f
        val half = hypot(bx - ax, bz - az) * 0.5f
        m.box(cx, pierTop + 0.55f, cz, half + pr, 0.5f, HALF_THICK + 0.4f, yaw, stone, FLAG_STONE)
        m.box(cx, pierTop + 0.55f, cz, 0.55f, 0.55f, HALF_THICK + 0.5f, yaw, shadeRgb(stone, 1.3f), FLAG_STONE)
    }

    /** True if a body of [r] at (x, z) would bump into the wall. */
    fun blocksWall(x: Float, z: Float, r: Float): Boolean {
        val bx = (x / BUCKET).toInt().coerceIn(0, bucketsN - 1)
        val bz = (z / BUCKET).toInt().coerceIn(0, bucketsN - 1)
        for (k in buckets[bz * bucketsN + bx]) {
            val dx = x - px[k]
            val dz = z - pz[k]
            val along = dx * pc[k] + dz * ps[k]
            val across = -dx * ps[k] + dz * pc[k]
            if (abs(along) < ph[k] + 0.3f + r && abs(across) < HALF_THICK + r) return true
        }
        for (k in gpx.indices) {
            val dx = x - gpx[k]
            val dz = z - gpz[k]
            val rr = HALF_THICK + 0.35f + r
            if (dx * dx + dz * dz < rr * rr) return true
        }
        return false
    }
}
