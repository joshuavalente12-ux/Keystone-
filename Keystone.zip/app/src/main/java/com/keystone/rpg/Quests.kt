package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** What a quest asks of you. */
object QKind {
    /** Slay a number of one kind of monster. */
    const val HUNT = 0
    /** Go deep into a cave and bring back what's there. */
    const val RELIC = 1
    /** Defeat a region's boss (the main missions). */
    const val BOSS = 2
}

/** Where a quest is up to. */
object QState {
    const val NEW = 0
    const val ACTIVE = 1
    /** Done: go back to whoever gave it to you. */
    const val READY = 2
    const val DONE = 3
}

class Quest(
    val id: Int,
    /** Who gives it (index into [People.npcs]). */
    val giver: Int,
    val kind: Int,
    /** A main mission (beat a boss) rather than a side quest. */
    val main: Boolean,
    val title: String,
    /** What the giver says when they ask you. */
    val intro: String,
    /** Monster species (HUNT), cave (RELIC) or boss (BOSS). */
    val target: Int,
    val count: Int,
    /** Where it's marked on the map while you're on it. */
    val markX: Float,
    val markZ: Float,
    val tier: Int,
    /** A quest that has to be finished first, or -1. */
    val after: Int,
    /** What you're sent for: "Thornlings", "the Moss Idol"... */
    val thing: String,
    /** Where: the cave's name, the boss's region... */
    val where: String,
) {
    @Volatile var state = QState.NEW
    @Volatile var progress = 0

    val gold: Int get() = (if (main) 150 else 45) * tier * (tier + 1) / 2
    val xp: Int get() = (if (main) 400 else 120) * tier * tier

    /** One line saying what to do next. */
    fun goal(): String = when {
        state == QState.READY -> "Return to the one who asked you"
        kind == QKind.HUNT -> "Slay $thing: $progress / $count"
        kind == QKind.RELIC -> "Find $thing in $where"
        else -> "Defeat $thing in $where"
    }
}

private val RELICS = mapOf(
    Zone.MEADOW to arrayOf("the Moss Idol", "Grandmother's Locket", "the Old Bell of Greenhollow"),
    Zone.FOREST to arrayOf("the Witchwood Lantern", "the Silver Chalice", "the Wraith's Crown"),
    Zone.SNOW to arrayOf("the Frozen Heart", "the Runed Horn", "the Frostwatch Seal"),
    Zone.DESERT to arrayOf("the Sun Amulet", "the Golden Scarab", "the Sunken Tablet"),
    Zone.CAVES to arrayOf("the Void Lantern", "a Keystone Shard", "the Crystal Eye"),
)

/** One hand-written quest: a hunt (by monster name) or a cave relic, with what the giver says. */
private class QSpec(val relic: Boolean, val what: String, val title: String, val intro: String)

/**
 * The quests in the villages and camps added later, by place name, offered one after another.
 * In the words: {n} is how many to slay, {cave} is the cave.
 */
private val NEW_QUESTS: Map<String, Array<QSpec>> = mapOf(
    "Applebrook" to arrayOf(
        QSpec(false, "Thornling", "Brambles with Teeth", "Thornlings have crept into the orchard and they're strangling the apple trees. Pull up {n} of them before the harvest is ruined. They gather where I've marked on your map."),
        QSpec(false, "Hivewasp", "Wasps in the Cider", "A Hivewasp nest swelled up over the summer, and now nobody can get near the cider press. Swat {n} of them for us."),
        QSpec(true, "the Orchard Deed", "The Lost Deed", "My grandfather hid the deed to this orchard in {cave} during the goblin raids, and never went back for it. Without it, Millbrook says the land is theirs. Please, fetch it for me."),
        QSpec(false, "Mossgolem", "The Walking Wall", "Something big has been flattening our fences at night. Tracks the size of cartwheels, moss everywhere: Mossgolems. Bring down {n} before they flatten a house."),
    ),
    "Ferrow's Rest" to arrayOf(
        QSpec(false, "Barkbiter Boar", "Boar Trouble", "Barkbiter Boars keep charging the pack mules on the road. Thin them out for me: {n} should do it."),
        QSpec(false, "Goblin Scrapper", "Scrap Raiders", "Goblin Scrappers stole half my stock last night. Teach {n} of them a lesson I won't have to repeat."),
        QSpec(true, "Ferrow's Strongbox", "Ferrow's Strongbox", "Old Ferrow, who built this rest stop, hid his strongbox deep in {cave}. Folk say it's still down there. Find it and bring it back, and you'll have earned your share."),
    ),
    "Shepherd's Camp" to arrayOf(
        QSpec(false, "Mudgrub", "Mud in the Meadow", "Mudgrubs are burrowing under the grazing fields, and the sheep keep breaking their legs in the holes. Squash {n} of them."),
        QSpec(false, "Rootsnake", "Snakes in the Grass", "Rootsnakes have been biting my flock. Hunt {n} of them down around the spot I've marked."),
        QSpec(false, "Hollowshroom", "Spore Season", "Hollowshrooms are puffing spores all over the pasture and the lambs are coughing. Stamp out {n} of them, would you?"),
    ),
    "Lanternwick" to arrayOf(
        QSpec(false, "Nightwisp", "Lights in the Dark", "Nightwisps lure our woodcutters off the path, and they don't come back. Snuff out {n} of them."),
        QSpec(true, "the First Lantern", "The First Lantern", "Lanternwick is named for a lantern that has never gone out. Someone stole it and carried it into {cave}. The town grows darker every night without it. Bring it home."),
        QSpec(false, "Shadow Treant", "Trees That Walk", "Some of the oldest trees round here have started to move: Shadow Treants. Fell {n} of them before they reach the town."),
    ),
    "Mosswater Camp" to arrayOf(
        QSpec(false, "Bog Hag", "The Hags of Mosswater", "Bog Hags have taken the marsh and they're souring our water. Drive out {n} of them."),
        QSpec(false, "Venomcoil", "Venom in the Reeds", "A trapper was bitten by a Venomcoil this morning. He'll live, barely. Clear {n} of them out of the reeds I've marked."),
        QSpec(true, "the Marsh Pearl", "The Marsh Pearl", "Our healer's pearl was the only thing keeping the marsh fever away, and a thief ran off with it into {cave}. Get it back before the fever spreads."),
    ),
    "Hollowbough Camp" to arrayOf(
        QSpec(false, "Wraithwolf", "Howls at Hollowbough", "Wraithwolves circle the camp every night. Bring down {n} of them so we can sleep."),
        QSpec(false, "Gloomspider", "Webs Across the Path", "Gloomspiders have strung webs across every trail out of camp. Cut down {n} of them."),
        QSpec(false, "Barrow Wight", "The Restless Dead", "The old barrows have opened and the Barrow Wights are walking. Lay {n} of them back to rest."),
    ),
    "Kettlefrost" to arrayOf(
        QSpec(false, "Icefang Wolf", "Wolves at the Gate", "Icefang Wolves have been taking goats straight out of our pens. Hunt {n} of them down."),
        QSpec(true, "the Warming Stone", "The Warming Stone", "The stone that keeps Kettlefrost's springs from freezing was carried off into {cave}. Without it, the whole town freezes. Hurry."),
        QSpec(false, "Rime Golem", "Rime and Ruin", "Rime Golems keep smashing the ice road. Break {n} of them apart."),
    ),
    "Ridgefire Camp" to arrayOf(
        QSpec(false, "Frost Yeti", "Yeti Country", "Frost Yetis tore through our supply sleds. Take down {n} of the brutes."),
        QSpec(false, "Snow Wyrm", "Under the Snow", "Snow Wyrms swim under the drifts and strike from below. Kill {n} of them near the place I've marked."),
        QSpec(true, "the Ridgefire Brand", "The Ridgefire Brand", "This camp's first fire was lit from a brand that has never gone cold. Raiders hid it in {cave}. Bring it back so we can light the fire properly again."),
    ),
    "Bearpelt Camp" to arrayOf(
        QSpec(false, "Tuskhorn", "Tuskhorn Stampede", "A Tuskhorn herd nearly flattened the camp. Thin them out by {n}."),
        QSpec(false, "Glacier Crab", "Claws on the Ice", "Glacier Crabs are cutting through our fishing lines, and our fishers' legs. Crack {n} of their shells."),
        QSpec(false, "Frostwisp", "Frozen Breath", "Frostwisps drift through camp at night and freeze anyone they touch. Destroy {n} of them."),
    ),
    "Qarim's Wells" to arrayOf(
        QSpec(false, "Dunestinger", "Stingers at the Well", "Dunestingers have nested by the wells and nobody can draw water. Kill {n} of them."),
        QSpec(false, "Bone Jackal", "The Jackal Packs", "Bone Jackals harry every caravan heading our way. Hunt {n} of them."),
        QSpec(true, "Qarim's Water Map", "Qarim's Map", "Qarim, who found these wells, drew a map of every hidden spring in the desert. It's buried in {cave}. Find it, and no caravan need ever die of thirst again."),
        QSpec(false, "Sun Basilisk", "Eyes of the Sun", "A Sun Basilisk's stare turned two of our guards to glass. Slay {n} of them."),
        QSpec(false, "Sand Golem", "Walking Dunes", "The dunes themselves are rising up and walking towards the wells: Sand Golems. Break {n} of them."),
    ),
    "Saltwind Camp" to arrayOf(
        QSpec(false, "Cinder Imp", "Imps in the Salt", "Cinder Imps keep setting our salt sacks alight. Put out {n} of them for good."),
        QSpec(false, "Mummy Warden", "Wrapped and Waiting", "Mummy Wardens have walked out of the old tombs and onto the salt flats. Put {n} of them back in the ground."),
        QSpec(true, "the Salt Crown", "The Salt Crown", "The crown of the old salt kings lies somewhere in {cave}. The merchant guilds would pay a fortune for it, and so would I."),
        QSpec(false, "Duneworm", "Something Below", "The ground shook and a Duneworm swallowed a whole cart. Kill {n} of them before it happens again."),
    ),
    "Scorpion Camp" to arrayOf(
        QSpec(false, "Scarab Titan", "Shells of Bronze", "Scarab Titans are digging up the caravan road. Crack {n} of their shells."),
        QSpec(false, "Dunestinger", "The Camp's Namesake", "We're named for scorpions for a reason. The Dunestingers are back, worse than ever. Kill {n} of them."),
        QSpec(true, "the Sandglass of Ages", "The Sandglass", "A sandglass whose sand never runs out was lost in {cave}. Our seer swears it shows the future. I'd very much like to see that."),
        QSpec(false, "Bone Jackal", "Bones in the Night", "Bone Jackals dug up our burial ground last night. Hunt {n} of them."),
    ),
    "Lumen Hollow" to arrayOf(
        QSpec(false, "Abyss Eye", "The Watching Eyes", "Abyss Eyes float over the town at night, watching. People are going mad from it. Close {n} of them."),
        QSpec(true, "the Lumen Crystal", "The Lumen Crystal", "Lumen Hollow's light comes from one great crystal, and it was stolen away into {cave}. Without it we're in the dark with everything else down here."),
        QSpec(false, "Crystal Golem", "Crystal Hearts", "Crystal Golems keep breaking into our mines. Shatter {n} of them."),
    ),
    "Cinderdeep" to arrayOf(
        QSpec(false, "Deep Crawler", "Things That Crawl", "Deep Crawlers come up through the cracks in the ground. Kill {n} of them."),
        QSpec(false, "Lurker Horror", "The Lurker", "Something waits just outside the torchlight: Lurker Horrors. Bring down {n} of them."),
        QSpec(true, "the Ember Heart", "The Ember Heart", "The ember that keeps Cinderdeep's forges burning was taken into {cave}. Our smiths can't work without it."),
    ),
    "Shardlight Camp" to arrayOf(
        QSpec(false, "Void Stalker", "Stalked", "Void Stalkers have been picking off our scouts one by one. Hunt {n} of them before they get the rest of us."),
        QSpec(true, "the Shardlight Compass", "The Shardlight Compass", "We had a compass that always points to Keystone shards. It was lost in {cave}. Find it, and maybe we can finally finish this."),
    ),
    "Ashveil Camp" to arrayOf(
        QSpec(false, "Soulwraith", "Souls Adrift", "Soulwraiths drift through the ash, draining the life out of anyone they pass. Banish {n} of them."),
        QSpec(false, "Shade Serpent", "Serpents in the Ash", "Shade Serpents hide in the ash drifts and strike without warning. Kill {n} of them."),
    ),
    "Gloomroot Camp" to arrayOf(
        QSpec(false, "Crystal Golem", "Crystals That Walk", "Crystal Golems trampled our gardens of glowroot. Smash {n} of them."),
        QSpec(true, "the Gloomroot Seed", "The Last Seed", "The last seed of the gloomroot tree, the only thing that grows down here, was carried off into {cave}. Bring it back so we can plant it."),
    ),
    "Voidwatch Camp" to arrayOf(
        QSpec(false, "Abyss Eye", "Watch the Watchers", "We keep watch on the void. Lately, the void watches back. Close {n} Abyss Eyes."),
        QSpec(false, "Void Stalker", "The Last Watch", "Void Stalkers overran our last watch post. Avenge them: slay {n} of them."),
    ),
)

private val MAIN_TITLES = arrayOf("The Moss King", "The Hollow Elder", "The Frost Tyrant", "The Sun Devourer", "The Keystone Warden")
private val MAIN_LINES = arrayOf(
    "Gorvak, the Moss King, has woken in his ring of standing stones. While he lives, the seal on Whisperwood holds fast. His lair is marked on your map. Bring him down, traveller.",
    "The Hollow Elder was a great tree once. Now it walks, and the whole wood whispers its name. Defeat it and the way to Frostpeak will open.",
    "Grimtusk the Frost Tyrant rules these peaks from his circle of stones. Break him, and the seal on the Sunscar Dunes will break with him.",
    "Khepri the Sun Devourer has buried whole caravans. Only when it falls will the road into the Hollow Deep be open.",
    "At the heart of the Hollow Deep waits the Keystone Warden, the oldest thing in this world. End it, and the Keystone is yours.",
)

/**
 * Every quest in the world. Elders in the towns and camps and the lords in their castles
 * have side quests; the main missions (one per region's boss) run from Greenhollow's
 * elder through each region's castle lord. Progress is saved with your game.
 */
class Quests(private val people: People, fauna: Fauna, treasure: Treasure, private val world: World) {
    val list = ArrayList<Quest>()
    private val lock = Any()
    private var ctx: Context? = null

    /** Changes whenever any quest changes, so the screen redraws. */
    var version by mutableIntStateOf(0)
        private set

    init {
        build(fauna, treasure)
    }

    private fun build(fauna: Fauna, treasure: Treasure) {
        val rnd = java.util.Random(777)
        val p = Probe()
        // Main missions: Greenhollow's elder first, then the lord of each region's castle.
        var prevMain = -1
        for (i in BOSSES.indices) {
            val b = BOSSES[i]
            val giver = (
                if (i == 0) {
                    people.giverAt(0)
                } else {
                    val ci = PLACES.indices.firstOrNull { idx ->
                        PLACES[idx].kind == Site.CASTLE && run { world.probe(PLACES[idx].x, PLACES[idx].z, p); p.zone == b.zone }
                    }
                    if (ci != null) people.giverAt(ci) else null
                }
                ) ?: continue
            val q = Quest(
                list.size, giver.id, QKind.BOSS, true, MAIN_TITLES[i], MAIN_LINES[i], i, 1,
                treasure.lairX[i], treasure.lairZ[i], tierOf(b.zone), prevMain, b.name, b.zone.title,
            )
            list.add(q)
            prevMain = q.id
        }
        // Side quests: a hunt and a cave for every elder and lord.
        val usedCaves = HashSet<Int>()
        for (g in people.npcs) {
            if (g.role != NpcRole.QUEST && g.role != NpcRole.LORD) continue
            // The newer villages and camps have their own hand-written runs of quests (below).
            if (g.place >= FIRST_NEW_PLACE) continue
            val tier = tierOf(g.zone)
            val place = PLACES[g.place].name
            // The hunt.
            val kinds = fauna.species.indices.filter { fauna.species[it].monster && g.zone in fauna.species[it].zones }
            var huntId = -1
            if (kinds.isNotEmpty()) {
                val si = kinds[rnd.nextInt(kinds.size)]
                val sp = fauna.species[si]
                val count = if (sp.hp >= 10) 2 + rnd.nextInt(2) else 4 + rnd.nextInt(3)
                val spot = huntingGround(g, p, rnd)
                val plural = plural(sp.name)
                val q = Quest(
                    list.size, g.id, QKind.HUNT, false, "Cull the $plural",
                    "$plural have been attacking travellers on the roads near $place. Slay $count of them and I'll make it worth your while. They're thick around the place I've marked on your map.",
                    si, count, spot[0], spot[1], tier, -1, plural, place,
                )
                list.add(q)
                huntId = q.id
            }
            // The cave.
            var best = -1
            var bestD = 1e9f
            for (cv in treasure.caves) {
                if (cv.zone != g.zone || cv.rot) continue
                val d = hypot(cv.x - g.homeX, cv.z - g.homeZ) + (if (cv.id in usedCaves) 2000f else 0f)
                if (d < bestD) {
                    bestD = d
                    best = cv.id
                }
            }
            if (best >= 0) {
                usedCaves.add(best)
                val cv = treasure.caves[best]
                val names = RELICS.getValue(g.zone)
                val relic = names[rnd.nextInt(names.size)]
                list.add(
                    Quest(
                        list.size, g.id, QKind.RELIC, false, "Into ${cv.name}",
                        "Something precious was lost deep inside ${cv.name}: ${relic}. The tunnels are dark and the way is long, but the cave is marked on your map. Go to the deepest chamber and bring it back to me.",
                        best, 1, cv.mouthX, cv.mouthZ, tier, huntId, relic, cv.name,
                    ),
                )
            }
        }
        buildNew(fauna, treasure, rnd, p, usedCaves)
    }

    /**
     * The newer villages' and camps' quests, appended after all the others so saved progress on
     * the old ones still lines up. Each elder offers theirs one at a time.
     */
    private fun buildNew(fauna: Fauna, treasure: Treasure, rnd: java.util.Random, p: Probe, usedCaves: HashSet<Int>) {
        for (g in people.npcs) {
            if (g.role != NpcRole.QUEST || g.place < FIRST_NEW_PLACE) continue
            val specs = NEW_QUESTS[PLACES[g.place].name] ?: continue
            val tier = tierOf(g.zone)
            val place = PLACES[g.place].name
            var prev = -1
            for (spec in specs) {
                if (spec.relic) {
                    var best = -1
                    var bestD = 1e9f
                    for (cv in treasure.caves) {
                        if (cv.zone != g.zone || cv.rot) continue
                        val d = hypot(cv.x - g.homeX, cv.z - g.homeZ) + (if (cv.id in usedCaves) 2000f else 0f)
                        if (d < bestD) {
                            bestD = d
                            best = cv.id
                        }
                    }
                    if (best < 0) continue
                    usedCaves.add(best)
                    val cv = treasure.caves[best]
                    val q = Quest(
                        list.size, g.id, QKind.RELIC, false, spec.title, spec.intro.replace("{cave}", cv.name),
                        best, 1, cv.mouthX, cv.mouthZ, tier, prev, spec.what, cv.name,
                    )
                    list.add(q)
                    prev = q.id
                } else {
                    val si = fauna.species.indexOfFirst { it.name == spec.what && it.monster }
                    if (si < 0) continue
                    val sp = fauna.species[si]
                    val count = if (sp.hp >= 10) 2 + rnd.nextInt(2) else 4 + rnd.nextInt(3)
                    val spot = huntingGround(g, p, rnd)
                    val q = Quest(
                        list.size, g.id, QKind.HUNT, false, spec.title, spec.intro.replace("{n}", count.toString()),
                        si, count, spot[0], spot[1], tier, prev, plural(sp.name), place,
                    )
                    list.add(q)
                    prev = q.id
                }
            }
        }
    }

    /** Open ground in the giver's region, a good walk away: where the hunt is marked. */
    private fun huntingGround(g: Npc, p: Probe, rnd: java.util.Random): FloatArray {
        val start = rnd.nextFloat() * 6.2831855f
        for (r in floatArrayOf(120f, 160f, 200f, 250f)) {
            for (k in 0 until 16) {
                val a = start + k * 0.3926991f
                val x = g.homeX + cos(a) * r
                val z = g.homeZ + sin(a) * r
                if (x < 60f || z < 60f || x > WORLD_SIZE - 60f || z > WORLD_SIZE - 60f) continue
                world.probe(x, z, p)
                if (p.zone != g.zone || p.site < 50f || p.mountain > 0.3f) continue
                if (world.terrainAt(x, z) < 0.8f || world.isBlocked(x, z, p)) continue
                return floatArrayOf(x, z)
            }
        }
        return floatArrayOf(g.homeX + 150f, g.homeZ)
    }

    private fun plural(name: String): String = when {
        name.endsWith("wolf") -> name.dropLast(4) + "wolves"
        name.endsWith("s") -> name + "es"
        name.endsWith("y") && !name.endsWith("ey") -> name.dropLast(1) + "ies"
        else -> name + "s"
    }

    // ---------- Asking and answering ----------

    private fun ready(q: Quest): Boolean = q.after < 0 || list[q.after].state == QState.DONE

    /**
     * What [npc] wants to talk to you about: a quest to hand in first, then one you're on,
     * then a new one they can offer. Null if they have nothing.
     */
    fun forGiver(npc: Int): Quest? = synchronized(lock) {
        list.firstOrNull { it.giver == npc && it.state == QState.READY }
            ?: list.firstOrNull { it.giver == npc && it.state == QState.ACTIVE }
            ?: list.firstOrNull { it.giver == npc && it.state == QState.NEW && ready(it) }
    }

    /** True if [npc] has a new quest for you or one to hand in (for the marker over their head). */
    fun hasNew(npc: Int): Boolean = synchronized(lock) { list.any { it.giver == npc && it.state == QState.NEW && ready(it) } }
    fun hasReady(npc: Int): Boolean = synchronized(lock) { list.any { it.giver == npc && it.state == QState.READY } }

    fun accept(q: Quest, loot: Loot) {
        synchronized(lock) {
            if (q.state != QState.NEW) return
            q.state = QState.ACTIVE
            q.progress = 0
            // Already beaten that boss? Then it's done straight away.
            if (q.kind == QKind.BOSS && loot.bossBeaten(q.target)) q.state = QState.READY
        }
        changed()
    }

    /** Marks [q] finished. The game hands out the reward. */
    fun complete(q: Quest): Boolean {
        synchronized(lock) {
            if (q.state != QState.READY) return false
            q.state = QState.DONE
        }
        changed()
        return true
    }

    /** You killed a monster of species [si]. Returns a quest that just got finished, if any. */
    fun onKill(si: Int): Quest? {
        var done: Quest? = null
        var any = false
        synchronized(lock) {
            for (q in list) {
                if (q.state != QState.ACTIVE || q.kind != QKind.HUNT || q.target != si) continue
                q.progress++
                any = true
                if (q.progress >= q.count) {
                    q.state = QState.READY
                    done = q
                }
            }
        }
        if (any) changed()
        return done
    }

    fun onBoss(i: Int): Quest? {
        var done: Quest? = null
        synchronized(lock) {
            for (q in list) {
                if (q.state == QState.ACTIVE && q.kind == QKind.BOSS && q.target == i) {
                    q.state = QState.READY
                    done = q
                }
            }
        }
        if (done != null) changed()
        return done
    }

    /** You took the relic from cave [cave]. */
    fun onRelic(cave: Int): Quest? {
        var done: Quest? = null
        synchronized(lock) {
            for (q in list) {
                if (q.state == QState.ACTIVE && q.kind == QKind.RELIC && q.target == cave) {
                    q.state = QState.READY
                    done = q
                }
            }
        }
        if (done != null) changed()
        return done
    }

    /** A relic is waiting in cave [cave] for a quest you're on. */
    fun relicWanted(cave: Int): Boolean = synchronized(lock) {
        list.any { it.state == QState.ACTIVE && it.kind == QKind.RELIC && it.target == cave }
    }

    /** The monster a hunt near (x, z) is after, so more of them turn up there; -1 if none. */
    fun huntNear(x: Float, z: Float): Int = synchronized(lock) {
        list.firstOrNull { it.state == QState.ACTIVE && it.kind == QKind.HUNT && hypot(it.markX - x, it.markZ - z) < 220f }?.target ?: -1
    }

    /** Quests you're on or can hand in. */
    fun current(): List<Quest> = synchronized(lock) { list.filter { it.state == QState.ACTIVE || it.state == QState.READY } }
    fun finishedCount(): Int = synchronized(lock) { list.count { it.state == QState.DONE } }

    private fun changed() {
        version++
        save()
    }

    // ---------- Saving ----------

    fun load(c: Context) {
        ctx = c.applicationContext
        val s = c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("quests", "") ?: ""
        synchronized(lock) {
            for (q in list) {
                q.state = QState.NEW
                q.progress = 0
            }
            for (entry in s.split(';')) {
                val f = entry.split(':')
                if (f.size != 3) continue
                val id = f[0].toIntOrNull() ?: continue
                val q = list.getOrNull(id) ?: continue
                q.state = (f[1].toIntOrNull() ?: 0).coerceIn(0, 3)
                q.progress = f[2].toIntOrNull() ?: 0
            }
        }
        version++
    }

    private fun save() {
        if (SaveLock.blocked) return
        val c = ctx ?: return
        val s = synchronized(lock) {
            list.filter { it.state != QState.NEW }.joinToString(";") { "${it.id}:${it.state}:${it.progress}" }
        }
        c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().putString("quests", s).apply()
    }
}
