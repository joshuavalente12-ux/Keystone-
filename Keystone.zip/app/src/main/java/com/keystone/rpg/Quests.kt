package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** What a quest asks of you. */
object QKind {
    /** Slay a number of one kind of monster. */
    const val HUNT = 0
    /** Go deep into a cave and bring back what's there. */
    const val RELIC = 1
    /** Defeat a region's boss (the main missions). */
    const val BOSS = 2
}

/** Where a quest is up to. */
object QState {
    const val NEW = 0
    const val ACTIVE = 1
    /** Done: go back to whoever gave it to you. */
    const val READY = 2
    const val DONE = 3
}

class Quest(
    val id: Int,
    /** Who gives it (index into [People.npcs]). */
    val giver: Int,
    val kind: Int,
    /** A main mission (beat a boss) rather than a side quest. */
    val main: Boolean,
    val title: String,
    /** What the giver says when they ask you. */
    val intro: String,
    /** Monster species (HUNT), cave (RELIC) or boss (BOSS). */
    val target: Int,
    val count: Int,
    /** Where it's marked on the map while you're on it. */
    val markX: Float,
    val markZ: Float,
    val tier: Int,
    /** A quest that has to be finished first, or -1. */
    val after: Int,
    /** What you're sent for: "Thornlings", "the Moss Idol"... */
    val thing: String,
    /** Where: the cave's name, the boss's region... */
    val where: String,
) {
    @Volatile var state = QState.NEW
    @Volatile var progress = 0

    val gold: Int get() = (if (main) 150 else 45) * tier * (tier + 1) / 2
    val xp: Int get() = (if (main) 400 else 120) * tier * tier

    /** One line saying what to do next. */
    fun goal(): String = when {
        state == QState.READY -> "Return to the one who asked you"
        kind == QKind.HUNT -> "Slay $thing: $progress / $count"
        kind == QKind.RELIC -> "Find $thing in $where"
        else -> "Defeat $thing in $where"
    }
}

private val RELICS = mapOf(
    Zone.MEADOW to arrayOf("the Moss Idol", "Grandmother's Locket", "the Old Bell of Greenhollow"),
    Zone.FOREST to arrayOf("the Witchwood Lantern", "the Silver Chalice", "the Wraith's Crown"),
    Zone.SNOW to arrayOf("the Frozen Heart", "the Runed Horn", "the Frostwatch Seal"),
    Zone.DESERT to arrayOf("the Sun Amulet", "the Golden Scarab", "the Sunken Tablet"),
    Zone.CAVES to arrayOf("the Void Lantern", "a Keystone Shard", "the Crystal Eye"),
)

private val MAIN_TITLES = arrayOf("The Moss King", "The Hollow Elder", "The Frost Tyrant", "The Sun Devourer", "The Keystone Warden")
private val MAIN_LINES = arrayOf(
    "Gorvak, the Moss King, has woken in his ring of standing stones. While he lives, the seal on Whisperwood holds fast. His lair is marked on your map. Bring him down, traveller.",
    "The Hollow Elder was a great tree once. Now it walks, and the whole wood whispers its name. Defeat it and the way to Frostpeak will open.",
    "Grimtusk the Frost Tyrant rules these peaks from his circle of stones. Break him, and the seal on the Sunscar Dunes will break with him.",
    "Khepri the Sun Devourer has buried whole caravans. Only when it falls will the road into the Hollow Deep be open.",
    "At the heart of the Hollow Deep waits the Keystone Warden, the oldest thing in this world. End it, and the Keystone is yours.",
)

/**
 * Every quest in the world. Elders in the towns and camps and the lords in their castles
 * have side quests; the main missions (one per region's boss) run from Greenhollow's
 * elder through each region's castle lord. Progress is saved with your game.
 */
class Quests(private val people: People, fauna: Fauna, treasure: Treasure, private val world: World) {
    val list = ArrayList<Quest>()
    private val lock = Any()
    private var ctx: Context? = null

    /** Changes whenever any quest changes, so the screen redraws. */
    var version by mutableIntStateOf(0)
        private set

    init {
        build(fauna, treasure)
    }

    private fun build(fauna: Fauna, treasure: Treasure) {
        val rnd = java.util.Random(777)
        val p = Probe()
        // Main missions: Greenhollow's elder first, then the lord of each region's castle.
        var prevMain = -1
        for (i in BOSSES.indices) {
            val b = BOSSES[i]
            val giver = (
                if (i == 0) {
                    people.giverAt(0)
                } else {
                    val ci = PLACES.indices.firstOrNull { idx ->
                        PLACES[idx].kind == Site.CASTLE && run { world.probe(PLACES[idx].x, PLACES[idx].z, p); p.zone == b.zone }
                    }
                    if (ci != null) people.giverAt(ci) else null
                }
                ) ?: continue
            val q = Quest(
                list.size, giver.id, QKind.BOSS, true, MAIN_TITLES[i], MAIN_LINES[i], i, 1,
                treasure.lairX[i], treasure.lairZ[i], tierOf(b.zone), prevMain, b.name, b.zone.title,
            )
            list.add(q)
            prevMain = q.id
        }
        // Side quests: a hunt and a cave for every elder and lord.
        val usedCaves = HashSet<Int>()
        for (g in people.npcs) {
            if (g.role != NpcRole.QUEST && g.role != NpcRole.LORD) continue
            val tier = tierOf(g.zone)
            val place = PLACES[g.place].name
            // The hunt.
            val kinds = fauna.species.indices.filter { fauna.species[it].monster && g.zone in fauna.species[it].zones }
            var huntId = -1
            if (kinds.isNotEmpty()) {
                val si = kinds[rnd.nextInt(kinds.size)]
                val sp = fauna.species[si]
                val count = if (sp.hp >= 10) 2 + rnd.nextInt(2) else 4 + rnd.nextInt(3)
                val spot = huntingGround(g, p, rnd)
                val plural = plural(sp.name)
                val q = Quest(
                    list.size, g.id, QKind.HUNT, false, "Cull the $plural",
                    "$plural have been attacking travellers on the roads near $place. Slay $count of them and I'll make it worth your while. They're thick around the place I've marked on your map.",
                    si, count, spot[0], spot[1], tier, -1, plural, place,
                )
                list.add(q)
                huntId = q.id
            }
            // The cave.
            var best = -1
            var bestD = 1e9f
            for (cv in treasure.caves) {
                if (cv.zone != g.zone) continue
                val d = hypot(cv.x - g.homeX, cv.z - g.homeZ) + (if (cv.id in usedCaves) 2000f else 0f)
                if (d < bestD) {
                    bestD = d
                    best = cv.id
                }
            }
            if (best >= 0) {
                usedCaves.add(best)
                val cv = treasure.caves[best]
                val names = RELICS.getValue(g.zone)
                val relic = names[rnd.nextInt(names.size)]
                list.add(
                    Quest(
                        list.size, g.id, QKind.RELIC, false, "Into ${cv.name}",
                        "Something precious was lost deep inside ${cv.name}: ${relic}. The tunnels are dark and the way is long, but the cave is marked on your map. Go to the deepest chamber and bring it back to me.",
                        best, 1, cv.mouthX, cv.mouthZ, tier, huntId, relic, cv.name,
                    ),
                )
            }
        }
    }

    /** Open ground in the giver's region, a good walk away: where the hunt is marked. */
    private fun huntingGround(g: Npc, p: Probe, rnd: java.util.Random): FloatArray {
        val start = rnd.nextFloat() * 6.2831855f
        for (r in floatArrayOf(120f, 160f, 200f, 250f)) {
            for (k in 0 until 16) {
                val a = start + k * 0.3926991f
                val x = g.homeX + cos(a) * r
                val z = g.homeZ + sin(a) * r
                if (x < 60f || z < 60f || x > WORLD_SIZE - 60f || z > WORLD_SIZE - 60f) continue
                world.probe(x, z, p)
                if (p.zone != g.zone || p.site < 50f || p.mountain > 0.3f) continue
                if (world.terrainAt(x, z) < 0.8f || world.isBlocked(x, z, p)) continue
                return floatArrayOf(x, z)
            }
        }
        return floatArrayOf(g.homeX + 150f, g.homeZ)
    }

    private fun plural(name: String): String = when {
        name.endsWith("wolf") -> name.dropLast(4) + "wolves"
        name.endsWith("s") -> name + "es"
        name.endsWith("y") && !name.endsWith("ey") -> name.dropLast(1) + "ies"
        else -> name + "s"
    }

    // ---------- Asking and answering ----------

    private fun ready(q: Quest): Boolean = q.after < 0 || list[q.after].state == QState.DONE

    /**
     * What [npc] wants to talk to you about: a quest to hand in first, then one you're on,
     * then a new one they can offer. Null if they have nothing.
     */
    fun forGiver(npc: Int): Quest? = synchronized(lock) {
        list.firstOrNull { it.giver == npc && it.state == QState.READY }
            ?: list.firstOrNull { it.giver == npc && it.state == QState.ACTIVE }
            ?: list.firstOrNull { it.giver == npc && it.state == QState.NEW && ready(it) }
    }

    /** True if [npc] has a new quest for you or one to hand in (for the marker over their head). */
    fun hasNew(npc: Int): Boolean = synchronized(lock) { list.any { it.giver == npc && it.state == QState.NEW && ready(it) } }
    fun hasReady(npc: Int): Boolean = synchronized(lock) { list.any { it.giver == npc && it.state == QState.READY } }

    fun accept(q: Quest, loot: Loot) {
        synchronized(lock) {
            if (q.state != QState.NEW) return
            q.state = QState.ACTIVE
            q.progress = 0
            // Already beaten that boss? Then it's done straight away.
            if (q.kind == QKind.BOSS && loot.bossBeaten(q.target)) q.state = QState.READY
        }
        changed()
    }

    /** Marks [q] finished. The game hands out the reward. */
    fun complete(q: Quest): Boolean {
        synchronized(lock) {
            if (q.state != QState.READY) return false
            q.state = QState.DONE
        }
        changed()
        return true
    }

    /** You killed a monster of species [si]. Returns a quest that just got finished, if any. */
    fun onKill(si: Int): Quest? {
        var done: Quest? = null
        var any = false
        synchronized(lock) {
            for (q in list) {
                if (q.state != QState.ACTIVE || q.kind != QKind.HUNT || q.target != si) continue
                q.progress++
                any = true
                if (q.progress >= q.count) {
                    q.state = QState.READY
                    done = q
                }
            }
        }
        if (any) changed()
        return done
    }

    fun onBoss(i: Int): Quest? {
        var done: Quest? = null
        synchronized(lock) {
            for (q in list) {
                if (q.state == QState.ACTIVE && q.kind == QKind.BOSS && q.target == i) {
                    q.state = QState.READY
                    done = q
                }
            }
        }
        if (done != null) changed()
        return done
    }

    /** You took the relic from cave [cave]. */
    fun onRelic(cave: Int): Quest? {
        var done: Quest? = null
        synchronized(lock) {
            for (q in list) {
                if (q.state == QState.ACTIVE && q.kind == QKind.RELIC && q.target == cave) {
                    q.state = QState.READY
                    done = q
                }
            }
        }
        if (done != null) changed()
        return done
    }

    /** A relic is waiting in cave [cave] for a quest you're on. */
    fun relicWanted(cave: Int): Boolean = synchronized(lock) {
        list.any { it.state == QState.ACTIVE && it.kind == QKind.RELIC && it.target == cave }
    }

    /** The monster a hunt near (x, z) is after, so more of them turn up there; -1 if none. */
    fun huntNear(x: Float, z: Float): Int = synchronized(lock) {
        list.firstOrNull { it.state == QState.ACTIVE && it.kind == QKind.HUNT && hypot(it.markX - x, it.markZ - z) < 220f }?.target ?: -1
    }

    /** Quests you're on or can hand in. */
    fun current(): List<Quest> = synchronized(lock) { list.filter { it.state == QState.ACTIVE || it.state == QState.READY } }
    fun finishedCount(): Int = synchronized(lock) { list.count { it.state == QState.DONE } }

    private fun changed() {
        version++
        save()
    }

    // ---------- Saving ----------

    fun load(c: Context) {
        ctx = c.applicationContext
        val s = c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("quests", "") ?: ""
        synchronized(lock) {
            for (q in list) {
                q.state = QState.NEW
                q.progress = 0
            }
            for (entry in s.split(';')) {
                val f = entry.split(':')
                if (f.size != 3) continue
                val id = f[0].toIntOrNull() ?: continue
                val q = list.getOrNull(id) ?: continue
                q.state = (f[1].toIntOrNull() ?: 0).coerceIn(0, 3)
                q.progress = f[2].toIntOrNull() ?: 0
            }
        }
        version++
    }

    private fun save() {
        val c = ctx ?: return
        val s = synchronized(lock) {
            list.filter { it.state != QState.NEW }.joinToString(";") { "${it.id}:${it.state}:${it.progress}" }
        }
        c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().putString("quests", s).apply()
    }
}
