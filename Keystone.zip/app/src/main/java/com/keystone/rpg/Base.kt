package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Size of one building square, and how tall one storey is. Everything you build snaps to this grid. */
const val BUILD_CELL = 3f
const val WALL_H = 3f
private const val HALF = BUILD_CELL / 2f
private const val ROOF_RISE = 1.5f
private const val HALF_PI = 1.5707964f

/** Raw materials you gather out in the world. */
object Res {
    const val WOOD = 0
    const val STONE = 1
    const val IRON = 2
    const val COUNT = 3
    val NAMES = arrayOf("Wood", "Stone", "Iron")
    val ICONS = arrayOf("\uD83E\uDEB5", "\uD83E\uDEA8", "\uD83D\uDD29")
}

/** The pieces you can snap together. */
object PieceType {
    const val FOUNDATION = 0
    const val WALL = 1
    const val DOORWAY = 2
    const val WINDOW = 3
    const val STONE_WALL = 4
    const val FLOOR = 5
    const val STAIRS = 6
    const val ROOF = 7
    const val BENCH = 8
    const val FLAT_ROOF = 9
    const val GABLE = 10
    const val STONE_GABLE = 11
    // Furniture: stands wherever you put it, not on the building grid.
    const val WALL_TORCH = 12
    const val TORCH = 13
    const val BED = 14
    const val CHEST_S = 15
    const val CHEST_M = 16
    const val CHEST_L = 17
    const val TABLE = 18
    const val CHAIR = 19
    const val FRIDGE = 20
    const val FIRE_PIT = 21
    const val COUNT = 22

    val NAMES = arrayOf(
        "Foundation", "Wall", "Doorway", "Window", "Stone Wall", "Floor", "Stairs", "Roof", "Crafting Bench",
        "Flat Roof", "Gable", "Stone Gable",
        "Wall Torch", "Torch", "Bed", "Small Chest", "Medium Chest", "Large Chest", "Table", "Chair", "Fridge", "Fire Pit",
    )
    val ICONS = arrayOf(
        "\u2B1B", "\uD83E\uDEB5", "\uD83D\uDEAA", "\uD83E\uDE9F", "\uD83E\uDDF1",
        "\uD83D\uDFEB", "\uD83E\uDE9C", "\uD83C\uDFE0", "\uD83D\uDEE0\uFE0F",
        "\uD83D\uDED6", "\uD83D\uDD3A", "\u26F0\uFE0F",
        "\uD83D\uDD6F\uFE0F", "\uD83D\uDD25", "\uD83D\uDECF\uFE0F", "\uD83D\uDCE6", "\uD83D\uDCE6", "\uD83D\uDCE6",
        "\uD83E\uDE91", "\uD83E\uDE91", "\uD83E\uDDCA", "\uD83C\uDF56",
    )
    /** The order they appear along the building bar. */
    val ORDER = intArrayOf(
        FOUNDATION, WALL, DOORWAY, WINDOW, STONE_WALL, FLOOR, STAIRS, ROOF, GABLE, STONE_GABLE, FLAT_ROOF, BENCH,
        WALL_TORCH, TORCH, BED, CHEST_S, CHEST_M, CHEST_L, TABLE, CHAIR, FRIDGE, FIRE_PIT,
    )
    /** Wood, stone, iron for each piece. */
    val COST = arrayOf(
        intArrayOf(0, 6, 0),
        intArrayOf(4, 0, 0),
        intArrayOf(3, 0, 0),
        intArrayOf(3, 0, 0),
        intArrayOf(0, 6, 0),
        intArrayOf(4, 0, 0),
        intArrayOf(5, 0, 0),
        intArrayOf(4, 0, 0),
        intArrayOf(10, 4, 0),
        intArrayOf(4, 0, 0),
        intArrayOf(2, 0, 0),
        intArrayOf(0, 3, 0),
        intArrayOf(2, 0, 0),
        intArrayOf(2, 1, 0),
        intArrayOf(12, 0, 0),
        intArrayOf(8, 0, 0),
        intArrayOf(16, 0, 0),
        intArrayOf(24, 0, 0),
        intArrayOf(6, 0, 0),
        intArrayOf(3, 0, 0),
        intArrayOf(10, 6, 0),
        intArrayOf(3, 8, 0),
    )

    /** Furniture: placed freely wherever you aim, rather than snapped to the building grid. */
    fun isFree(t: Int): Boolean = t >= WALL_TORCH
    /** Things that hold your items, and how many. */
    fun isStorage(t: Int): Boolean = t == CHEST_S || t == CHEST_M || t == CHEST_L || t == FRIDGE
    fun capacity(t: Int): Int = when (t) {
        CHEST_S -> 20
        CHEST_M -> 40
        CHEST_L -> 50
        FRIDGE -> 30
        else -> 0
    }
    /** How brightly it lights up the dark (0 = not a light). */
    fun light(t: Int): Float = when (t) {
        WALL_TORCH -> 0.9f
        TORCH -> 1.0f
        FIRE_PIT -> 1.4f
        else -> 0f
    }
    /** How much room a piece of furniture takes up, for keeping them from overlapping. */
    fun room(t: Int): Float = when (t) {
        WALL_TORCH -> 0.25f
        TORCH -> 0.3f
        BED -> 1.0f
        CHEST_S -> 0.45f
        CHEST_M -> 0.6f
        CHEST_L -> 0.8f
        TABLE -> 0.85f
        CHAIR -> 0.35f
        FRIDGE -> 0.5f
        FIRE_PIT -> 0.9f
        else -> 0.5f
    }

    /** Full-height walls. */
    fun isWall(t: Int): Boolean = t == WALL || t == DOORWAY || t == WINDOW || t == STONE_WALL
    /** The triangle (or strip) that fills the gap between a wall's top and the roof above it. */
    fun isGable(t: Int): Boolean = t == GABLE || t == STONE_GABLE
    /** Walls and gables sit on the edge between two squares; everything else fills a square. */
    fun onEdge(t: Int): Boolean = isWall(t) || isGable(t)
    /** Things you stand on top of and build from. */
    fun isDeck(t: Int): Boolean = t == FOUNDATION || t == FLOOR || t == FLAT_ROOF
    /** Things that take up a square without being a floor. */
    fun isFixture(t: Int): Boolean = t == STAIRS || t == ROOF || t == BENCH
    /** Pieces that turn when you tap ROTATE. */
    fun turns(t: Int): Boolean = isFixture(t) || isGable(t) || (isFree(t) && t != WALL_TORCH)

    fun costText(t: Int): String {
        val c = COST[t]
        val parts = ArrayList<String>()
        for (r in 0 until Res.COUNT) if (c[r] > 0) parts.add("${c[r]}${Res.ICONS[r]}")
        return parts.joinToString(" ")
    }
}

/** Things you make at a crafting bench. */
object Recipe {
    const val STONE_AXE = 0
    const val STONE_PICK = 1
    const val IRON_AXE = 2
    const val IRON_PICK = 3
    const val COUNT = 4
    val NAMES = arrayOf("Stone Axe", "Stone Pickaxe", "Iron Axe", "Iron Pickaxe")
    val ICONS = arrayOf("\uD83E\uDE93", "\u26CF\uFE0F", "\uD83E\uDE93", "\u26CF\uFE0F")
    val INFO = arrayOf(
        "Fells trees: 1 wood a blow, down in 6. Wears out after 150 blows.",
        "Breaks rocks and mines iron ore in caves. Wears out after 150 blows.",
        "Twice as fast: 2 wood a blow, down in 3. Lasts 400 blows.",
        "Twice as fast: 2 stone a blow, more iron. Lasts 400 blows.",
    )
    val COST = arrayOf(
        intArrayOf(4, 3, 0),
        intArrayOf(4, 3, 0),
        intArrayOf(6, 0, 5),
        intArrayOf(6, 0, 5),
    )

    fun costText(r: Int): String {
        val c = COST[r]
        val parts = ArrayList<String>()
        for (k in 0 until Res.COUNT) if (c[k] > 0) parts.add("${c[k]}${Res.ICONS[k]}")
        return parts.joinToString(" ")
    }
}

/*
 * A wall's [Piece.o] is just which edge it's on: 0 = along x, 1 = along z. A gable adds two more
 * bits: +2 = its high end is flipped round, +4 = it's a full-width strip (under the high side of a
 * sloping roof) rather than a triangle (under the slope's end).
 */
fun pieceAnchorX(type: Int, gi: Int, o: Int): Float =
    if (PieceType.onEdge(type) && (o and 1) == 1) gi * BUILD_CELL else (gi + 0.5f) * BUILD_CELL
// (Furniture keeps its own exact spot in Piece.fx / Piece.fz instead.)

fun pieceAnchorZ(type: Int, gk: Int, o: Int): Float =
    if (PieceType.onEdge(type) && (o and 1) == 0) gk * BUILD_CELL else (gk + 0.5f) * BUILD_CELL

/** How far to turn a piece's mesh, in degrees, round the vertical. */
fun pieceAngle(type: Int, o: Int): Float = when {
    PieceType.isGable(type) -> (o and 1) * 90f + ((o shr 1) and 1) * 180f
    PieceType.onEdge(type) -> (o and 1) * 90f
    PieceType.isDeck(type) -> 0f
    else -> o * 90f
}

/** True for a gable that's a full-width strip rather than a triangle. */
fun gableStrip(type: Int, o: Int): Boolean = PieceType.isGable(type) && (o and 4) != 0

/**
 * One placed piece. [y] is the top of a foundation or floor, and the bottom of everything else.
 * [o] is which edge a wall is on (0 = along x, 1 = along z) or which way a fixture faces (0..3 =
 * +z, +x, -z, -x). It starts as a frame; once everything it needs has been paid in, it's [built].
 */
class Piece(val type: Int, val gi: Int, val gk: Int, val o: Int, val y: Float) {
    val paid = IntArray(Res.COUNT)
    var built = false
    /** How far a foundation's stone reaches down to the ground. */
    var depth = 1f
    val solids = ArrayList<Solid>()
    val walks = ArrayList<Walk>()
    /** Furniture only: exactly where it stands. */
    var fx = 0f
    var fz = 0f

    val paidInFull: Boolean get() {
        val c = PieceType.COST[type]
        for (r in 0 until Res.COUNT) if (paid[r] < c[r]) return false
        return true
    }

    fun missingText(): String {
        val c = PieceType.COST[type]
        val parts = ArrayList<String>()
        for (r in 0 until Res.COUNT) if (paid[r] < c[r]) parts.add("${c[r] - paid[r]}${Res.ICONS[r]}")
        return parts.joinToString(" ")
    }

    val anchorX: Float get() = if (PieceType.isFree(type)) fx else pieceAnchorX(type, gi, o)
    val anchorZ: Float get() = if (PieceType.isFree(type)) fz else pieceAnchorZ(type, gk, o)
    /** How far to turn the mesh, in degrees, round the vertical. */
    val angleDeg: Float get() = pieceAngle(type, o)
    /** A rough middle point, for finding the piece you're pointing at. */
    val midY: Float get() = when {
        PieceType.isDeck(type) -> y
        PieceType.isGable(type) -> y + ROOF_RISE * 0.5f
        PieceType.onEdge(type) -> y + WALL_H * 0.5f
        type == PieceType.STAIRS -> y + WALL_H * 0.5f
        type == PieceType.ROOF -> y + ROOF_RISE * 0.5f
        else -> y + 0.5f
    }
}

/** Where the piece you're about to place would go, and whether it can. */
class Ghost {
    var type = 0
    /** Furniture: its exact spot. */
    var fx = 0f
    var fz = 0f
    var gi = 0
    var gk = 0
    var o = 0
    var y = 0f
    var depth = 1f
    var ok = false
    var reason = ""
    var show = false
}

/**
 * Your base: everything you've built anywhere in the world, the wood, stone and iron you've
 * gathered, and the tools you've made. Only ever changed on the game's own thread.
 */
class Base(private val world: World) {
    val pieces = ArrayList<Piece>()
    private val cells = HashMap<Int, ArrayList<Piece>>()
    val res = IntArray(Res.COUNT)
    /** 0 = none (bare hands), 1 = stone, 2 = iron. */
    @Volatile var axeTier = 0
    /** Blows left before the axe / pickaxe breaks, and the best of each you've ever made. */
    @Volatile var axeUses = 0
    @Volatile var pickUses = 0
    @Volatile var bestAxe = 0
    @Volatile var bestPick = 0
        private set
    @Volatile var pickTier = 0
        private set
    /** Bumps whenever materials or tools change, so the screen redraws. */
    var version by mutableIntStateOf(0)
        private set

    private var appCtx: Context? = null
    private var dirty = false
    private var saveTimer = 0f
    private var regrowTimer = 0f
    private var finishTimer = 0f
    private val tmp = Placed()
    private val probe = Probe()

    // ---------- Meshes ----------
    val meshes = ArrayList<CreaturePart>()
    val solidMesh: Array<CreaturePart>
    val frameMesh: Array<CreaturePart>
    val ghostOk: Array<CreaturePart>
    val ghostBad: Array<CreaturePart>
    /** The planks across the top of a foundation (its stone is stretched down to the ground). */
    val deck: CreaturePart

    init {
        solidMesh = Array(PieceType.COUNT) { t -> mesh { m -> buildSolid(m, t) } }
        frameMesh = Array(PieceType.COUNT) { t -> mesh { m -> buildFrame(m, t, FRAME_WOOD, FLAG_WOOD) } }
        ghostOk = Array(PieceType.COUNT) { t -> mesh { m -> buildFrame(m, t, 0x6CFF7A, FLAG_GLOW) } }
        ghostBad = Array(PieceType.COUNT) { t -> mesh { m -> buildFrame(m, t, 0xFF4A3A, FLAG_GLOW) } }
        deck = mesh { m -> buildDeck(m) }
    }

    private fun mesh(build: (MeshBuilder) -> Unit): CreaturePart {
        val m = MeshBuilder(4096)
        build(m)
        val cp = CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
        meshes.add(cp)
        return cp
    }

    // ---------- Looking things up ----------

    private fun key(gi: Int, gk: Int): Int = gi * 2048 + gk

    private fun cellOf(v: Float): Int = floor(v / BUILD_CELL).toInt()

    private fun index(p: Piece) {
        cells.getOrPut(key(p.gi, p.gk)) { ArrayList() }.add(p)
        if (PieceType.onEdge(p.type)) {
            val k2 = if ((p.o and 1) == 0) key(p.gi, p.gk - 1) else key(p.gi - 1, p.gk)
            cells.getOrPut(k2) { ArrayList() }.add(p)
        }
    }

    private fun unindex(p: Piece) {
        cells[key(p.gi, p.gk)]?.remove(p)
        if (PieceType.onEdge(p.type)) {
            val k2 = if ((p.o and 1) == 0) key(p.gi, p.gk - 1) else key(p.gi - 1, p.gk)
            cells[k2]?.remove(p)
        }
    }

    /** Tops of the foundations and floors in square (gi, gk). */
    private fun decks(gi: Int, gk: Int, out: ArrayList<Float>) {
        val list = cells[key(gi, gk)] ?: return
        for (p in list) if (PieceType.isDeck(p.type) && p.gi == gi && p.gk == gk) out.add(p.y)
    }

    private fun foundationAt(gi: Int, gk: Int): Piece? {
        val list = cells[key(gi, gk)] ?: return null
        for (p in list) if (p.type == PieceType.FOUNDATION && p.gi == gi && p.gk == gk) return p
        return null
    }

    private fun edgeTaken(gi: Int, gk: Int, o: Int, y: Float): Boolean {
        val list = cells[key(gi, gk)] ?: return false
        for (p in list) {
            if (PieceType.onEdge(p.type) && p.gi == gi && p.gk == gk && (p.o and 1) == o && abs(p.y - y) < 0.5f) return true
        }
        return false
    }

    /** Tops of the walls round square (gi, gk). */
    private fun wallTops(gi: Int, gk: Int, out: ArrayList<Float>) {
        val list = cells[key(gi, gk)] ?: return
        for (p in list) {
            if (!PieceType.isWall(p.type)) continue
            val mine = (p.o == 0 && p.gi == gi && (p.gk == gk || p.gk == gk + 1)) ||
                (p.o == 1 && p.gk == gk && (p.gi == gi || p.gi == gi + 1))
            // Each wall is filed under both squares it borders, so all four edges turn up here.
            if (mine) out.add(p.y + WALL_H)
        }
    }

    private fun fixtureTaken(gi: Int, gk: Int, y: Float): Boolean {
        val list = cells[key(gi, gk)] ?: return false
        for (p in list) if (PieceType.isFixture(p.type) && p.gi == gi && p.gk == gk && abs(p.y - y) < 0.5f) return true
        return false
    }

    /** Tops of the walls standing on exactly this edge. */
    private fun wallsOn(gi: Int, gk: Int, axis: Int, out: ArrayList<Float>) {
        val list = cells[key(gi, gk)] ?: return
        for (p in list) if (PieceType.isWall(p.type) && p.gi == gi && p.gk == gk && p.o == axis) out.add(p.y + WALL_H)
    }

    /**
     * Which gable fits the roof over this edge at height [y]: +2 if its high end is flipped, +4 for
     * a full strip under a roof's high side, or -1 if there's no roof here to go by.
     */
    private fun gableFit(gi: Int, gk: Int, axis: Int, y: Float): Int {
        // The two squares this edge borders, and which side of each it is.
        val ai = gi
        val ak = gk
        val bi = if (axis == 0) gi else gi - 1
        val bk = if (axis == 0) gk - 1 else gk
        var fit = -1
        for (side in 0..1) {
            val si = if (side == 0) ai else bi
            val sk = if (side == 0) ak else bk
            val list = cells[key(si, sk)] ?: continue
            for (p in list) {
                if (p.type != PieceType.ROOF || p.gi != si || p.gk != sk || abs(p.y - y) > 0.5f) continue
                val f = p.o
                val v = if (axis == 0) {
                    when {
                        f == 1 -> 0
                        f == 3 -> 2
                        // Rising towards this edge: the high side, which wants a full strip.
                        (side == 0 && f == 2) || (side == 1 && f == 0) -> 4
                        else -> -1
                    }
                } else {
                    when {
                        f == 2 -> 0
                        f == 0 -> 2
                        (side == 0 && f == 3) || (side == 1 && f == 1) -> 4
                        else -> -1
                    }
                }
                // A strip under a high side beats a triangle if both are about.
                if (v == 4) return 4
                if (v >= 0 && fit < 0) fit = v
            }
        }
        return fit
    }

    private fun roofsAt(gi: Int, gk: Int, out: ArrayList<Float>) {
        val list = cells[key(gi, gk)] ?: return
        for (p in list) if (p.type == PieceType.ROOF && p.gi == gi && p.gk == gk) out.add(p.y)
    }

    // ---------- Collision: what the world asks ----------

    /** The highest thing you've built under (x, z) that you could step onto from [feet]. */
    fun ground(x: Float, z: Float, feet: Float, best: Float): Float {
        if (pieces.isEmpty()) return best
        var b = best
        val ci = cellOf(x)
        val ck = cellOf(z)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (!p.built) continue
                for (w in p.walks) {
                    val h = w.heightAt(x, z)
                    if (h.isNaN()) continue
                    if (h <= feet + 0.65f && h > b) b = h
                }
            }
        }
        return b
    }

    /** True if a body of [radius] at (x, z) with its feet at [feet] would walk into something built. */
    fun hits(x: Float, z: Float, radius: Float, feet: Float): Boolean {
        if (pieces.isEmpty()) return false
        val ci = cellOf(x)
        val ck = cellOf(z)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (!p.built) continue
                for (s in p.solids) if (s.hits(x, z, radius, feet)) return true
            }
        }
        return false
    }

    fun hitsPoint(px: Float, py: Float, pz: Float, r: Float): Boolean {
        if (pieces.isEmpty()) return false
        val ci = cellOf(px)
        val ck = cellOf(pz)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (!p.built) continue
                for (s in p.solids) if (s.hitsPoint(px, py, pz, r)) return true
            }
        }
        return false
    }

    /** Monsters and animals walk on the bare ground, so walls and raised foundations keep them out. */
    fun blocksCreature(x: Float, z: Float, radius: Float): Boolean {
        if (pieces.isEmpty()) return false
        return hits(x, z, radius, world.terrainAt(x, z))
    }

    /**
     * What you're standing on: 0 = nothing you built, 1 = a floor with a roof over it (indoors),
     * 5 = an open wooden deck, 6 = an open stone foundation.
     */
    fun under(x: Float, z: Float, feet: Float): Int {
        if (pieces.isEmpty()) return 0
        val ci = cellOf(x)
        val ck = cellOf(z)
        var on: Piece? = null
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (!p.built) continue
                for (w in p.walks) {
                    val h = w.heightAt(x, z)
                    if (!h.isNaN() && abs(h - feet) < 0.35f) on = p
                }
            }
        }
        val p = on ?: return 0
        // Something overhead in this square?
        val list = cells[key(ci, ck)]
        if (list != null) {
            for (q in list) {
                if (!q.built || q.gi != ci || q.gk != ck) continue
                if ((q.type == PieceType.FLOOR || q.type == PieceType.ROOF || q.type == PieceType.FLAT_ROOF) &&
                    q.y > feet + 1.5f && q.y < feet + 4.5f
                ) return 1
            }
        }
        return if (p.type == PieceType.FOUNDATION) 6 else 5
    }

    /** Is anything built within [r] metres of (x, z)? Trees don't grow back through your floor. */
    fun anyNear(x: Float, z: Float, r: Float): Boolean {
        if (pieces.isEmpty()) return false
        val ci = cellOf(x)
        val ck = cellOf(z)
        for (dk in -2..2) for (di in -2..2) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                val dx = p.anchorX - x
                val dz = p.anchorZ - z
                if (dx * dx + dz * dz < (r + HALF + 0.5f) * (r + HALF + 0.5f)) return true
            }
        }
        return false
    }

    private fun makeCollision(p: Piece) {
        p.solids.clear()
        p.walks.clear()
        val cx = (p.gi + 0.5f) * BUILD_CELL
        val cz = (p.gk + 0.5f) * BUILD_CELL
        val rise = HALF_PI - p.o * HALF_PI
        when (p.type) {
            PieceType.FOUNDATION -> {
                p.walks.add(Walk(cx, cz, HALF, HALF, 0f, p.y, 0f))
                p.solids.add(Solid(cx, cz, HALF, HALF, 0f, p.y - 30f, p.y))
            }
            PieceType.FLOOR, PieceType.FLAT_ROOF -> p.walks.add(Walk(cx, cz, HALF, HALF, 0f, p.y, 0f))
            PieceType.GABLE, PieceType.STONE_GABLE -> {
                val a = (p.o and 1) * HALF_PI
                if (gableStrip(p.type, p.o)) {
                    p.solids.add(Solid(p.anchorX, p.anchorZ, HALF, 0.18f, a, p.y, p.y + ROOF_RISE))
                } else {
                    // A triangle: three steps, each as tall as its high end, rising along the edge.
                    val r = Math.toRadians(p.angleDeg.toDouble())
                    val ux = kotlin.math.cos(r).toFloat()
                    val uz = -kotlin.math.sin(r).toFloat()
                    for (k in -1..1) {
                        val top = p.y + ROOF_RISE * (k + 0.5f + HALF) / BUILD_CELL
                        p.solids.add(Solid(p.anchorX + ux * k, p.anchorZ + uz * k, 0.5f, 0.18f, a, p.y, top))
                    }
                }
            }
            PieceType.WALL, PieceType.WINDOW, PieceType.STONE_WALL -> {
                val a = if ((p.o and 1) == 0) 0f else HALF_PI
                p.solids.add(Solid(p.anchorX, p.anchorZ, HALF, 0.18f, a, p.y, p.y + WALL_H))
            }
            PieceType.DOORWAY -> {
                val a = if (p.o == 0) 0f else HALF_PI
                val ux = if (p.o == 0) 1f else 0f
                val uz = if (p.o == 0) 0f else 1f
                for (s in intArrayOf(-1, 1)) {
                    p.solids.add(Solid(p.anchorX + ux * 1.05f * s, p.anchorZ + uz * 1.05f * s, 0.45f, 0.18f, a, p.y, p.y + WALL_H))
                }
                p.solids.add(Solid(p.anchorX, p.anchorZ, HALF, 0.18f, a, p.y + 2.3f, p.y + WALL_H))
            }
            PieceType.STAIRS -> p.walks.add(Walk(cx, cz, HALF, 0.75f, rise, p.y, WALL_H))
            PieceType.ROOF -> p.walks.add(Walk(cx, cz, HALF, HALF, rise, p.y, ROOF_RISE))
            PieceType.BENCH -> p.solids.add(Solid(cx, cz, 0.8f, 0.42f, -p.o * HALF_PI, p.y, p.y + 0.95f))
            // Furniture you can't walk through. Chairs and torches you can brush past.
            PieceType.BED -> p.solids.add(Solid(p.fx, p.fz, 0.55f, 1.05f, p.o * HALF_PI, p.y, p.y + 0.6f))
            PieceType.CHEST_S -> p.solids.add(Solid(p.fx, p.fz, 0.4f, 0.27f, p.o * HALF_PI, p.y, p.y + 0.55f))
            PieceType.CHEST_M -> p.solids.add(Solid(p.fx, p.fz, 0.55f, 0.32f, p.o * HALF_PI, p.y, p.y + 0.7f))
            PieceType.CHEST_L -> p.solids.add(Solid(p.fx, p.fz, 0.75f, 0.37f, p.o * HALF_PI, p.y, p.y + 0.8f))
            PieceType.TABLE -> p.solids.add(Solid(p.fx, p.fz, 0.8f, 0.45f, p.o * HALF_PI, p.y, p.y + 0.8f))
            PieceType.FRIDGE -> p.solids.add(Solid(p.fx, p.fz, 0.42f, 0.37f, p.o * HALF_PI, p.y, p.y + 1.9f))
            PieceType.FIRE_PIT -> p.solids.add(Solid(p.fx, p.fz, 0.7f, 0.7f, 0f, p.y, p.y + 0.4f))
        }
    }

    private fun foundationDepth(gi: Int, gk: Int, top: Float): Float {
        var lo = top
        for (k in 0..2) for (i in 0..2) {
            lo = min(lo, world.terrainAt((gi + i * 0.5f) * BUILD_CELL, (gk + k * 0.5f) * BUILD_CELL))
        }
        return max(0.6f, top - lo + 0.5f)
    }

    // ---------- Planning where a new piece goes ----------

    private val ys = ArrayList<Float>()

    /**
     * Works out where a [type] would go if placed at the spot you're aiming at (ax, ay, az), with
     * you standing at (px, pz) facing [yaw], and whether it can go there.
     */
    fun plan(
        g: Ghost, type: Int, ax: Float, ay: Float, az: Float,
        px: Float, pz: Float, feet: Float, yaw: Float, rot: Int,
    ) {
        g.type = type
        g.show = true
        g.ok = false
        g.reason = ""
        g.depth = 1f
        if (PieceType.isFree(type)) {
            planFree(g, type, ax, ay, az, px, pz, feet, yaw, rot)
            return
        }
        var gi = cellOf(ax)
        var gk = cellOf(az)
        val facing = (((yaw / HALF_PI).roundToInt() % 4) + 4) % 4
        g.o = 0
        when {
            PieceType.onEdge(type) -> {
                // The edge of the square nearest where you're aiming.
                val fx = ax / BUILD_CELL - gi
                val fz = az / BUILD_CELL - gk
                val south = fz
                val north = 1f - fz
                val west = fx
                val east = 1f - fx
                val m = min(min(south, north), min(west, east))
                when (m) {
                    south -> g.o = 0
                    north -> { g.o = 0; gk += 1 }
                    west -> g.o = 1
                    else -> { g.o = 1; gi += 1 }
                }
            }
            type == PieceType.BENCH -> g.o = (facing + 2 + rot) % 4
            PieceType.isFixture(type) -> g.o = (facing + rot) % 4
        }
        g.gi = gi
        g.gk = gk
        val cx = (gi + 0.5f) * BUILD_CELL
        val cz = (gk + 0.5f) * BUILD_CELL
        g.y = world.terrainAt(cx, cz)
        if (gi < 2 || gk < 2 || gi > (WORLD_SIZE / BUILD_CELL).toInt() - 3 || gk > (WORLD_SIZE / BUILD_CELL).toInt() - 3) {
            g.reason = "Can't build here"
            return
        }
        val dist = kotlin.math.hypot(cx - px, cz - pz)
        if (dist > 9f) {
            g.reason = "Too far away"
            return
        }
        ys.clear()
        when (type) {
            PieceType.FOUNDATION -> {
                if (foundationAt(gi, gk) != null) {
                    g.reason = "There's already a foundation here"
                    return
                }
                var lo = 1e9f
                var hi = -1e9f
                for (k in 0..2) for (i in 0..2) {
                    val t = world.terrainAt((gi + i * 0.5f) * BUILD_CELL, (gk + k * 0.5f) * BUILD_CELL)
                    lo = min(lo, t)
                    hi = max(hi, t)
                }
                // Next to another foundation: line up with it, so the floor runs on level.
                var top = Float.NaN
                for (n in NEIGHBOURS) {
                    val f = foundationAt(gi + n[0], gk + n[1]) ?: continue
                    top = f.y
                    break
                }
                if (top.isNaN()) top = hi + 0.25f
                g.y = top
                if (lo < 0.2f) {
                    g.reason = "Too wet to build here"
                    return
                }
                if (hi > top + 0.9f) {
                    g.reason = "The ground's too high here"
                    return
                }
                if (top - lo > 4.5f) {
                    g.reason = "Too steep here"
                    return
                }
                if (!world.clearForBuilding(cx, cz, HALF + 0.2f, tmp, probe)) {
                    g.reason = "Something's in the way: chop trees and break rocks first"
                    return
                }
                g.depth = max(0.6f, top - lo + 0.5f)
            }
            PieceType.WALL, PieceType.DOORWAY, PieceType.WINDOW, PieceType.STONE_WALL -> {
                decks(gi, gk, ys)
                if (g.o == 0) decks(gi, gk - 1, ys) else decks(gi - 1, gk, ys)
                if (ys.isEmpty()) {
                    g.reason = "Walls go on the edge of a foundation or floor"
                    return
                }
                g.y = nearest(ys, ay)
                if (edgeTaken(gi, gk, g.o, g.y)) {
                    g.reason = "There's already a wall here"
                    return
                }
            }
            PieceType.GABLE, PieceType.STONE_GABLE -> {
                val axis = g.o
                wallsOn(gi, gk, axis, ys)
                if (ys.isEmpty()) {
                    g.reason = "A gable goes on top of a wall, under the end of a roof"
                    return
                }
                g.y = nearest(ys, ay)
                if (edgeTaken(gi, gk, axis, g.y)) {
                    g.reason = "Something's already here"
                    return
                }
                // Shape it to the roof above; TURN flips a triangle the other way.
                val fit = gableFit(gi, gk, axis, g.y)
                g.o = when {
                    fit == 4 -> axis + 4
                    fit >= 0 -> axis + (fit xor ((rot and 1) * 2))
                    else -> axis + (rot and 1) * 2
                }
            }
            PieceType.FLOOR, PieceType.FLAT_ROOF -> {
                wallTops(gi, gk, ys)
                for (n in NEIGHBOURS) decks(gi + n[0], gk + n[1], ys)
                // Not on a level this square already has.
                val have = ArrayList<Float>()
                decks(gi, gk, have)
                ys.removeAll { y -> have.any { abs(it - y) < 0.5f } }
                if (ys.isEmpty()) {
                    val what = if (type == PieceType.FLAT_ROOF) "flat roof" else "floor"
                    g.reason = if (have.isEmpty()) "A $what needs walls under it, or a floor beside it" else "There's already a floor here"
                    return
                }
                g.y = nearest(ys, ay)
            }
            PieceType.STAIRS -> {
                decks(gi, gk, ys)
                if (ys.isEmpty()) {
                    g.reason = "Stairs go on a foundation or floor"
                    return
                }
                g.y = nearest(ys, ay)
                if (fixtureTaken(gi, gk, g.y)) {
                    g.reason = "Something's already here"
                    return
                }
            }
            PieceType.ROOF -> {
                wallTops(gi, gk, ys)
                for (n in NEIGHBOURS) roofsAt(gi + n[0], gk + n[1], ys)
                if (ys.isEmpty()) {
                    g.reason = "A roof goes on top of walls"
                    return
                }
                g.y = nearest(ys, ay)
                if (fixtureTaken(gi, gk, g.y)) {
                    g.reason = "Something's already here"
                    return
                }
            }
            PieceType.BENCH -> {
                decks(gi, gk, ys)
                if (ys.isEmpty()) {
                    // Straight on the ground is fine too, if it's clear.
                    if (!world.clearForBuilding(cx, cz, 1.0f, tmp, probe)) {
                        g.reason = "Something's in the way"
                        return
                    }
                    g.y = world.terrainAt(cx, cz)
                    if (g.y < 0.2f) {
                        g.reason = "Too wet to build here"
                        return
                    }
                } else {
                    g.y = nearest(ys, ay)
                }
                if (fixtureTaken(gi, gk, g.y)) {
                    g.reason = "Something's already here"
                    return
                }
            }
        }
        // Don't build it round yourself.
        val test = Piece(type, gi, gk, g.o, g.y)
        makeCollision(test)
        for (s in test.solids) {
            if (s.hits(px, pz, Game.RADIUS + 0.05f, feet)) {
                g.reason = "You're standing in the way"
                return
            }
        }
        g.ok = true
    }

    /** Where a piece of furniture would go: right where you aim, on whatever floor or ground is there. */
    private fun planFree(g: Ghost, type: Int, ax: Float, ay: Float, az: Float, px: Float, pz: Float, feet: Float, yaw: Float, rot: Int) {
        val facing = (((yaw / HALF_PI).roundToInt() % 4) + 4) % 4
        var fx = (ax * 4f).roundToInt() / 4f
        var fz = (az * 4f).roundToInt() / 4f
        var y: Float
        // Its front faces you; TURN spins it round.
        g.o = (facing + 2 + rot) % 4
        if (type == PieceType.WALL_TORCH) {
            // On the face of the wall nearest where you aim, on your side of it, at shoulder height.
            val gi = cellOf(ax)
            val gk = cellOf(az)
            val fxr = ax / BUILD_CELL - gi
            val fzr = az / BUILD_CELL - gk
            val m = min(min(fzr, 1f - fzr), min(fxr, 1f - fxr))
            var ei = gi
            var ek = gk
            val axis: Int
            when (m) {
                fzr -> axis = 0
                1f - fzr -> { axis = 0; ek = gk + 1 }
                fxr -> axis = 1
                else -> { axis = 1; ei = gi + 1 }
            }
            var wall: Piece? = null
            for (q in cells[key(ei, ek)] ?: emptyList<Piece>()) {
                if (!PieceType.isWall(q.type) || q.gi != ei || q.gk != ek || q.o != axis) continue
                if (ay < q.y - 0.3f || ay > q.y + WALL_H + 0.3f) continue
                if (wall == null || abs(q.y + 1.5f - ay) < abs(wall.y + 1.5f - ay)) wall = q
            }
            g.gi = ei
            g.gk = ek
            if (wall == null) {
                g.fx = ax
                g.fz = az
                g.y = ay - 0.3f
                g.reason = "A wall torch hangs on a wall: aim at one"
                return
            }
            val lineX = wall.anchorX
            val lineZ = wall.anchorZ
            if (axis == 0) {
                val side = if (pz >= lineZ) 1f else -1f
                fz = lineZ + side * 0.24f
                fx = (fx).coerceIn(lineX - 1.2f, lineX + 1.2f)
                g.o = if (side > 0f) 0 else 2
            } else {
                val side = if (px >= lineX) 1f else -1f
                fx = lineX + side * 0.24f
                fz = (fz).coerceIn(lineZ - 1.2f, lineZ + 1.2f)
                g.o = if (side > 0f) 1 else 3
            }
            y = wall.y + 1.75f
        } else {
            y = world.terrainAt(fx, fz)
            y = ground(fx, fz, ay + 0.4f, y)
        }
        g.fx = fx
        g.fz = fz
        g.y = y
        g.gi = cellOf(fx)
        g.gk = cellOf(fz)
        if (fx < 10f || fz < 10f || fx > WORLD_SIZE - 10f || fz > WORLD_SIZE - 10f) {
            g.reason = "Can't build here"
            return
        }
        if (kotlin.math.hypot(fx - px, fz - pz) > 9f) {
            g.reason = "Too far away"
            return
        }
        val r = PieceType.room(type)
        if (type != PieceType.WALL_TORCH) {
            if (y < 0.2f) {
                g.reason = "Too wet to build here"
                return
            }
            // Not into a wall, a tree or a rock.
            if (world.hitsObstacle(fx, fz, r * 0.7f, tmp, probe, y + 0.1f)) {
                g.reason = "Something's in the way"
                return
            }
        }
        // Not on top of another piece of furniture.
        val ci = cellOf(fx)
        val ck = cellOf(fz)
        for (dk in -1..1) for (di in -1..1) {
            for (q in cells[key(ci + di, ck + dk)] ?: continue) {
                if (!PieceType.isFree(q.type) || q.gi != ci + di || q.gk != ck + dk) continue
                if (abs(q.y - y) > 1.2f) continue
                if (kotlin.math.hypot(q.fx - fx, q.fz - fz) < (r + PieceType.room(q.type)) * 0.8f) {
                    g.reason = "Too close to the ${PieceType.NAMES[q.type].lowercase()}"
                    return
                }
            }
        }
        // Don't build it round yourself.
        val test = Piece(type, g.gi, g.gk, g.o, y)
        test.fx = fx
        test.fz = fz
        makeCollision(test)
        for (sd in test.solids) {
            if (sd.hits(px, pz, Game.RADIUS + 0.05f, feet)) {
                g.reason = "You're standing in the way"
                return
            }
        }
        g.ok = true
    }

    private fun nearest(list: ArrayList<Float>, want: Float): Float {
        var best = list[0]
        for (v in list) if (abs(v - want) < abs(best - want)) best = v
        return best
    }

    // ---------- Changing things (game thread only) ----------

    /** Puts down the planned piece and pays in whatever you have towards it. Returns it. */
    fun place(g: Ghost): Piece {
        val p = Piece(g.type, g.gi, g.gk, g.o, g.y)
        p.depth = if (g.type == PieceType.FOUNDATION) g.depth else 1f
        p.fx = g.fx
        p.fz = g.fz
        pieces.add(p)
        index(p)
        payInto(p)
        changed()
        return p
    }

    /** Pays whatever you can towards an unfinished piece. True if anything went in. */
    fun payInto(p: Piece): Boolean {
        val c = PieceType.COST[p.type]
        var any = false
        for (r in 0 until Res.COUNT) {
            val need = c[r] - p.paid[r]
            if (need <= 0) continue
            val give = min(need, res[r])
            if (give > 0) {
                res[r] -= give
                p.paid[r] += give
                any = true
            }
        }
        if (any) changed()
        return any
    }

    /** Takes a piece down and gives back everything that went into it. */
    fun remove(p: Piece): Boolean {
        // A chest with things in it stays put, so nothing's ever lost.
        if (synchronized(storeLock) { store[p]?.isNotEmpty() == true }) return false
        for (r in 0 until Res.COUNT) res[r] += p.paid[r]
        unindex(p)
        pieces.remove(p)
        synchronized(storeLock) { store.remove(p) }
        if (spawnBed === p) spawnBed = null
        changed()
        return true
    }

    // ---------- Furniture: storage, beds, lights ----------

    private val storeLock = Any()
    /** What's in each chest and fridge. */
    private val store = HashMap<Piece, ArrayList<Item>>()
    /** The bed you last slept in or set as home: where you wake up after being knocked out. */
    @Volatile var spawnBed: Piece? = null
    /** 100 = full, 0 = starving. */
    @Volatile var hunger = 100f

    fun stored(p: Piece): List<Item> = synchronized(storeLock) { ArrayList(store[p] ?: emptyList<Item>()) }

    /** Puts [item] into [p]. False if it's full, or a fridge and [item] isn't food. */
    fun deposit(p: Piece, item: Item): Boolean {
        if (p.type == PieceType.FRIDGE && item.slot != Slot.FOOD) return false
        synchronized(storeLock) {
            val list = store.getOrPut(p) { ArrayList() }
            if (list.size >= PieceType.capacity(p.type)) return false
            list.add(item)
        }
        changed()
        return true
    }

    /** Takes item [index] out of [p], or null. */
    fun withdraw(p: Piece, index: Int): Item? {
        val got = synchronized(storeLock) {
            val list = store[p] ?: return null
            if (index !in list.indices) return null
            list.removeAt(index)
        }
        changed()
        return got
    }

    /** The finished piece of furniture of one of [types] nearest you, within [reach]. */
    fun furnitureNear(x: Float, feet: Float, z: Float, reach: Float, types: (Int) -> Boolean): Piece? {
        var best: Piece? = null
        var bestD = reach
        val ci = cellOf(x)
        val ck = cellOf(z)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (!p.built || !PieceType.isFree(p.type) || !types(p.type)) continue
                if (abs(p.y - feet) > 1.6f) continue
                val d = kotlin.math.hypot(p.fx - x, p.fz - z) - PieceType.room(p.type) * 0.6f
                if (d < bestD) {
                    bestD = d
                    best = p
                }
            }
        }
        return best
    }

    /** Finished torches and fire pits near (x, z): up to [out].size / 4 of them as x, y, z, brightness. */
    fun lights(x: Float, z: Float, out: FloatArray): Int {
        var n = 0
        val max = out.size / 4
        val dist = FloatArray(max)
        for (p in pieces) {
            val b = PieceType.light(p.type)
            if (b <= 0f || !p.built) continue
            val d = kotlin.math.hypot(p.fx - x, p.fz - z)
            if (d > 60f) continue
            // Keep the nearest ones.
            var slot = -1
            if (n < max) {
                slot = n++
            } else {
                var far = -1
                for (i in 0 until max) if (far < 0 || dist[i] > dist[far]) far = i
                if (dist[far] > d) slot = far
            }
            if (slot < 0) continue
            dist[slot] = d
            val h = when (p.type) {
                PieceType.FIRE_PIT -> 0.8f
                PieceType.TORCH -> 1.9f
                else -> 0.6f
            }
            out[slot * 4] = p.fx
            out[slot * 4 + 1] = p.y + h
            out[slot * 4 + 2] = p.fz
            out[slot * 4 + 3] = b
        }
        for (i in n until max) out[i * 4 + 3] = 0f
        return n
    }

    /** Hunger changed: saved with everything else now and then. */
    fun hungerChanged() {
        dirty = true
    }

    /** The piece nearest the spot you're aiming at, within [reach] metres. */
    fun pieceNear(ax: Float, ay: Float, az: Float, reach: Float): Piece? {
        var best: Piece? = null
        var bestD = reach * reach
        val ci = cellOf(ax)
        val ck = cellOf(az)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                val dx = p.anchorX - ax
                val dy = (p.midY - ay) * 0.7f
                val dz = p.anchorZ - az
                val d = dx * dx + dy * dy + dz * dz
                if (d < bestD) {
                    bestD = d
                    best = p
                }
            }
        }
        return best
    }

    /** The nearest frame still waiting for materials, within [reach] of (x, feet, z). */
    fun unfinishedNear(x: Float, feet: Float, z: Float, reach: Float): Piece? {
        var best: Piece? = null
        var bestD = reach * reach
        val ci = cellOf(x)
        val ck = cellOf(z)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (p.paidInFull) continue
                val dx = p.anchorX - x
                val dz = p.anchorZ - z
                val dy = (p.midY - feet - 1f) * 0.5f
                val d = dx * dx + dy * dy + dz * dz
                if (d < bestD) {
                    bestD = d
                    best = p
                }
            }
        }
        return best
    }

    /** A finished crafting bench within [reach] of you. */
    fun benchNear(x: Float, feet: Float, z: Float, reach: Float): Piece? {
        val ci = cellOf(x)
        val ck = cellOf(z)
        for (dk in -1..1) for (di in -1..1) {
            val list = cells[key(ci + di, ck + dk)] ?: continue
            for (p in list) {
                if (p.type != PieceType.BENCH || !p.built) continue
                if (abs(p.y - feet) > 1.6f) continue
                if (kotlin.math.hypot(p.anchorX - x, p.anchorZ - z) < reach) return p
            }
        }
        return null
    }

    fun canAfford(cost: IntArray): Boolean {
        for (r in 0 until Res.COUNT) if (res[r] < cost[r]) return false
        return true
    }

    fun has(t: Int): Boolean = canAfford(PieceType.COST[t])

    /** Whether you're carrying anything this unfinished piece still needs. */
    fun canHelp(p: Piece): Boolean {
        val c = PieceType.COST[p.type]
        for (r in 0 until Res.COUNT) if (p.paid[r] < c[r] && res[r] > 0) return true
        return false
    }

    /** Makes a tool at the bench. False if you can't afford it or already have one as good. */
    fun craft(recipe: Int): Boolean {
        val cost = Recipe.COST[recipe]
        if (!canAfford(cost)) return false
        when (recipe) {
            Recipe.STONE_AXE -> if (axeTier >= 1) return false
            Recipe.STONE_PICK -> if (pickTier >= 1) return false
            Recipe.IRON_AXE -> if (axeTier >= 2) return false
            Recipe.IRON_PICK -> if (pickTier >= 2) return false
        }
        for (r in 0 until Res.COUNT) res[r] -= cost[r]
        when (recipe) {
            Recipe.STONE_AXE -> axeTier = 1
            Recipe.STONE_PICK -> pickTier = 1
            Recipe.IRON_AXE -> axeTier = 2
            Recipe.IRON_PICK -> pickTier = 2
        }
        when (recipe) {
            Recipe.STONE_AXE, Recipe.IRON_AXE -> {
                axeUses = TOOL_USES[axeTier]
                bestAxe = max(bestAxe, axeTier)
            }
            else -> {
                pickUses = TOOL_USES[pickTier]
                bestPick = max(bestPick, pickTier)
            }
        }
        changed()
        return true
    }

    /** Whether you already own this tool (or a better one). */
    fun owns(recipe: Int): Boolean = when (recipe) {
        Recipe.STONE_AXE -> axeTier >= 1
        Recipe.STONE_PICK -> pickTier >= 1
        Recipe.IRON_AXE -> axeTier >= 2
        else -> pickTier >= 2
    }

    /**
     * One blow with the axe ([axe]) or pickaxe. Returns the name of the tool if that blow broke
     * it (it's gone, and you're back to bare hands), or null.
     */
    fun wearTool(axe: Boolean): String? {
        val broke: String?
        if (axe) {
            if (axeTier == 0) return null
            axeUses--
            broke = if (axeUses <= 0) (if (axeTier >= 2) "Iron Axe" else "Stone Axe") else null
            if (broke != null) {
                axeTier = 0
                axeUses = 0
            }
        } else {
            if (pickTier == 0) return null
            pickUses--
            broke = if (pickUses <= 0) (if (pickTier >= 2) "Iron Pickaxe" else "Stone Pickaxe") else null
            if (broke != null) {
                pickTier = 0
                pickUses = 0
            }
        }
        changed()
        return broke
    }

    /** How worn a tool is: 1 = brand new, 0 = about to break (or none). */
    fun toolLeft(axe: Boolean): Float {
        val tier = if (axe) axeTier else pickTier
        if (tier == 0) return 0f
        return (if (axe) axeUses else pickUses).toFloat() / TOOL_USES[tier]
    }

    // ---------- Iron ore in caves ----------

    /** Ore veins you've mined out: key (cave id * 64 + vein) to when it grows back. */
    private val oreGone = java.util.concurrent.ConcurrentHashMap<Int, Long>()

    fun oreMined(key: Int): Boolean {
        val t = oreGone[key] ?: return false
        if (t <= System.currentTimeMillis()) {
            oreGone.remove(key)
            dirty = true
            return false
        }
        return true
    }

    fun mineOut(key: Int) {
        oreGone[key] = System.currentTimeMillis() + ORE_REGROW_MS
        changed()
    }

    fun add(r: Int, n: Int) {
        if (n <= 0) return
        res[r] += n
        changed()
    }

    private fun changed() {
        dirty = true
        version = version + 1
    }

    /**
     * Ticks along: finishes frames once they're paid for (and you've stepped out of the way), lets
     * chopped trees and broken rocks grow back after a while, and saves.
     */
    fun update(dt: Float, px: Float, pz: Float, feet: Float) {
        finishTimer += dt
        if (finishTimer > 0.25f) {
            finishTimer = 0f
            for (p in pieces) {
                if (p.built || !p.paidInFull) continue
                makeCollision(p)
                var blocked = false
                for (s in p.solids) if (s.hits(px, pz, Game.RADIUS, feet)) blocked = true
                if (blocked) {
                    p.solids.clear()
                    p.walks.clear()
                    continue
                }
                p.built = true
                Sound.step(Surface.WOOD, 1.3f)
            }
        }
        regrowTimer += dt
        if (regrowTimer > 5f) {
            regrowTimer = 0f
            regrow(px, pz)
        }
        if (dirty) {
            saveTimer += dt
            if (saveTimer > 1f) {
                saveTimer = 0f
                dirty = false
                save()
            }
        }
    }

    // ---------- Trees and rocks you've cut down ----------

    /** Marks world cell (i, j)'s tree or rock as gone, growing back in [ms] milliseconds. */
    fun cut(i: Int, j: Int, ms: Long) {
        world.harvested[j * GRID + i] = System.currentTimeMillis() + ms
        world.markDirty(i, j)
        dirty = true
    }

    private fun regrow(px: Float, pz: Float) {
        if (world.harvested.isEmpty()) return
        val now = System.currentTimeMillis()
        val it = world.harvested.entries.iterator()
        var grew = false
        while (it.hasNext()) {
            val e = it.next()
            if (e.value > now) continue
            val i = e.key % GRID
            val j = e.key / GRID
            if (!world.objectAt(i, j, tmp, probe, true)) {
                it.remove()
                continue
            }
            // Not right on top of you, and never through something you've built.
            if (anyNear(tmp.x, tmp.z, tmp.radius)) {
                e.setValue(Long.MAX_VALUE)
                continue
            }
            if (kotlin.math.hypot(tmp.x - px, tmp.z - pz) < 30f) continue
            it.remove()
            world.markDirty(i, j)
            grew = true
        }
        if (grew) dirty = true
    }

    // ---------- Saving ----------

    fun load(ctx: Context) {
        appCtx = ctx.applicationContext
        val prefs = ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE)
        pieces.clear()
        cells.clear()
        spawnBed = null
        for (r in 0 until Res.COUNT) res[r] = 0
        prefs.getString("bRes", "")?.split(',')?.forEachIndexed { r, s ->
            if (r < Res.COUNT) res[r] = s.toIntOrNull()?.coerceAtLeast(0) ?: 0
        }
        val tools = prefs.getString("bTools", "")?.split(',') ?: emptyList()
        axeTier = tools.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 2) ?: 0
        pickTier = tools.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 2) ?: 0
        // Older saves had no wear: their tools start out like new.
        axeUses = tools.getOrNull(2)?.toIntOrNull() ?: TOOL_USES[axeTier]
        pickUses = tools.getOrNull(3)?.toIntOrNull() ?: TOOL_USES[pickTier]
        bestAxe = max(axeTier, tools.getOrNull(4)?.toIntOrNull() ?: 0)
        bestPick = max(pickTier, tools.getOrNull(5)?.toIntOrNull() ?: 0)
        oreGone.clear()
        for (e in (prefs.getString("bOre", "") ?: "").split(',')) {
            val kv = e.split(':')
            val k = kv.getOrNull(0)?.toIntOrNull() ?: continue
            val t = kv.getOrNull(1)?.toLongOrNull() ?: continue
            oreGone[k] = t
        }
        for (rec in (prefs.getString("bPieces", "") ?: "").split(';')) {
            val f = rec.split(',')
            if (f.size < 8) continue
            val t = f[0].toIntOrNull() ?: continue
            if (t < 0 || t >= PieceType.COUNT) continue
            val gi = f[1].toIntOrNull() ?: continue
            val gk = f[2].toIntOrNull() ?: continue
            val o = f[3].toIntOrNull() ?: continue
            val y = f[4].toFloatOrNull() ?: continue
            val p = Piece(t, gi, gk, o, y)
            if (PieceType.isFree(t)) {
                p.fx = f.getOrNull(8)?.toFloatOrNull() ?: continue
                p.fz = f.getOrNull(9)?.toFloatOrNull() ?: continue
            }
            for (r in 0 until Res.COUNT) p.paid[r] = f[5 + r].toIntOrNull()?.coerceIn(0, PieceType.COST[t][r]) ?: 0
            if (t == PieceType.FOUNDATION) p.depth = foundationDepth(gi, gk, y)
            if (p.paidInFull) {
                makeCollision(p)
                p.built = true
            }
            pieces.add(p)
            index(p)
        }
        synchronized(storeLock) {
            store.clear()
            for (line in (prefs.getString("bStore", "") ?: "").split('\n')) {
                val hashAt = line.indexOf('#')
                if (hashAt <= 0) continue
                val pi = line.substring(0, hashAt).toIntOrNull() ?: continue
                val p = pieces.getOrNull(pi) ?: continue
                if (!PieceType.isStorage(p.type)) continue
                val list = ArrayList<Item>()
                for (enc in line.substring(hashAt + 1).split(';')) Item.decode(enc)?.let { list.add(it) }
                store[p] = list
            }
        }
        spawnBed = pieces.getOrNull(prefs.getInt("bBed", -1))?.takeIf { it.type == PieceType.BED }
        hunger = prefs.getFloat("bHunger", 100f).coerceIn(0f, 100f)
        // Trees and rocks: which are down, and when they grow back.
        val old = ArrayList(world.harvested.keys)
        world.harvested.clear()
        for (k in old) world.markDirty(k % GRID, k / GRID)
        for (rec in (prefs.getString("bCut", "") ?: "").split(',')) {
            val f = rec.split(':')
            if (f.size != 2) continue
            val k = f[0].toIntOrNull() ?: continue
            val t = f[1].toLongOrNull() ?: continue
            if (k < 0 || k >= GRID * GRID) continue
            world.harvested[k] = t
            world.markDirty(k % GRID, k / GRID)
        }
        dirty = false
        version = version + 1
    }

    private fun save() {
        if (SaveLock.blocked) return
        val ctx = appCtx ?: return
        val sb = StringBuilder()
        for (p in pieces) {
            if (sb.isNotEmpty()) sb.append(';')
            sb.append(p.type).append(',').append(p.gi).append(',').append(p.gk).append(',').append(p.o).append(',')
                .append(p.y).append(',').append(p.paid[0]).append(',').append(p.paid[1]).append(',').append(p.paid[2])
            if (PieceType.isFree(p.type)) sb.append(',').append(p.fx).append(',').append(p.fz)
        }
        // Chest and fridge contents, by the piece's place in the list: "index#item;item" per line.
        val st = StringBuilder()
        synchronized(storeLock) {
            for ((i, p) in pieces.withIndex()) {
                val list = store[p] ?: continue
                if (list.isEmpty()) continue
                if (st.isNotEmpty()) st.append('\n')
                st.append(i).append('#').append(list.joinToString(";") { it.encode() })
            }
        }
        val bed = spawnBed?.let { pieces.indexOf(it) } ?: -1
        val cut = StringBuilder()
        for ((k, t) in world.harvested) {
            if (cut.isNotEmpty()) cut.append(',')
            cut.append(k).append(':').append(t)
        }
        ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit()
            .putString("bRes", res.joinToString(","))
            .putString("bTools", "$axeTier,$pickTier,$axeUses,$pickUses,$bestAxe,$bestPick")
            .putString("bOre", oreGone.entries.joinToString(",") { "${it.key}:${it.value}" })
            .putString("bPieces", sb.toString())
            .putString("bCut", cut.toString())
            .putString("bStore", st.toString())
            .putInt("bBed", bed)
            .putFloat("bHunger", hunger)
            .apply()
    }

    // ---------- What the pieces look like ----------

    private fun log(m: MeshBuilder, x0: Float, x1: Float, y: Float, rgb: Int) {
        m.limb(x0, y, 0f, x1, y, 0f, 0.25f, 0.25f, rgb, FLAG_BARK)
    }

    private fun logShade(i: Int, seed: Int): Int = shadeRgb(LOG, 0.88f + 0.22f * hash(i, seed, 71))

    private fun buildSolid(m: MeshBuilder, t: Int) {
        if (PieceType.isFree(t)) {
            buildFurniture(m, t)
            return
        }
        when (t) {
            // A block of mortared stone; drawn stretched down to meet the ground.
            PieceType.FOUNDATION -> {
                m.box(0f, -0.5f, 0f, HALF, 0.5f, HALF, 0f, STONE, FLAG_STONE)
                m.box(0f, -0.5f, 0f, HALF + 0.03f, 0.03f, HALF + 0.03f, 0f, STONE_DARK, FLAG_STONE)
            }
            PieceType.WALL -> {
                for (i in 0 until 6) log(m, -HALF - 0.05f, HALF + 0.05f, 0.25f + i * 0.5f, logShade(i, 1))
                for (s in intArrayOf(-1, 1)) m.prism(s * HALF, 0f, 0f, 0.2f, 0.18f, WALL_H + 0.1f, 6, LOG_DARK, 0f, true, FLAG_BARK)
            }
            PieceType.DOORWAY -> {
                for (i in 0 until 6) {
                    val y = 0.25f + i * 0.5f
                    if (y < 2.3f) {
                        log(m, -HALF - 0.05f, -0.62f, y, logShade(i, 2))
                        log(m, 0.62f, HALF + 0.05f, y, logShade(i, 3))
                    } else {
                        log(m, -HALF - 0.05f, HALF + 0.05f, y, logShade(i, 4))
                    }
                }
                for (s in intArrayOf(-1, 1)) {
                    m.prism(s * HALF, 0f, 0f, 0.2f, 0.18f, WALL_H + 0.1f, 6, LOG_DARK, 0f, true, FLAG_BARK)
                    m.box(s * 0.62f, 1.15f, 0f, 0.07f, 1.15f, 0.2f, 0f, PLANK, FLAG_WOOD)
                }
                m.box(0f, 2.3f, 0f, 0.7f, 0.08f, 0.2f, 0f, PLANK, FLAG_WOOD)
            }
            PieceType.WINDOW -> {
                for (i in 0 until 6) {
                    val y = 0.25f + i * 0.5f
                    if (y > 1.0f && y < 2.2f) {
                        log(m, -HALF - 0.05f, -0.7f, y, logShade(i, 5))
                        log(m, 0.7f, HALF + 0.05f, y, logShade(i, 6))
                    } else {
                        log(m, -HALF - 0.05f, HALF + 0.05f, y, logShade(i, 7))
                    }
                }
                for (s in intArrayOf(-1, 1)) {
                    m.prism(s * HALF, 0f, 0f, 0.2f, 0.18f, WALL_H + 0.1f, 6, LOG_DARK, 0f, true, FLAG_BARK)
                    m.box(s * 0.7f, 1.5f, 0f, 0.06f, 0.52f, 0.22f, 0f, PLANK, FLAG_WOOD)
                }
                m.box(0f, 0.98f, 0f, 0.76f, 0.06f, 0.26f, 0f, PLANK, FLAG_WOOD)
                m.box(0f, 2.02f, 0f, 0.76f, 0.06f, 0.24f, 0f, PLANK, FLAG_WOOD)
                // A cross of glazing bars.
                m.box(0f, 1.5f, 0f, 0.03f, 0.46f, 0.03f, 0f, LOG_DARK, FLAG_WOOD)
                m.box(0f, 1.5f, 0f, 0.66f, 0.03f, 0.03f, 0f, LOG_DARK, FLAG_WOOD)
            }
            PieceType.STONE_WALL -> {
                for (row in 0 until 6) {
                    val y = 0.25f + row * 0.5f
                    val off = if (row % 2 == 0) 0f else 0.375f
                    var x = -HALF - off
                    var k = 0
                    while (x < HALF - 0.01f) {
                        val x0 = max(-HALF, x)
                        val x1 = min(HALF, x + 0.75f)
                        if (x1 - x0 > 0.05f) {
                            val c = shadeRgb(STONE, 0.82f + 0.3f * hash(row, k, 91))
                            m.box((x0 + x1) * 0.5f, y, 0f, (x1 - x0) * 0.5f - 0.015f, 0.235f, 0.2f, 0f, c, FLAG_STONE)
                        }
                        x += 0.75f
                        k++
                    }
                }
                m.box(0f, 0.25f, 0f, HALF, 0.22f, 0.17f, 0f, STONE_DARK, FLAG_STONE)
                m.box(0f, 2.75f, 0f, HALF, 0.22f, 0.17f, 0f, STONE_DARK, FLAG_STONE)
                m.box(0f, 1.5f, 0f, HALF, 1.25f, 0.17f, 0f, STONE_DARK, FLAG_STONE)
            }
            PieceType.FLOOR -> {
                for (k in 0 until 6) {
                    val c = shadeRgb(PLANK, 0.88f + 0.24f * hash(k, 3, 72))
                    m.box(-HALF + 0.25f + k * 0.5f, -0.07f, 0f, 0.24f, 0.07f, HALF, 0f, c, FLAG_WOOD)
                }
                for (s in intArrayOf(-1, 1)) {
                    m.limb(-HALF, -0.28f, s * (HALF - 0.2f), HALF, -0.28f, s * (HALF - 0.2f), 0.14f, 0.14f, LOG_DARK, FLAG_BARK)
                }
            }
            PieceType.STAIRS -> {
                for (s in intArrayOf(-1, 1)) {
                    m.limb(s * 0.72f, -0.1f, -HALF, s * 0.72f, WALL_H - 0.1f, HALF, 0.1f, 0.1f, LOG_DARK, FLAG_BARK)
                }
                val steps = 10
                for (k in 0 until steps) {
                    val t = (k + 0.5f) / steps
                    val c = shadeRgb(PLANK, 0.9f + 0.2f * hash(k, 5, 73))
                    m.box(0f, WALL_H * t - 0.05f, -HALF + BUILD_CELL * t, 0.76f, 0.05f, 0.17f, 0f, c, FLAG_WOOD)
                }
                // A post and rail on each side to hold onto.
                for (s in intArrayOf(-1, 1)) {
                    m.prism(s * 0.78f, 0f, -HALF + 0.1f, 0.05f, 0.05f, 1.0f, 5, LOG_DARK, 0f, true, FLAG_BARK)
                    m.prism(s * 0.78f, WALL_H - 0.2f, HALF - 0.1f, 0.05f, 0.05f, 1.0f, 5, LOG_DARK, 0f, true, FLAG_BARK)
                    m.limb(s * 0.78f, 0.95f, -HALF + 0.1f, s * 0.78f, WALL_H + 0.75f, HALF - 0.1f, 0.04f, 0.04f, LOG, FLAG_BARK)
                }
            }
            PieceType.ROOF -> {
                // Shingles rising towards +z, with a little overhang all round.
                val rows = 6
                for (k in 0 until rows) {
                    val t0 = k / rows.toFloat()
                    val t1 = (k + 1) / rows.toFloat()
                    val z0 = -HALF - 0.2f + (BUILD_CELL + 0.4f) * t0
                    val z1 = -HALF - 0.2f + (BUILD_CELL + 0.4f) * t1
                    val y0 = -0.1f + (ROOF_RISE + 0.2f) * t0 + 0.12f
                    val y1 = -0.1f + (ROOF_RISE + 0.2f) * t1 + 0.12f
                    val c = shadeRgb(SHINGLE, 0.86f + 0.26f * hash(k, 7, 74))
                    m.quad(-HALF - 0.2f, y0 - 0.04f, z0, HALF + 0.2f, y0 - 0.04f, z0, HALF + 0.2f, y1, z1, -HALF - 0.2f, y1, z1, c, FLAG_ROOF, 0f, -9f, 0f)
                    m.quad(-HALF - 0.2f, y0 - 0.1f, z0, HALF + 0.2f, y0 - 0.1f, z0, HALF + 0.2f, y1 - 0.06f, z1, -HALF - 0.2f, y1 - 0.06f, z1, shadeRgb(PLANK, 0.8f), FLAG_WOOD, 0f, 9f, 0f)
                }
                for (s in floatArrayOf(-1.3f, 0f, 1.3f)) {
                    m.limb(s, -0.15f, -HALF - 0.15f, s, ROOF_RISE - 0.05f, HALF + 0.15f, 0.08f, 0.08f, LOG_DARK, FLAG_BARK)
                }
                // A ridge log along the high edge: where two roofs meet back to back it caps the peak.
                m.limb(-HALF - 0.25f, ROOF_RISE + 0.06f, HALF, HALF + 0.25f, ROOF_RISE + 0.06f, HALF, 0.14f, 0.14f, LOG_DARK, FLAG_BARK)
            }
            PieceType.FLAT_ROOF -> {
                // Boards on joists, shingled over, with a drip edge all round.
                for (s in intArrayOf(-1, 1)) {
                    m.limb(-HALF, -0.3f, s * (HALF - 0.2f), HALF, -0.3f, s * (HALF - 0.2f), 0.14f, 0.14f, LOG_DARK, FLAG_BARK)
                }
                m.box(0f, -0.1f, 0f, HALF, 0.08f, HALF, 0f, shadeRgb(PLANK, 0.8f), FLAG_WOOD)
                for (k in 0 until 6) {
                    val c = shadeRgb(SHINGLE, 0.86f + 0.26f * hash(k, 11, 76))
                    m.box(0f, -0.005f, -HALF + 0.25f + k * 0.5f, HALF + 0.02f, 0.025f, 0.26f, 0f, c, FLAG_ROOF)
                }
                for (s in intArrayOf(-1, 1)) {
                    m.box(0f, -0.1f, s * (HALF + 0.03f), HALF + 0.06f, 0.1f, 0.03f, 0f, LOG_DARK, FLAG_WOOD)
                    m.box(s * (HALF + 0.03f), -0.1f, 0f, 0.03f, 0.1f, HALF + 0.06f, 0f, LOG_DARK, FLAG_WOOD)
                }
            }
            PieceType.GABLE -> {
                // Upright boards, each cut to the slope, rising towards +x, with a trim along the top.
                for (k in 0 until 6) {
                    val x = -HALF + 0.25f + k * 0.5f
                    val h = ROOF_RISE * (x + HALF) / BUILD_CELL
                    val c = shadeRgb(PLANK, 0.85f + 0.25f * hash(k, 13, 77))
                    m.box(x, h * 0.5f, 0f, 0.24f, h * 0.5f, 0.12f, 0f, c, FLAG_WOOD)
                }
                m.limb(-HALF - 0.05f, 0.05f, 0f, HALF + 0.05f, ROOF_RISE + 0.05f, 0f, 0.09f, 0.09f, LOG_DARK, FLAG_BARK)
                m.limb(-HALF, 0.05f, 0f, HALF, 0.05f, 0f, 0.12f, 0.12f, LOG_DARK, FLAG_BARK)
                m.prism(HALF, 0f, 0f, 0.16f, 0.15f, ROOF_RISE + 0.05f, 6, LOG_DARK, 0f, true, FLAG_BARK)
            }
            PieceType.STONE_GABLE -> {
                // Courses of stone, each shorter than the last, under a sloping coping.
                for (row in 0 until 6) {
                    val y0 = row * 0.25f
                    val xs = (y0 + 0.25f) / ROOF_RISE * BUILD_CELL - HALF
                    var x = HALF
                    var k = 0
                    val len = if (row % 2 == 0) 0.75f else 0.6f
                    while (x > xs + 0.02f) {
                        val x0 = max(xs, x - len)
                        val c = shadeRgb(STONE, 0.82f + 0.3f * hash(row, k, 93))
                        m.box((x0 + x) * 0.5f, y0 + 0.125f, 0f, (x - x0) * 0.5f - 0.012f, 0.115f, 0.18f, 0f, c, FLAG_STONE)
                        x -= len
                        k++
                    }
                }
                m.limb(-HALF - 0.05f, 0.08f, 0f, HALF + 0.05f, ROOF_RISE + 0.08f, 0f, 0.13f, 0.13f, STONE_DARK, FLAG_STONE)
            }
            PieceType.BENCH -> {
                // A heavy workbench, with a vice, a saw and a mallet on it. Its front faces +z.
                m.box(0f, 0.86f, 0f, 0.8f, 0.07f, 0.42f, 0f, PLANK, FLAG_WOOD)
                for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) {
                    m.box(sx * 0.68f, 0.4f, sz * 0.3f, 0.06f, 0.4f, 0.06f, 0f, LOG_DARK, FLAG_WOOD)
                }
                m.box(0f, 0.25f, 0f, 0.68f, 0.03f, 0.3f, 0f, shadeRgb(PLANK, 0.85f), FLAG_WOOD)
                m.box(-0.55f, 1.0f, 0.3f, 0.1f, 0.07f, 0.08f, 0f, 0x55585E, FLAG_STONE)
                m.box(0.1f, 0.95f, -0.1f, 0.32f, 0.015f, 0.09f, 0.3f, 0xA8ACB2, FLAG_STONE)
                m.box(0.42f, 0.96f, -0.05f, 0.08f, 0.03f, 0.03f, 0.3f, LOG_DARK, FLAG_WOOD)
                m.limb(0.45f, 0.95f, 0.22f, 0.7f, 0.95f, 0.1f, 0.025f, 0.025f, LOG, FLAG_WOOD)
                m.box(0.4f, 0.97f, 0.24f, 0.05f, 0.05f, 0.09f, 0f, LOG_DARK, FLAG_WOOD)
                // A few logs and a stone waiting their turn.
                m.limb(-0.5f, 0.12f, -0.62f, 0.5f, 0.12f, -0.62f, 0.12f, 0.12f, LOG, FLAG_BARK)
                m.limb(-0.4f, 0.34f, -0.62f, 0.4f, 0.34f, -0.62f, 0.11f, 0.11f, shadeRgb(LOG, 0.9f), FLAG_BARK)
                m.rock(0.75f, 0.15f, -0.6f, 0.18f, 0.15f, 0.16f, STONE, 77)
            }
        }
    }

    /** Furniture, each built with its front facing +z. */
    private fun buildFurniture(m: MeshBuilder, t: Int) {
        when (t) {
            PieceType.WALL_TORCH -> {
                // An iron bracket on a back plate, holding a torch tipped out from the wall.
                m.box(0f, 0.05f, -0.2f, 0.07f, 0.16f, 0.02f, 0f, 0x3A3A3E, FLAG_STONE)
                m.limb(0f, 0.0f, -0.18f, 0f, 0.0f, -0.02f, 0.025f, 0.025f, 0x3A3A3E, FLAG_STONE)
                m.limb(0f, -0.25f, -0.1f, 0f, 0.3f, 0.05f, 0.035f, 0.03f, LOG_DARK, FLAG_WOOD)
                m.prism(0f, 0.27f, 0.04f, 0.06f, 0.07f, 0.1f, 6, 0x3A2416, 0f, true, FLAG_BARK)
                m.flame(0f, 0.36f, 0.05f, 0.09f, 0.42f, 0.3f, 0xFF7A18, 0xFFE070)
                m.flame(0.02f, 0.36f, 0.05f, 0.06f, 0.3f, 1.4f, 0xFFA030, 0xFFF4B0)
            }
            PieceType.TORCH -> {
                // A post driven into the ground, a basket of pitch on top, and its flame.
                m.prism(0f, 0f, 0f, 0.06f, 0.045f, 1.75f, 6, LOG_DARK, 0f, true, FLAG_WOOD)
                for (s in intArrayOf(-1, 1)) m.limb(s * 0.12f, -0.1f, 0f, 0f, 0.35f, 0f, 0.03f, 0.03f, LOG_DARK, FLAG_WOOD)
                m.prism(0f, 1.7f, 0f, 0.09f, 0.13f, 0.18f, 8, 0x3A3A3E, 0f, false, FLAG_STONE)
                m.prism(0f, 1.75f, 0f, 0.1f, 0.1f, 0.05f, 8, 0x2A1A10, 0f, true, FLAG_BARK)
                m.flame(0f, 1.82f, 0f, 0.12f, 0.6f, 0.2f, 0xFF7A18, 0xFFE070)
                m.flame(0f, 1.82f, 0f, 0.09f, 0.45f, 1.3f, 0xFFA030, 0xFFF4B0)
            }
            PieceType.BED -> {
                // A plank frame with posts, a straw mattress, a pillow at the head (-z) and a wool blanket.
                for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) {
                    val h = if (sz < 0) 0.85f else 0.5f
                    m.box(sx * 0.5f, h * 0.5f, sz * 1.0f, 0.05f, h * 0.5f, 0.05f, 0f, LOG_DARK, FLAG_WOOD)
                }
                for (sx in intArrayOf(-1, 1)) m.box(sx * 0.5f, 0.3f, 0f, 0.04f, 0.08f, 1.0f, 0f, PLANK, FLAG_WOOD)
                m.box(0f, 0.65f, -1.0f, 0.5f, 0.17f, 0.04f, 0f, PLANK, FLAG_WOOD)
                m.box(0f, 0.3f, 0f, 0.48f, 0.05f, 0.98f, 0f, shadeRgb(PLANK, 0.8f), FLAG_WOOD)
                m.box(0f, 0.42f, 0f, 0.45f, 0.08f, 0.95f, 0f, 0xD8C890, FLAG_PLASTER)
                m.box(0f, 0.53f, -0.72f, 0.3f, 0.06f, 0.16f, 0f, 0xF0EADC, FLAG_PLASTER)
                m.box(0f, 0.52f, 0.25f, 0.47f, 0.035f, 0.68f, 0f, 0x8A2A2A, FLAG_PLASTER)
                m.box(0f, 0.52f, -0.42f, 0.47f, 0.04f, 0.05f, 0f, 0xE8E0CC, FLAG_PLASTER)
            }
            PieceType.CHEST_S, PieceType.CHEST_M, PieceType.CHEST_L -> {
                val hx = when (t) { PieceType.CHEST_S -> 0.38f; PieceType.CHEST_M -> 0.52f; else -> 0.72f }
                val hz = when (t) { PieceType.CHEST_S -> 0.25f; PieceType.CHEST_M -> 0.3f; else -> 0.35f }
                val h = when (t) { PieceType.CHEST_S -> 0.4f; PieceType.CHEST_M -> 0.5f; else -> 0.58f }
                m.box(0f, h * 0.5f, 0f, hx, h * 0.5f, hz, 0f, PLANK, FLAG_WOOD)
                // A rounded lid, iron bands and a lock on the front.
                m.limb(-hx, h, 0f, hx, h, 0f, hz, hz * 0.55f, shadeRgb(PLANK, 0.9f), FLAG_WOOD)
                for (s in floatArrayOf(-0.7f, 0.7f)) {
                    m.box(s * hx, h * 0.5f, 0f, 0.03f, h * 0.5f + 0.01f, hz + 0.01f, 0f, 0x4A4A50, FLAG_STONE)
                    m.limb(s * hx - 0.03f, h, 0f, s * hx + 0.03f, h, 0f, hz + 0.015f, hz * 0.55f + 0.015f, 0x4A4A50, FLAG_STONE)
                }
                m.box(0f, h * 0.82f, hz + 0.01f, 0.06f, 0.07f, 0.02f, 0f, 0xC8A040, FLAG_STONE)
                m.box(0f, 0.02f, 0f, hx + 0.02f, 0.02f, hz + 0.02f, 0f, LOG_DARK, FLAG_WOOD)
            }
            PieceType.TABLE -> {
                m.box(0f, 0.76f, 0f, 0.8f, 0.04f, 0.45f, 0f, PLANK, FLAG_WOOD)
                for (k in 0 until 4) {
                    val c = shadeRgb(PLANK, 0.9f + 0.15f * hash(k, 21, 78))
                    m.box(-0.6f + k * 0.4f, 0.805f, 0f, 0.195f, 0.006f, 0.44f, 0f, c, FLAG_WOOD)
                }
                for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) {
                    m.box(sx * 0.7f, 0.37f, sz * 0.36f, 0.045f, 0.37f, 0.045f, 0f, LOG_DARK, FLAG_WOOD)
                }
                for (sz in intArrayOf(-1, 1)) m.box(0f, 0.2f, sz * 0.36f, 0.66f, 0.025f, 0.025f, 0f, LOG_DARK, FLAG_WOOD)
                // A candle, a mug and a plate.
                m.prism(0.45f, 0.81f, 0.1f, 0.03f, 0.03f, 0.14f, 6, 0xF0E8D0, 0f, true, FLAG_PLASTER)
                m.flame(0.45f, 0.95f, 0.1f, 0.015f, 0.06f, 0f, 0xFF9A30, 0xFFF0B0)
                m.prism(-0.3f, 0.81f, -0.1f, 0.05f, 0.045f, 0.1f, 8, 0x8A6A40, 0f, true, FLAG_WOOD)
                m.prism(0f, 0.81f, 0.12f, 0.12f, 0.12f, 0.015f, 10, 0xC8C0B0, 0f, true, FLAG_PLASTER)
            }
            PieceType.CHAIR -> {
                // Seat at sitting height, its back to -z, so you sit facing +z.
                m.box(0f, 0.46f, 0f, 0.24f, 0.03f, 0.24f, 0f, PLANK, FLAG_WOOD)
                for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) {
                    val h = if (sz < 0) 1.0f else 0.45f
                    m.box(sx * 0.2f, h * 0.5f, sz * 0.2f, 0.025f, h * 0.5f, 0.025f, 0f, LOG_DARK, FLAG_WOOD)
                }
                for (k in 0 until 3) m.box(0f, 0.62f + k * 0.13f, -0.2f, 0.2f, 0.035f, 0.02f, 0f, PLANK, FLAG_WOOD)
            }
            PieceType.FRIDGE -> {
                // A tall, frost-rimed ice chest of stone and timber, its doors at the front (+z).
                m.box(0f, 0.95f, 0f, 0.42f, 0.95f, 0.36f, 0f, 0xA8B4BC, FLAG_STONE)
                m.box(0f, 1.32f, 0.365f, 0.38f, 0.5f, 0.015f, 0f, 0xD8E4EC, FLAG_PLASTER)
                m.box(0f, 0.42f, 0.365f, 0.38f, 0.36f, 0.015f, 0f, 0xD8E4EC, FLAG_PLASTER)
                for (y in floatArrayOf(1.5f, 0.55f)) m.box(0.3f, y, 0.39f, 0.02f, 0.12f, 0.02f, 0f, 0x4A4A50, FLAG_STONE)
                m.box(0f, 1.9f, 0f, 0.45f, 0.04f, 0.39f, 0f, LOG_DARK, FLAG_WOOD)
                m.box(0f, 0.03f, 0f, 0.45f, 0.03f, 0.39f, 0f, LOG_DARK, FLAG_WOOD)
                // A blue glow of cold inside the seams.
                m.box(0f, 0.82f, 0.37f, 0.38f, 0.012f, 0.012f, 0f, 0x6ACBFF, FLAG_GLOW)
            }
            PieceType.FIRE_PIT -> {
                // A ring of stones, crossed logs, embers and flames: and a spit for cooking.
                for (k in 0 until 9) {
                    val a = k * 6.2831855f / 9f
                    m.rock(kotlin.math.cos(a) * 0.6f, 0.1f, kotlin.math.sin(a) * 0.6f, 0.2f, 0.15f, 0.18f, shadeRgb(STONE, 0.8f + 0.2f * hash(k, 3, 79)), 80 + k)
                }
                m.limb(-0.4f, 0.1f, -0.12f, 0.4f, 0.1f, 0.12f, 0.07f, 0.07f, LOG_DARK, FLAG_BARK)
                m.limb(-0.12f, 0.14f, 0.4f, 0.12f, 0.14f, -0.4f, 0.07f, 0.07f, LOG_DARK, FLAG_BARK)
                m.prism(0f, 0.02f, 0f, 0.42f, 0.36f, 0.05f, 8, 0xFF5A18, 0f, true, FLAG_FIRE)
                for (k in 0 until 4) {
                    val a = k * 1.5707964f
                    m.flame(kotlin.math.cos(a) * 0.12f, 0.08f, kotlin.math.sin(a) * 0.12f, 0.2f, 0.65f + 0.2f * (k % 2), a, 0xFF6A10, 0xFFE070)
                }
                m.flame(0f, 0.08f, 0f, 0.15f, 1.0f, 0.4f, 0xFFA030, 0xFFF4B0)
                for (s in intArrayOf(-1, 1)) {
                    m.limb(s * 0.72f, 0f, 0f, s * 0.72f, 0.9f, 0f, 0.03f, 0.03f, LOG_DARK, FLAG_WOOD)
                    m.limb(s * 0.72f, 0.9f, 0f, s * 0.6f, 1.0f, 0f, 0.025f, 0.025f, LOG_DARK, FLAG_WOOD)
                }
                m.limb(-0.8f, 0.97f, 0f, 0.8f, 0.97f, 0f, 0.02f, 0.02f, 0x4A4A50, FLAG_STONE)
            }
        }
    }

    /** The glowing outline of a piece of furniture: a box of its size. */
    private fun furnitureFrame(m: MeshBuilder, t: Int, c: Int, f: Int) {
        val hx: Float
        val hz: Float
        val y0: Float
        val y1: Float
        when (t) {
            PieceType.WALL_TORCH -> { hx = 0.08f; hz = 0.12f; y0 = -0.25f; y1 = 0.75f }
            PieceType.TORCH -> { hx = 0.15f; hz = 0.15f; y0 = 0f; y1 = 2.3f }
            PieceType.BED -> { hx = 0.55f; hz = 1.05f; y0 = 0f; y1 = 0.85f }
            PieceType.CHEST_S -> { hx = 0.4f; hz = 0.27f; y0 = 0f; y1 = 0.55f }
            PieceType.CHEST_M -> { hx = 0.55f; hz = 0.32f; y0 = 0f; y1 = 0.7f }
            PieceType.CHEST_L -> { hx = 0.75f; hz = 0.37f; y0 = 0f; y1 = 0.8f }
            PieceType.TABLE -> { hx = 0.8f; hz = 0.45f; y0 = 0f; y1 = 0.8f }
            PieceType.CHAIR -> { hx = 0.25f; hz = 0.25f; y0 = 0f; y1 = 1.0f }
            PieceType.FRIDGE -> { hx = 0.42f; hz = 0.37f; y0 = 0f; y1 = 1.9f }
            else -> { hx = 0.75f; hz = 0.75f; y0 = 0f; y1 = 0.4f }
        }
        for (y in floatArrayOf(y0, y1)) {
            beam(m, -hx, y, -hz, hx, y, -hz, c, f)
            beam(m, hx, y, -hz, hx, y, hz, c, f)
            beam(m, hx, y, hz, -hx, y, hz, c, f)
            beam(m, -hx, y, hz, -hx, y, -hz, c, f)
        }
        for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) beam(m, sx * hx, y0, sz * hz, sx * hx, y1, sz * hz, c, f)
        // An arrow on the floor showing which way its front faces.
        beam(m, 0f, y0, 0f, 0f, y0, hz + 0.3f, c, f)
    }

    private fun buildDeck(m: MeshBuilder) {
        for (k in 0 until 6) {
            val c = shadeRgb(PLANK, 0.85f + 0.25f * hash(k, 9, 75))
            m.box(-HALF + 0.25f + k * 0.5f, -0.04f, 0f, 0.235f, 0.05f, HALF + 0.02f, 0f, c, FLAG_WOOD)
        }
    }

    private fun beam(m: MeshBuilder, x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, rgb: Int, flag: Int) {
        m.limb(x0, y0, z0, x1, y1, z1, 0.05f, 0.05f, rgb, flag)
    }

    /** The bare timber outline a piece starts as, or the glowing outline of where it'll go. */
    private fun buildFrame(m: MeshBuilder, t: Int, c: Int, f: Int) {
        if (PieceType.isFree(t)) {
            furnitureFrame(m, t, c, f)
            return
        }
        when (t) {
            PieceType.FOUNDATION, PieceType.FLOOR, PieceType.FLAT_ROOF -> {
                val y = 0f
                beam(m, -HALF, y, -HALF, HALF, y, -HALF, c, f)
                beam(m, HALF, y, -HALF, HALF, y, HALF, c, f)
                beam(m, HALF, y, HALF, -HALF, y, HALF, c, f)
                beam(m, -HALF, y, HALF, -HALF, y, -HALF, c, f)
                beam(m, -HALF, y, -HALF, HALF, y, HALF, c, f)
                beam(m, HALF, y, -HALF, -HALF, y, HALF, c, f)
                if (t == PieceType.FOUNDATION) {
                    for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) beam(m, sx * HALF, y, sz * HALF, sx * HALF, -1f, sz * HALF, c, f)
                }
            }
            PieceType.WALL, PieceType.WINDOW, PieceType.STONE_WALL, PieceType.DOORWAY -> {
                beam(m, -HALF, 0f, 0f, HALF, 0f, 0f, c, f)
                beam(m, -HALF, WALL_H, 0f, HALF, WALL_H, 0f, c, f)
                beam(m, -HALF, 0f, 0f, -HALF, WALL_H, 0f, c, f)
                beam(m, HALF, 0f, 0f, HALF, WALL_H, 0f, c, f)
                when (t) {
                    PieceType.DOORWAY -> {
                        beam(m, -0.62f, 0f, 0f, -0.62f, 2.3f, 0f, c, f)
                        beam(m, 0.62f, 0f, 0f, 0.62f, 2.3f, 0f, c, f)
                        beam(m, -0.62f, 2.3f, 0f, 0.62f, 2.3f, 0f, c, f)
                    }
                    PieceType.WINDOW -> {
                        beam(m, -0.7f, 1.0f, 0f, 0.7f, 1.0f, 0f, c, f)
                        beam(m, -0.7f, 2.0f, 0f, 0.7f, 2.0f, 0f, c, f)
                        beam(m, -0.7f, 1.0f, 0f, -0.7f, 2.0f, 0f, c, f)
                        beam(m, 0.7f, 1.0f, 0f, 0.7f, 2.0f, 0f, c, f)
                    }
                    else -> {
                        beam(m, 0f, 0f, 0f, 0f, WALL_H, 0f, c, f)
                        beam(m, -HALF, 0f, 0f, 0f, WALL_H, 0f, c, f)
                        beam(m, HALF, 0f, 0f, 0f, WALL_H, 0f, c, f)
                    }
                }
            }
            PieceType.STAIRS -> {
                for (s in intArrayOf(-1, 1)) beam(m, s * 0.72f, 0f, -HALF, s * 0.72f, WALL_H, HALF, c, f)
                for (k in 0 until 4) {
                    val tt = (k + 0.5f) / 4f
                    beam(m, -0.72f, WALL_H * tt, -HALF + BUILD_CELL * tt, 0.72f, WALL_H * tt, -HALF + BUILD_CELL * tt, c, f)
                }
            }
            PieceType.ROOF -> {
                beam(m, -HALF, 0f, -HALF, HALF, 0f, -HALF, c, f)
                beam(m, -HALF, ROOF_RISE, HALF, HALF, ROOF_RISE, HALF, c, f)
                beam(m, -HALF, 0f, -HALF, -HALF, ROOF_RISE, HALF, c, f)
                beam(m, HALF, 0f, -HALF, HALF, ROOF_RISE, HALF, c, f)
                beam(m, 0f, 0f, -HALF, 0f, ROOF_RISE, HALF, c, f)
                beam(m, -HALF, 0f, -HALF, HALF, ROOF_RISE, HALF, c, f)
            }
            PieceType.GABLE, PieceType.STONE_GABLE -> {
                beam(m, -HALF, 0f, 0f, HALF, 0f, 0f, c, f)
                beam(m, HALF, 0f, 0f, HALF, ROOF_RISE, 0f, c, f)
                beam(m, -HALF, 0f, 0f, HALF, ROOF_RISE, 0f, c, f)
                beam(m, 0f, 0f, 0f, 0f, ROOF_RISE * 0.5f, 0f, c, f)
            }
            PieceType.BENCH -> {
                val y = 0.9f
                beam(m, -0.8f, y, -0.42f, 0.8f, y, -0.42f, c, f)
                beam(m, 0.8f, y, -0.42f, 0.8f, y, 0.42f, c, f)
                beam(m, 0.8f, y, 0.42f, -0.8f, y, 0.42f, c, f)
                beam(m, -0.8f, y, 0.42f, -0.8f, y, -0.42f, c, f)
                for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) beam(m, sx * 0.72f, 0f, sz * 0.34f, sx * 0.72f, y, sz * 0.34f, c, f)
            }
        }
    }

    companion object {
        /** How long a felled tree or broken rock takes to grow back. */
        const val REGROW_MS = 15L * 60L * 1000L
        /** How long a mined-out ore vein takes to come back. */
        const val ORE_REGROW_MS = 20L * 60L * 1000L
        /** Blows a tool lasts, by tier (none, stone, iron). */
        val TOOL_USES = intArrayOf(0, 150, 400)
        private val NEIGHBOURS = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
        private const val LOG = 0x7A5634
        private const val LOG_DARK = 0x5A3E26
        private const val PLANK = 0x9C7449
        private const val STONE = 0x8E8A80
        private const val STONE_DARK = 0x6A665E
        private const val SHINGLE = 0x6A3E2A
        private const val FRAME_WOOD = 0xD8B884
    }
}
