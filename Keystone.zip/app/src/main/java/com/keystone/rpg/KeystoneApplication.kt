package com.keystone.rpg

import android.app.Application
import com.google.android.gms.games.PlayGamesSdk

/** Starts Play Games Services as soon as the app process does; sign-in is then attempted automatically. */
class KeystoneApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        PlayGamesSdk.initialize(this)
    }
}
