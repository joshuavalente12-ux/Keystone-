package com.keystone.rpg

import android.content.Context
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * How your hero looks: chosen before you pick a weapon. Every field is an index into one of the
 * option lists in the companion. Saved in "keystone_save" under "look".
 */
class Look {
    var skin = 3
    var hair = 1
    var hairStyle = 0
    var eyes = 0
    var eyeColor = 0
    var face = 0
    var ears = 0
    var nose = 0
    var beard = 1
    var arms = 1
    var body = 1
    var legs = 1
    var feet = 1

    fun get(f: Int): Int = when (f) {
        F_SKIN -> skin
        F_HAIR -> hair
        F_STYLE -> hairStyle
        F_EYES -> eyes
        F_EYE_COLOR -> eyeColor
        F_FACE -> face
        F_EARS -> ears
        F_NOSE -> nose
        F_BEARD -> beard
        F_ARMS -> arms
        F_BODY -> body
        F_LEGS -> legs
        else -> feet
    }

    fun set(f: Int, v: Int) {
        val n = FIELDS[f].second.size
        val w = ((v % n) + n) % n
        when (f) {
            F_SKIN -> skin = w
            F_HAIR -> hair = w
            F_STYLE -> hairStyle = w
            F_EYES -> eyes = w
            F_EYE_COLOR -> eyeColor = w
            F_FACE -> face = w
            F_EARS -> ears = w
            F_NOSE -> nose = w
            F_BEARD -> beard = w
            F_ARMS -> arms = w
            F_BODY -> body = w
            F_LEGS -> legs = w
            else -> feet = w
        }
    }

    fun copy(): Look = Look().also { for (f in FIELDS.indices) it.set(f, get(f)) }

    fun encode(): String = FIELDS.indices.joinToString(",") { get(it).toString() }

    fun randomize(rnd: java.util.Random) {
        for (f in FIELDS.indices) set(f, rnd.nextInt(FIELDS[f].second.size))
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().putString("look", encode()).apply()
    }

    companion object {
        const val F_SKIN = 0
        const val F_HAIR = 1
        const val F_STYLE = 2
        const val F_EYES = 3
        const val F_EYE_COLOR = 4
        const val F_FACE = 5
        const val F_EARS = 6
        const val F_NOSE = 7
        const val F_BEARD = 8
        const val F_ARMS = 9
        const val F_BODY = 10
        const val F_LEGS = 11
        const val F_FEET = 12

        val SKIN_NAMES = arrayOf(
            "White", "Fair", "Light", "Tan", "Olive", "Brown", "Dark Brown", "Deep",
            "Ash Grey", "Orc Green", "Frost Blue", "Ember Red",
        )
        val SKIN = intArrayOf(
            0xF4E2D6.toInt(), 0xEBC6A8.toInt(), 0xDDAE88.toInt(), 0xC8977A.toInt(), 0xB08A5E.toInt(), 0x8D5A3B,
            0x6A3F28, 0x4A2A1A, 0x9A9A9E.toInt(), 0x6E8A4A, 0x7FA4C8, 0xA84A3A.toInt(),
        )
        val HAIR_NAMES = arrayOf(
            "Black", "Dark Brown", "Brown", "Auburn", "Ginger", "Blonde", "Platinum", "Grey", "White",
            "Blue", "Green", "Purple", "Pink", "Red",
        )
        val HAIR = intArrayOf(
            0x1A1412, 0x4A2F1E, 0x6E4A2C, 0x8A3A1E.toInt(), 0xC0602A.toInt(), 0xD8B86A.toInt(), 0xEDE2C4.toInt(),
            0x8E8A86.toInt(), 0xF2F0EA.toInt(), 0x2E5AB0, 0x2E7A3A, 0x6A2E9A, 0xD86AA0.toInt(), 0xB01A1A.toInt(),
        )
        val EYE_NAMES = arrayOf("Brown", "Hazel", "Green", "Blue", "Grey", "Amber", "Red", "Violet")
        val EYE = intArrayOf(
            0x3A2816, 0x6A5A2A, 0x3A7A3A, 0x3A6AB0, 0x7A8088, 0xC08A20.toInt(), 0xB01A1A.toInt(), 0x7A3AB0,
        )
        val STYLE_NAMES = arrayOf("Short", "Shaved", "Long", "Mohawk", "Ponytail")
        val EYES_NAMES = arrayOf("Normal", "Narrow", "Big", "Almond")
        val FACE_NAMES = arrayOf("Oval", "Round", "Square", "Long", "Heart")
        val EARS_NAMES = arrayOf("Normal", "Small", "Big", "Pointed")
        val NOSE_NAMES = arrayOf("Normal", "Button", "Broad", "Long", "Hooked")
        val BEARD_NAMES = arrayOf("None", "Goatee", "Stubble", "Full Beard", "Long Beard", "Moustache")
        val ARMS_NAMES = arrayOf("Slim", "Normal", "Muscular", "Huge")
        val BODY_NAMES = arrayOf("Slim", "Normal", "Athletic", "Broad", "Heavy")
        val LEGS_NAMES = arrayOf("Slim", "Normal", "Strong", "Thick")
        val FEET_NAMES = arrayOf("Small", "Normal", "Large")

        /** Every option, in the order shown on the screen: its label and its choices. */
        val FIELDS: List<Pair<String, Array<String>>> = listOf(
            "Skin" to SKIN_NAMES, "Hair Color" to HAIR_NAMES, "Hair Style" to STYLE_NAMES, "Eye Shape" to EYES_NAMES,
            "Eye Color" to EYE_NAMES, "Face" to FACE_NAMES, "Ears" to EARS_NAMES, "Nose" to NOSE_NAMES,
            "Beard" to BEARD_NAMES, "Arms" to ARMS_NAMES, "Body" to BODY_NAMES, "Legs" to LEGS_NAMES, "Feet" to FEET_NAMES,
        )

        /** A colour swatch for an option row, or null if it isn't a colour. */
        fun swatch(f: Int, v: Int): Int? = when (f) {
            F_SKIN -> SKIN[v]
            F_HAIR -> HAIR[v]
            F_EYE_COLOR -> EYE[v]
            else -> null
        }

        // Body proportions for the 3D hero.
        val BODY_W = floatArrayOf(0.88f, 1f, 1.06f, 1.17f, 1.14f)
        val BODY_D = floatArrayOf(0.9f, 1f, 1.04f, 1.06f, 1.12f)
        val BELLY = floatArrayOf(0.95f, 1f, 0.96f, 1.02f, 1.28f)
        val ARM_T = floatArrayOf(0.8f, 1f, 1.25f, 1.45f)
        val LEG_T = floatArrayOf(0.82f, 1f, 1.18f, 1.35f)
        val FOOT_S = floatArrayOf(0.85f, 1f, 1.2f)

        fun load(ctx: Context): Look {
            val l = Look()
            val s = ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("look", "") ?: ""
            val f = s.split(',')
            for (i in FIELDS.indices) f.getOrNull(i)?.toIntOrNull()?.let { l.set(i, it) }
            return l
        }
    }
}

private fun c(rgb: Int): Color = Color(0xFF000000L or (rgb.toLong() and 0xFFFFFFL))

private fun shade(rgb: Int, k: Float): Color {
    val r = (((rgb shr 16) and 255) * k).toInt().coerceIn(0, 255)
    val g = (((rgb shr 8) and 255) * k).toInt().coerceIn(0, 255)
    val b = ((rgb and 255) * k).toInt().coerceIn(0, 255)
    return Color(r, g, b)
}

/** A front-on picture of the hero as you've made them, for the character screen. */
fun DrawScope.drawLookPreview(look: Look) {
    val u = size.height / 2.15f
    val cx = size.width / 2f
    val ground = size.height * 0.97f
    // Heights in metres, measured up from the feet.
    fun y(m: Float) = ground - m * u
    val skin = Look.SKIN[look.skin]
    val hair = Look.HAIR[look.hair]
    val shirt = 0xD9CFB6
    val pants = 0x5B4633
    val bw = Look.BODY_W[look.body]
    val belly = Look.BELLY[look.body]
    val armT = Look.ARM_T[look.arms]
    val legT = Look.LEG_T[look.legs]
    val footS = Look.FOOT_S[look.feet]

    // Legs and feet.
    for (s in intArrayOf(-1, 1)) {
        val lx = cx + s * 0.095f * u
        val tw = 0.17f * legT * u
        drawRoundRect(c(pants), Offset(lx - tw / 2f, y(0.95f)), Size(tw, 0.5f * u), CornerRadius(tw / 2f))
        drawRoundRect(shade(pants, 0.92f), Offset(lx - tw * 0.4f, y(0.5f)), Size(tw * 0.8f, 0.44f * u), CornerRadius(tw / 2f))
        drawOval(c(skin), Offset(lx - 0.06f * footS * u + s * 0.02f * u, y(0.07f)), Size(0.12f * footS * u, 0.07f * u))
        drawOval(c(0x6E4A2C), Offset(lx - 0.065f * footS * u + s * 0.02f * u, y(0.03f)), Size(0.13f * footS * u, 0.035f * u))
    }
    // Arms, behind the body.
    for (s in intArrayOf(-1, 1)) {
        val ax = cx + s * 0.215f * bw * u
        val aw = 0.12f * armT * u
        drawRoundRect(c(shirt), Offset(ax - aw / 2f, y(1.5f)), Size(aw, 0.3f * u), CornerRadius(aw / 2f))
        val fw = 0.085f * (1f + (armT - 1f) * 0.8f) * u
        drawRoundRect(c(skin), Offset(ax - fw / 2f, y(1.22f)), Size(fw, 0.27f * u), CornerRadius(fw / 2f))
        drawCircle(c(skin), 0.05f * u, Offset(ax, y(0.92f)))
    }
    // Hips and body.
    val hw = 0.36f * bw * u
    drawRoundRect(c(pants), Offset(cx - hw / 2f, y(1.05f)), Size(hw, 0.16f * u), CornerRadius(0.05f * u))
    val tw = 0.4f * bw * u
    val bellyW = tw * belly
    drawRoundRect(c(shirt), Offset(cx - bellyW / 2f, y(1.38f)), Size(bellyW, 0.36f * u), CornerRadius(0.1f * u))
    drawRoundRect(c(shirt), Offset(cx - tw * 0.55f, y(1.57f)), Size(tw * 1.1f, 0.25f * u), CornerRadius(0.08f * u))
    drawRect(c(0x3A2616), Offset(cx - hw / 2f, y(1.1f)), Size(hw, 0.04f * u))
    drawRect(c(0xB09868), Offset(cx - 0.025f * u, y(1.105f)), Size(0.05f * u, 0.035f * u))
    // Neck.
    drawRoundRect(c(skin), Offset(cx - 0.05f * u, y(1.68f)), Size(0.1f * u, 0.14f * u), CornerRadius(0.04f * u))

    // Head: its shape depends on the face.
    val hx = cx
    val hy = y(1.79f)
    val (fw, fh) = when (look.face) {
        1 -> 0.22f to 0.24f
        2 -> 0.21f to 0.25f
        3 -> 0.18f to 0.29f
        4 -> 0.21f to 0.26f
        else -> 0.2f to 0.26f
    }
    val headW = fw * u
    val headH = fh * u
    // Long hair hangs behind the head.
    if (look.hairStyle == 2) {
        drawRoundRect(c(hair), Offset(hx - headW * 0.62f, hy - headH * 0.45f), Size(headW * 1.24f, headH * 1.25f), CornerRadius(headW * 0.3f))
    }
    if (look.hairStyle == 4) {
        drawRoundRect(c(hair), Offset(hx + headW * 0.35f, hy - headH * 0.05f), Size(headW * 0.18f, headH * 0.7f), CornerRadius(headW * 0.09f))
    }
    // Ears.
    for (s in intArrayOf(-1, 1)) {
        val ex = hx + s * headW * 0.5f
        val (ew, eh) = when (look.ears) {
            1 -> 0.025f to 0.045f
            2 -> 0.045f to 0.075f
            else -> 0.032f to 0.055f
        }
        drawOval(shade(skin, 0.95f), Offset(ex - ew * u / 2f, hy - eh * u / 2f), Size(ew * u, eh * u))
        if (look.ears == 3) {
            val p = Path().apply {
                moveTo(ex, hy - 0.015f * u)
                lineTo(ex + s * 0.055f * u, hy - 0.075f * u)
                lineTo(ex + s * 0.005f * u, hy + 0.01f * u)
                close()
            }
            drawPath(p, shade(skin, 0.95f))
        }
    }
    // The face itself.
    when (look.face) {
        2 -> drawRoundRect(c(skin), Offset(hx - headW / 2f, hy - headH / 2f), Size(headW, headH), CornerRadius(headW * 0.3f))
        4 -> {
            drawOval(c(skin), Offset(hx - headW / 2f, hy - headH / 2f), Size(headW, headH * 0.8f))
            val chin = Path().apply {
                moveTo(hx - headW * 0.45f, hy)
                lineTo(hx + headW * 0.45f, hy)
                lineTo(hx, hy + headH / 2f)
                close()
            }
            drawPath(chin, c(skin))
        }
        else -> drawOval(c(skin), Offset(hx - headW / 2f, hy - headH / 2f), Size(headW, headH))
    }
    // Eyes and brows.
    val eyeY = hy - headH * 0.06f
    val (ew, eh) = when (look.eyes) {
        1 -> 0.036f to 0.012f
        2 -> 0.042f to 0.03f
        3 -> 0.044f to 0.018f
        else -> 0.036f to 0.022f
    }
    for (s in intArrayOf(-1, 1)) {
        val ex = hx + s * headW * 0.21f
        drawOval(Color(0xFFF0EDE6), Offset(ex - ew * u / 2f, eyeY - eh * u / 2f), Size(ew * u, eh * u))
        drawCircle(c(Look.EYE[look.eyeColor]), (eh * u / 2f).coerceAtMost(0.009f * u), Offset(ex, eyeY))
        drawRoundRect(c(hair), Offset(ex - 0.024f * u, eyeY - 0.035f * u), Size(0.048f * u, 0.01f * u), CornerRadius(0.005f * u))
    }
    // Nose.
    val noseTop = eyeY + 0.005f * u
    when (look.nose) {
        1 -> drawCircle(shade(skin, 0.9f), 0.014f * u, Offset(hx, eyeY + 0.045f * u))
        2 -> drawOval(shade(skin, 0.9f), Offset(hx - 0.026f * u, eyeY + 0.03f * u), Size(0.052f * u, 0.032f * u))
        3 -> drawRoundRect(shade(skin, 0.9f), Offset(hx - 0.012f * u, noseTop), Size(0.024f * u, 0.07f * u), CornerRadius(0.012f * u))
        4 -> {
            val p = Path().apply {
                moveTo(hx - 0.008f * u, noseTop)
                lineTo(hx + 0.02f * u, eyeY + 0.055f * u)
                lineTo(hx - 0.016f * u, eyeY + 0.06f * u)
                close()
            }
            drawPath(p, shade(skin, 0.88f))
        }
        else -> drawRoundRect(shade(skin, 0.9f), Offset(hx - 0.014f * u, noseTop), Size(0.028f * u, 0.055f * u), CornerRadius(0.014f * u))
    }
    // Mouth.
    drawRoundRect(Color(0xFF8A4A40), Offset(hx - 0.025f * u, eyeY + 0.085f * u), Size(0.05f * u, 0.008f * u), CornerRadius(0.004f * u))
    // Beard.
    val chinY = hy + headH * 0.5f
    when (look.beard) {
        1 -> {
            drawRoundRect(c(hair), Offset(hx - 0.03f * u, eyeY + 0.07f * u), Size(0.06f * u, 0.012f * u), CornerRadius(0.006f * u))
            drawOval(c(hair), Offset(hx - 0.03f * u, eyeY + 0.098f * u), Size(0.06f * u, chinY - eyeY - 0.08f * u))
        }
        2 -> drawOval(c(hair).copy(alpha = 0.35f), Offset(hx - headW * 0.45f, eyeY + 0.04f * u), Size(headW * 0.9f, chinY - eyeY - 0.03f * u))
        3, 4 -> {
            val extra = if (look.beard == 4) 0.12f * u else 0f
            val p = Path().apply {
                moveTo(hx - headW * 0.48f, eyeY + 0.02f * u)
                lineTo(hx + headW * 0.48f, eyeY + 0.02f * u)
                lineTo(hx + headW * 0.3f, chinY + 0.02f * u)
                lineTo(hx, chinY + 0.04f * u + extra)
                lineTo(hx - headW * 0.3f, chinY + 0.02f * u)
                close()
            }
            drawPath(p, c(hair))
            drawRoundRect(Color(0xFF6A3A30), Offset(hx - 0.022f * u, eyeY + 0.085f * u), Size(0.044f * u, 0.008f * u), CornerRadius(0.004f * u))
        }
        5 -> {
            drawRoundRect(c(hair), Offset(hx - 0.035f * u, eyeY + 0.068f * u), Size(0.07f * u, 0.016f * u), CornerRadius(0.008f * u))
            for (s in intArrayOf(-1, 1)) {
                drawRoundRect(c(hair), Offset(hx + s * 0.03f * u - 0.006f * u, eyeY + 0.07f * u), Size(0.012f * u, 0.04f * u), CornerRadius(0.006f * u))
            }
        }
    }
    // Hair on top.
    val top = hy - headH / 2f
    when (look.hairStyle) {
        1 -> drawArc(c(hair).copy(alpha = 0.45f), 180f, 180f, true, Offset(hx - headW * 0.5f, top), Size(headW, headH * 0.55f))
        3 -> {
            drawArc(c(hair).copy(alpha = 0.4f), 180f, 180f, true, Offset(hx - headW * 0.5f, top), Size(headW, headH * 0.55f))
            drawRoundRect(c(hair), Offset(hx - 0.022f * u, top - 0.07f * u), Size(0.044f * u, 0.13f * u), CornerRadius(0.02f * u))
        }
        else -> {
            drawArc(c(hair), 180f, 180f, true, Offset(hx - headW * 0.54f, top - 0.02f * u), Size(headW * 1.08f, headH * 0.6f))
            drawRoundRect(c(hair), Offset(hx - headW * 0.5f, top + headH * 0.05f), Size(headW, headH * 0.14f), CornerRadius(headW * 0.1f))
        }
    }
    // A soft outline round the whole figure's ground spot.
    drawOval(Color.Black.copy(alpha = 0.25f), Offset(cx - 0.3f * u, ground - 0.03f * u), Size(0.6f * u, 0.06f * u))
    drawCircle(Color.White.copy(alpha = 0.06f), size.minDimension * 0.48f, Offset(cx, size.height * 0.5f), style = Stroke(1f))
}
