package com.keystone.rpg

/** One piece of the buried story, found in a specific chest out in the world. */
class LoreFragment(val id: Int, val title: String, val zone: Zone?, val text: String)

/**
 * The story of PROLONG, told in fragments hidden in chests around each region: three per region, in
 * the order you're meant to find them if you play the regions in order. Together they tell of the
 * Keystone kingdom, the Grain Rot curse, and the family it tore apart. (They hint at the truth; the
 * main story keeps its biggest secrets for the very end.)
 */
object LoreBook {
    val fragments = listOf(
        // ---- Greenhollow ----
        LoreFragment(
            0, "The Keystone Kingdom", Zone.MEADOW,
            "Long ago one kingdom ruled every land you can see, from the green hollows to the frozen " +
                "peaks. Its crown was a single stone, the Keystone, and whoever was its rightful king " +
                "held the lands together. Then the Grain Rot came, and the kingdom forgot itself.",
        ),
        LoreFragment(
            1, "The Prophecy", Zone.MEADOW,
            "An old rhyme still goes round the village hearths, though no one remembers who first " +
                "sang it: one day the last of the Keystone line will walk out of the rot with no name " +
                "and no past, and gather what was lost. The grandmothers say it as a comfort. The " +
                "wizard says it as a warning.",
        ),
        LoreFragment(
            2, "The Wizard's Garden", Zone.MEADOW,
            "Everything in Greenhollow still grows because one old wizard refused to leave it. His " +
                "magic keeps a single circle of green alive while the curse chews at everything past " +
                "it. He never says how much it costs him to hold that circle.",
        ),

        // ---- Whisperwoods ----
        LoreFragment(
            3, "The Poisoned Grain", Zone.FOREST,
            "The curse came in the harvest. Black grain that looked like gold, fruit that tasted of " +
                "honey, trees that wept dark sap. Anyone who ate of it began to forget, first their " +
                "names, then their faces, then why they had ever been afraid.",
        ),
        LoreFragment(
            4, "The Hollow Elder", Zone.FOREST,
            "The thing that guards the deep trees was once the forest's own keeper. The rot hollowed " +
                "it out and left only the habit of guarding. It still mutters the same warning, over " +
                "and over, in a voice that is no longer its own.",
        ),
        LoreFragment(
            5, "Nullfang", Zone.FOREST,
            "Villagers speak of a great beast that walks out of a green-black portal on moonless " +
                "nights. They say he serves something deeper, something that has never shown its face. " +
                "He does not hunt for food. He takes people, and he is always looking for someone in " +
                "particular.",
        ),

        // ---- Frost Peak ----
        LoreFragment(
            6, "The Frozen Highlands", Zone.SNOW,
            "The highlands used to run with rivers and with people. When the rot reached them, a " +
                "tyrant rose from among the frost-trolls and bound the whole region to his will. " +
                "Nothing moves here now that he has not allowed.",
        ),
        LoreFragment(
            7, "Grimtusk's Orders", Zone.SNOW,
            "He is not the master he pretends to be. Soldiers who fled his camp tell of a voice that " +
                "reaches him through the ice, giving orders he repeats as if they were his own. He " +
                "has not made a decision in years.",
        ),
        LoreFragment(
            8, "A Winter Without End", Zone.SNOW,
            "Ask anyone left in Frost Peak the date and you will get a different answer each time. " +
                "The cold has made them forget the count of their days. It is a small mercy, since " +
                "none of the days have been good.",
        ),

        // ---- Sand Dunes ----
        LoreFragment(
            9, "The Burning Dunes", Zone.DESERT,
            "The oasis towns once traded with every corner of the old kingdom. Now the sandstorms " +
                "come without wind, and the creatures that ride them take whatever they can carry. " +
                "The caravans stopped coming long ago.",
        ),
        LoreFragment(
            10, "Khepri's Hunger", Zone.DESERT,
            "They call her the Sun Devourer, and it is no exaggeration. She dims the sky itself so " +
                "that her scarabs can hunt in the day. Like the others, she is only a servant. Her " +
                "master asked for a desert that would never again look to the sun.",
        ),
        LoreFragment(
            11, "The Lost Caves", Zone.DESERT,
            "Old miners tell of caves beneath the dunes where the cursed grain does not grow. People " +
                "vanish into them at the first sign of trouble, and some of them do not come out. " +
                "The caves remember what the surface has forgotten.",
        ),

        // ---- Hollow Deep ----
        LoreFragment(
            12, "The Hollow Deep", Zone.CAVES,
            "Here the kingdom dug down to hide from the rot, and the rot followed. The caves are " +
                "full of people who woke up one morning unable to say how they came to be there. " +
                "Whatever took them did not take their lives, only their memories.",
        ),
        LoreFragment(
            13, "The Keystone Warden", Zone.CAVES,
            "A great hollow titan guards the deepest chamber, and it does not seem to be guarding " +
                "treasure. It guards a door. It also seems, at times, to hesitate, as if some part of " +
                "it is still trying to remember why it fights.",
        ),
        LoreFragment(
            14, "The Grain Rot Key", Zone.CAVES,
            "A heavy iron key, marked with two letters, is hidden somewhere in these tunnels. It " +
                "opens the one true way into the Grain Rot, the black land where the curse began and " +
                "where its master waits. Whoever carries it must be ready for what the master is " +
                "hiding.",
        ),
    )

    /**
     * Josh's own memory fragments, in story order. Each one comes back by itself when its scene plays
     * (see [Story]); the Chronicle lists them, and the chest lore above is kept as the Tales tab.
     */
    val memories = listOf(
        LoreFragment(
            100, "My Name", Zone.MEADOW,
            "My name is Josh. I come from a small village far from Greenhollow. I was sent into the Grain Rot " +
                "portal on purpose, to stop Nullfang, but he threw me back through, and the throw took my memory. " +
                "I still don't know why I was the one sent, or who sent me.",
        ),
        LoreFragment(
            101, "The Night of the Fire", Zone.FOREST,
            "Our house was burning and I ran in, shouting for my mother and father. Through the smoke stood a " +
                "towering figure: Nullfang. He seized my family and vanished with them.",
        ),
        LoreFragment(
            102, "The Sleeping Potion", Zone.FOREST,
            "That same night my father threw himself at Nullfang to stop him. Nullfang flung a sleeping potion over " +
                "both of my parents. They fell. He scooped them up and stepped into the portal.",
        ),
        LoreFragment(
            103, "Roger the Great", Zone.SNOW,
            "I saw the old man in Frost Peak standing against Nullfang, trying to stop him. Nullfang called him " +
                "Roger the Great, and said the two people he was taking were the most important in the world to " +
                "someone, who would never find out who.",
        ),
        LoreFragment(
            104, "Behind the Bars", Zone.SNOW,
            "A cave, dark and cold. Behind thick iron bars, my mother and my father, crying out for me, calling " +
                "for help.",
        ),
        LoreFragment(
            105, "A Secret Plan", Zone.DESERT,
            "I overheard the boss of the Sand Dunes talking with Nullfang. They were planning something for my " +
                "parents, something I wasn't meant to find out, and they agreed to keep it a secret.",
        ),
        LoreFragment(
            106, "Please Don't", Zone.DESERT,
            "A villager at the Oasis Camp heard my mother and father through the portal when it opened, begging " +
                "\"please don't do this to us\", before it closed again.",
        ),
        LoreFragment(
            107, "What He Meant to Do", Zone.CAVES,
            "Nullfang, standing over my mother, about to do something to her. The memory cuts off before it shows " +
                "what.",
        ),
        LoreFragment(
            108, "Home", null,
            "A beautiful city. My mother and father sitting together, laughing, villagers all around in the sun. " +
                "The Grain Rot was my home, my home city, before Vely took it over and turned it into chaos.",
        ),
        LoreFragment(
            109, "Every Memory Restored", null,
            "The three of us held hands and a Keystone rose from the ground between us. We reached out and " +
                "grabbed it together, and a beam of light restored every missing fragment and healed us fully.",
        ),
    )

    /** Chest id -> fragment id, three chests per region (see the wild-chest id ranges in Treasure.kt). */
    val chestFragment: Map<Int, Int> = mapOf(
        0 to 0, 3 to 1, 6 to 2,
        10 to 3, 13 to 4, 16 to 5,
        30 to 6, 33 to 7, 36 to 8,
        20 to 9, 23 to 10, 26 to 11,
        40 to 12, 43 to 13, 46 to 14,
    )

    fun byId(id: Int): LoreFragment? = fragments.getOrNull(id) ?: memories.firstOrNull { it.id == id }
}

/** What each region boss is really about, shown alongside its bestiary entry. */
object SovereignLore {
    /** Boss index (into [BOSSES]) -> what the boss is, in the story. */
    val fear: Map<Int, String> = mapOf(
        0 to "A guardian of the Cradle, grown huge on the rot's moss. Not one of the curse's servants, but it will not let anything change.",
        1 to "Once the forest's keeper, now hollowed out by the Grain Rot. It repeats a warning in a voice that isn't its own.",
        2 to "The Frost Tyrant. Rules the highlands for a master he never names.",
        3 to "The Sun Devourer. Dimmed the desert sky so her scarabs could hunt in daylight, on her master's orders.",
        4 to "Guards the deepest door of the Hollow Deep. Something in it still seems to remember why it fights.",
    )
}
