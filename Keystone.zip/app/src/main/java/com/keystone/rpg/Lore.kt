package com.keystone.rpg

/** One piece of the buried story, found in a specific chest out in the world. */
class LoreFragment(val id: Int, val title: String, val zone: Zone?, val text: String)

/**
 * The story of PROLONG, told in fragments hidden in chests around each region — three per
 * region, in the order you're meant to find them if you play the regions in order. Reading
 * them all in the Chronicle tells the whole tale of the Sovereigns, their fear, and Veyl.
 */
object LoreBook {
    val fragments = listOf(
        // ---- Greenhollow: The Cradle ----
        LoreFragment(
            0, "The Cradle", Zone.MEADOW,
            "You woke here with no name and no past, only a single fragment of a place that " +
                "isn't supposed to exist anywhere in anyone's memory. This is the Cradle — the last " +
                "ground that never broke. Everywhere past it, the world is still falling apart.",
        ),
        LoreFragment(
            1, "The Voice", Zone.MEADOW,
            "Something guided you up out of the dark before you had a name for it. It doesn't " +
                "claim to know who you were. It only says the fragment in your mind is the reason " +
                "you're still whole, and that the four realms beyond here were each broken on " +
                "purpose, by someone who was afraid.",
        ),
        LoreFragment(
            2, "What You Carry", Zone.MEADOW,
            "Every realm out there was sealed by a Sovereign who saw the collapse coming and " +
                "flinched. You carry the one thing they all tried to erase — the memory of the city " +
                "the collapse came from. No mind but yours still holds where it is.",
        ),

        // ---- Whisperwood: Nullwake ----
        LoreFragment(
            3, "What Nullwake Was", Zone.FOREST,
            "Where these trees stand was once the realm most afraid of all — not of losing " +
                "something, but of being someone. Its Sovereign didn't hide from the collapse. He " +
                "erased his own name first, then his memories, then whatever was left underneath.",
        ),
        LoreFragment(
            4, "The Hollow Elder", Zone.FOREST,
            "The thing you'll find guarding the deep trees isn't quite alive and isn't quite a " +
                "memory either — a shape left behind after its Sovereign went further than erasing a " +
                "name. It repeats the same warning, over and over, in a voice that isn't its own.",
        ),
        LoreFragment(
            5, "Veyl", Zone.FOREST,
            "That's the name the Elder keeps almost saying. Veyl was Nullwake's ruler, once. Now " +
                "he's something that used to be a person, hunting for the banned city so he can end " +
                "it — and every mind that still remembers it — for good. He believes that's mercy.",
        ),

        // ---- Frostpeak: Frostspire ----
        LoreFragment(
            6, "What Frostspire Was", Zone.SNOW,
            "This whole highland used to move — seasons, rivers, people growing older. Its " +
                "Sovereign froze it all in a single moment rather than watch anyone he loved leave it. " +
                "Nothing here has changed since. Nothing here is allowed to.",
        ),
        LoreFragment(
            7, "Grimtusk, Before", Zone.SNOW,
            "He wasn't always the Frost Tyrant. Before the collapse he was called a protector — " +
                "the one who kept this highland's people safe through worse winters than this. Fear " +
                "of losing them a final time is what turned protecting into trapping.",
        ),
        LoreFragment(
            8, "A Moment Forever", Zone.SNOW,
            "Ask anyone frozen here what year it is and they'll all give the same answer, word " +
                "for word, because none of them have lived a single day since. Grimtusk calls it " +
                "safety. It's the only kind of loss he never learned how to grieve.",
        ),

        // ---- Sunscar: Ashreach ----
        LoreFragment(
            9, "What Ashreach Was", Zone.DESERT,
            "Every record this land ever kept — every book, ledger, carved name — was burned on " +
                "the same night. Its Sovereign wasn't hiding from the collapse. She was hiding from " +
                "what the collapse would prove she'd known and ignored.",
        ),
        LoreFragment(
            10, "Khepri's Hunger", Zone.DESERT,
            "They call her the Sun Devourer because she didn't stop at paper. She reached for the " +
                "sky's own memory of this land — the light itself — so that even the shape of what " +
                "used to stand here would stop being provable.",
        ),
        LoreFragment(
            11, "A People Without Why", Zone.DESERT,
            "Ask anyone in these dunes why they're afraid and they'll tell you only that they " +
                "must never look back. Nobody left alive remembers what's behind them. That was " +
                "always the plan.",
        ),

        // ---- Hollow Deep: Gravehold ----
        LoreFragment(
            12, "What Gravehold Was", Zone.CAVES,
            "The deepest realm didn't burn or freeze. It dug. Its Sovereign buried every city " +
                "under this stone rather than stand above ground and answer for what his choices had " +
                "done. Burial was easier than a trial no one was left to hold.",
        ),
        LoreFragment(
            13, "The Keystone Warden", Zone.CAVES,
            "What guards the deepest chamber isn't guarding treasure. It's guarding a door — the " +
                "one door in all five realms that leads somewhere lower than Gravehold's own grief. " +
                "It won't step aside for anyone who hasn't earned the right to remember.",
        ),
        LoreFragment(
            14, "The Banned City", Zone.CAVES,
            "Beneath all of it — beneath the buried cities, beneath the Warden's door — is the " +
                "place no mind but yours still holds the shape of. Veyl is already there, waiting for " +
                "whoever restores enough memory to open the way down to him.",
        ),
    )

    /** Chest id -> fragment id, three chests per region (see the wild-chest id ranges in Treasure.kt). */
    val chestFragment: Map<Int, Int> = mapOf(
        0 to 0, 3 to 1, 6 to 2,
        10 to 3, 13 to 4, 16 to 5,
        30 to 6, 33 to 7, 36 to 8,
        20 to 9, 23 to 10, 26 to 11,
        40 to 12, 43 to 13, 46 to 14,
    )

    fun byId(id: Int): LoreFragment? = fragments.getOrNull(id)
}

/** What a Sovereign's boss fight is really about, shown alongside its bestiary entry. */
object SovereignLore {
    /** Boss index (into [BOSSES]) -> which fear its realm was built on. */
    val fear: Map<Int, String> = mapOf(
        0 to "Guardian of the Cradle, not one of the four Sovereigns — but no less determined to keep things from changing.",
        1 to "Sovereign of Nullwake. Fear of losing itself — erased into something that isn't quite anyone anymore.",
        2 to "Sovereign of Frostspire. Fear of loss — froze his whole highland in the last moment before anyone could leave it.",
        3 to "Sovereign of Ashreach. Fear of truth — burned every record of what her choices cost.",
        4 to "Guardian of Gravehold's deepest door. Fear of responsibility — buried the truth rather than answer for it.",
    )
}
