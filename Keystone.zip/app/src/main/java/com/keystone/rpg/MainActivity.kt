package com.keystone.rpg

import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** The 3D view, kept here so the activity can pause and resume it. */
private object GlHolder {
    var view: GLSurfaceView? = null
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent { KeystoneApp() }
    }

    override fun onPause() {
        super.onPause()
        GlHolder.view?.onPause()
    }

    override fun onResume() {
        super.onResume()
        GlHolder.view?.onResume()
    }
}

@Composable
fun KeystoneApp() {
    var playing by remember { mutableStateOf(false) }
    var game by remember { mutableStateOf<Game?>(null) }
    // Building the world takes a few seconds, so do it behind the title screen.
    LaunchedEffect(Unit) {
        game = withContext(Dispatchers.Default) { Game(World()) }
    }
    val ready = game
    if (playing && ready != null) {
        GameScreen(ready)
    } else {
        TitleScreen(ready = ready != null, onStart = { playing = true })
    }
}

@Composable
fun TitleScreen(ready: Boolean, onStart: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E3B2F), Color(0xFF0F1D17))))
            .safeDrawingPadding()
            .padding(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🗝️", fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text("Keystone", color = Palette.gold, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Explore the wilds. Find the keys.\nOpen up the world.",
                color = Color(0xFFCFE3D6),
                fontSize = 17.sp,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp,
            )
            Spacer(Modifier.height(44.dp))
            Button(
                onClick = onStart,
                enabled = ready,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Palette.gold,
                    contentColor = Color(0xFF1E2A22),
                    disabledContainerColor = Palette.gold.copy(alpha = 0.35f),
                    disabledContentColor = Color(0xFF1E2A22),
                ),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
            ) {
                Text(
                    if (ready) "Start adventure" else "Building the world…",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.height(14.dp))
            Text("Early build: explore the world", color = Color(0xFF8FA99A), fontSize = 13.sp)
        }
    }
}

@Composable
fun GameScreen(game: Game) {
    var stickOrigin by remember { mutableStateOf<Offset?>(null) }
    var stickKnob by remember { mutableStateOf(Offset.Zero) }
    var hasMoved by remember { mutableStateOf(false) }
    var hasLooked by remember { mutableStateOf(false) }
    val density = LocalDensity.current.density

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            GlHolder.view = null
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.night)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    preserveEGLContextOnPause = true
                    setRenderer(WorldRenderer(game))
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    GlHolder.view = this
                }
            },
        )

        // Touch layer: left half of the screen walks, right half looks around.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(game) {
                    val maxR = 56.dp.toPx()
                    val lookScale = 0.012f / density
                    awaitPointerEventScope {
                        var moveId: PointerId? = null
                        var lookId: PointerId? = null
                        var origin = Offset.Zero
                        var lastLook = Offset.Zero
                        while (true) {
                            val event = awaitPointerEvent()
                            for (change in event.changes) {
                                val pos = change.position
                                if (change.pressed && !change.previousPressed) {
                                    if (pos.x < size.width / 2f && moveId == null) {
                                        moveId = change.id
                                        origin = pos
                                        stickOrigin = pos
                                        stickKnob = pos
                                    } else if (lookId == null) {
                                        lookId = change.id
                                        lastLook = pos
                                    }
                                } else if (change.pressed) {
                                    if (change.id == moveId) {
                                        var d = pos - origin
                                        var len = d.getDistance()
                                        if (len > maxR) {
                                            origin = pos - d * (maxR / len)
                                            d = pos - origin
                                            len = maxR
                                            stickOrigin = origin
                                        }
                                        stickKnob = pos
                                        if (len > maxR * 0.12f) {
                                            game.moveX = d.x / maxR
                                            game.moveY = d.y / maxR
                                            hasMoved = true
                                        } else {
                                            game.moveX = 0f
                                            game.moveY = 0f
                                        }
                                    } else if (change.id == lookId) {
                                        val d = pos - lastLook
                                        lastLook = pos
                                        game.addLook(d.x * lookScale, d.y * lookScale)
                                        if (d.getDistance() > 2f) hasLooked = true
                                    }
                                } else if (!change.pressed && change.previousPressed) {
                                    if (change.id == moveId) {
                                        moveId = null
                                        stickOrigin = null
                                        game.moveX = 0f
                                        game.moveY = 0f
                                    }
                                    if (change.id == lookId) lookId = null
                                }
                                change.consume()
                            }
                        }
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                stickOrigin?.let { o ->
                    val r = 56.dp.toPx()
                    drawCircle(color = Color.White.copy(alpha = 0.12f), radius = r, center = o)
                    drawCircle(
                        color = Color.White.copy(alpha = 0.35f),
                        radius = r,
                        center = o,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                    drawCircle(color = Color.White.copy(alpha = 0.6f), radius = 24.dp.toPx(), center = stickKnob)
                }
            }
        }

        ZoneEffects(game)

        Minimap(
            game,
            Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(12.dp),
        )

        ZoneBanner(game)

        if (!hasMoved || !hasLooked) {
            Text(
                "Left thumb: walk     Right thumb: look",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 72.dp)
                    .background(Color(0xAA15131C), RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}

/** Falling snow in Frostpeak. */
@Composable
fun ZoneEffects(game: Game) {
    if (game.zone != Zone.SNOW) return
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) t += (now - last) / 1_000_000_000f
                last = now
            }
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val s = 40.dp.toPx()
        for (i in 0 until 70) {
            val fall = s * (0.8f + hash(i, 3, 7) * 1.4f)
            val fx = hash(i, 1, 7) * w + kotlin.math.sin(t * 0.8f + i) * s * 0.4f
            val fy = (hash(i, 2, 7) * h + t * fall) % h
            drawCircle(
                color = Color.White.copy(alpha = 0.8f),
                radius = s * (0.03f + hash(i, 4, 7) * 0.05f),
                center = Offset(fx, fy),
            )
        }
    }
}

/** A map of the area around you, filling in as you explore. North is up. */
@Composable
fun Minimap(game: Game, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    val arrow = remember { Path() }
    Canvas(
        modifier
            .size(116.dp)
            .clip(shape)
            .background(Palette.night)
            .border(2.dp, Palette.gold.copy(alpha = 0.7f), shape),
    ) {
        if (game.hudTick < 0L) return@Canvas
        val window = 110 // cells shown across, about 660 m
        val ci = (game.x / CELL).toInt()
        val cj = (game.z / CELL).toInt()
        val sx = (ci - window / 2).coerceIn(0, GRID - window)
        val sz = (cj - window / 2).coerceIn(0, GRID - window)
        drawImage(
            image = game.minimapImage,
            srcOffset = IntOffset(sx, sz),
            srcSize = IntSize(window, window),
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.Low,
        )
        val scale = size.width / window
        val px = (game.x / CELL - sx) * scale
        val pz = (game.z / CELL - sz) * scale
        val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
        rotate(degrees = deg, pivot = Offset(px, pz)) {
            val a = 7.dp.toPx()
            arrow.reset()
            arrow.moveTo(px, pz - a)
            arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
            arrow.lineTo(px, pz + a * 0.3f)
            arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
            arrow.close()
            drawPath(arrow, color = Color.White)
            drawPath(arrow, color = Palette.night, style = Stroke(width = 1.dp.toPx()))
        }
    }
}

@Composable
fun BoxScope.ZoneBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val zone = game.zone
    LaunchedEffect(game.zoneVisit) {
        visible = true
        delay(2800)
        visible = false
    }
    val bannerAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(500),
        label = "zoneBanner",
    )
    if (bannerAlpha > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 140.dp)
                .graphicsLayer { alpha = bannerAlpha }
                .background(Color(0xCC15131C), RoundedCornerShape(16.dp))
                .padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(zone.title, color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(zone.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
        }
    }
}
