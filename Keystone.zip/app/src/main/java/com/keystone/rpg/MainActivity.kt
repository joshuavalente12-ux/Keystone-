package com.keystone.rpg

import android.content.Context
import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Image
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** The 3D view, kept here so the activity can pause and resume it. */
private object GlHolder {
    var view: GLSurfaceView? = null
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        // Signs in to Google Play Games by itself; falls back to guest if that isn't possible.
        CloudSave.start(this)
        setContent { KeystoneApp() }
    }

    override fun onStop() {
        super.onStop()
        // Copy the save to the cloud when you leave the game (does nothing as a guest).
        CloudSave.upload(this)
    }

    override fun onPause() {
        super.onPause()
        GlHolder.view?.onPause()
        Sound.stop()
    }

    override fun onResume() {
        super.onResume()
        GlHolder.view?.onResume()
        if (Sound.wanted) Sound.start()
    }
}

@Composable
fun KeystoneApp() {
    // 0 = title, 1 = choosing a weapon, 2 = playing, 3 = making your hero (before the weapon),
    // 4 = the opening cinematic (a new game only, before choosing a class).
    var stage by remember { mutableIntStateOf(0) }
    var game by remember { mutableStateOf<Game?>(null) }
    // Building the world takes a few seconds, so do it behind the title screen.
    LaunchedEffect(Unit) {
        game = withContext(Dispatchers.Default) { Game(World()) }
    }
    val ready = game
    val appCtx = LocalContext.current
    // Once you've picked a weapon there is a save to Play. New Game wipes it, and pulling
    // down a cloud save can bring one back, so this is worked out again when that happens.
    var hasSave by remember(CloudSave.restoredTick) {
        mutableStateOf(
            !appCtx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("weapon", "").isNullOrEmpty(),
        )
    }
    val savedHardcore = appCtx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getBoolean("hardcore", false)
    if (stage == 4 && ready != null) {
        IntroScreen(ready, onDone = { stage = 1 })
    } else if (stage == 2 && ready != null) {
        GameScreen(ready, onExit = { stage = 0 })
    } else if (stage == 3 && ready != null) {
        // Your class is already chosen by now, so your look starts out built like one of its kind.
        CharacterScreen(heroClass = ready.heroClassPending, onDone = { stage = 2 })
    } else if (stage == 1 && ready != null) {
        ClassSelectScreen(onBegin = { chosen ->
            val def = HERO_CLASSES[chosen]
            ready.weaponClass = def.startKind
            ready.heroClassPending = chosen
            ready.startWeaponName = def.startName
            stage = 3
        })
    } else {
        TitleScreen(
            ready = ready != null,
            hasSave = hasSave,
            savedHardcore = savedHardcore,
            onPlay = {
                CloudSave.locked = true
                stage = if (hasSave) 2 else 4
            },
            onNewGame = { hardcore ->
                CloudSave.locked = true
                appCtx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().clear()
                    .putBoolean("hardcore", hardcore).commit()
                hasSave = false
                stage = 4
            },
        )
    }
}

@Composable
fun TitleScreen(ready: Boolean, hasSave: Boolean, savedHardcore: Boolean, onPlay: () -> Unit, onNewGame: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val activity = remember { ctx.keystoneActivity() }
    // 0 = nothing, 1 = "start over?", 2 = "replace with cloud save?"
    var confirm by remember { mutableIntStateOf(0) }
    // Hardcore: 0 = not asked, 1 = what it means, 2 = are you sure, 3 = really sure, 4 = last chance.
    var hardcoreStep by remember { mutableIntStateOf(0) }
    var settingsOpen by remember { mutableStateOf(false) }
    val cloudOn = CloudSave.state == CloudSave.SIGNED_IN && !CloudSave.working
    val goldButton = ButtonDefaults.buttonColors(
        containerColor = Palette.gold,
        contentColor = Color(0xFF1E2A22),
        disabledContainerColor = Palette.gold.copy(alpha = 0.35f),
        disabledContentColor = Color(0xFF1E2A22),
    )
    val darkButton = ButtonDefaults.buttonColors(
        containerColor = Color(0xCC101A15),
        contentColor = Palette.gold,
        disabledContainerColor = Color(0x66101A15),
        disabledContentColor = Palette.gold.copy(alpha = 0.4f),
    )
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF050A08))) {
        Canvas(Modifier.fillMaxSize()) { drawTitleScene() }
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .safeDrawingPadding()
                .padding(end = 30.dp)
                .width(300.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "KEYSTONE",
                color = Palette.gold,
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 6.sp,
            )
            Text(
                "Explore the wilds. Find the keys.",
                color = Color(0xFFCFE3D6),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            // Who is signed in. A guest can tap here to try signing in again.
            Text(
                CloudSave.statusText(),
                color = if (CloudSave.state == CloudSave.SIGNED_IN) Color(0xFF9CFF9C) else Color(0xFF8FA99A),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.pointerInput(Unit) {
                    detectTapGestures { activity?.let { CloudSave.signIn(it) } }
                },
            )
            Spacer(Modifier.height(10.dp))
            if (confirm != 0) {
                Text(
                    if (confirm == 1) {
                        if (CloudSave.state == CloudSave.SIGNED_IN) {
                            "Start over? This erases your saved adventure, and your cloud save is replaced the next time you save."
                        } else {
                            "Start over? This erases your saved adventure."
                        }
                    } else {
                        "Replace the adventure on this phone with your cloud save?"
                    },
                    color = Color.White,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val was = confirm
                        confirm = 0
                        if (was == 1) {
                            onNewGame(false)
                        } else {
                            CloudSave.locked = false
                            activity?.let { CloudSave.download(it) }
                        }
                    },
                    colors = goldButton,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                ) {
                    Text(if (confirm == 1) "Yes, erase it" else "Yes, load it", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { confirm = 0 },
                    colors = darkButton,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                ) {
                    Text("Cancel", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = onPlay,
                    enabled = ready,
                    colors = goldButton,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                ) {
                    Text(
                        if (!ready) "Building the world\u2026" else if (savedHardcore) "\u2620\uFE0F Play Hardcore" else "Play",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { if (hasSave) confirm = 1 else onNewGame(false) },
                        enabled = ready,
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("New Game", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { settingsOpen = true },
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Settings", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { activity?.let { CloudSave.upload(it, force = true) } },
                        enabled = cloudOn && hasSave,
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Save", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (hasSave) {
                                confirm = 2
                            } else {
                                CloudSave.locked = false
                                activity?.let { CloudSave.download(it) }
                            }
                        },
                        enabled = cloudOn,
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Load", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { hardcoreStep = 1 },
                    enabled = ready,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xCC5A0E14),
                        contentColor = Color(0xFFFF8A80),
                        disabledContainerColor = Color(0x665A0E14),
                        disabledContentColor = Color(0x88FF8A80),
                    ),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp).border(1.dp, Color(0xFFFF3B5C).copy(alpha = 0.6f), RoundedCornerShape(28.dp)),
                ) {
                    Text("\u2620\uFE0F  New Hardcore Game", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (CloudSave.note.isNotEmpty()) {
                        CloudSave.note
                    } else if (CloudSave.state == CloudSave.SIGNED_IN) {
                        "Save and Load use your Google cloud save."
                    } else {
                        "Save and Load need Google Play Games sign-in."
                    },
                    color = Color(0xFFB9CFC2),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                )
            }
        }
        // The hardcore warnings cover the whole screen, so the buttons are always in view.
        if (hardcoreStep != 0) {
            HardcoreAsk(
                step = hardcoreStep,
                hasSave = hasSave,
                onYes = {
                    if (hardcoreStep >= 4) {
                        hardcoreStep = 0
                        onNewGame(true)
                    } else {
                        hardcoreStep++
                    }
                },
                onNo = { hardcoreStep = 0 },
            )
        }
        if (settingsOpen) {
            SettingsPanel(
                autoFight = false,
                onAutoFight = {},
                onClose = { settingsOpen = false },
                onEditHud = {},
                inGame = false,
            )
        }
    }
}

@Composable
fun GameScreen(game: Game, onExit: () -> Unit = {}) {
    var stickOrigin by remember { mutableStateOf<Offset?>(null) }
    var stickKnob by remember { mutableStateOf(Offset.Zero) }
    var hasMoved by remember { mutableStateOf(false) }
    var hasLooked by remember { mutableStateOf(false) }
    var runOn by remember { mutableStateOf(false) }
    var mapOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var todoOpen by remember { mutableStateOf(false) }
    var todoShownStep by remember { mutableIntStateOf(-1) }
    var bagOpen by remember { mutableStateOf(false) }
    var questLogOpen by remember { mutableStateOf(false) }
    var bookOpen by remember { mutableStateOf(false) }
    var gridOpen by remember { mutableStateOf(false) }
    var craftOpen by remember { mutableStateOf(false) }
    var editingHud by remember { mutableStateOf(false) }
    val context0 = LocalContext.current
    val hudLayout = remember { HudLayout.load(context0) }
    var thirdPerson by remember {
        mutableStateOf(
            context0.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("third", true),
        )
    }
    game.thirdPerson = thirdPerson
    var autoFight by remember {
        mutableStateOf(
            context0.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("auto_fight", false),
        )
    }
    game.autoFight = autoFight
    val density = LocalDensity.current.density
    val context = LocalContext.current
    val openMap = {
        game.moveX = 0f
        game.moveY = 0f
        stickOrigin = null
        mapOpen = true
    }

    // While signed in to Google Play Games, copy the save to the cloud every few minutes.
    LaunchedEffect(Unit) {
        while (true) {
            delay(180_000L)
            context.keystoneActivity()?.let { CloudSave.upload(it) }
        }
    }

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        Sound.load(context)
        game.loadSave(context)
        Sound.wanted = true
        Sound.start()
        onDispose {
            Sound.wanted = false
            Sound.stop()
            view.keepScreenOn = false
            GlHolder.view = null
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.night)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setEGLConfigChooser(DepthConfigChooser())
                    preserveEGLContextOnPause = true
                    setRenderer(WorldRenderer(game))
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    GlHolder.view = this
                }
            },
        )

        // Touch layer: left half of the screen walks, right half looks around.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(game) {
                    val maxR = 56.dp.toPx()
                    val lookScale = 0.012f / density
                    awaitPointerEventScope {
                        var moveId: PointerId? = null
                        var lookId: PointerId? = null
                        var origin = Offset.Zero
                        var lastLook = Offset.Zero
                        while (true) {
                            val event = awaitPointerEvent()
                            for (change in event.changes) {
                                val pos = change.position
                                if (change.pressed && !change.previousPressed) {
                                    if (pos.x < size.width / 2f && moveId == null) {
                                        moveId = change.id
                                        origin = pos
                                        stickOrigin = pos
                                        stickKnob = pos
                                    } else if (lookId == null) {
                                        lookId = change.id
                                        lastLook = pos
                                    }
                                } else if (change.pressed) {
                                    if (change.id == moveId) {
                                        var d = pos - origin
                                        var len = d.getDistance()
                                        if (len > maxR) {
                                            origin = pos - d * (maxR / len)
                                            d = pos - origin
                                            len = maxR
                                            stickOrigin = origin
                                        }
                                        stickKnob = pos
                                        if (len > maxR * 0.12f) {
                                            game.moveX = d.x / maxR
                                            game.moveY = d.y / maxR
                                            hasMoved = true
                                        } else {
                                            game.moveX = 0f
                                            game.moveY = 0f
                                        }
                                    } else if (change.id == lookId) {
                                        val d = pos - lastLook
                                        lastLook = pos
                                        game.addLook(d.x * lookScale, d.y * lookScale)
                                        if (d.getDistance() > 2f) hasLooked = true
                                    }
                                } else if (!change.pressed && change.previousPressed) {
                                    if (change.id == moveId) {
                                        moveId = null
                                        stickOrigin = null
                                        game.moveX = 0f
                                        game.moveY = 0f
                                    }
                                    if (change.id == lookId) lookId = null
                                }
                                change.consume()
                            }
                        }
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                stickOrigin?.let { o ->
                    val r = 56.dp.toPx()
                    drawCircle(color = Color.White.copy(alpha = 0.12f), radius = r, center = o)
                    drawCircle(
                        color = Color.White.copy(alpha = 0.35f),
                        radius = r,
                        center = o,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                    drawCircle(color = Color.White.copy(alpha = 0.6f), radius = 24.dp.toPx(), center = stickKnob)
                }
            }
        }

        // Soft darkening towards the screen edges, like a camera lens.
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    0.6f to Color.Transparent,
                    1f to Color(0x55000000),
                    center = center,
                    radius = size.maxDimension * 0.62f,
                ),
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Minimap(game, Modifier.pointerInput(Unit) { detectTapGestures { openMap() } })
            Spacer(Modifier.height(4.dp))
            GridRef(game)
            Spacer(Modifier.height(6.dp))
            HudDraggable("map", editingHud, hudLayout) {
                HudButton("MAP", active = false, size = 52.dp) { if (!editingHud) openMap() }
            }
        }

        // Settings gear and the camera switch live in the top-left corner, clear of the action buttons.
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudDraggable("gear", editingHud, hudLayout) {
                HudButton("\u2699", active = false, size = 44.dp, fontSize = 22.sp) {
                    if (!editingHud) {
                        game.moveX = 0f
                        game.moveY = 0f
                        stickOrigin = null
                        settingsOpen = true
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            // Equipment: your bag and what you're wearing.
            HudDraggable("bag", editingHud, hudLayout) {
                HudButton("\uD83C\uDF92", active = false, size = 44.dp, fontSize = 20.sp) {
                    if (!editingHud) {
                        game.moveX = 0f
                        game.moveY = 0f
                        stickOrigin = null
                        bagOpen = true
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            HudDraggable("quests", editingHud, hudLayout) {
                Box {
                    HudButton("\uD83D\uDCDC", active = false, size = 44.dp, fontSize = 20.sp) {
                        if (!editingHud) {
                            game.moveX = 0f
                            game.moveY = 0f
                            stickOrigin = null
                            questLogOpen = true
                        }
                    }
                    if (game.quests.current().any { it.state == QState.READY }) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Palette.gold)
                                .border(1.dp, Color.White, CircleShape),
                        )
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            HudDraggable("book", editingHud, hudLayout) {
                HudButton("\uD83D\uDCD6", active = false, size = 44.dp, fontSize = 20.sp) {
                    if (!editingHud) {
                        game.moveX = 0f
                        game.moveY = 0f
                        stickOrigin = null
                        bookOpen = true
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            // The Sphere Grid: spend the point you earn every level.
            HudDraggable("grid", editingHud, hudLayout) {
                Box {
                    HudButton("\u2726", active = false, size = 44.dp, fontSize = 20.sp) {
                        if (!editingHud) {
                            game.moveX = 0f
                            game.moveY = 0f
                            stickOrigin = null
                            gridOpen = true
                        }
                    }
                    if (game.loot.version >= 0 && game.loot.gridPoints > 0) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Palette.gold)
                                .border(1.dp, Color.White, CircleShape),
                        )
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            HudDraggable("view", editingHud, hudLayout) {
                HudButton("VIEW", active = !thirdPerson, size = 44.dp, fontSize = 11.sp) {
                    if (!editingHud) {
                        thirdPerson = !thirdPerson
                        game.thirdPerson = thirdPerson
                        context.getSharedPreferences("keystone_view", Context.MODE_PRIVATE)
                            .edit().putBoolean("third", thirdPerson).apply()
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            // Build mode: snap walls, floors and roofs together anywhere in the world.
            HudDraggable("build", editingHud, hudLayout) {
                HudButton("\uD83D\uDD28", active = game.buildMode, size = 44.dp, fontSize = 20.sp) {
                    if (!editingHud) game.buildMode = !game.buildMode
                }
            }
        }
        ResourceChip(game)
        WorldBossChip(game)
        RaidWarnChip(game)
        HardcoreBadge(game)

        HurtFlash(game)
        ZoneBanner(game)
        DiscoveryBanner(game)
        TargetPanel(game)

        // Health, experience and stamina, centred along the top of the screen.
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = hudBarsTop()),
        ) {
            HudDraggable("bars", editingHud, hudLayout) {
                PlayerBars(game)
            }
        }
        // Quick slots along the bottom: potions and gear, one tap away. The piece bar replaces them while building.
        if (!game.buildMode) Box(
            Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .padding(bottom = 10.dp),
        ) {
            HudDraggable("quick", editingHud, hudLayout) {
                QuickBar(game, editingHud) {
                    game.moveX = 0f
                    game.moveY = 0f
                    stickOrigin = null
                    bagOpen = true
                }
            }
        }
        LevelUpBanner(game)

        // Action buttons under the right thumb.
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .safeDrawingPadding()
                .padding(end = 24.dp, bottom = 22.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Attack with your weapon. The button shows the weapon you chose.
                HudDraggable("attack", editingHud, hudLayout) {
                    WeaponButton(
                        icon = when (game.weaponClass) {
                            WeaponClass.KUNAI -> R.drawable.icon_kunai
                            WeaponClass.HALBERD -> R.drawable.icon_halberd
                            WeaponClass.AXE -> R.drawable.icon_axe
                            WeaponClass.BOW -> R.drawable.icon_bow
                            WeaponClass.STAFF -> R.drawable.icon_staff
                            WeaponClass.WAND -> R.drawable.icon_wand
                            else -> R.drawable.icon_sword
                        },
                        size = 64.dp,
                    ) { if (!editingHud) game.attack() }
                }
                // A bow shows what's left in the quiver, turning red when it's running low.
                if (game.weaponClass == WeaponClass.BOW && game.hudTick >= 0L) {
                    val left = game.loot.arrows
                    Text(
                        "\uD83C\uDFF9 $left",
                        color = when {
                            left == 0 -> Color(0xFFFF5A4E)
                            left <= 15 -> Color(0xFFFFB04A)
                            else -> Color.White
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .padding(top = 3.dp)
                            .background(Color(0x88000000), RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                }
                Spacer(Modifier.height(12.dp))
                HudDraggable("dodge", editingHud, hudLayout) {
                    HudButton("DODGE", active = game.dodgeReady, size = 62.dp, fontSize = 12.sp) {
                        if (!editingHud) game.dodge()
                    }
                }
                Spacer(Modifier.height(12.dp))
                HudDraggable("run", editingHud, hudLayout) {
                    HudButton("RUN", active = runOn, size = 70.dp) {
                        if (!editingHud) {
                            runOn = !runOn
                            game.runOn = runOn
                        }
                    }
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                HudDraggable("lock", editingHud, hudLayout) {
                    HudButton("LOCK", active = game.locked, size = 62.dp, fontSize = 12.sp) {
                        if (!editingHud) game.toggleLock()
                    }
                }
                Spacer(Modifier.height(12.dp))
                HudDraggable("jump", editingHud, hudLayout) {
                    Box(Modifier.padding(bottom = 46.dp)) {
                        HudButton("JUMP", active = false, size = 82.dp) { if (!editingHud) game.jump() }
                    }
                }
            }
        }

        if (!hasMoved || !hasLooked) {
            Text(
                "Left thumb: walk     Right thumb: look",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 74.dp)
                    .background(Color(0xAA15131C), RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }

        if (game.buildMode) BuildHud(game)
        ResToast(game)
        ActionButton(game)
        LootPopup(game)
        BossBanner(game)
        SealBanner(game)
        DefeatOverlay(game)
        CaveFade(game)
        SearchWindow(game)
        QuestToast(game)
        ObjectiveChip(game)
        TalkWindow(game)
        TradeWindow(game)
        StoryWindow(game)
        EndingOverlay(game, onExit)

        if (mapOpen) {
            WorldMap(game, onClose = { mapOpen = false })
        }
        if (bagOpen) {
            EquipmentPanel(game, onClose = { bagOpen = false })
        }
        if (questLogOpen) {
            QuestLogPanel(game, onClose = { questLogOpen = false })
        }
        if (bookOpen) {
            BookPanel(game, onClose = { bookOpen = false })
        }
        if (gridOpen) {
            GridPanel(game, onClose = { gridOpen = false })
        }
        // Using a crafting bench opens its window.
        val craftVisit = game.craftVisit
        LaunchedEffect(craftVisit) {
            if (craftVisit > 0) {
                game.moveX = 0f
                game.moveY = 0f
                stickOrigin = null
                craftOpen = true
            }
        }
        if (craftOpen) {
            CraftPanel(game, onClose = { craftOpen = false })
        }
        // A chest or fridge you've opened.
        val storeVisit = game.storeVisit
        LaunchedEffect(storeVisit) {
            if (game.storeOpen != null) {
                game.moveX = 0f
                game.moveY = 0f
                stickOrigin = null
            }
        }
        if (storeVisit >= 0 && game.storeOpen != null) {
            StoragePanel(game, onClose = { game.closeStore() })
        }
        SleepFade(game)
        if (settingsOpen) {
            SettingsPanel(
                autoFight = autoFight,
                onAutoFight = {
                    autoFight = it
                    game.autoFight = it
                    context.getSharedPreferences("keystone_view", Context.MODE_PRIVATE)
                        .edit().putBoolean("auto_fight", it).apply()
                },
                onClose = { settingsOpen = false },
                onEditHud = {
                    settingsOpen = false
                    editingHud = true
                },
                onWhatToDo = {
                    settingsOpen = false
                    todoOpen = true
                },
            )
        }
        // A new goal: say what it is, once.
        val todoVersion = game.story.version
        LaunchedEffect(todoVersion) {
            val st = game.story.step
            if (st != todoShownStep && !game.story.active && game.story.objective.isNotEmpty()) {
                todoShownStep = st
                todoOpen = true
            }
        }
        if (todoOpen && !game.story.active) WhatToDoPanel(game) { todoOpen = false }
        if (editingHud) {
            HudEditBanner(
                onReset = { HudLayout.reset(context, hudLayout) },
                onDone = { editingHud = false },
            )
        }
    }
}

/** Shown while rearranging the HUD: explains what's happening and lets you finish or reset. */
@Composable
fun HudEditBanner(onReset: () -> Unit, onDone: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(top = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            modifier = Modifier
                .background(Color(0xEE1E1B26), RoundedCornerShape(16.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Drag any button to move it", color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.width(14.dp))
            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3644), contentColor = Color.White),
            ) {
                Text("Reset", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onDone,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
            ) {
                Text("Done", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

/** Settings: how loud each kind of sound is. Remembered between games. */
@Composable
fun SettingsPanel(
    autoFight: Boolean,
    onAutoFight: (Boolean) -> Unit,
    onClose: () -> Unit,
    onEditHud: () -> Unit,
    inGame: Boolean = true,
    onWhatToDo: () -> Unit = {},
) {
    val ctx = LocalContext.current
    // The title screen opens this too, before the sound engine has read what you chose last time.
    LaunchedEffect(Unit) { if (!inGame) Sound.load(ctx) }
    var steps by remember { mutableFloatStateOf(Sound.volSteps) }
    var wind by remember { mutableFloatStateOf(Sound.volWind) }
    var rain by remember { mutableFloatStateOf(Sound.volRain) }
    var animals by remember { mutableFloatStateOf(Sound.volAnimals) }
    var music by remember { mutableFloatStateOf(Sound.volMusic) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAA000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .width(420.dp)
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 14.dp),
        ) {
            Text("Settings", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Sound", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            VolumeRow("Music", music) {
                music = it
                Sound.setMusicVolume(it)
                Sound.save(ctx)
            }
            VolumeRow("Footsteps", steps) {
                steps = it
                Sound.volSteps = it
                Sound.save(ctx)
            }
            VolumeRow("Wind", wind) {
                wind = it
                Sound.volWind = it
                Sound.save(ctx)
            }
            VolumeRow("Rain & thunder", rain) {
                rain = it
                Sound.volRain = it
                Sound.save(ctx)
            }
            VolumeRow("Animals", animals) {
                animals = it
                Sound.volAnimals = it
                Sound.save(ctx)
            }
            if (inGame) {
            Spacer(Modifier.height(8.dp))
            Text("Combat", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Auto fight", color = Color.White, fontSize = 15.sp)
                    Text(
                        "Attacks anything that comes close, by itself",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp,
                    )
                }
                Button(
                    onClick = { onAutoFight(!autoFight) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (autoFight) Palette.gold else Color(0xFF3A3644),
                        contentColor = if (autoFight) Color(0xFF1E2A22) else Color.White,
                    ),
                ) {
                    Text(if (autoFight) "ON" else "OFF", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Help", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("What to do", color = Color.White, fontSize = 15.sp)
                    Text(
                        "Your goal right now, and a few tips",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp,
                    )
                }
                Button(
                    onClick = onWhatToDo,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3644), contentColor = Color.White),
                ) {
                    Text("Show", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Buttons", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Customize HUD", color = Color.White, fontSize = 15.sp)
                    Text(
                        "Drag any button wherever you want it",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp,
                    )
                }
                Button(
                    onClick = onEditHud,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3644), contentColor = Color.White),
                ) {
                    Text("Edit", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            }
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) {
                Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun VolumeRow(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(44.dp)) {
        Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.width(120.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Palette.gold,
                activeTrackColor = Palette.gold,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
            ),
        )
        Text(
            "${(value * 100f).toInt()}%",
            color = Color.White,
            fontSize = 14.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(48.dp),
        )
    }
}

/** The attack button: a picture of your weapon in a gold ring. Reacts the moment you touch it. */
@Composable
fun WeaponButton(icon: Int, size: Dp, onPress: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0x77000000))
            .border(2.dp, Palette.gold.copy(alpha = 0.85f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(icon),
            contentDescription = "Attack",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().padding(7.dp),
        )
    }
}

/** Before the adventure starts: pick your class. Locks which weapons you can ever use. */
@Composable
fun ClassSelectScreen(onBegin: (Int) -> Unit) {
    val infos = HERO_CLASSES
    var chosen by remember { mutableIntStateOf(-1) }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "glow",
    )
    val bob by pulse.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob",
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E3B2F), Color(0xFF0F1D17))))
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "CHOOSE YOUR CLASS",
                color = Palette.gold,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
            )
            Text(
                "This locks which weapons you can ever use. Choose wisely.",
                color = Color(0xFFCFE3D6),
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                infos.forEachIndexed { i, info ->
                    ClassCard(
                        info = info,
                        selected = chosen == i,
                        dimmed = chosen >= 0 && chosen != i,
                        glow = glow,
                        bob = bob,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onTap = { chosen = i },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (chosen >= 0) onBegin(chosen) },
                enabled = chosen >= 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Palette.gold,
                    contentColor = Color(0xFF1E2A22),
                    disabledContainerColor = Color(0xFF3A3644),
                    disabledContentColor = Color.White.copy(alpha = 0.7f),
                ),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier
                    .width(360.dp)
                    .height(48.dp),
            ) {
                Text(
                    if (chosen >= 0) "Begin as the ${infos[chosen].name}" else "Tap a class to choose it",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun ClassCard(
    info: ClassDef,
    selected: Boolean,
    dimmed: Boolean,
    glow: Float,
    bob: Float,
    modifier: Modifier,
    onTap: () -> Unit,
) {
    val scale by animateFloatAsState(if (selected) 1.04f else 1f, tween(250), label = "scale")
    val fade by animateFloatAsState(if (dimmed) 0.5f else 1f, tween(250), label = "fade")
    val accent = Color(info.color)
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = fade
            }
            .clip(shape)
            .background(Color(0xFF191720))
            .border(
                if (selected) 3.dp else 1.dp,
                if (selected) Palette.gold.copy(alpha = glow) else Color.White.copy(alpha = 0.18f),
                shape,
            )
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFFF6EFE2), Color(0xFFE6D9C2)))),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.45f * glow), Color.Transparent),
                            center = center,
                            radius = size.minDimension * 0.75f,
                        ),
                        radius = size.minDimension * 0.75f,
                    )
                }
            }
            Text(
                info.icon,
                fontSize = 64.sp,
                modifier = Modifier.graphicsLayer { translationY = if (selected) bob.dp.toPx() else 0f },
            )
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(
                info.name,
                color = if (selected) Palette.gold else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            Text(info.style, color = Color(0xFFB9C6BE), fontSize = 11.sp, lineHeight = 14.sp)
            Spacer(Modifier.height(2.dp))
            Text(info.blurb, color = Color(0xFF9FAFA6), fontSize = 10.sp, lineHeight = 13.sp, maxLines = 4)
            Spacer(Modifier.height(4.dp))
            StatBar("Power", info.power, accent)
            StatBar("Speed", info.speed, accent)
            StatBar("Range", info.range, accent)
            Spacer(Modifier.height(2.dp))
            Text(
                "Starts with: ${info.startName}",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 9.sp,
            )
        }
    }
}

@Composable
private fun StatBar(label: String, value: Float, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(14.dp)) {
        Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, modifier = Modifier.width(44.dp))
        Canvas(Modifier.weight(1f).height(6.dp)) {
            val r = CornerRadius(size.height / 2f)
            drawRoundRect(color = Color(0x33FFFFFF), cornerRadius = r)
            drawRoundRect(color = color, size = Size(size.width * value, size.height), cornerRadius = r)
        }
    }
}

/**
 * Wraps a HUD button so it can be dragged to a new spot. Outside edit mode it just applies
 * whatever offset was saved for [id]; in edit mode it also shows a gold outline and follows
 * the finger, saving the new spot as soon as the drag moves.
 */
@Composable
fun HudDraggable(
    id: String,
    editing: Boolean,
    layout: SnapshotStateMap<String, Offset>,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val savedOffset = layout[id] ?: Offset.Zero
    Box(
        modifier = Modifier
            .offset { IntOffset(savedOffset.x.roundToInt(), savedOffset.y.roundToInt()) }
            .then(
                if (editing) {
                    Modifier
                        .border(2.dp, Palette.gold, RoundedCornerShape(14.dp))
                        .pointerInput(id) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val next = (layout[id] ?: Offset.Zero) + drag
                                layout[id] = next
                                HudLayout.save(context, id, next)
                            }
                        }
                } else {
                    Modifier
                },
            ),
    ) {
        content()
    }
}

/** A round button that reacts the moment your thumb touches it. */
@Composable
fun HudButton(label: String, active: Boolean, size: Dp, fontSize: TextUnit = 14.sp, onPress: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (active) Palette.gold.copy(alpha = 0.85f) else Color(0x66000000))
            .border(2.dp, Color.White.copy(alpha = if (active) 0.9f else 0.5f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (active) Color(0xFF1E2A22) else Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
        )
    }
}

/** How wide the health, experience and stamina bars are. */
private val BAR_W = 220.dp

/**
 * How far down the centred bars sit. On a wide screen there's room for them level with the
 * corner buttons; on a phone they sit just underneath, so nothing overlaps.
 */
@Composable
fun hudBarsTop(): Dp = if (LocalConfiguration.current.screenWidthDp >= 1040) 10.dp else 66.dp

/** Just below the centred bars: where banners and the monster you're fighting are shown. */
@Composable
fun belowHudBars(): Dp = hudBarsTop() + 78.dp

/**
 * Top middle of the screen: your level badge, then (top to bottom) health with numbers,
 * experience, and stamina. "+48 XP" floats up underneath after a kill.
 */
@Composable
fun PlayerBars(game: Game, modifier: Modifier = Modifier) {
    val tick = game.hudTick
    val shadow = TextStyle(shadow = Shadow(Color.Black, blurRadius = 3f))
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xCC15131C))
                    .border(2.dp, Palette.gold, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("LV", color = Palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 9.sp)
                    Text("${if (tick >= 0L) game.level else 1}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column {
                Box(contentAlignment = Alignment.Center) {
                    HealthBar(game)
                    Text(
                        "${game.health.toInt()} / ${game.maxHealth.toInt()}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 10.sp,
                        style = shadow,
                    )
                }
                Spacer(Modifier.height(3.dp))
                Box(contentAlignment = Alignment.Center) {
                    XpBar(game)
                    if (tick >= 0L) {
                        val lv = game.loot.level
                        Text(
                            if (lv >= MAX_LEVEL) "MAX LEVEL" else "${game.loot.xp} / ${game.loot.xpNeeded(lv)} XP",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 8.sp,
                            style = shadow,
                        )
                    }
                }
                Spacer(Modifier.height(3.dp))
                StaminaBar(game)
                if (game.heroClass == HeroClass.MAGE) {
                    Spacer(Modifier.height(3.dp))
                    MpBar(game)
                }
                Spacer(Modifier.height(3.dp))
                HungerBar(game)
            }
        }
        Box(Modifier.height(18.dp), contentAlignment = Alignment.Center) {
            XpToast(game)
        }
    }
}

/**
 * Five quick slots along the bottom of the screen. Tap one to drink the potion in it, or to
 * wear or wield what's in it. Press and hold to empty it. Tap an empty one to open your bag,
 * where the +Q button on anything puts it in a slot.
 */
@Composable
fun QuickBar(game: Game, editing: Boolean, onOpenBag: () -> Unit) {
    val loot = game.loot
    val version = loot.version
    val slots = remember(version) { List(QUICK_SLOTS) { loot.quick(it) } }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0 until QUICK_SLOTS) {
            val q = slots[i]
            val item = q.item
            val empty = item == null
            val out = item != null && q.count == 0
            val edge = when {
                q.inUse -> Palette.gold
                item != null -> Color(Rarity.COLORS[item.rarity.coerceIn(0, Rarity.MAX)]).copy(alpha = if (out) 0.3f else 0.85f)
                else -> Color.White.copy(alpha = 0.3f)
            }
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (q.inUse) Palette.gold.copy(alpha = 0.3f) else Color(0x99000000))
                    .border(2.dp, edge, RoundedCornerShape(12.dp))
                    .pointerInput(i, version, editing) {
                        detectTapGestures(
                            onTap = {
                                if (!editing) {
                                    if (empty) onOpenBag() else game.useQuick(i)
                                }
                            },
                            onLongPress = { if (!editing && !empty) loot.setQuick(i, null) },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (item != null) {
                    Text(
                        Slot.ICONS[item.slot.coerceIn(0, Slot.ICONS.size - 1)],
                        fontSize = 22.sp,
                        modifier = Modifier.graphicsLayer { alpha = if (out) 0.35f else 1f },
                    )
                    if (item.slot == Slot.POTION || item.slot == Slot.FOOD) {
                        Text(
                            "${q.count}",
                            color = if (out) Color(0xFFFF6A5A) else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 3f)),
                            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 5.dp, bottom = 2.dp),
                        )
                    } else if (q.inUse) {
                        Text(
                            "ON",
                            color = Palette.gold,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
                        )
                    }
                } else {
                    Text("+", color = Color.White.copy(alpha = 0.4f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "${i + 1}",
                    color = Color.White.copy(alpha = 0.55f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(start = 5.dp, top = 2.dp),
                )
            }
        }
    }
}

/** Gold bar: how close you are to the next level. */
@Composable
fun XpBar(game: Game) {
    Canvas(Modifier.size(width = BAR_W, height = 11.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(color = Color(0x88000000), cornerRadius = r)
        val f = game.xpFrac.coerceIn(0f, 1f)
        if (f > 0.005f) drawRoundRect(color = Palette.gold, size = Size(size.width * f, size.height), cornerRadius = r)
        drawRoundRect(color = Color.White.copy(alpha = 0.4f), cornerRadius = r, style = Stroke(1.dp.toPx()))
    }
}

/** "+48 XP" floating up for a moment after a kill. */
@Composable
fun XpToast(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.xpVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(1600)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(300), label = "xp")
    if (a > 0.01f) {
        Text(
            game.xpToast,
            color = Palette.gold,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.graphicsLayer {
                alpha = a
                translationY = (1f - a) * 12f
            },
        )
    }
}

/** Big and gold when you go up a level. */
@Composable
fun BoxScope.LevelUpBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.levelVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3000)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(400), label = "levelup")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .safeDrawingPadding()
            .padding(top = belowHudBars() + 64.dp)
            .graphicsLayer {
                alpha = a
                scaleX = 0.8f + 0.2f * a
                scaleY = 0.8f + 0.2f * a
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("LEVEL UP!", color = Palette.gold, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
        Text("You are now level ${game.level}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Health restored, and you're tougher", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

/** Your health, the top one of the three bars. */
@Composable
fun HealthBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = BAR_W, height = 14.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val h = (game.health / game.maxHealth).coerceIn(0f, 1f)
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        if (h > 0.005f) {
            drawRoundRect(
                color = if (h < 0.3f) Color(0xFFFF4A3A) else Color(0xFFD83A34),
                size = Size(size.width * h, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(color = Color.White.copy(alpha = 0.5f), cornerRadius = CornerRadius(r), style = Stroke(1.5.dp.toPx()))
    }
}

/** A red glow round the edge of the screen when you're hit, and while you're badly hurt. */
@Composable
fun HurtFlash(game: Game) {
    Canvas(Modifier.fillMaxSize()) {
        if (game.hudTick < 0L) return@Canvas
        val low = if (game.health < 30f && !game.dead) 0.3f else 0f
        val k = kotlin.math.max(game.hurtFlash * 0.7f, low)
        if (k < 0.01f) return@Canvas
        drawRect(
            brush = Brush.radialGradient(
                listOf(Color.Transparent, Color(0xFFB0101A).copy(alpha = k)),
                center = center,
                radius = size.maxDimension * 0.62f,
            ),
        )
    }
}

/** The monster you're fighting: its name, level and health, at the top of the screen. */
@Composable
fun BoxScope.TargetPanel(game: Game) {
    val tick = game.hudTick
    val frac = game.targetFrac
    if (tick < 0L || frac < 0f) return
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .safeDrawingPadding()
            .padding(top = belowHudBars())
            .background(Color(0xAA15131C), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val boss = game.targetBoss
            Text(
                if (boss) "\u2620\uFE0F  ${game.targetName}" else game.targetName,
                color = if (boss) Palette.gold else Color(0xFFFF8A7A),
                fontSize = if (boss) 17.sp else 14.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(8.dp))
            // Coloured by how it matches your level: red is too strong for you, grey is too weak to be worth it.
            val gap = game.targetLevel - game.level
            val lvColor = when {
                gap >= 8 -> Color(0xFFFF4A4A)
                gap >= 3 -> Color(0xFFFFA040)
                gap >= -3 -> Color(0xFFFFE070)
                gap >= -10 -> Color(0xFF7CE06A)
                else -> Color(0xFF9A9A9A)
            }
            Text("Lv ${game.targetLevel}", color = lvColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Canvas(Modifier.size(width = if (game.targetBoss) 280.dp else 200.dp, height = if (game.targetBoss) 11.dp else 8.dp)) {
            val r = CornerRadius(size.height / 2f)
            drawRoundRect(color = Color(0x88000000), cornerRadius = r)
            if (frac > 0.005f) drawRoundRect(color = Color(0xFFD83A34), size = Size(size.width * frac, size.height), cornerRadius = r)
        }
    }
}

/** The context button: shows up near a chest or a cave mouth. */
@Composable
fun BoxScope.ActionButton(game: Game) {
    val tick = game.hudTick
    val action = game.action
    if (tick < 0L || action == Game.ACTION_NONE) return
    val label = when (action) {
        Game.ACTION_OPEN -> "\uD83D\uDDDD\uFE0F  OPEN CHEST"
        Game.ACTION_ENTER -> "\uD83D\uDD26  ENTER CAVE"
        Game.ACTION_SEARCH -> "\uD83D\uDD0D  SEARCH BODY"
        Game.ACTION_TALK -> "\uD83D\uDCAC  TALK"
        Game.ACTION_RELIC -> "\u2728  TAKE RELIC"
        Game.ACTION_CRAFT, Game.ACTION_FINISH, Game.ACTION_CHOP, Game.ACTION_MINE, Game.ACTION_FURN, Game.ACTION_DOOR, Game.ACTION_REPAIR, Game.ACTION_PORTAL -> game.actionLabel
        else -> "\u2600\uFE0F  LEAVE CAVE"
    }
    if (label.isEmpty()) return
    Box(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .safeDrawingPadding()
            .padding(bottom = if (game.buildMode) 118.dp else 84.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Palette.gold)
            .border(2.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(24.dp))
            .pointerInput(Unit) { detectTapGestures(onPress = { game.interact() }) }
            .padding(horizontal = 22.dp, vertical = 11.dp),
    ) {
        Text(label, color = Color(0xFF1E2A22), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** What came out of the chest you just opened. */
@Composable
fun BoxScope.LootPopup(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.lootVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(4200)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(350), label = "loot")
    if (a < 0.01f) return
    val items = game.lastLoot
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .graphicsLayer {
                alpha = a
                scaleX = 0.9f + 0.1f * a
                scaleY = 0.9f + 0.1f * a
            }
            .background(Color(0xE615131C), RoundedCornerShape(16.dp))
            .border(1.5.dp, Palette.gold.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(game.lootTitle, color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        for (item in items) {
            val isGold = item.slot == Slot.POTION && item.vit < 0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (isGold) "\uD83E\uDE99" else Slot.ICONS[item.slot], fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    item.name,
                    color = if (isGold) Palette.gold else Color(Rarity.COLORS[item.rarity]),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("Open your bag \uD83C\uDF92 to wear it", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
    }
}

/** Fades to black and back when you go in or out of a cave. */
@Composable
fun CaveFade(game: Game) {
    Canvas(Modifier.fillMaxSize()) {
        if (game.hudTick < 0L) return@Canvas
        val f = game.fade
        if (f > 0.01f) drawRect(Color.Black.copy(alpha = kotlin.math.min(1f, f * 1.4f)))
    }
}

/** Your equipment: what you're wearing on the left, your bag on the right. Tap to wear or take off. */
@Composable
fun EquipmentPanel(game: Game, onClose: () -> Unit) {
    val loot = game.loot
    val version = loot.version
    val bag = remember(version) { loot.bagItems() }
    val worn = remember(version) { loot.wornItems() }
    val held = remember(version) { loot.wielded() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.94f)
                .fillMaxHeight()
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(14.dp),
        ) {
            // Worn items and totals.
            Column(Modifier.width(250.dp).fillMaxHeight().verticalScroll(rememberScrollState())) {
                Text("Equipment", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                // The weapon in your hands.
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Palette.gold.copy(alpha = 0.16f))
                        .border(1.dp, Palette.gold.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                ) {
                    Text(Slot.ICONS[Slot.WEAPON], fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Weapon in hand", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                        Text(
                            held?.name ?: "Nothing",
                            color = if (held != null) Color(Rarity.COLORS[held.rarity]) else Color.White.copy(alpha = 0.35f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                        )
                        if (held != null) {
                            Text("\u2694\uFE0F Power +${held.pow}", color = Palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(WEAPON_KINDS[held.kind.coerceIn(0, 6)], color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1)
                            val el = held.element()
                            if (el != null) {
                                Text("${held.elementLabel()}: $el", color = Color(0xFF9FD8FF), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                held.elementEffect()?.let { fx ->
                                    Text(fx, color = Color(0xFF9FD8FF).copy(alpha = 0.75f), fontSize = 10.sp)
                                }
                            }
                            if (held.kind == WeaponClass.BOW) {
                                Text("\uD83C\uDFF9 Quiver ${loot.arrows}/$QUIVER_MAX", color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
                            }
                        }
                    }
                }
                for (slot in 0 until Slot.WORN) {
                    val w = worn[slot]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x22FFFFFF))
                            .pointerInput(slot, version) { detectTapGestures(onTap = { if (w != null) loot.unequip(slot) }) }
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                    ) {
                        Text(Slot.ICONS[slot], fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(Slot.NAMES[slot], color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                            Text(
                                w?.name ?: "Nothing",
                                color = if (w != null) Color(Rarity.COLORS[w.rarity]) else Color.White.copy(alpha = 0.35f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("\u2764\uFE0F  Health ${game.maxHealth.toInt()}", color = Color.White, fontSize = 13.sp)
                Text("\uD83D\uDEE1\uFE0F  Defense ${loot.defense}", color = Color.White, fontSize = 13.sp)
                Text("\u2694\uFE0F  Power ${loot.power}", color = Color.White, fontSize = 13.sp)
                Text("\uD83D\uDCA8  Speed +${loot.speed}%", color = Color.White, fontSize = 13.sp)
                Text("\uD83E\uDE99  Gold ${loot.gold}", color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            // The bag.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("Bag (${bag.size})", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(
                        onClick = onClose,
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
                Text("Tap to wear or wield it, or drink a potion. Tap something you're wearing to take it off. +Q puts it in a quick slot along the bottom of the screen (hold a quick slot to empty it). Gems sell to traders.", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    if (bag.isEmpty()) {
                        Text("Empty. Find hidden chests out in the wild and deep in caves!", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    }
                    bag.forEachIndexed { i, item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x22FFFFFF))
                                .border(1.dp, Color(Rarity.COLORS[item.rarity]).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .pointerInput(i, version) {
                                    detectTapGestures(onTap = {
                                        when (item.slot) {
                                            Slot.POTION -> game.drinkPotion(i)
                                            Slot.FOOD -> game.eat(i)
                                            Slot.GEM -> {}
                                            else -> game.tryEquip(i)
                                        }
                                    })
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        ) {
                            Text(Slot.ICONS[item.slot], fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = Color(Rarity.COLORS[item.rarity]), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(
                                    "${Rarity.NAMES[item.rarity]}  \u00B7  ${item.stats()}",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                )
                            }
                            if (item.slot != Slot.GEM) {
                                val qi = loot.quickIndexOf(item)
                                Box(
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .size(width = 36.dp, height = 26.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (qi >= 0) Palette.gold else Color(0x33FFFFFF))
                                        .pointerInput(i, version) {
                                            detectTapGestures(onTap = {
                                                if (qi >= 0) {
                                                    loot.setQuick(qi, null)
                                                } else {
                                                    val f = loot.firstFreeQuick()
                                                    if (f >= 0) loot.setQuick(f, item)
                                                }
                                            })
                                        },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        if (qi >= 0) "Q${qi + 1}" else "+Q",
                                        color = if (qi >= 0) Color(0xFF1E2A22) else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                            }
                            Text(
                                when (item.slot) {
                                    Slot.POTION -> "DRINK"
                                    Slot.FOOD -> "EAT"
                                    Slot.WEAPON -> "WIELD"
                                    Slot.GEM -> "${item.value()}g"
                                    else -> "WEAR"
                                },
                                color = Palette.gold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * The hardcore warnings: what it means, then "are you sure" three times over. Every step has a
 * way back out.
 */
@Composable
fun HardcoreAsk(step: Int, hasSave: Boolean, onYes: () -> Unit, onNo: () -> Unit) {
    val title = when (step) {
        1 -> "\u2620\uFE0F  HARDCORE MODE"
        2 -> "Are you sure?"
        3 -> "Are you REALLY sure?"
        else -> "Last chance."
    }
    val body = when (step) {
        1 -> "You get ONE life.\n\n" +
            "If you die, your hero is gone for good. Your level, gear, gold, quests, everything you've built and " +
            "everything in your chests is erased the moment you fall. There's no waking up at a bed, no reloading, " +
            "and closing the game won't save you.\n\n" +
            "You'll start over from level 1 with nothing.\n\n" +
            "It's harder, too: monsters hit 50% harder, take 50% more to kill, spot you from further away and " +
            "chase you longer. You don't heal on your own (only potions, food and sleep), and starving can kill you. " +
            "In return you get 50% more XP and gold, and better loot." +
            (if (hasSave) "\n\nStarting a hardcore game also erases the adventure you have saved now." else "")
        2 -> "One death and you lose EVERYTHING. Your whole save is deleted, and you go back to level 1."
        3 -> "There is no undo. Not for a lucky monster, not for a fall, not for starving. Dead means gone."
        else -> "Once you begin, this run can only end one way. Start your hardcore adventure?"
    }
    val yes = when (step) {
        1 -> "I understand"
        2 -> "Yes, I'm sure"
        3 -> "Yes, I'm really sure"
        else -> "\u2620\uFE0F  Begin Hardcore"
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.92f)
                .background(Color(0xF0140608), RoundedCornerShape(16.dp))
                .border(1.5.dp, Color(0xFFFF3B5C).copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                .safeDrawingPadding()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(title, color = Color(0xFFFF6A6A), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Text("Step ${step.coerceAtMost(4)} of 4", color = Color.White.copy(alpha = 0.45f), fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            // The words scroll if there are a lot of them; the buttons stay put underneath.
            Column(
                Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(body, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Button(
                    onClick = onNo,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC101A15), contentColor = Palette.gold),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.weight(1f).height(48.dp),
                ) {
                    Text("No, take me back", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Button(
                    onClick = onYes,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB0202E), contentColor = Color.White),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.weight(1f).height(48.dp),
                ) {
                    Text(yes, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** A hardcore run has ended: the save is already gone. The only way on is to start again. */
@Composable
fun HardcoreDeath(game: Game) {
    val ctx = LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE0A0204))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(12.dp),
        ) {
            Text("\u2620\uFE0F", fontSize = 40.sp)
            LaunchedEffect(Unit) { ctx.keystoneActivity()?.let { CloudSave.buryCloud(it) } }
            Text("YOU DIED", color = Color(0xFFFF3B3B), fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 6.sp)
            Spacer(Modifier.height(6.dp))
            Text("Your hardcore run is over. Everything has been erased.", color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text(game.runSummary, color = Palette.gold, fontSize = 13.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    // Straight into another hardcore run: you'll pick your class and begin at level 1.
                    ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().clear().putBoolean("hardcore", true).commit()
                    ctx.keystoneActivity()?.recreate()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB0202E), contentColor = Color.White),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.width(260.dp).height(50.dp),
            ) {
                Text("\u2620\uFE0F  New Hardcore Run", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    ctx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().clear().commit()
                    ctx.keystoneActivity()?.recreate()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC101A15), contentColor = Palette.gold),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.width(260.dp).height(46.dp),
            ) {
                Text("Back to Title", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Shown while you're knocked out. */
@Composable
fun BoxScope.DefeatOverlay(game: Game) {
    val tick = game.hudTick
    if (tick < 0L || !game.dead) return
    if (game.hardcore) {
        if (game.hardcoreOver) HardcoreDeath(game)
        return
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("You were defeated", color = Color(0xFFFF6A5A), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text(
                if (game.base.spawnBed != null) "Waking up at your bed\u2026" else "Waking up in Greenhollow\u2026",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp,
            )
        }
    }
}

/** The hunger bar: orange, turning red as you go hungry. Eat to fill it. */
@Composable
fun HungerBar(game: Game, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Text("\uD83C\uDF56", fontSize = 9.sp, lineHeight = 9.sp)
        Spacer(Modifier.width(3.dp))
        Canvas(Modifier.size(width = BAR_W - 15.dp, height = 8.dp)) {
            if (game.hudTick < 0L) return@Canvas
            val h = game.hunger.coerceIn(0f, 1f)
            val r = size.height / 2f
            drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
            val fill = when {
                h < 0.15f -> Color(0xFFE5534B)
                h < 0.35f -> Color(0xFFFFB347)
                else -> Color(0xFFE8A04A)
            }
            if (h > 0.01f) drawRoundRect(color = fill, size = Size(size.width * h, size.height), cornerRadius = CornerRadius(r))
            drawRoundRect(color = Color.White.copy(alpha = 0.4f), cornerRadius = CornerRadius(r), style = Stroke(width = 1.dp.toPx()))
        }
    }
}

/** The stamina bar. Turns red when you're out of breath. */
@Composable
fun StaminaBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = BAR_W, height = 12.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val s = game.stamina
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        val fill = when {
            game.winded -> Color(0xFFE5534B)
            s < 0.3f -> Color(0xFFFFB347)
            else -> Color(0xFF7BD66F)
        }
        if (s > 0.01f) {
            drawRoundRect(
                color = fill,
                size = Size(size.width * s, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(
            color = Color.White.copy(alpha = 0.5f),
            cornerRadius = CornerRadius(r),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
}

/** The MP bar: a Mage's fuel for the staff. Flashes red for a moment when you swing dry. */
@Composable
fun MpBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = BAR_W, height = 12.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val frac = (game.mp / game.maxMp).coerceIn(0f, 1f)
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        val fill = if (game.outOfMpFlash > 0.01f) Color(0xFFE5534B) else Color(0xFF6B8EE0)
        if (frac > 0.01f) {
            drawRoundRect(
                color = fill,
                size = Size(size.width * frac, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(
            color = Color.White.copy(alpha = 0.5f),
            cornerRadius = CornerRadius(r),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
}

/** The whole world on one screen. Places you've been are in colour, the rest is faded. */
@Composable
fun WorldMap(game: Game, onClose: () -> Unit) {
    if (game.inGrainMap) {
        GrainMap(game, onClose)
        return
    }
    val arrow = remember { Path() }
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var mapSide by remember { mutableFloatStateOf(0f) }
    var homeMsg by remember { mutableStateOf("") }
    fun clampPan() {
        val lim = (zoom - 1f) * mapSide / 2f
        panX = panX.coerceIn(-lim, lim)
        panY = panY.coerceIn(-lim, lim)
    }
    val rank = game.loot.unlockedRank
    val sealed = remember(rank) { sealOverlay(game.world, rank) }
    val labelPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    val regionPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(5f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    val gridPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = 0xCCFFFFFF.toInt()
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(3f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6101014))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxHeight()
                .aspectRatio(1f)
                .clipToBounds()
                .onSizeChanged { mapSide = it.width.toFloat() }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zc, _ ->
                        zoom = (zoom * zc).coerceIn(1f, 5f)
                        panX += pan.x
                        panY += pan.y
                        clampPan()
                    }
                },
        ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoom
                    scaleY = zoom
                    translationX = panX
                    translationY = panY
                },
        ) {
            if (game.hudTick < 0L) return@Canvas
            val side = size.minDimension
            drawImage(
                image = game.minimapImage,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )
            drawRect(
                color = Palette.gold.copy(alpha = 0.8f),
                size = Size(side, side),
                style = Stroke(width = 2.dp.toPx()),
            )
            val scale = side / WORLD_SIZE

            // Region colours and borders.
            drawImage(
                image = game.regionOverlay,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )
            // Regions still sealed are shaded over.
            drawImage(
                image = sealed,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )

            // Grid: numbers along the top, letters down the side.
            val cellPx = side / Game.MAP_GRID
            for (g in 1 until Game.MAP_GRID) {
                val t = g * cellPx
                drawLine(Color.White.copy(alpha = 0.16f), Offset(t, 0f), Offset(t, side), strokeWidth = 1f)
                drawLine(Color.White.copy(alpha = 0.16f), Offset(0f, t), Offset(side, t), strokeWidth = 1f)
            }
            gridPaint.textSize = 9.dp.toPx()
            drawIntoCanvas { c ->
                for (g in 0 until Game.MAP_GRID) {
                    val mid = (g + 0.5f) * cellPx
                    c.nativeCanvas.drawText(g.toString(), mid, 11.dp.toPx(), gridPaint)
                    c.nativeCanvas.drawText(('A' + g).toString(), 7.dp.toPx(), mid + 3.dp.toPx(), gridPaint)
                }
            }

            // Region names and how tough they are.
            drawIntoCanvas { c ->
                for (k in Zone.entries.indices) {
                    val zn = Zone.entries[k]
                    val lx = REGION_LABEL_X[k] * scale
                    val lz = REGION_LABEL_Z[k] * scale
                    regionPaint.textSize = 15.dp.toPx()
                    regionPaint.color = zn.mapColor or (0xFF shl 24)
                    c.nativeCanvas.drawText(zn.title.uppercase(), lx, lz, regionPaint)
                    regionPaint.textSize = 11.dp.toPx()
                    regionPaint.color = android.graphics.Color.WHITE
                    c.nativeCanvas.drawText(zn.levels, lx, lz + 14.dp.toPx(), regionPaint)
                    if (zoneRank(zn) > rank) {
                        regionPaint.color = 0xFFD8A8FF.toInt()
                        c.nativeCanvas.drawText("\uD83D\uDD12 SEALED", lx, lz + 28.dp.toPx(), regionPaint)
                    }
                }
            }

            // Quest markers: where to go, where to hand in, and new work waiting.
            val qm = game.marks
            var mi = 0
            while (mi < qm.size) {
                val mc = Offset(qm[mi] * scale, qm[mi + 1] * scale)
                val kind = qm[mi + 2].toInt()
                val col = when (kind) { 1 -> Color(0xFF5AE0C0); 2 -> Palette.gold; else -> Color(0xFFFFE070) }
                drawCircle(Palette.night, radius = 8.dp.toPx(), center = mc)
                drawPath(
                    Path().apply {
                        moveTo(mc.x, mc.y - 7.dp.toPx())
                        lineTo(mc.x + 6.dp.toPx(), mc.y + 5.dp.toPx())
                        lineTo(mc.x - 6.dp.toPx(), mc.y + 5.dp.toPx())
                        close()
                    },
                    color = col,
                )
                mi += 3
            }

            // Your current goal: a bold orange ring with a target, so it's easy to find.
            val goalSpot = game.objectiveSpot()
            if (goalSpot != null) {
                val gc = Offset(goalSpot[0] * scale, goalSpot[1] * scale)
                drawCircle(Palette.night, radius = 14.dp.toPx(), center = gc)
                drawCircle(Color(0xFFFF9A3C), radius = 12.dp.toPx(), center = gc, style = Stroke(width = 3.dp.toPx()))
                labelPaint.textSize = 13.dp.toPx()
                drawIntoCanvas { cv ->
                    labelPaint.alpha = 255
                    cv.nativeCanvas.drawText("\uD83C\uDFAF", gc.x, gc.y + 5.dp.toPx(), labelPaint)
                    labelPaint.textSize = 11.dp.toPx()
                    cv.nativeCanvas.drawText("Objective", gc.x, gc.y - 18.dp.toPx(), labelPaint)
                }
            }

            // Places: gold and named once found, a hollow ring until then.
            labelPaint.textSize = 10.dp.toPx()
            for (i in PLACES.indices) {
                val pl = PLACES[i]
                val c = Offset(pl.x * scale, pl.z * scale)
                if (game.discovered[i]) {
                    drawCircle(Palette.night, radius = 5.dp.toPx(), center = c)
                    drawCircle(Palette.gold, radius = 3.5.dp.toPx(), center = c)
                } else {
                    drawCircle(Color.White.copy(alpha = 0.7f), radius = 3.5.dp.toPx(), center = c, style = Stroke(width = 1.5.dp.toPx()))
                }
            }
            drawIntoCanvas { cv ->
                for (i in PLACES.indices) {
                    if (!game.discovered[i]) continue
                    val pl = PLACES[i]
                    cv.nativeCanvas.drawText(pl.name, pl.x * scale, pl.z * scale - 7.dp.toPx(), labelPaint)
                }
            }

            // Boss lairs: a red skull while the boss lives, a green tick once it's beaten.
            labelPaint.textSize = 11.dp.toPx()
            for (i in BOSSES.indices) {
                val bc = Offset(game.treasure.lairX[i] * scale, game.treasure.lairZ[i] * scale)
                val beaten = game.loot.bossBeaten(i)
                val dim = zoneRank(BOSSES[i].zone) > rank
                val ring = if (beaten) Color(0xFF3FA84A) else Color(0xFFD83A34)
                drawCircle(Palette.night.copy(alpha = if (dim) 0.5f else 1f), radius = 9.dp.toPx(), center = bc)
                drawCircle(ring.copy(alpha = if (dim) 0.45f else 1f), radius = 7.5.dp.toPx(), center = bc)
                drawIntoCanvas { cv ->
                    labelPaint.alpha = if (dim) 120 else 255
                    cv.nativeCanvas.drawText(if (beaten) "\u2714" else "\u2620", bc.x, bc.y + 4.dp.toPx(), labelPaint)
                    // The boss you need next gets its name on the map.
                    if (i == rank && !beaten) {
                        cv.nativeCanvas.drawText(BOSSES[i].name, bc.x, bc.y - 12.dp.toPx(), labelPaint)
                    }
                    labelPaint.alpha = 255
                }
            }

            // The world boss, while one's out: a big crown with its name.
            val wbx = game.wbMapX
            val wbz = game.wbMapZ
            if (!wbx.isNaN() && !wbz.isNaN()) {
                val wc = Offset(wbx * scale, wbz * scale)
                drawCircle(Palette.night, radius = 12.dp.toPx(), center = wc)
                drawCircle(Color(0xFFFF3B5C), radius = 10.5.dp.toPx(), center = wc)
                drawIntoCanvas { cv ->
                    labelPaint.alpha = 255
                    cv.nativeCanvas.drawText("\uD83D\uDC51", wc.x, wc.y + 5.dp.toPx(), labelPaint)
                    cv.nativeCanvas.drawText(game.wbMapName, wc.x, wc.y - 15.dp.toPx(), labelPaint)
                }
            }

            // Carriages caught by monsters: a gold ring with a horse, until you save them.
            if (!game.inGrainMap) {
                for (ev in game.carriages.live) {
                    if (ev.state >= 2) continue
                    val cc = Offset(ev.x * scale, ev.z * scale)
                    drawCircle(Palette.night, radius = 11.dp.toPx(), center = cc)
                    drawCircle(Color(0xFFFFC24A), radius = 9.5.dp.toPx(), center = cc, style = Stroke(width = 2.5.dp.toPx()))
                    labelPaint.textSize = 12.dp.toPx()
                    drawIntoCanvas { cv ->
                        labelPaint.alpha = 255
                        cv.nativeCanvas.drawText("\uD83D\uDC0E", cc.x, cc.y + 4.5.dp.toPx(), labelPaint)
                        labelPaint.textSize = 10.dp.toPx()
                        cv.nativeCanvas.drawText("Carriage", cc.x, cc.y - 14.dp.toPx(), labelPaint)
                    }
                }
            }

            // Scale bar: 500 m.
            val bar = 500f * scale
            val by = side - 14.dp.toPx()
            val bx = side - bar - 14.dp.toPx()
            drawLine(Color.White, Offset(bx, by), Offset(bx + bar, by), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx, by - 5.dp.toPx()), Offset(bx, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx + bar, by - 5.dp.toPx()), Offset(bx + bar, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            labelPaint.textSize = 11.dp.toPx()
            drawIntoCanvas { it.nativeCanvas.drawText("500 m", bx + bar / 2f, by - 8.dp.toPx(), labelPaint) }

            // You are here.
            val px = game.x * scale
            val pz = game.z * scale
            val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
            drawCircle(Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(px, pz))
            rotate(degrees = deg, pivot = Offset(px, pz)) {
                val a = 9.dp.toPx()
                arrow.reset()
                arrow.moveTo(px, pz - a)
                arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
                arrow.lineTo(px, pz + a * 0.3f)
                arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
                arrow.close()
                drawPath(arrow, color = Palette.gold)
                drawPath(arrow, color = Palette.night, style = Stroke(width = 1.5.dp.toPx()))
            }
        }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(20.dp),
        ) {
            Text("World map", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("2.9 km across", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text("You are in ${game.gridRef()}", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            val goalText = game.story.objective
            if (goalText.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "\uD83C\uDFAF $goalText",
                    color = Color(0xFFFFB066), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.widthIn(max = 170.dp),
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Places found: ${game.discovered.count { it }} of ${PLACES.size}",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
            )
            Text("Bright: explored", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            val nextBoss = BOSSES.indices.firstOrNull { !game.loot.bossBeaten(it) }
            if (nextBoss != null) {
                Text("\u2620\uFE0F Next boss", color = Color(0xFFFF6A5A), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(BOSSES[nextBoss].name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("in ${BOSSES[nextBoss].zone.title}, Lv ${BOSSES[nextBoss].level}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                Text("Beat it to break the next seal", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
            } else {
                Text("Every boss beaten!", color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Box(
            Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(16.dp),
        ) {
            HudButton("✕", active = false, size = 52.dp, onPress = onClose)
        }

        // Zoom, find yourself, and head home. (You can also pinch and drag the map.)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .safeDrawingPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (homeMsg.isNotEmpty()) {
                Text(homeMsg, color = Color(0xFFFFB0A0), fontSize = 12.sp, modifier = Modifier.widthIn(max = 170.dp))
            }
            Button(
                onClick = {
                    val why = game.teleportHome()
                    if (why == null) onClose() else homeMsg = why
                },
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
            ) {
                Text("\uD83C\uDFE0 GO HOME", fontWeight = FontWeight.ExtraBold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("+", active = false, size = 48.dp) {
                    zoom = (zoom * 1.5f).coerceAtMost(5f)
                    clampPan()
                }
                HudButton("\u2212", active = false, size = 48.dp) {
                    zoom = (zoom / 1.5f).coerceAtLeast(1f)
                    clampPan()
                }
                HudButton("\uD83D\uDCCD", active = false, size = 48.dp) {
                    val sc = mapSide / WORLD_SIZE
                    if (zoom < 2.5f) zoom = 2.5f
                    panX = -(game.x * sc - mapSide / 2f) * zoom
                    panY = -(game.z * sc - mapSide / 2f) * zoom
                    clampPan()
                }
            }
        }
    }
}

/** The Grain Rot's own map: its 1.5 km square, the gate you came through, and you. */
@Composable
fun GrainMap(game: Game, onClose: () -> Unit) {
    val arrow = remember { Path() }
    val labelPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6101014))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxHeight()
                .aspectRatio(1f),
        ) {
            if (game.hudTick < 0L) return@Canvas
            val side = size.minDimension
            val cells = (ROT_SIDE / CELL).toInt()
            val c0 = (ROT_ORIGIN / CELL).toInt()
            drawImage(
                image = game.activeMinimap,
                srcOffset = IntOffset(c0, c0),
                srcSize = IntSize(cells, cells),
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )
            drawRect(
                color = Color(0xFF9AFF3A).copy(alpha = 0.8f),
                size = Size(side, side),
                style = Stroke(width = 2.dp.toPx()),
            )
            val scale = side / ROT_SIDE

            // Grid: five columns and rows of 300 m.
            val gridN = 5
            val cellPx = side / gridN
            for (g in 1 until gridN) {
                val t = g * cellPx
                drawLine(Color.White.copy(alpha = 0.16f), Offset(t, 0f), Offset(t, side), strokeWidth = 1f)
                drawLine(Color.White.copy(alpha = 0.16f), Offset(0f, t), Offset(side, t), strokeWidth = 1f)
            }

            // The gate you came through.
            val gc = Offset((ROT_SPAWN_X - ROT_ORIGIN) * scale, (ROT_GATE_Z - ROT_ORIGIN) * scale)
            drawCircle(Palette.night, radius = 9.dp.toPx(), center = gc)
            drawCircle(Color(0xFF9AFF3A), radius = 7.dp.toPx(), center = gc, style = Stroke(width = 2.dp.toPx()))
            labelPaint.textSize = 11.dp.toPx()
            drawIntoCanvas { it.nativeCanvas.drawText("Rot-gate", gc.x, gc.y - 12.dp.toPx(), labelPaint) }

            // The dirt arena.
            val ac = Offset((ROT_ARENA_X - ROT_ORIGIN) * scale, (ROT_ARENA_Z - ROT_ORIGIN) * scale)
            drawCircle(Color(0xFFC89B5A).copy(alpha = 0.3f), radius = ROT_ARENA_R * scale, center = ac)
            drawCircle(Color(0xFFC89B5A), radius = ROT_ARENA_R * scale, center = ac, style = Stroke(width = 2.dp.toPx()))
            drawIntoCanvas { it.nativeCanvas.drawText("Arena", ac.x, ac.y + 4.dp.toPx(), labelPaint) }

            // The two servants' strongholds.
            for (fi in 0 until 2) {
                val fc = Offset(((if (fi == 0) ROT_FORT1_X else ROT_FORT2_X) - ROT_ORIGIN) * scale, ((if (fi == 0) ROT_FORT1_Z else ROT_FORT2_Z) - ROT_ORIGIN) * scale)
                drawCircle(Palette.night, radius = 6.dp.toPx(), center = fc)
                drawCircle(Color(0xFFB070FF), radius = 4.dp.toPx(), center = fc)
                drawIntoCanvas { it.nativeCanvas.drawText("Stronghold", fc.x, fc.y - 9.dp.toPx(), labelPaint) }
            }

            // The villages near the gate.
            val villageNames = arrayOf("Greywick", "Mourne", "Dunmere", "Harrowby", "Fallowmere")
            for ((vi, v) in game.grainVillages().withIndex()) {
                val vc = Offset((v[0] - ROT_ORIGIN) * scale, (v[1] - ROT_ORIGIN) * scale)
                drawCircle(Palette.night, radius = 6.dp.toPx(), center = vc)
                drawCircle(Palette.gold, radius = 4.dp.toPx(), center = vc)
                drawIntoCanvas { it.nativeCanvas.drawText(villageNames[vi % villageNames.size], vc.x, vc.y - 9.dp.toPx(), labelPaint) }
            }

            // Scale bar: 300 m.
            val bar = 300f * scale
            val by = side - 14.dp.toPx()
            val bx = side - bar - 14.dp.toPx()
            drawLine(Color.White, Offset(bx, by), Offset(bx + bar, by), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx, by - 5.dp.toPx()), Offset(bx, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx + bar, by - 5.dp.toPx()), Offset(bx + bar, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawIntoCanvas { it.nativeCanvas.drawText("300 m", bx + bar / 2f, by - 8.dp.toPx(), labelPaint) }

            // You are here.
            val px = ((game.x - ROT_ORIGIN) * scale).coerceIn(0f, side)
            val pz = ((game.z - ROT_ORIGIN) * scale).coerceIn(0f, side)
            val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
            drawCircle(Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(px, pz))
            rotate(degrees = deg, pivot = Offset(px, pz)) {
                val a = 9.dp.toPx()
                arrow.reset()
                arrow.moveTo(px, pz - a)
                arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
                arrow.lineTo(px, pz + a * 0.3f)
                arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
                arrow.close()
                drawPath(arrow, color = Palette.gold)
                drawPath(arrow, color = Palette.night, style = Stroke(width = 1.5.dp.toPx()))
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(20.dp),
        ) {
            Text("The Grain Rot", color = Color(0xFF9AFF3A), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("1.5 km across", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text("Bright: explored", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }

        Box(
            Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(16.dp),
        ) {
            HudButton("✕", active = false, size = 52.dp, onPress = onClose)
        }
    }
}

/** A map of the area around you, filling in as you explore. North is up. */
@Composable
fun Minimap(game: Game, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    val arrow = remember { Path() }
    Canvas(
        modifier
            .size(116.dp)
            .clip(shape)
            .background(Palette.night)
            .border(2.dp, Palette.gold.copy(alpha = 0.7f), shape),
    ) {
        if (game.hudTick < 0L) return@Canvas
        val window = 110 // cells shown across, about 660 m
        val ci = (game.x / CELL).toInt()
        val cj = (game.z / CELL).toInt()
        val sx = (ci - window / 2).coerceIn(0, GRID - window)
        val sz = (cj - window / 2).coerceIn(0, GRID - window)
        drawImage(
            image = game.activeMinimap,
            srcOffset = IntOffset(sx, sz),
            srcSize = IntSize(window, window),
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.Low,
        )
        val scale = size.width / window
        val qm = if (game.inGrainMap) FloatArray(0) else game.marks
        var mi = 0
        while (mi < qm.size) {
            val mx = (qm[mi] / CELL - sx) * scale
            val mz = (qm[mi + 1] / CELL - sz) * scale
            if (mx in 0f..size.width && mz in 0f..size.height) {
                val kind = qm[mi + 2].toInt()
                val col = when (kind) { 1 -> Color(0xFF5AE0C0); 2 -> Palette.gold; else -> Color(0xFFFFE070) }
                drawCircle(col, radius = 4.dp.toPx(), center = Offset(mx, mz))
            }
            mi += 3
        }
        val px = (game.x / CELL - sx) * scale
        val pz = (game.z / CELL - sz) * scale
        val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
        rotate(degrees = deg, pivot = Offset(px, pz)) {
            val a = 7.dp.toPx()
            arrow.reset()
            arrow.moveTo(px, pz - a)
            arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
            arrow.lineTo(px, pz + a * 0.3f)
            arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
            arrow.close()
            drawPath(arrow, color = Color.White)
            drawPath(arrow, color = Palette.night, style = Stroke(width = 1.dp.toPx()))
        }
    }
}

@Composable
fun BoxScope.ZoneBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val zone = game.zone
    LaunchedEffect(game.zoneVisit) {
        visible = true
        delay(2800)
        visible = false
    }
    val bannerAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(500),
        label = "zoneBanner",
    )
    if (bannerAlpha > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = belowHudBars())
                .graphicsLayer { alpha = bannerAlpha }
                .background(Color(0xCC15131C), RoundedCornerShape(16.dp))
                .padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(zone.title, color = Color(zone.mapColor or (0xFF shl 24)), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(zone.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text(zone.levels, color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Pops up when you find a named place. */
@Composable
fun BoxScope.DiscoveryBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val name = game.lastDiscovered
    LaunchedEffect(game.discoverVisit) {
        if (game.discoverVisit == 0) return@LaunchedEffect
        visible = true
        delay(3200)
        visible = false
    }
    val a by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(400),
        label = "discovery",
    )
    if (a > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer { alpha = a }
                .background(Color(0xCC15131C), RoundedCornerShape(14.dp))
                .border(1.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(horizontal = 26.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("DISCOVERED", color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Which map square you're in. */
@Composable
fun GridRef(game: Game) {
    val tick = game.hudTick
    Text(
        if (tick >= 0L) game.gridRef() else "",
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(Color(0x99000000), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}

/** A dark, hatched layer over every region that's still sealed, for the big map. */
fun sealOverlay(world: World, rank: Int): ImageBitmap {
    val px = IntArray(GRID * GRID)
    for (j in 0 until GRID) {
        for (i in 0 until GRID) {
            val idx = j * GRID + i
            val zr = zoneRank(Zone.entries[world.regionMap[idx].toInt()])
            px[idx] = if (zr <= rank) 0 else if ((i + j) % 9 < 2) 0xB05A2A7A.toInt() else 0x8C000000.toInt()
        }
    }
    return android.graphics.Bitmap.createBitmap(GRID, GRID, android.graphics.Bitmap.Config.ARGB_8888).apply {
        setPixels(px, 0, GRID, 0, 0, GRID, GRID)
    }.asImageBitmap()
}

/**
 * Searching a fallen monster, like in Fallout: everything it was carrying in a list.
 * Tap something to take it, or take the lot.
 */
@Composable
fun SearchWindow(game: Game) {
    val v = game.searchVersion
    val body = game.searching ?: return
    val items = remember(v, body) { game.searchItems() }
    val gold = remember(v, body) { game.searchGold() }
    LaunchedEffect(body) {
        game.moveX = 0f
        game.moveY = 0f
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.62f)
                .fillMaxHeight(0.9f)
                .background(Color(0xF21B1812), RoundedCornerShape(16.dp))
                .border(2.dp, Palette.gold.copy(alpha = 0.75f), RoundedCornerShape(16.dp))
                .padding(14.dp),
        ) {
            Text("\uD83D\uDD0D  SEARCHING", color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text(game.searchName(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Tap something to take it", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                if (gold > 0) {
                    LootRow("\uD83E\uDE99", "$gold gold", Palette.gold, "Coins", "TAKE") { game.takeGold() }
                }
                items.forEachIndexed { i, item ->
                    LootRow(
                        Slot.ICONS[item.slot],
                        item.name,
                        Color(Rarity.COLORS[item.rarity]),
                        "${Rarity.NAMES[item.rarity]} ${Slot.NAMES[item.slot]}  \u00B7  ${item.stats()}",
                        "TAKE",
                    ) { game.takeItem(i) }
                }
                if (items.isEmpty() && gold == 0) {
                    Text("Nothing left on the body.", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (items.isNotEmpty() || gold > 0) {
                    Button(
                        onClick = { game.takeAll() },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("TAKE ALL", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(10.dp))
                }
                Button(
                    onClick = { game.closeSearch() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A342A), contentColor = Color.White),
                ) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** One line in the loot window. */
@Composable
private fun LootRow(icon: String, name: String, color: Color, detail: String, button: String, onTake: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .pointerInput(name, detail) { detectTapGestures(onTap = { onTake() }) }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(detail, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, maxLines = 1)
        }
        Text(button, color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** A boss steps out to fight you, or falls. */
@Composable
fun BoxScope.BossBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.bossVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(4000)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(450), label = "boss")
    if (a < 0.01f) return
    val defeated = game.bossTitle.endsWith("DEFEATED")
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .padding(bottom = 150.dp)
            .graphicsLayer {
                alpha = a
                scaleX = 0.85f + 0.15f * a
                scaleY = 0.85f + 0.15f * a
            }
            .background(Color(0xCC120C0C), RoundedCornerShape(16.dp))
            .border(1.5.dp, (if (defeated) Palette.gold else Color(0xFFD83A34)).copy(alpha = 0.85f), RoundedCornerShape(16.dp))
            .padding(horizontal = 26.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            if (defeated) game.bossTitle else "\u2620\uFE0F  ${game.bossTitle}",
            color = if (defeated) Palette.gold else Color(0xFFFF5A4A),
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp,
        )
        Text(game.bossLine, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** You walked into the seal round a region you haven't earned yet. */
@Composable
fun BoxScope.SealBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.sealVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3800)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(400), label = "seal")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .padding(horizontal = 60.dp)
            .graphicsLayer { alpha = a }
            .background(Color(0xDD1A1224), RoundedCornerShape(16.dp))
            .border(1.5.dp, Color(0xFFB080FF).copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("\uD83D\uDD12  SEALED", color = Color(0xFFD8A8FF), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Text(game.sealText, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

/** What you need to do next, in plain words. Pops up when you get a new goal; also under Settings. */
@Composable
fun WhatToDoPanel(game: Game, onClose: () -> Unit) {
    val v = game.story.version
    val goal = remember(v) { game.story.objective }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .widthIn(max = 420.dp)
                .fillMaxWidth(0.9f)
                .background(Color(0xF21E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
        ) {
            Text("What to do", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Your goal right now", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Text(
                if (goal.isEmpty()) "Explore, fight, and level up. The story picks up again when you're ready." else goal,
                color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(12.dp))
            Text("Good to know", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Text(
                "\u2022 Build your base BEFORE night falls, and make sure you're back at it before dark. Raiders attack your base at night!\n" +
                    "\u2022 Gather food and watch your hunger. Eat before it runs low.\n" +
                    "\u2022 Talk to people with the TALK button when you're close to them.\n" +
                    "\u2022 Monsters stop chasing you if you get far enough away.\n" +
                    "\u2022 The Book holds your Chronicle of memories, your Tales, and the Bestiary.\n" +
                    "\u2022 The map shows where you are and marks your goal with \uD83C\uDFAF. Pinch or tap +/\u2212 to zoom, and tap GO HOME to travel back to your base.\n" +
                    "\u2022 You can open this screen again from Settings.",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp,
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) {
                Text("GOT IT", fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** News about a quest: given, or ready to hand in. */
@Composable
fun QuestToast(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.questVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3800)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(350), label = "quest")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(bottom = 84.dp),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            game.questToast,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .graphicsLayer { alpha = a }
                .background(Color(0xDD1E1B26), RoundedCornerShape(12.dp))
                .border(1.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .padding(horizontal = 18.dp, vertical = 9.dp)
                .widthIn(max = 280.dp),
        )
    }
}

/** Talking to a villager, trader, elder, guard or lord. Elders and lords may have a quest. */
@Composable
fun TalkWindow(game: Game) {
    val v = game.talkVersion
    val npc = game.talkingTo ?: return
    val quest = remember(v, npc) { game.talkQuest() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxWidth(0.92f)
                .background(Color(0xF21E1B26), RoundedCornerShape(16.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                .padding(16.dp),
        ) {
            Text(npc.title, color = Palette.gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(npc.subtitle, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            if (quest != null) {
                Text(
                    when (quest.state) {
                        QState.READY -> "You've done it. Thank you, truly."
                        QState.ACTIVE -> quest.intro
                        else -> quest.intro
                    },
                    color = Color.White,
                    fontSize = 14.sp,
                )
                Spacer(Modifier.height(6.dp))
                if (quest.state != QState.READY) {
                    Text(quest.goal(), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Reward: ${quest.gold} gold, ${quest.xp} XP" + (if (quest.state == QState.NEW) ", and something good" else ""),
                        color = Palette.gold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            } else {
                Text(game.talkLine, color = Color.White, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (npc.role == NpcRole.TRADER) {
                    Button(
                        onClick = { game.openTrade() },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("BROWSE GOODS", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                } else if (quest != null && quest.state == QState.NEW) {
                    Button(
                        onClick = { game.acceptQuest(quest) },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("ACCEPT", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(10.dp))
                } else if (quest != null && quest.state == QState.READY) {
                    Button(
                        onClick = { game.handInQuest(quest) },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("HAND IN", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(10.dp))
                }
                Button(
                    onClick = { game.closeTalk() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A342A), contentColor = Color.White),
                ) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** A small line at the top of the screen saying what to do next in the story. */
@Composable
fun ObjectiveChip(game: Game) {
    val v = game.story.version
    if (game.story.active || v < 0) return
    val text = game.story.objective
    if (text.isEmpty()) return
    Box(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(top = 60.dp),
        contentAlignment = Alignment.TopCenter,
    ) {
        Text(
            text,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .background(Color(0xAA1E1B26), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 5.dp)
                .widthIn(max = 260.dp),
        )
    }
}

/** A story scene: one line at a time, tap NEXT. The game stands still until it's done. */
@Composable
fun StoryWindow(game: Game) {
    val v = game.story.version
    val lines = game.story.scene ?: return
    if (v < 0 || lines.isEmpty()) return
    val i = game.story.sceneIdx.coerceIn(0, lines.size - 1)
    val line = lines[i]
    val last = i == lines.size - 1
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        // The Keystone's light (1) or Roger's change into the king (2): a glow that breathes behind the scene.
        if (line.fx != 0) {
            val pulse = rememberInfiniteTransition(label = "sceneFx")
            val glow by pulse.animateFloat(
                initialValue = 0.55f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
                label = "glow",
            )
            val core = if (line.fx == 1) Color(0xFFFFE680) else Color(0xFFFFFFFF)
            val rim = if (line.fx == 1) Color(0xFFFFB020) else Color(0xFFC8A02A)
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(core.copy(alpha = 0.85f * glow), rim.copy(alpha = 0.45f * glow), Color.Transparent),
                        ),
                    ),
            )
        }
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxWidth(0.92f)
                .background(Color(0xF21E1B26), RoundedCornerShape(16.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                .padding(16.dp),
        ) {
            if (line.speaker.isNotEmpty()) {
                Text(line.speaker, color = Palette.gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
            }
            Text(line.text, color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Button(
                    onClick = { game.storyNext() },
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                ) {
                    Text(if (last) "DONE" else "NEXT", fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

/** The last screen of the story. */
@Composable
fun EndingOverlay(game: Game, onExit: () -> Unit) {
    if (!game.story.ending) return
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF2000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .safeDrawingPadding()
                .padding(28.dp),
        ) {
            Text("THE END", color = Palette.gold, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Text(
                "Josh and his family are together again. The Grain Rot portal stays open, and the adventure goes on.",
                color = Color.White,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    game.story.finishEnding()
                    onExit()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
            ) {
                Text("RETURN TO TITLE", fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** A trader's stall: their goods to buy, and your bag to sell from. */
@Composable
fun TradeWindow(game: Game) {
    val v = game.talkVersion
    val npc = game.trading ?: return
    val loot = game.loot
    val stock = remember(v, npc) { game.tradeStock() }
    val bag = remember(v, loot.version) { loot.bagItems() }
    val held = remember(v, loot.version) { loot.wielded() }
    val worn = remember(v, loot.version) { loot.wornItems() }
    fun equippedNow(slot: Int): Item? = if (slot == Slot.WEAPON) held else worn.getOrNull(slot)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.94f)
                .fillMaxHeight()
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(14.dp),
        ) {
            // The trader's goods.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(npc.title, color = Palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("\uD83E\uDE99 ${loot.gold}", color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Text("Tap to buy", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    stock.forEachIndexed { i, item ->
                        val price = loot.buyPrice(item)
                        TradeRow(item, "${price}g", loot.gold >= price, equippedNow(item.slot)) { game.buy(i) }
                    }
                    if (stock.isEmpty()) Text("Sold out for now.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                }
            }
            Spacer(Modifier.width(14.dp))
            // Your bag.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Your bag", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(
                        onClick = { game.closeTrade() },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
                Text("What you're wearing", color = Color(0xFF9FD8FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x1A9FD8FF))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                ) {
                    for (slot in intArrayOf(Slot.WEAPON, Slot.HEAD, Slot.BODY, Slot.HANDS, Slot.FEET, Slot.RING, Slot.AMULET)) {
                        val it = equippedNow(slot)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
                            Text(Slot.ICONS[slot], fontSize = 12.sp)
                            Spacer(Modifier.width(5.dp))
                            if (it == null) {
                                Text("${Slot.NAMES[slot]}: empty", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp, maxLines = 1)
                            } else {
                                Text(it.name, color = Color(Rarity.COLORS[it.rarity]), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Spacer(Modifier.width(6.dp))
                                Text(it.stats(), color = Color.White.copy(alpha = 0.55f), fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Tap to sell", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    if (bag.isEmpty()) Text("Nothing to sell.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    bag.forEachIndexed { i, item ->
                        TradeRow(item, "${loot.sellPrice(item)}g", true, equippedNow(item.slot)) { game.sell(i) }
                    }
                }
            }
        }
    }
}

@Composable
private fun TradeRow(item: Item, price: String, affordable: Boolean, equipped: Item?, onTap: () -> Unit) {
    val gear = item.slot <= Slot.WEAPON && item.slot != Slot.POTION && item.slot != Slot.FOOD && item.slot != Slot.GEM
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, Color(Rarity.COLORS[item.rarity]).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .pointerInput(item, price) { detectTapGestures(onTap = { if (affordable) onTap() }) }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(Slot.ICONS[item.slot], fontSize = 18.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = Color(Rarity.COLORS[item.rarity]), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(item.stats(), color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1)
            if (gear) {
                if (equipped == null) {
                    Text("Wearing: nothing in this slot  \u2192  all new", color = Color(0xFF9FD8FF), fontSize = 10.sp, maxLines = 1)
                } else {
                    Text("Wearing: ${equipped.name}", color = Color(0xFF9FD8FF), fontSize = 10.sp, maxLines = 1)
                    val changes = ArrayList<Pair<String, Int>>()
                    if (item.def != equipped.def) changes.add("Defense" to item.def - equipped.def)
                    if (item.pow != equipped.pow) changes.add("Power" to item.pow - equipped.pow)
                    if (item.vit != equipped.vit) changes.add("Health" to item.vit - equipped.vit)
                    if (item.spd != equipped.spd) changes.add("Speed" to item.spd - equipped.spd)
                    if (changes.isEmpty()) {
                        Text("Same as what you wear", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp, maxLines = 1)
                    } else {
                        Row {
                            for ((label, d) in changes) {
                                Text(
                                    (if (d > 0) "\u25B2 +$d " else "\u25BC $d ") + label,
                                    color = if (d > 0) Color(0xFF5BE07A) else Color(0xFFFF6B6B),
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                        }
                    }
                }
            }
        }
        Text(price, color = if (affordable) Palette.gold else Color(0xFF8A5A5A), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** Monsters you've fought (Bestiary) and story fragments you've found (Chronicle). */
@Composable
fun BookPanel(game: Game, onClose: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val v = game.loot.version
    val discovered = remember(v) { game.loot.discoveredSet() }
    val loreHad = remember(v) { game.loot.loreSet() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.86f)
                .background(Color(0xF21E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Book", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                BookTab("Bestiary", tab == 0, Modifier.weight(1f)) { tab = 0 }
                Spacer(Modifier.width(8.dp))
                BookTab("Chronicle", tab == 1, Modifier.weight(1f)) { tab = 1 }
                Spacer(Modifier.width(8.dp))
                BookTab("Tales", tab == 2, Modifier.weight(1f)) { tab = 2 }
            }
            Spacer(Modifier.height(8.dp))
            if (tab == 0) BestiaryList(game, discovered)
            else if (tab == 1) ChronicleList(loreHad, LoreBook.memories, "memories restored")
            else ChronicleList(loreHad, LoreBook.fragments, "tales found")
        }
    }
}

@Composable
private fun BookTab(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (on) Palette.gold.copy(alpha = 0.22f) else Color(0x22FFFFFF))
            .border(1.dp, if (on) Palette.gold else Color.White.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Palette.gold else Color.White.copy(alpha = 0.7f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ColumnScope.BestiaryList(game: Game, discovered: Set<Int>) {
    val total = remember { game.fauna.species.count { it.monster } }
    Text("${discovered.size} / $total monsters catalogued", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
        for (zone in ZONE_ORDER) {
            val entries = game.fauna.species.withIndex()
                .filter { it.value.monster && it.value.zones[0] == zone }
                .sortedBy { it.value.levelMin }
            if (entries.isEmpty()) continue
            Text(
                zone.title, color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
            )
            for ((idx, sp) in entries) {
                val known = idx in discovered
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x22FFFFFF))
                        .padding(10.dp),
                ) {
                    Row {
                        Text(
                            if (known) sp.name else "???",
                            color = if (known) Color.White else Color.White.copy(alpha = 0.35f),
                            fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                        )
                        Text("Lv ${sp.levelMin}-${sp.levelMax}", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                    }
                    if (known) {
                        Text(
                            "HP ${sp.hp}   Damage ${sp.damage.toInt()}   Defense ${(sp.defense * 100).toInt()}%",
                            color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp,
                        )
                        if (sp.ability != Ability.NONE) {
                            Text(
                                "${Ability.label(sp.ability)} \u2014 ${Ability.desc(sp.ability)}",
                                color = Color(0xFFE0A85A), fontSize = 11.sp,
                            )
                        }
                    } else {
                        Text("Fight one to learn what it can do.", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.ChronicleList(had: Set<Int>, list: List<LoreFragment>, noun: String) {
    Text("${list.count { it.id in had }} / ${list.size} $noun", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
        for (f in list) {
            val known = f.id in had
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x22FFFFFF))
                    .padding(10.dp),
            ) {
                Text(
                    if (known) f.title else "???",
                    color = if (known) Palette.gold else Color.White.copy(alpha = 0.35f),
                    fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    if (known) f.text else if (f.id >= 100) "A memory not yet restored. Keep following the story." else "A tale not yet found, somewhere in ${f.zone?.title ?: "the world"}.",
                    color = Color.White.copy(alpha = if (known) 0.75f else 0.4f), fontSize = 12.sp,
                )
            }
        }
    }
}

/** Your main missions and side quests: what's active, and what's ready to hand in. */
@Composable
fun QuestLogPanel(game: Game, onClose: () -> Unit) {
    val v = game.quests.version
    val list = remember(v) { game.quests.current() }
    val done = remember(v) { game.quests.finishedCount() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.86f)
                .background(Color(0xF21E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quest Log", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
            Text("$done quests completed", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                if (list.isEmpty()) {
                    Text(
                        "No active quests. Look for a notice board or an elder in any town, or the lord of a castle, marked with a gold sign over their head.",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                    )
                }
                for (q in list) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (q.main) Palette.gold.copy(alpha = 0.12f) else Color(0x22FFFFFF))
                            .border(
                                1.dp,
                                (if (q.state == QState.READY) Color(0xFF5AE0C0) else Palette.gold).copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp),
                            )
                            .padding(10.dp),
                    ) {
                        Row {
                            Text(
                                if (q.main) "\u2694\uFE0F MAIN" else "SIDE",
                                color = if (q.main) Palette.gold else Color.White.copy(alpha = 0.5f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.weight(1f),
                            )
                            if (q.state == QState.READY) {
                                Text("READY TO HAND IN", color = Color(0xFF5AE0C0), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Text(q.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(q.goal(), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        Text("${q.gold} gold  \u00B7  ${q.xp} XP", color = Palette.gold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}


// ---------- Building ----------

/** Your wood, stone and iron, just under the buttons in the top-left corner. */
@Composable
fun BoxScope.ResourceChip(game: Game) {
    val v = game.base.version
    val res = game.base.res
    if (v < 0 || (!game.buildMode && res[0] + res[1] + res[2] == 0)) return
    Row(
        modifier = Modifier
            .align(Alignment.TopStart)
            .safeDrawingPadding()
            .padding(start = 12.dp, top = 64.dp)
            .background(Color(0xAA15131C), RoundedCornerShape(12.dp))
            .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (r in 0 until Res.COUNT) {
            if (r > 0) Spacer(Modifier.width(10.dp))
            Text(Res.ICONS[r], fontSize = 14.sp)
            Spacer(Modifier.width(3.dp))
            Text("${res[r]}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        // Your tools, and how much wear is left in each (red when it's about to break).
        for (axe in booleanArrayOf(true, false)) {
            val tier = if (axe) game.base.axeTier else game.base.pickTier
            if (tier == 0) continue
            val left = game.base.toolLeft(axe)
            Spacer(Modifier.width(10.dp))
            Text(if (axe) "\uD83E\uDE93" else "\u26CF\uFE0F", fontSize = 13.sp)
            Text(
                "${(left * 100f).toInt().coerceAtLeast(1)}%",
                color = if (left < 0.15f) Color(0xFFFF6A5A) else if (left < 0.35f) Color(0xFFFFB347) else Color(0xFFB8F0B0),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

/** A small skull badge so you never forget this run has only one life. */
@Composable
fun BoxScope.HardcoreBadge(game: Game) {
    if (!game.hardcore || game.buildMode) return
    Text(
        "\u2620\uFE0F HARDCORE",
        color = Color(0xFFFF6A6A),
        fontSize = 11.sp,
        fontWeight = FontWeight.ExtraBold,
        modifier = Modifier
            .align(Alignment.TopStart)
            .safeDrawingPadding()
            .padding(start = 12.dp, top = 128.dp)
            .background(Color(0xCC2A0A0E), RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
    )
}

/** Warns you a raid is coming at your base, and counts down to it. */
@Composable
fun BoxScope.RaidWarnChip(game: Game) {
    if (!game.raidWarnActive || game.buildMode) return
    val pct = (100 - (game.raidWarnFrac * 100).toInt()).coerceIn(0, 100)
    val label = if (pct > 80) "Raid coming with nightfall" else "Raid approaching \u2014 $pct% of dusk left"
    Text(
        "\uD83D\uDEA8 $label \u2014 fortify your base!",
        color = Color(0xFFFF9B4A),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = Modifier
            .align(Alignment.TopStart)
            .safeDrawingPadding()
            .padding(start = 12.dp, top = 72.dp)
            .background(Color(0xCC3A2410), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFFFF9B4A).copy(alpha = 0.8f), RoundedCornerShape(10.dp))
            .padding(horizontal = 9.dp, vertical = 4.dp),
    )
}

/** When the next world boss is due, or where the one that's out is and how long it has left. */
@Composable
fun BoxScope.WorldBossChip(game: Game) {
    val text = game.wbText
    if (text.isEmpty() || game.buildMode) return
    val out = game.wbOut
    Text(
        text,
        color = if (out) Palette.gold else Color.White.copy(alpha = 0.8f),
        fontSize = 12.sp,
        fontWeight = if (out) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier
            .align(Alignment.TopStart)
            .safeDrawingPadding()
            .padding(start = 12.dp, top = 100.dp)
            .background(Color(if (out) 0xCC3A0E12 else 0x8815131C), RoundedCornerShape(10.dp))
            .border(1.dp, (if (out) Color(0xFFFF3B5C) else Color.White).copy(alpha = if (out) 0.8f else 0.2f), RoundedCornerShape(10.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { game.tapWorldBoss() }) }
            .padding(horizontal = 9.dp, vertical = 4.dp),
    )
}

/** Fades to black and back when you sleep. */
@Composable
fun SleepFade(game: Game) {
    val visit = game.sleepVisit
    val dark = remember { Animatable(0f) }
    LaunchedEffect(visit) {
        if (visit > 0) {
            dark.snapTo(1f)
            delay(900)
            dark.animateTo(0f, tween(1600))
        }
    }
    if (dark.value > 0.01f) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dark.value)), contentAlignment = Alignment.Center) {
            Text("Zzz...", color = Color.White.copy(alpha = dark.value), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * An open chest or fridge: what's inside on top (tap to take it), your bag underneath (tap to put
 * it in). Fridges only take food.
 */
@Composable
fun StoragePanel(game: Game, onClose: () -> Unit) {
    val p = game.storeOpen ?: return
    val v = game.storeVisit + game.base.version + game.loot.version
    val inside = remember(v) { game.base.stored(p) }
    val bag = remember(v) { game.loot.bagItems() }
    val cap = PieceType.capacity(p.type)
    val fridge = p.type == PieceType.FRIDGE
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xAA000000))
            .pointerInput(Unit) { detectTapGestures { onClose() } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 480.dp)
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${PieceType.ICONS[p.type]}  ${PieceType.NAMES[p.type].uppercase()}   ${inside.size} / $cap",
                    color = Palette.gold,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "\u2715",
                    color = Color.White,
                    fontSize = 20.sp,
                    modifier = Modifier.pointerInput(Unit) { detectTapGestures { onClose() } }.padding(6.dp),
                )
            }
            Text(
                if (fridge) "Tap food to take it out. Tap food in your bag to put it in. Only food goes in the fridge." else "Tap something to take it out. Tap something in your bag to put it in.",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 11.sp,
            )
            Spacer(Modifier.height(6.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                if (inside.isEmpty()) Text("Empty.", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                inside.forEachIndexed { i, item -> StoreRow(item, "TAKE", true) { game.storeWithdraw(i) } }
            }
            Spacer(Modifier.height(6.dp))
            Text("YOUR BAG  (${bag.size})", color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                if (bag.isEmpty()) Text("Nothing in your bag.", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                bag.forEachIndexed { i, item ->
                    val ok = (!fridge || item.slot == Slot.FOOD) && inside.size < cap
                    StoreRow(item, "STORE", ok) { if (ok) game.storeDeposit(i) }
                }
            }
        }
    }
}

@Composable
private fun StoreRow(item: Item, verb: String, enabled: Boolean, onTap: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, Color(Rarity.COLORS[item.rarity.coerceIn(0, Rarity.MAX)]).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .pointerInput(item, verb, enabled) { detectTapGestures(onTap = { onTap() }) }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f },
    ) {
        Text(Slot.ICONS[item.slot.coerceIn(0, Slot.ICONS.size - 1)], fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = Color(Rarity.COLORS[item.rarity.coerceIn(0, Rarity.MAX)]), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(item.stats(), color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp, maxLines = 1)
        }
        Text(verb, color = Palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

/** "+2 wood" floating up each time a blow lands on a tree or rock. */
@Composable
fun BoxScope.ResToast(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.resVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(1100)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(250), label = "res")
    if (a < 0.01f) return
    Text(
        game.resToast,
        color = Color.White,
        fontSize = 15.sp,
        fontWeight = FontWeight.ExtraBold,
        style = TextStyle(shadow = Shadow(Color.Black, Offset(1f, 2f), 4f)),
        modifier = Modifier
            .align(Alignment.Center)
            .padding(top = 90.dp)
            .graphicsLayer {
                alpha = a
                translationY = (1f - a) * 18f
            },
    )
}

/** Build mode: a crosshair to aim with, the pieces you can place, and PLACE / TURN / REMOVE. */
@Composable
fun BoxScope.BuildHud(game: Game) {
    val tick = game.hudTick
    val v = game.base.version
    // Crosshair: the middle of the screen is where the piece goes.
    Canvas(Modifier.align(Alignment.Center).size(22.dp)) {
        val ok = tick >= 0L && game.ghost.ok
        val c = if (ok) Color(0xFF6CFF7A) else Color(0xFFFF6A5A)
        drawCircle(Color.Black.copy(alpha = 0.5f), radius = size.minDimension / 2f, style = Stroke(width = 4.dp.toPx()))
        drawCircle(c, radius = size.minDimension / 2f, style = Stroke(width = 2.dp.toPx()))
        drawCircle(c, radius = 2.dp.toPx())
    }
    // The pieces, along the bottom where the quick slots usually are.
    Column(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .safeDrawingPadding()
            .padding(bottom = 8.dp)
            .widthIn(max = 440.dp)
            .background(Color(0xCC15131C), RoundedCornerShape(14.dp))
            .border(1.dp, Palette.gold.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            if (tick >= 0L) game.buildHint else "",
            color = if (game.ghost.ok) Color.White else Color(0xFFFFB0A6),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 2,
        )
        Spacer(Modifier.height(5.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            for (t in PieceType.ORDER) {
                val on = game.buildType == t
                val afford = v >= 0 && game.base.has(t)
                Column(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (on) Palette.gold.copy(alpha = 0.9f) else Color(0x33FFFFFF))
                        .border(1.dp, Color.White.copy(alpha = if (on) 0.9f else 0.25f), RoundedCornerShape(10.dp))
                        .pointerInput(t) { detectTapGestures(onTap = { game.selectPiece(t) }) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .widthIn(min = 58.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(PieceType.ICONS[t], fontSize = 18.sp)
                    Text(
                        PieceType.NAMES[t].replace("Crafting ", ""),
                        color = if (on) Color(0xFF1E2A22) else Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        PieceType.costText(t),
                        color = if (on) Color(0xFF1E2A22) else if (afford) Color(0xFFB8F0B0) else Color(0xFFFFB0A6),
                        fontSize = 10.sp,
                    )
                }
            }
        }
    }
    // PLACE, TURN and REMOVE, just left of the fighting buttons.
    Column(
        modifier = Modifier
            .align(Alignment.CenterEnd)
            .safeDrawingPadding()
            .padding(end = 200.dp, bottom = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        HudButton("PLACE", active = game.ghost.ok, size = 70.dp, fontSize = 13.sp) { game.placePiece() }
        Spacer(Modifier.height(10.dp))
        if (PieceType.turns(game.buildType)) {
            HudButton("TURN", active = false, size = 50.dp, fontSize = 11.sp) { game.rotatePiece() }
            Spacer(Modifier.height(10.dp))
        }
        HudButton("REMOVE", active = false, size = 50.dp, fontSize = 9.sp) { game.removePiece() }
        Spacer(Modifier.height(10.dp))
        // Aim at a finished wooden wall or gable and rebuild it in stone, right where it stands.
        HudButton("STONE", active = false, size = 50.dp, fontSize = 10.sp) { game.upgradePiece() }
    }
}

/** The crafting bench: make axes and pickaxes from what you've gathered. */
@Composable
fun CraftPanel(game: Game, onClose: () -> Unit) {
    val v = game.base.version
    val res = game.base.res
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xAA000000))
            .pointerInput(Unit) { detectTapGestures { onClose() } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 460.dp)
                .fillMaxWidth(0.9f)
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("\uD83D\uDEE0\uFE0F  CRAFTING BENCH", color = Palette.gold, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                if (v >= 0) (0 until Res.COUNT).joinToString("     ") { "${Res.ICONS[it]} ${res[it]}  ${Res.NAMES[it]}" } else "",
                color = Color.White,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(12.dp))
            for (r in 0 until Recipe.COUNT) {
                val owned = game.base.owns(r)
                val afford = game.base.canAfford(Recipe.COST[r])
                // Iron tools only once you have the stone one.
                val locked = (r == Recipe.IRON_AXE && game.base.bestAxe < 1) || (r == Recipe.IRON_PICK && game.base.bestPick < 1)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(Color(0x22FFFFFF), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(Recipe.ICONS[r], fontSize = 24.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(Recipe.NAMES[r], color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(Recipe.INFO[r], color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp)
                        Text(
                            Recipe.costText(r),
                            color = if (afford) Color(0xFFB8F0B0) else Color(0xFFFFB0A6),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    val full = r == Recipe.ARROWS && game.loot.arrows >= QUIVER_MAX
                    val canMake = !owned && !locked && afford && !full
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (canMake) Palette.gold else Color(0x44FFFFFF))
                            .pointerInput(r, canMake) { detectTapGestures { if (canMake) game.craft(r) } }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    ) {
                        Text(
                            when {
                                owned -> "OWNED"
                                full -> "FULL"
                                locked -> "NEED STONE"
                                else -> "MAKE"
                            },
                            color = if (canMake) Color(0xFF1E2A22) else Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Bare hands gather slowly. An axe fells trees and a pickaxe breaks rocks, which is where iron comes from.",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x44FFFFFF))
                    .pointerInput(Unit) { detectTapGestures { onClose() } }
                    .padding(horizontal = 26.dp, vertical = 9.dp),
            ) {
                Text("CLOSE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * The opening cinematic, at the start of a new game: losing to Nullfang in the Grain Rot, thrown
 * back through a portal into Greenhollow, found by the villagers with no memory at all. Then on
 * to choosing a class. Can be skipped.
 */
@Composable
fun IntroScreen(game: Game, onDone: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    // A sword in his hand for the fight he's losing; the class you pick afterwards replaces it.
    val started = remember {
        game.weaponClass = WeaponClass.SWORD
        game.startIntro()
    }
    var tick by remember { mutableStateOf(0L) }
    var finished by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        Sound.load(context)
        Sound.wanted = true
        Sound.start()
        onDispose {
            Sound.wanted = false
            Sound.stop()
            view.keepScreenOn = false
            GlHolder.view = null
        }
    }
    var failMsg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        if (!started) {
            failMsg = game.introFailReason
            if (failMsg.isEmpty()) {
                finished = true
                onDone()
            }
            return@LaunchedEffect
        }
        while (true) {
            withFrameNanos { tick = it }
            val io = game.intro
            if (io == null || io.done) {
                game.endIntro()
                finished = true
                onDone()
                break
            }
        }
    }
    // Couldn't build the cinematic: say why instead of just vanishing into class select,
    // and give a button through since there's nothing more to show.
    if (failMsg.isNotEmpty()) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Couldn't start the cinematic:", color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text(failMsg, color = Color(0xFFFFB04A), fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Palette.gold)
                        .pointerInput(Unit) { detectTapGestures { onDone() } }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                ) {
                    Text("CONTINUE", color = Color(0xFF1E2A22), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        return
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (started && !finished) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    GLSurfaceView(ctx).apply {
                        setEGLContextClientVersion(2)
                        setEGLConfigChooser(DepthConfigChooser())
                        preserveEGLContextOnPause = true
                        setRenderer(WorldRenderer(game))
                        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                        GlHolder.view = this
                    }
                },
            )
        }
        val io = game.intro
        if (io != null && tick >= 0L) {
            // Taking a beating: the edges of the screen flash red.
            if (io.hurtFlash > 0f) {
                Box(Modifier.fillMaxSize().background(Color(0xFFB0141C).copy(alpha = 0.35f * io.hurtFlash)))
            }
            // Letterbox bars, like a film.
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.11f).align(Alignment.TopCenter).background(Color.Black))
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.11f).align(Alignment.BottomCenter).background(Color.Black))

            // The fight's health bars: his draining away, Nullfang's untouched.
            if (io.showBars) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .safeDrawingPadding()
                        .padding(top = 30.dp, start = 24.dp, end = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    IntroBar("???", io.heroHp, Color(0xFFE0453A))
                    IntroBar(ROT_LORD_NAME, io.bossHp, Color(0xFFC86BFF))
                }
            }

            // Where we are.
            if (io.title.isNotEmpty()) {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(bottom = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(io.title, color = Palette.gold, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 6.sp)
                    if (io.subtitle.isNotEmpty()) {
                        Text(io.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, letterSpacing = 2.sp)
                    }
                }
            }

            // Who's speaking, and what they say.
            if (io.caption.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(bottom = 46.dp, start = 40.dp, end = 40.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(12.dp))
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    if (io.speaker.isNotEmpty()) {
                        Text(
                            io.speaker.uppercase(),
                            color = if (io.speaker == "Nullfang") Color(0xFFC86BFF) else Palette.gold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp,
                        )
                    }
                    Text(io.caption, color = Color.White, fontSize = 17.sp, textAlign = TextAlign.Center)
                }
            }

            // The flash of the portal, and the fades in and out.
            if (io.white > 0f) Box(Modifier.fillMaxSize().background(Color(0xFFF4FFE8).copy(alpha = io.white.coerceIn(0f, 1f))))
            if (io.black > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = io.black.coerceIn(0f, 1f))))

            // Skip.
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .safeDrawingPadding()
                    .padding(top = 6.dp, end = 14.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x66000000))
                    .border(1.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                    .pointerInput(Unit) { detectTapGestures { game.intro?.skipAsked = true } }
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            ) {
                Text("SKIP \u25B6\u25B6", color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** One health bar in the opening fight: a name over a bar. */
@Composable
private fun IntroBar(name: String, frac: Float, color: Color) {
    Column(Modifier.width(220.dp)) {
        Text(name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(3.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(9.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(Color(0x99000000))
                .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(5.dp)),
        ) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color))
        }
    }
}
