package com.keystone.rpg

import android.content.Context
import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Image
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.TextUnit
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** The 3D view, kept here so the activity can pause and resume it. */
private object GlHolder {
    var view: GLSurfaceView? = null
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent { KeystoneApp() }
    }

    override fun onPause() {
        super.onPause()
        GlHolder.view?.onPause()
        Sound.stop()
    }

    override fun onResume() {
        super.onResume()
        GlHolder.view?.onResume()
        if (Sound.wanted) Sound.start()
    }
}

@Composable
fun KeystoneApp() {
    // 0 = title, 1 = choosing a weapon, 2 = playing.
    var stage by remember { mutableIntStateOf(0) }
    var game by remember { mutableStateOf<Game?>(null) }
    // Building the world takes a few seconds, so do it behind the title screen.
    LaunchedEffect(Unit) {
        game = withContext(Dispatchers.Default) { Game(World()) }
    }
    val ready = game
    if (stage == 2 && ready != null) {
        GameScreen(ready)
    } else if (stage == 1 && ready != null) {
        ClassSelectScreen(onBegin = { chosen ->
            ready.weaponClass = chosen
            stage = 2
        })
    } else {
        TitleScreen(ready = ready != null, onStart = { stage = 1 })
    }
}

@Composable
fun TitleScreen(ready: Boolean, onStart: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E3B2F), Color(0xFF0F1D17))))
            .safeDrawingPadding()
            .padding(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Keystone", color = Palette.gold, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Explore the wilds. Find the keys.\nOpen up the world.",
                color = Color(0xFFCFE3D6),
                fontSize = 17.sp,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp,
            )
            Spacer(Modifier.height(22.dp))
            Button(
                onClick = onStart,
                enabled = ready,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Palette.gold,
                    contentColor = Color(0xFF1E2A22),
                    disabledContainerColor = Palette.gold.copy(alpha = 0.35f),
                    disabledContentColor = Color(0xFF1E2A22),
                ),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .width(320.dp)
                    .height(54.dp),
            ) {
                Text(
                    if (ready) "Start adventure" else "Building the world…",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("Early build: explore the world", color = Color(0xFF8FA99A), fontSize = 13.sp)
        }
    }
}

@Composable
fun GameScreen(game: Game) {
    var stickOrigin by remember { mutableStateOf<Offset?>(null) }
    var stickKnob by remember { mutableStateOf(Offset.Zero) }
    var hasMoved by remember { mutableStateOf(false) }
    var hasLooked by remember { mutableStateOf(false) }
    var runOn by remember { mutableStateOf(false) }
    var mapOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var bagOpen by remember { mutableStateOf(false) }
    val context0 = LocalContext.current
    var thirdPerson by remember {
        mutableStateOf(
            context0.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("third", true),
        )
    }
    game.thirdPerson = thirdPerson
    var autoFight by remember {
        mutableStateOf(
            context0.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("auto_fight", false),
        )
    }
    game.autoFight = autoFight
    val density = LocalDensity.current.density
    val context = LocalContext.current
    val openMap = {
        game.moveX = 0f
        game.moveY = 0f
        stickOrigin = null
        mapOpen = true
    }

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        Sound.load(context)
        game.loadSave(context)
        Sound.wanted = true
        Sound.start()
        onDispose {
            Sound.wanted = false
            Sound.stop()
            view.keepScreenOn = false
            GlHolder.view = null
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.night)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setEGLConfigChooser(DepthConfigChooser())
                    preserveEGLContextOnPause = true
                    setRenderer(WorldRenderer(game))
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    GlHolder.view = this
                }
            },
        )

        // Touch layer: left half of the screen walks, right half looks around.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(game) {
                    val maxR = 56.dp.toPx()
                    val lookScale = 0.012f / density
                    awaitPointerEventScope {
                        var moveId: PointerId? = null
                        var lookId: PointerId? = null
                        var origin = Offset.Zero
                        var lastLook = Offset.Zero
                        while (true) {
                            val event = awaitPointerEvent()
                            for (change in event.changes) {
                                val pos = change.position
                                if (change.pressed && !change.previousPressed) {
                                    if (pos.x < size.width / 2f && moveId == null) {
                                        moveId = change.id
                                        origin = pos
                                        stickOrigin = pos
                                        stickKnob = pos
                                    } else if (lookId == null) {
                                        lookId = change.id
                                        lastLook = pos
                                    }
                                } else if (change.pressed) {
                                    if (change.id == moveId) {
                                        var d = pos - origin
                                        var len = d.getDistance()
                                        if (len > maxR) {
                                            origin = pos - d * (maxR / len)
                                            d = pos - origin
                                            len = maxR
                                            stickOrigin = origin
                                        }
                                        stickKnob = pos
                                        if (len > maxR * 0.12f) {
                                            game.moveX = d.x / maxR
                                            game.moveY = d.y / maxR
                                            hasMoved = true
                                        } else {
                                            game.moveX = 0f
                                            game.moveY = 0f
                                        }
                                    } else if (change.id == lookId) {
                                        val d = pos - lastLook
                                        lastLook = pos
                                        game.addLook(d.x * lookScale, d.y * lookScale)
                                        if (d.getDistance() > 2f) hasLooked = true
                                    }
                                } else if (!change.pressed && change.previousPressed) {
                                    if (change.id == moveId) {
                                        moveId = null
                                        stickOrigin = null
                                        game.moveX = 0f
                                        game.moveY = 0f
                                    }
                                    if (change.id == lookId) lookId = null
                                }
                                change.consume()
                            }
                        }
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                stickOrigin?.let { o ->
                    val r = 56.dp.toPx()
                    drawCircle(color = Color.White.copy(alpha = 0.12f), radius = r, center = o)
                    drawCircle(
                        color = Color.White.copy(alpha = 0.35f),
                        radius = r,
                        center = o,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                    drawCircle(color = Color.White.copy(alpha = 0.6f), radius = 24.dp.toPx(), center = stickKnob)
                }
            }
        }

        // Soft darkening towards the screen edges, like a camera lens.
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    0.6f to Color.Transparent,
                    1f to Color(0x55000000),
                    center = center,
                    radius = size.maxDimension * 0.62f,
                ),
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Minimap(game, Modifier.pointerInput(Unit) { detectTapGestures { openMap() } })
            Spacer(Modifier.height(4.dp))
            GridRef(game)
            Spacer(Modifier.height(6.dp))
            HudButton("MAP", active = false, size = 52.dp) { openMap() }
        }

        // Settings gear and the camera switch live in the top-left corner, clear of the action buttons.
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudButton("\u2699", active = false, size = 44.dp, fontSize = 22.sp) {
                game.moveX = 0f
                game.moveY = 0f
                stickOrigin = null
                settingsOpen = true
            }
            Spacer(Modifier.width(10.dp))
            // Equipment: your bag and what you're wearing.
            HudButton("\uD83C\uDF92", active = false, size = 44.dp, fontSize = 20.sp) {
                game.moveX = 0f
                game.moveY = 0f
                stickOrigin = null
                bagOpen = true
            }
            Spacer(Modifier.width(10.dp))
            HudButton("VIEW", active = !thirdPerson, size = 44.dp, fontSize = 11.sp) {
                thirdPerson = !thirdPerson
                game.thirdPerson = thirdPerson
                context.getSharedPreferences("keystone_view", Context.MODE_PRIVATE)
                    .edit().putBoolean("third", thirdPerson).apply()
            }
        }

        HurtFlash(game)
        ZoneBanner(game)
        DiscoveryBanner(game)
        TargetPanel(game)

        PlayerBars(
            game,
            Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .padding(bottom = 12.dp),
        )
        LevelUpBanner(game)

        // Action buttons under the right thumb.
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .safeDrawingPadding()
                .padding(end = 24.dp, bottom = 22.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Attack with your weapon. The button shows the weapon you chose.
                WeaponButton(
                    icon = when (game.weaponClass) {
                        WeaponClass.KUNAI -> R.drawable.icon_kunai
                        WeaponClass.HALBERD -> R.drawable.icon_halberd
                        else -> R.drawable.icon_sword
                    },
                    size = 64.dp,
                ) { game.attack() }
                Spacer(Modifier.height(12.dp))
                HudButton("RUN", active = runOn, size = 70.dp) {
                    runOn = !runOn
                    game.runOn = runOn
                }
            }
            Spacer(Modifier.width(16.dp))
            Box(Modifier.padding(bottom = 46.dp)) {
                HudButton("JUMP", active = false, size = 82.dp) { game.jump() }
            }
        }

        if (!hasMoved || !hasLooked) {
            Text(
                "Left thumb: walk     Right thumb: look",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 44.dp)
                    .background(Color(0xAA15131C), RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }

        ActionButton(game)
        LootPopup(game)
        DefeatOverlay(game)
        CaveFade(game)

        if (mapOpen) {
            WorldMap(game, onClose = { mapOpen = false })
        }
        if (bagOpen) {
            EquipmentPanel(game, onClose = { bagOpen = false })
        }
        if (settingsOpen) {
            SettingsPanel(
                autoFight = autoFight,
                onAutoFight = {
                    autoFight = it
                    game.autoFight = it
                    context.getSharedPreferences("keystone_view", Context.MODE_PRIVATE)
                        .edit().putBoolean("auto_fight", it).apply()
                },
                onClose = { settingsOpen = false },
            )
        }
    }
}

/** Settings: how loud each kind of sound is. Remembered between games. */
@Composable
fun SettingsPanel(autoFight: Boolean, onAutoFight: (Boolean) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var steps by remember { mutableFloatStateOf(Sound.volSteps) }
    var wind by remember { mutableFloatStateOf(Sound.volWind) }
    var rain by remember { mutableFloatStateOf(Sound.volRain) }
    var animals by remember { mutableFloatStateOf(Sound.volAnimals) }
    var music by remember { mutableFloatStateOf(Sound.volMusic) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAA000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .width(420.dp)
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 14.dp),
        ) {
            Text("Settings", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Sound", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            VolumeRow("Music", music) {
                music = it
                Sound.setMusicVolume(it)
                Sound.save(ctx)
            }
            VolumeRow("Footsteps", steps) {
                steps = it
                Sound.volSteps = it
                Sound.save(ctx)
            }
            VolumeRow("Wind", wind) {
                wind = it
                Sound.volWind = it
                Sound.save(ctx)
            }
            VolumeRow("Rain & thunder", rain) {
                rain = it
                Sound.volRain = it
                Sound.save(ctx)
            }
            VolumeRow("Animals", animals) {
                animals = it
                Sound.volAnimals = it
                Sound.save(ctx)
            }
            Spacer(Modifier.height(8.dp))
            Text("Combat", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Auto fight", color = Color.White, fontSize = 15.sp)
                    Text(
                        "Attacks anything that comes close, by itself",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp,
                    )
                }
                Button(
                    onClick = { onAutoFight(!autoFight) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (autoFight) Palette.gold else Color(0xFF3A3644),
                        contentColor = if (autoFight) Color(0xFF1E2A22) else Color.White,
                    ),
                ) {
                    Text(if (autoFight) "ON" else "OFF", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) {
                Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun VolumeRow(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(44.dp)) {
        Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.width(120.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Palette.gold,
                activeTrackColor = Palette.gold,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
            ),
        )
        Text(
            "${(value * 100f).toInt()}%",
            color = Color.White,
            fontSize = 14.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(48.dp),
        )
    }
}

/** The attack button: a picture of your weapon in a gold ring. Reacts the moment you touch it. */
@Composable
fun WeaponButton(icon: Int, size: Dp, onPress: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0x77000000))
            .border(2.dp, Palette.gold.copy(alpha = 0.85f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(icon),
            contentDescription = "Attack",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().padding(7.dp),
        )
    }
}

/** What the weapon-choosing screen shows about each weapon. */
private class WeaponInfo(
    val cls: Int,
    val name: String,
    val style: String,
    val art: Int,
    val power: Float,
    val speed: Float,
    val reach: Float,
    val accent: Color,
)

/** Before the adventure starts: pick the weapon you'll fight with. */
@Composable
fun ClassSelectScreen(onBegin: (Int) -> Unit) {
    val infos = listOf(
        WeaponInfo(
            WeaponClass.KUNAI, "Bloodsworn Kunai", "Throw kunai without end.\nStrike from far away.",
            R.drawable.class_kunai, 0.55f, 0.9f, 1f, Color(0xFFD2323A),
        ),
        WeaponInfo(
            WeaponClass.HALBERD, "Rotroot Halberd", "Double swing: a spinning\nsweep, then a crushing slam.",
            R.drawable.class_halberd, 0.95f, 0.4f, 0.8f, Color(0xFF6CCB5F),
        ),
        WeaponInfo(
            WeaponClass.SWORD, "Mind, Body & Soul", "Triple swing: two slashes\nand an overhead chop.",
            R.drawable.class_sword, 0.75f, 0.65f, 0.55f, Color(0xFFF08AB8),
        ),
    )
    var chosen by remember { mutableIntStateOf(-1) }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "glow",
    )
    val bob by pulse.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob",
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E3B2F), Color(0xFF0F1D17))))
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "CHOOSE YOUR WEAPON",
                color = Palette.gold,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
            )
            Text(
                "Your weapon decides how you fight. Choose wisely.",
                color = Color(0xFFCFE3D6),
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                infos.forEachIndexed { i, info ->
                    WeaponCard(
                        info = info,
                        selected = chosen == i,
                        dimmed = chosen >= 0 && chosen != i,
                        glow = glow,
                        bob = bob,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onTap = { chosen = i },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (chosen >= 0) onBegin(infos[chosen].cls) },
                enabled = chosen >= 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Palette.gold,
                    contentColor = Color(0xFF1E2A22),
                    disabledContainerColor = Color(0xFF3A3644),
                    disabledContentColor = Color.White.copy(alpha = 0.7f),
                ),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier
                    .width(360.dp)
                    .height(48.dp),
            ) {
                Text(
                    if (chosen >= 0) "Begin with the ${infos[chosen].name}" else "Tap a weapon to choose it",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun WeaponCard(
    info: WeaponInfo,
    selected: Boolean,
    dimmed: Boolean,
    glow: Float,
    bob: Float,
    modifier: Modifier,
    onTap: () -> Unit,
) {
    val scale by animateFloatAsState(if (selected) 1.04f else 1f, tween(250), label = "scale")
    val fade by animateFloatAsState(if (dimmed) 0.5f else 1f, tween(250), label = "fade")
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = fade
            }
            .clip(shape)
            .background(Color(0xFF191720))
            .border(
                if (selected) 3.dp else 1.dp,
                if (selected) Palette.gold.copy(alpha = glow) else Color.White.copy(alpha = 0.18f),
                shape,
            )
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFFF6EFE2), Color(0xFFE6D9C2)))),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(info.accent.copy(alpha = 0.45f * glow), Color.Transparent),
                            center = center,
                            radius = size.minDimension * 0.75f,
                        ),
                        radius = size.minDimension * 0.75f,
                    )
                }
            }
            Image(
                painter = painterResource(info.art),
                contentDescription = info.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
                    .graphicsLayer { translationY = if (selected) bob.dp.toPx() else 0f },
            )
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(
                info.name,
                color = if (selected) Palette.gold else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            Text(info.style, color = Color(0xFFB9C6BE), fontSize = 11.sp, lineHeight = 14.sp)
            Spacer(Modifier.height(4.dp))
            StatBar("Power", info.power, info.accent)
            StatBar("Speed", info.speed, info.accent)
            StatBar("Reach", info.reach, info.accent)
        }
    }
}

@Composable
private fun StatBar(label: String, value: Float, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(14.dp)) {
        Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, modifier = Modifier.width(44.dp))
        Canvas(Modifier.weight(1f).height(6.dp)) {
            val r = CornerRadius(size.height / 2f)
            drawRoundRect(color = Color(0x33FFFFFF), cornerRadius = r)
            drawRoundRect(color = color, size = Size(size.width * value, size.height), cornerRadius = r)
        }
    }
}

/** A round button that reacts the moment your thumb touches it. */
@Composable
fun HudButton(label: String, active: Boolean, size: Dp, fontSize: TextUnit = 14.sp, onPress: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (active) Palette.gold.copy(alpha = 0.85f) else Color(0x66000000))
            .border(2.dp, Color.White.copy(alpha = if (active) 0.9f else 0.5f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (active) Color(0xFF1E2A22) else Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
        )
    }
}

/**
 * Bottom of the screen: your level badge, then (top to bottom) experience,
 * health with numbers, and stamina.
 */
@Composable
fun PlayerBars(game: Game, modifier: Modifier = Modifier) {
    val tick = game.hudTick
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xCC15131C))
                .border(2.dp, Palette.gold, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("LV", color = Palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 9.sp)
                Text("${if (tick >= 0L) game.level else 1}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Box(Modifier.size(width = 240.dp, height = 18.dp), contentAlignment = Alignment.Center) {
                XpToast(game)
            }
            XpBar(game)
            Spacer(Modifier.height(3.dp))
            Box(contentAlignment = Alignment.Center) {
                HealthBar(game)
                Text(
                    "${game.health.toInt()} / ${game.maxHealth.toInt()}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 10.sp,
                )
            }
            Spacer(Modifier.height(3.dp))
            StaminaBar(game)
        }
    }
}

/** Thin gold bar: how close you are to the next level. */
@Composable
fun XpBar(game: Game) {
    Canvas(Modifier.size(width = 240.dp, height = 5.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(color = Color(0x88000000), cornerRadius = r)
        val f = game.xpFrac.coerceIn(0f, 1f)
        if (f > 0.005f) drawRoundRect(color = Palette.gold, size = Size(size.width * f, size.height), cornerRadius = r)
    }
}

/** "+48 XP" floating up for a moment after a kill. */
@Composable
fun XpToast(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.xpVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(1600)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(300), label = "xp")
    if (a > 0.01f) {
        Text(
            game.xpToast,
            color = Palette.gold,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.graphicsLayer {
                alpha = a
                translationY = (1f - a) * 12f
            },
        )
    }
}

/** Big and gold when you go up a level. */
@Composable
fun BoxScope.LevelUpBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.levelVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3000)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(400), label = "levelup")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .safeDrawingPadding()
            .padding(top = 70.dp)
            .graphicsLayer {
                alpha = a
                scaleX = 0.8f + 0.2f * a
                scaleY = 0.8f + 0.2f * a
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("LEVEL UP!", color = Palette.gold, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
        Text("You are now level ${game.level}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Health restored, and you're tougher", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

/** Your health, just above the stamina bar. */
@Composable
fun HealthBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 240.dp, height = 14.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val h = (game.health / game.maxHealth).coerceIn(0f, 1f)
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        if (h > 0.005f) {
            drawRoundRect(
                color = if (h < 0.3f) Color(0xFFFF4A3A) else Color(0xFFD83A34),
                size = Size(size.width * h, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(color = Color.White.copy(alpha = 0.5f), cornerRadius = CornerRadius(r), style = Stroke(1.5.dp.toPx()))
    }
}

/** A red glow round the edge of the screen when you're hit, and while you're badly hurt. */
@Composable
fun HurtFlash(game: Game) {
    Canvas(Modifier.fillMaxSize()) {
        if (game.hudTick < 0L) return@Canvas
        val low = if (game.health < 30f && !game.dead) 0.3f else 0f
        val k = kotlin.math.max(game.hurtFlash * 0.7f, low)
        if (k < 0.01f) return@Canvas
        drawRect(
            brush = Brush.radialGradient(
                listOf(Color.Transparent, Color(0xFFB0101A).copy(alpha = k)),
                center = center,
                radius = size.maxDimension * 0.62f,
            ),
        )
    }
}

/** The monster you're fighting: its name, level and health, at the top of the screen. */
@Composable
fun BoxScope.TargetPanel(game: Game) {
    val tick = game.hudTick
    val frac = game.targetFrac
    if (tick < 0L || frac < 0f) return
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .safeDrawingPadding()
            .padding(top = 6.dp)
            .background(Color(0xAA15131C), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(game.targetName, color = Color(0xFFFF8A7A), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            // Coloured by how it matches your level: red is too strong for you, grey is too weak to be worth it.
            val gap = game.targetLevel - game.level
            val lvColor = when {
                gap >= 8 -> Color(0xFFFF4A4A)
                gap >= 3 -> Color(0xFFFFA040)
                gap >= -3 -> Color(0xFFFFE070)
                gap >= -10 -> Color(0xFF7CE06A)
                else -> Color(0xFF9A9A9A)
            }
            Text("Lv ${game.targetLevel}", color = lvColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Canvas(Modifier.size(width = 200.dp, height = 8.dp)) {
            val r = CornerRadius(size.height / 2f)
            drawRoundRect(color = Color(0x88000000), cornerRadius = r)
            if (frac > 0.005f) drawRoundRect(color = Color(0xFFD83A34), size = Size(size.width * frac, size.height), cornerRadius = r)
        }
    }
}

/** The context button: shows up near a chest or a cave mouth. */
@Composable
fun BoxScope.ActionButton(game: Game) {
    val tick = game.hudTick
    val action = game.action
    if (tick < 0L || action == Game.ACTION_NONE) return
    val label = when (action) {
        Game.ACTION_OPEN -> "\uD83D\uDDDD\uFE0F  OPEN CHEST"
        Game.ACTION_ENTER -> "\uD83D\uDD26  ENTER CAVE"
        else -> "\u2600\uFE0F  LEAVE CAVE"
    }
    Box(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .safeDrawingPadding()
            .padding(bottom = 84.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Palette.gold)
            .border(2.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(24.dp))
            .pointerInput(Unit) { detectTapGestures(onPress = { game.interact() }) }
            .padding(horizontal = 22.dp, vertical = 11.dp),
    ) {
        Text(label, color = Color(0xFF1E2A22), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** What came out of the chest you just opened. */
@Composable
fun BoxScope.LootPopup(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.lootVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(4200)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(350), label = "loot")
    if (a < 0.01f) return
    val items = game.lastLoot
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .graphicsLayer {
                alpha = a
                scaleX = 0.9f + 0.1f * a
                scaleY = 0.9f + 0.1f * a
            }
            .background(Color(0xE615131C), RoundedCornerShape(16.dp))
            .border(1.5.dp, Palette.gold.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(game.lootTitle, color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        for (item in items) {
            val isGold = item.slot == Slot.POTION && item.vit < 0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (isGold) "\uD83E\uDE99" else Slot.ICONS[item.slot], fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    item.name,
                    color = if (isGold) Palette.gold else Color(Rarity.COLORS[item.rarity]),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("Open your bag \uD83C\uDF92 to wear it", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
    }
}

/** Fades to black and back when you go in or out of a cave. */
@Composable
fun CaveFade(game: Game) {
    Canvas(Modifier.fillMaxSize()) {
        if (game.hudTick < 0L) return@Canvas
        val f = game.fade
        if (f > 0.01f) drawRect(Color.Black.copy(alpha = kotlin.math.min(1f, f * 1.4f)))
    }
}

/** Your equipment: what you're wearing on the left, your bag on the right. Tap to wear or take off. */
@Composable
fun EquipmentPanel(game: Game, onClose: () -> Unit) {
    val loot = game.loot
    val version = loot.version
    val bag = remember(version) { loot.bagItems() }
    val worn = remember(version) { loot.wornItems() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.94f)
                .fillMaxHeight()
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(14.dp),
        ) {
            // Worn items and totals.
            Column(Modifier.width(250.dp).fillMaxHeight().verticalScroll(rememberScrollState())) {
                Text("Equipment", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                for (slot in 0 until Slot.WORN) {
                    val w = worn[slot]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x22FFFFFF))
                            .pointerInput(slot, version) { detectTapGestures(onTap = { if (w != null) loot.unequip(slot) }) }
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                    ) {
                        Text(Slot.ICONS[slot], fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(Slot.NAMES[slot], color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                            Text(
                                w?.name ?: "Nothing",
                                color = if (w != null) Color(Rarity.COLORS[w.rarity]) else Color.White.copy(alpha = 0.35f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("\u2764\uFE0F  Health ${game.maxHealth.toInt()}", color = Color.White, fontSize = 13.sp)
                Text("\uD83D\uDEE1\uFE0F  Defense ${loot.defense}", color = Color.White, fontSize = 13.sp)
                Text("\u2694\uFE0F  Power ${loot.power}", color = Color.White, fontSize = 13.sp)
                Text("\uD83D\uDCA8  Speed +${loot.speed}%", color = Color.White, fontSize = 13.sp)
                Text("\uD83E\uDE99  Gold ${loot.gold}", color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            // The bag.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("Bag (${bag.size})", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(
                        onClick = onClose,
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
                Text("Tap to wear it (or drink a potion). Tap something you're wearing to take it off.", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    if (bag.isEmpty()) {
                        Text("Empty. Find hidden chests out in the wild and deep in caves!", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    }
                    bag.forEachIndexed { i, item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x22FFFFFF))
                                .border(1.dp, Color(Rarity.COLORS[item.rarity]).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .pointerInput(i, version) {
                                    detectTapGestures(onTap = {
                                        if (item.slot == Slot.POTION) game.drinkPotion(i) else loot.equip(i)
                                    })
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        ) {
                            Text(Slot.ICONS[item.slot], fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = Color(Rarity.COLORS[item.rarity]), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(
                                    "${Rarity.NAMES[item.rarity]}  \u00B7  ${item.stats()}",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                )
                            }
                            Text(
                                if (item.slot == Slot.POTION) "DRINK" else "WEAR",
                                color = Palette.gold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Shown while you're knocked out. */
@Composable
fun BoxScope.DefeatOverlay(game: Game) {
    val tick = game.hudTick
    if (tick < 0L || !game.dead) return
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("You were defeated", color = Color(0xFFFF6A5A), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text("Waking up in Greenhollow\u2026", color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp)
        }
    }
}

/** The stamina bar. Turns red when you're out of breath. */
@Composable
fun StaminaBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 240.dp, height = 12.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val s = game.stamina
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        val fill = when {
            game.winded -> Color(0xFFE5534B)
            s < 0.3f -> Color(0xFFFFB347)
            else -> Color(0xFF7BD66F)
        }
        if (s > 0.01f) {
            drawRoundRect(
                color = fill,
                size = Size(size.width * s, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(
            color = Color.White.copy(alpha = 0.5f),
            cornerRadius = CornerRadius(r),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
}

/** The whole world on one screen. Places you've been are in colour, the rest is faded. */
@Composable
fun WorldMap(game: Game, onClose: () -> Unit) {
    val arrow = remember { Path() }
    val labelPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    val regionPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(5f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    val gridPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = 0xCCFFFFFF.toInt()
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(3f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6101014))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxHeight()
                .aspectRatio(1f),
        ) {
            if (game.hudTick < 0L) return@Canvas
            val side = size.minDimension
            drawImage(
                image = game.minimapImage,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )
            drawRect(
                color = Palette.gold.copy(alpha = 0.8f),
                size = Size(side, side),
                style = Stroke(width = 2.dp.toPx()),
            )
            val scale = side / WORLD_SIZE

            // Region colours and borders.
            drawImage(
                image = game.regionOverlay,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )

            // Grid: numbers along the top, letters down the side.
            val cellPx = side / Game.MAP_GRID
            for (g in 1 until Game.MAP_GRID) {
                val t = g * cellPx
                drawLine(Color.White.copy(alpha = 0.16f), Offset(t, 0f), Offset(t, side), strokeWidth = 1f)
                drawLine(Color.White.copy(alpha = 0.16f), Offset(0f, t), Offset(side, t), strokeWidth = 1f)
            }
            gridPaint.textSize = 9.dp.toPx()
            drawIntoCanvas { c ->
                for (g in 0 until Game.MAP_GRID) {
                    val mid = (g + 0.5f) * cellPx
                    c.nativeCanvas.drawText(g.toString(), mid, 11.dp.toPx(), gridPaint)
                    c.nativeCanvas.drawText(('A' + g).toString(), 7.dp.toPx(), mid + 3.dp.toPx(), gridPaint)
                }
            }

            // Region names and how tough they are.
            drawIntoCanvas { c ->
                for (k in Zone.entries.indices) {
                    val zn = Zone.entries[k]
                    val lx = REGION_LABEL_X[k] * scale
                    val lz = REGION_LABEL_Z[k] * scale
                    regionPaint.textSize = 15.dp.toPx()
                    regionPaint.color = zn.mapColor or (0xFF shl 24)
                    c.nativeCanvas.drawText(zn.title.uppercase(), lx, lz, regionPaint)
                    regionPaint.textSize = 11.dp.toPx()
                    regionPaint.color = android.graphics.Color.WHITE
                    c.nativeCanvas.drawText(zn.levels, lx, lz + 14.dp.toPx(), regionPaint)
                }
            }

            // Places: gold and named once found, a hollow ring until then.
            labelPaint.textSize = 10.dp.toPx()
            for (i in PLACES.indices) {
                val pl = PLACES[i]
                val c = Offset(pl.x * scale, pl.z * scale)
                if (game.discovered[i]) {
                    drawCircle(Palette.night, radius = 5.dp.toPx(), center = c)
                    drawCircle(Palette.gold, radius = 3.5.dp.toPx(), center = c)
                } else {
                    drawCircle(Color.White.copy(alpha = 0.7f), radius = 3.5.dp.toPx(), center = c, style = Stroke(width = 1.5.dp.toPx()))
                }
            }
            drawIntoCanvas { cv ->
                for (i in PLACES.indices) {
                    if (!game.discovered[i]) continue
                    val pl = PLACES[i]
                    cv.nativeCanvas.drawText(pl.name, pl.x * scale, pl.z * scale - 7.dp.toPx(), labelPaint)
                }
            }

            // Scale bar: 500 m.
            val bar = 500f * scale
            val by = side - 14.dp.toPx()
            val bx = side - bar - 14.dp.toPx()
            drawLine(Color.White, Offset(bx, by), Offset(bx + bar, by), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx, by - 5.dp.toPx()), Offset(bx, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx + bar, by - 5.dp.toPx()), Offset(bx + bar, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            labelPaint.textSize = 11.dp.toPx()
            drawIntoCanvas { it.nativeCanvas.drawText("500 m", bx + bar / 2f, by - 8.dp.toPx(), labelPaint) }

            // You are here.
            val px = game.x * scale
            val pz = game.z * scale
            val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
            drawCircle(Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(px, pz))
            rotate(degrees = deg, pivot = Offset(px, pz)) {
                val a = 9.dp.toPx()
                arrow.reset()
                arrow.moveTo(px, pz - a)
                arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
                arrow.lineTo(px, pz + a * 0.3f)
                arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
                arrow.close()
                drawPath(arrow, color = Palette.gold)
                drawPath(arrow, color = Palette.night, style = Stroke(width = 1.5.dp.toPx()))
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(20.dp),
        ) {
            Text("World map", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("2.9 km across", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text("You are in ${game.gridRef()}", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "Places found: ${game.discovered.count { it }} of ${PLACES.size}",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
            )
            Text("Bright: explored", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }

        Box(
            Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(16.dp),
        ) {
            HudButton("✕", active = false, size = 52.dp, onPress = onClose)
        }
    }
}

/** A map of the area around you, filling in as you explore. North is up. */
@Composable
fun Minimap(game: Game, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    val arrow = remember { Path() }
    Canvas(
        modifier
            .size(116.dp)
            .clip(shape)
            .background(Palette.night)
            .border(2.dp, Palette.gold.copy(alpha = 0.7f), shape),
    ) {
        if (game.hudTick < 0L) return@Canvas
        val window = 110 // cells shown across, about 660 m
        val ci = (game.x / CELL).toInt()
        val cj = (game.z / CELL).toInt()
        val sx = (ci - window / 2).coerceIn(0, GRID - window)
        val sz = (cj - window / 2).coerceIn(0, GRID - window)
        drawImage(
            image = game.minimapImage,
            srcOffset = IntOffset(sx, sz),
            srcSize = IntSize(window, window),
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.Low,
        )
        val scale = size.width / window
        val px = (game.x / CELL - sx) * scale
        val pz = (game.z / CELL - sz) * scale
        val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
        rotate(degrees = deg, pivot = Offset(px, pz)) {
            val a = 7.dp.toPx()
            arrow.reset()
            arrow.moveTo(px, pz - a)
            arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
            arrow.lineTo(px, pz + a * 0.3f)
            arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
            arrow.close()
            drawPath(arrow, color = Color.White)
            drawPath(arrow, color = Palette.night, style = Stroke(width = 1.dp.toPx()))
        }
    }
}

@Composable
fun BoxScope.ZoneBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val zone = game.zone
    LaunchedEffect(game.zoneVisit) {
        visible = true
        delay(2800)
        visible = false
    }
    val bannerAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(500),
        label = "zoneBanner",
    )
    if (bannerAlpha > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 36.dp)
                .graphicsLayer { alpha = bannerAlpha }
                .background(Color(0xCC15131C), RoundedCornerShape(16.dp))
                .padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(zone.title, color = Color(zone.mapColor or (0xFF shl 24)), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(zone.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text(zone.levels, color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Pops up when you find a named place. */
@Composable
fun BoxScope.DiscoveryBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val name = game.lastDiscovered
    LaunchedEffect(game.discoverVisit) {
        if (game.discoverVisit == 0) return@LaunchedEffect
        visible = true
        delay(3200)
        visible = false
    }
    val a by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(400),
        label = "discovery",
    )
    if (a > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer { alpha = a }
                .background(Color(0xCC15131C), RoundedCornerShape(14.dp))
                .border(1.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(horizontal = 26.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("DISCOVERED", color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Which map square you're in. */
@Composable
fun GridRef(game: Game) {
    val tick = game.hudTick
    Text(
        if (tick >= 0L) game.gridRef() else "",
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(Color(0x99000000), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}
