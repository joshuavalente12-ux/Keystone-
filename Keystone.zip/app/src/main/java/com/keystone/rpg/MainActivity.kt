package com.keystone.rpg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent { KeystoneApp() }
    }
}

@Composable
fun KeystoneApp() {
    var playing by remember { mutableStateOf(false) }
    val game = remember { Game(World()) }
    if (playing) GameScreen(game) else TitleScreen(onStart = { playing = true })
}

@Composable
fun TitleScreen(onStart: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E3B2F), Color(0xFF0F1D17))))
            .safeDrawingPadding()
            .padding(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🗝️", fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                "Keystone",
                color = Palette.gold,
                fontSize = 52.sp,
                fontWeight = FontWeight.ExtraBold,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Explore the wilds. Find the keys.\nOpen up the world.",
                color = Color(0xFFCFE3D6),
                fontSize = 17.sp,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp,
            )
            Spacer(Modifier.height(44.dp))
            Button(
                onClick = onStart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Palette.gold,
                    contentColor = Color(0xFF1E2A22),
                ),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
            ) {
                Text("Start adventure", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Early build: explore the world",
                color = Color(0xFF8FA99A),
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
fun GameScreen(game: Game) {
    var stickOrigin by remember { mutableStateOf<Offset?>(null) }
    var stickKnob by remember { mutableStateOf(Offset.Zero) }
    var hasMoved by remember { mutableStateOf(false) }

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // Game loop: one update per screen frame.
    LaunchedEffect(game) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                game.update(dt)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Palette.night)
            .pointerInput(game) {
                val maxR = 56.dp.toPx()
                // Floating joystick: put a thumb down anywhere and drag.
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var origin = down.position
                    stickOrigin = origin
                    stickKnob = origin
                    val id = down.id
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == id } ?: break
                        if (!change.pressed) break
                        val pos = change.position
                        var d = pos - origin
                        var len = d.getDistance()
                        if (len > maxR) {
                            // Drag the base along so the stick never "runs out".
                            origin = pos - d * (maxR / len)
                            d = pos - origin
                            len = maxR
                            stickOrigin = origin
                        }
                        stickKnob = pos
                        if (len > maxR * 0.15f) {
                            game.inputX = d.x / maxR
                            game.inputY = d.y / maxR
                            hasMoved = true
                        } else {
                            game.inputX = 0f
                            game.inputY = 0f
                        }
                        change.consume()
                    }
                    stickOrigin = null
                    game.inputX = 0f
                    game.inputY = 0f
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            if (game.tick < 0L) return@Canvas
            drawWorld(game, 44.dp.toPx())
            stickOrigin?.let { o ->
                val r = 56.dp.toPx()
                drawCircle(color = Color.White.copy(alpha = 0.12f), radius = r, center = o)
                drawCircle(
                    color = Color.White.copy(alpha = 0.35f),
                    radius = r,
                    center = o,
                    style = Stroke(width = 2.dp.toPx()),
                )
                drawCircle(color = Color.White.copy(alpha = 0.6f), radius = 24.dp.toPx(), center = stickKnob)
            }
        }

        Minimap(
            game,
            Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(12.dp),
        )

        ZoneBanner(game)

        if (!hasMoved) {
            Text(
                "Touch and drag anywhere to walk",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 72.dp)
                    .background(Color(0xAA15131C), RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
fun Minimap(game: Game, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Canvas(
        modifier
            .size(104.dp)
            .clip(shape)
            .background(Palette.night)
            .border(2.dp, Palette.gold.copy(alpha = 0.7f), shape),
    ) {
        if (game.tick < 0L) return@Canvas
        drawImage(
            image = game.minimapImage,
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.None,
        )
        val scale = size.width / game.world.size
        val dot = Offset(game.x * scale, game.y * scale)
        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = dot)
        drawCircle(color = Palette.hero, radius = 2.5.dp.toPx(), center = dot)
    }
}

@Composable
fun BoxScope.ZoneBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val zone = game.zone
    LaunchedEffect(game.zoneVisit) {
        visible = true
        delay(2600)
        visible = false
    }
    val bannerAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(500),
        label = "zoneBanner",
    )
    if (bannerAlpha > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 132.dp)
                .graphicsLayer { alpha = bannerAlpha }
                .background(Color(0xCC15131C), RoundedCornerShape(16.dp))
                .padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(zone.title, color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(zone.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
        }
    }
}
