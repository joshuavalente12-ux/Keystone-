package com.keystone.rpg

import android.content.Context
import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Image
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.TextUnit
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** The 3D view, kept here so the activity can pause and resume it. */
private object GlHolder {
    var view: GLSurfaceView? = null
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        // Signs in to Google Play Games by itself; falls back to guest if that isn't possible.
        CloudSave.start(this)
        setContent { KeystoneApp() }
    }

    override fun onStop() {
        super.onStop()
        // Copy the save to the cloud when you leave the game (does nothing as a guest).
        CloudSave.upload(this)
    }

    override fun onPause() {
        super.onPause()
        GlHolder.view?.onPause()
        Sound.stop()
    }

    override fun onResume() {
        super.onResume()
        GlHolder.view?.onResume()
        if (Sound.wanted) Sound.start()
    }
}

@Composable
fun KeystoneApp() {
    // 0 = title, 1 = choosing a weapon, 2 = playing.
    var stage by remember { mutableIntStateOf(0) }
    var game by remember { mutableStateOf<Game?>(null) }
    // Building the world takes a few seconds, so do it behind the title screen.
    LaunchedEffect(Unit) {
        game = withContext(Dispatchers.Default) { Game(World()) }
    }
    val ready = game
    val appCtx = LocalContext.current
    // Once you've picked a weapon there is a save to Play. New Game wipes it, and pulling
    // down a cloud save can bring one back, so this is worked out again when that happens.
    var hasSave by remember(CloudSave.restoredTick) {
        mutableStateOf(
            !appCtx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("weapon", "").isNullOrEmpty(),
        )
    }
    if (stage == 2 && ready != null) {
        GameScreen(ready)
    } else if (stage == 1 && ready != null) {
        ClassSelectScreen(onBegin = { chosen ->
            ready.weaponClass = chosen
            stage = 2
        })
    } else {
        TitleScreen(
            ready = ready != null,
            hasSave = hasSave,
            onPlay = {
                CloudSave.locked = true
                stage = if (hasSave) 2 else 1
            },
            onNewGame = {
                CloudSave.locked = true
                appCtx.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().clear().commit()
                hasSave = false
                stage = 1
            },
        )
    }
}

@Composable
fun TitleScreen(ready: Boolean, hasSave: Boolean, onPlay: () -> Unit, onNewGame: () -> Unit) {
    val ctx = LocalContext.current
    val activity = remember { ctx.keystoneActivity() }
    // 0 = nothing, 1 = "start over?", 2 = "replace with cloud save?"
    var confirm by remember { mutableIntStateOf(0) }
    var settingsOpen by remember { mutableStateOf(false) }
    val cloudOn = CloudSave.state == CloudSave.SIGNED_IN && !CloudSave.working
    val goldButton = ButtonDefaults.buttonColors(
        containerColor = Palette.gold,
        contentColor = Color(0xFF1E2A22),
        disabledContainerColor = Palette.gold.copy(alpha = 0.35f),
        disabledContentColor = Color(0xFF1E2A22),
    )
    val darkButton = ButtonDefaults.buttonColors(
        containerColor = Color(0xCC101A15),
        contentColor = Palette.gold,
        disabledContainerColor = Color(0x66101A15),
        disabledContentColor = Palette.gold.copy(alpha = 0.4f),
    )
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF050A08))) {
        Canvas(Modifier.fillMaxSize()) { drawTitleScene() }
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .safeDrawingPadding()
                .padding(end = 30.dp)
                .width(300.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "KEYSTONE",
                color = Palette.gold,
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 6.sp,
            )
            Text(
                "Explore the wilds. Find the keys.",
                color = Color(0xFFCFE3D6),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            // Who is signed in. A guest can tap here to try signing in again.
            Text(
                CloudSave.statusText(),
                color = if (CloudSave.state == CloudSave.SIGNED_IN) Color(0xFF9CFF9C) else Color(0xFF8FA99A),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.pointerInput(Unit) {
                    detectTapGestures { activity?.let { CloudSave.signIn(it) } }
                },
            )
            Spacer(Modifier.height(10.dp))
            if (confirm != 0) {
                Text(
                    if (confirm == 1) {
                        if (CloudSave.state == CloudSave.SIGNED_IN) {
                            "Start over? This erases your saved adventure, and your cloud save is replaced the next time you save."
                        } else {
                            "Start over? This erases your saved adventure."
                        }
                    } else {
                        "Replace the adventure on this phone with your cloud save?"
                    },
                    color = Color.White,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val was = confirm
                        confirm = 0
                        if (was == 1) {
                            onNewGame()
                        } else {
                            CloudSave.locked = false
                            activity?.let { CloudSave.download(it) }
                        }
                    },
                    colors = goldButton,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                ) {
                    Text(if (confirm == 1) "Yes, erase it" else "Yes, load it", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { confirm = 0 },
                    colors = darkButton,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                ) {
                    Text("Cancel", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = onPlay,
                    enabled = ready,
                    colors = goldButton,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                ) {
                    Text(if (ready) "Play" else "Building the world\u2026", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { if (hasSave) confirm = 1 else onNewGame() },
                        enabled = ready,
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("New Game", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { settingsOpen = true },
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Settings", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { activity?.let { CloudSave.upload(it, force = true) } },
                        enabled = cloudOn && hasSave,
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Save", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (hasSave) {
                                confirm = 2
                            } else {
                                CloudSave.locked = false
                                activity?.let { CloudSave.download(it) }
                            }
                        },
                        enabled = cloudOn,
                        colors = darkButton,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                    ) {
                        Text("Load", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (CloudSave.note.isNotEmpty()) {
                        CloudSave.note
                    } else if (CloudSave.state == CloudSave.SIGNED_IN) {
                        "Save and Load use your Google cloud save."
                    } else {
                        "Save and Load need Google Play Games sign-in."
                    },
                    color = Color(0xFFB9CFC2),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                )
            }
        }
        if (settingsOpen) {
            SettingsPanel(
                autoFight = false,
                onAutoFight = {},
                onClose = { settingsOpen = false },
                onEditHud = {},
                inGame = false,
            )
        }
    }
}

@Composable
fun GameScreen(game: Game) {
    var stickOrigin by remember { mutableStateOf<Offset?>(null) }
    var stickKnob by remember { mutableStateOf(Offset.Zero) }
    var hasMoved by remember { mutableStateOf(false) }
    var hasLooked by remember { mutableStateOf(false) }
    var runOn by remember { mutableStateOf(false) }
    var mapOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var bagOpen by remember { mutableStateOf(false) }
    var questLogOpen by remember { mutableStateOf(false) }
    var bookOpen by remember { mutableStateOf(false) }
    var gridOpen by remember { mutableStateOf(false) }
    var editingHud by remember { mutableStateOf(false) }
    val context0 = LocalContext.current
    val hudLayout = remember { HudLayout.load(context0) }
    var thirdPerson by remember {
        mutableStateOf(
            context0.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("third", true),
        )
    }
    game.thirdPerson = thirdPerson
    var autoFight by remember {
        mutableStateOf(
            context0.getSharedPreferences("keystone_view", Context.MODE_PRIVATE).getBoolean("auto_fight", false),
        )
    }
    game.autoFight = autoFight
    val density = LocalDensity.current.density
    val context = LocalContext.current
    val openMap = {
        game.moveX = 0f
        game.moveY = 0f
        stickOrigin = null
        mapOpen = true
    }

    // While signed in to Google Play Games, copy the save to the cloud every few minutes.
    LaunchedEffect(Unit) {
        while (true) {
            delay(180_000L)
            context.keystoneActivity()?.let { CloudSave.upload(it) }
        }
    }

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        Sound.load(context)
        game.loadSave(context)
        Sound.wanted = true
        Sound.start()
        onDispose {
            Sound.wanted = false
            Sound.stop()
            view.keepScreenOn = false
            GlHolder.view = null
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.night)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setEGLConfigChooser(DepthConfigChooser())
                    preserveEGLContextOnPause = true
                    setRenderer(WorldRenderer(game))
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    GlHolder.view = this
                }
            },
        )

        // Touch layer: left half of the screen walks, right half looks around.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(game) {
                    val maxR = 56.dp.toPx()
                    val lookScale = 0.012f / density
                    awaitPointerEventScope {
                        var moveId: PointerId? = null
                        var lookId: PointerId? = null
                        var origin = Offset.Zero
                        var lastLook = Offset.Zero
                        while (true) {
                            val event = awaitPointerEvent()
                            for (change in event.changes) {
                                val pos = change.position
                                if (change.pressed && !change.previousPressed) {
                                    if (pos.x < size.width / 2f && moveId == null) {
                                        moveId = change.id
                                        origin = pos
                                        stickOrigin = pos
                                        stickKnob = pos
                                    } else if (lookId == null) {
                                        lookId = change.id
                                        lastLook = pos
                                    }
                                } else if (change.pressed) {
                                    if (change.id == moveId) {
                                        var d = pos - origin
                                        var len = d.getDistance()
                                        if (len > maxR) {
                                            origin = pos - d * (maxR / len)
                                            d = pos - origin
                                            len = maxR
                                            stickOrigin = origin
                                        }
                                        stickKnob = pos
                                        if (len > maxR * 0.12f) {
                                            game.moveX = d.x / maxR
                                            game.moveY = d.y / maxR
                                            hasMoved = true
                                        } else {
                                            game.moveX = 0f
                                            game.moveY = 0f
                                        }
                                    } else if (change.id == lookId) {
                                        val d = pos - lastLook
                                        lastLook = pos
                                        game.addLook(d.x * lookScale, d.y * lookScale)
                                        if (d.getDistance() > 2f) hasLooked = true
                                    }
                                } else if (!change.pressed && change.previousPressed) {
                                    if (change.id == moveId) {
                                        moveId = null
                                        stickOrigin = null
                                        game.moveX = 0f
                                        game.moveY = 0f
                                    }
                                    if (change.id == lookId) lookId = null
                                }
                                change.consume()
                            }
                        }
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                stickOrigin?.let { o ->
                    val r = 56.dp.toPx()
                    drawCircle(color = Color.White.copy(alpha = 0.12f), radius = r, center = o)
                    drawCircle(
                        color = Color.White.copy(alpha = 0.35f),
                        radius = r,
                        center = o,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                    drawCircle(color = Color.White.copy(alpha = 0.6f), radius = 24.dp.toPx(), center = stickKnob)
                }
            }
        }

        // Soft darkening towards the screen edges, like a camera lens.
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    0.6f to Color.Transparent,
                    1f to Color(0x55000000),
                    center = center,
                    radius = size.maxDimension * 0.62f,
                ),
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Minimap(game, Modifier.pointerInput(Unit) { detectTapGestures { openMap() } })
            Spacer(Modifier.height(4.dp))
            GridRef(game)
            Spacer(Modifier.height(6.dp))
            HudDraggable("map", editingHud, hudLayout) {
                HudButton("MAP", active = false, size = 52.dp) { if (!editingHud) openMap() }
            }
        }

        // Settings gear and the camera switch live in the top-left corner, clear of the action buttons.
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudDraggable("gear", editingHud, hudLayout) {
                HudButton("\u2699", active = false, size = 44.dp, fontSize = 22.sp) {
                    if (!editingHud) {
                        game.moveX = 0f
                        game.moveY = 0f
                        stickOrigin = null
                        settingsOpen = true
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            // Equipment: your bag and what you're wearing.
            HudDraggable("bag", editingHud, hudLayout) {
                HudButton("\uD83C\uDF92", active = false, size = 44.dp, fontSize = 20.sp) {
                    if (!editingHud) {
                        game.moveX = 0f
                        game.moveY = 0f
                        stickOrigin = null
                        bagOpen = true
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            HudDraggable("quests", editingHud, hudLayout) {
                Box {
                    HudButton("\uD83D\uDCDC", active = false, size = 44.dp, fontSize = 20.sp) {
                        if (!editingHud) {
                            game.moveX = 0f
                            game.moveY = 0f
                            stickOrigin = null
                            questLogOpen = true
                        }
                    }
                    if (game.quests.current().any { it.state == QState.READY }) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Palette.gold)
                                .border(1.dp, Color.White, CircleShape),
                        )
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            HudDraggable("book", editingHud, hudLayout) {
                HudButton("\uD83D\uDCD6", active = false, size = 44.dp, fontSize = 20.sp) {
                    if (!editingHud) {
                        game.moveX = 0f
                        game.moveY = 0f
                        stickOrigin = null
                        bookOpen = true
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            // The Sphere Grid: spend the point you earn every level.
            HudDraggable("grid", editingHud, hudLayout) {
                Box {
                    HudButton("\u2726", active = false, size = 44.dp, fontSize = 20.sp) {
                        if (!editingHud) {
                            game.moveX = 0f
                            game.moveY = 0f
                            stickOrigin = null
                            gridOpen = true
                        }
                    }
                    if (game.loot.version >= 0 && game.loot.gridPoints > 0) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Palette.gold)
                                .border(1.dp, Color.White, CircleShape),
                        )
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            HudDraggable("view", editingHud, hudLayout) {
                HudButton("VIEW", active = !thirdPerson, size = 44.dp, fontSize = 11.sp) {
                    if (!editingHud) {
                        thirdPerson = !thirdPerson
                        game.thirdPerson = thirdPerson
                        context.getSharedPreferences("keystone_view", Context.MODE_PRIVATE)
                            .edit().putBoolean("third", thirdPerson).apply()
                    }
                }
            }
        }

        HurtFlash(game)
        ZoneBanner(game)
        DiscoveryBanner(game)
        TargetPanel(game)

        PlayerBars(
            game,
            Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .padding(bottom = 12.dp),
        )
        LevelUpBanner(game)

        // Action buttons under the right thumb.
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .safeDrawingPadding()
                .padding(end = 24.dp, bottom = 22.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Attack with your weapon. The button shows the weapon you chose.
                HudDraggable("attack", editingHud, hudLayout) {
                    WeaponButton(
                        icon = when (game.weaponClass) {
                            WeaponClass.KUNAI -> R.drawable.icon_kunai
                            WeaponClass.HALBERD -> R.drawable.icon_halberd
                            else -> R.drawable.icon_sword
                        },
                        size = 64.dp,
                    ) { if (!editingHud) game.attack() }
                }
                Spacer(Modifier.height(12.dp))
                HudDraggable("run", editingHud, hudLayout) {
                    HudButton("RUN", active = runOn, size = 70.dp) {
                        if (!editingHud) {
                            runOn = !runOn
                            game.runOn = runOn
                        }
                    }
                }
            }
            Spacer(Modifier.width(16.dp))
            HudDraggable("jump", editingHud, hudLayout) {
                Box(Modifier.padding(bottom = 46.dp)) {
                    HudButton("JUMP", active = false, size = 82.dp) { if (!editingHud) game.jump() }
                }
            }
        }

        if (!hasMoved || !hasLooked) {
            Text(
                "Left thumb: walk     Right thumb: look",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 44.dp)
                    .background(Color(0xAA15131C), RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }

        ActionButton(game)
        LootPopup(game)
        BossBanner(game)
        SealBanner(game)
        DefeatOverlay(game)
        CaveFade(game)
        SearchWindow(game)
        QuestToast(game)
        TalkWindow(game)
        TradeWindow(game)

        if (mapOpen) {
            WorldMap(game, onClose = { mapOpen = false })
        }
        if (bagOpen) {
            EquipmentPanel(game, onClose = { bagOpen = false })
        }
        if (questLogOpen) {
            QuestLogPanel(game, onClose = { questLogOpen = false })
        }
        if (bookOpen) {
            BookPanel(game, onClose = { bookOpen = false })
        }
        if (gridOpen) {
            GridPanel(game, onClose = { gridOpen = false })
        }
        if (settingsOpen) {
            SettingsPanel(
                autoFight = autoFight,
                onAutoFight = {
                    autoFight = it
                    game.autoFight = it
                    context.getSharedPreferences("keystone_view", Context.MODE_PRIVATE)
                        .edit().putBoolean("auto_fight", it).apply()
                },
                onClose = { settingsOpen = false },
                onEditHud = {
                    settingsOpen = false
                    editingHud = true
                },
            )
        }
        if (editingHud) {
            HudEditBanner(
                onReset = { HudLayout.reset(context, hudLayout) },
                onDone = { editingHud = false },
            )
        }
    }
}

/** Shown while rearranging the HUD: explains what's happening and lets you finish or reset. */
@Composable
fun HudEditBanner(onReset: () -> Unit, onDone: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(top = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            modifier = Modifier
                .background(Color(0xEE1E1B26), RoundedCornerShape(16.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Drag any button to move it", color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.width(14.dp))
            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3644), contentColor = Color.White),
            ) {
                Text("Reset", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onDone,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
            ) {
                Text("Done", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

/** Settings: how loud each kind of sound is. Remembered between games. */
@Composable
fun SettingsPanel(
    autoFight: Boolean,
    onAutoFight: (Boolean) -> Unit,
    onClose: () -> Unit,
    onEditHud: () -> Unit,
    inGame: Boolean = true,
) {
    val ctx = LocalContext.current
    // The title screen opens this too, before the sound engine has read what you chose last time.
    LaunchedEffect(Unit) { if (!inGame) Sound.load(ctx) }
    var steps by remember { mutableFloatStateOf(Sound.volSteps) }
    var wind by remember { mutableFloatStateOf(Sound.volWind) }
    var rain by remember { mutableFloatStateOf(Sound.volRain) }
    var animals by remember { mutableFloatStateOf(Sound.volAnimals) }
    var music by remember { mutableFloatStateOf(Sound.volMusic) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAA000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .width(420.dp)
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 14.dp),
        ) {
            Text("Settings", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Sound", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            VolumeRow("Music", music) {
                music = it
                Sound.setMusicVolume(it)
                Sound.save(ctx)
            }
            VolumeRow("Footsteps", steps) {
                steps = it
                Sound.volSteps = it
                Sound.save(ctx)
            }
            VolumeRow("Wind", wind) {
                wind = it
                Sound.volWind = it
                Sound.save(ctx)
            }
            VolumeRow("Rain & thunder", rain) {
                rain = it
                Sound.volRain = it
                Sound.save(ctx)
            }
            VolumeRow("Animals", animals) {
                animals = it
                Sound.volAnimals = it
                Sound.save(ctx)
            }
            if (inGame) {
            Spacer(Modifier.height(8.dp))
            Text("Combat", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Auto fight", color = Color.White, fontSize = 15.sp)
                    Text(
                        "Attacks anything that comes close, by itself",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp,
                    )
                }
                Button(
                    onClick = { onAutoFight(!autoFight) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (autoFight) Palette.gold else Color(0xFF3A3644),
                        contentColor = if (autoFight) Color(0xFF1E2A22) else Color.White,
                    ),
                ) {
                    Text(if (autoFight) "ON" else "OFF", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Buttons", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Customize HUD", color = Color.White, fontSize = 15.sp)
                    Text(
                        "Drag any button wherever you want it",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp,
                    )
                }
                Button(
                    onClick = onEditHud,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3644), contentColor = Color.White),
                ) {
                    Text("Edit", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            }
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) {
                Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun VolumeRow(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(44.dp)) {
        Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.width(120.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Palette.gold,
                activeTrackColor = Palette.gold,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
            ),
        )
        Text(
            "${(value * 100f).toInt()}%",
            color = Color.White,
            fontSize = 14.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(48.dp),
        )
    }
}

/** The attack button: a picture of your weapon in a gold ring. Reacts the moment you touch it. */
@Composable
fun WeaponButton(icon: Int, size: Dp, onPress: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0x77000000))
            .border(2.dp, Palette.gold.copy(alpha = 0.85f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(icon),
            contentDescription = "Attack",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().padding(7.dp),
        )
    }
}

/** What the weapon-choosing screen shows about each weapon. */
private class WeaponInfo(
    val cls: Int,
    val name: String,
    val style: String,
    val art: Int,
    val power: Float,
    val speed: Float,
    val reach: Float,
    val accent: Color,
)

/** Before the adventure starts: pick the weapon you'll fight with. */
@Composable
fun ClassSelectScreen(onBegin: (Int) -> Unit) {
    val infos = listOf(
        WeaponInfo(
            WeaponClass.KUNAI, "Bloodsworn Kunai", "Throw kunai without end.\nStrike from far away.",
            R.drawable.class_kunai, 0.55f, 0.9f, 1f, Color(0xFFD2323A),
        ),
        WeaponInfo(
            WeaponClass.HALBERD, "Rotroot Halberd", "Double swing: a spinning\nsweep, then a crushing slam.",
            R.drawable.class_halberd, 0.95f, 0.4f, 0.8f, Color(0xFF6CCB5F),
        ),
        WeaponInfo(
            WeaponClass.SWORD, "Mind, Body & Soul", "Triple swing: two slashes\nand an overhead chop.",
            R.drawable.class_sword, 0.75f, 0.65f, 0.55f, Color(0xFFF08AB8),
        ),
    )
    var chosen by remember { mutableIntStateOf(-1) }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "glow",
    )
    val bob by pulse.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob",
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E3B2F), Color(0xFF0F1D17))))
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "CHOOSE YOUR WEAPON",
                color = Palette.gold,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
            )
            Text(
                "Your weapon decides how you fight. Choose wisely.",
                color = Color(0xFFCFE3D6),
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                infos.forEachIndexed { i, info ->
                    WeaponCard(
                        info = info,
                        selected = chosen == i,
                        dimmed = chosen >= 0 && chosen != i,
                        glow = glow,
                        bob = bob,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onTap = { chosen = i },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (chosen >= 0) onBegin(infos[chosen].cls) },
                enabled = chosen >= 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Palette.gold,
                    contentColor = Color(0xFF1E2A22),
                    disabledContainerColor = Color(0xFF3A3644),
                    disabledContentColor = Color.White.copy(alpha = 0.7f),
                ),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier
                    .width(360.dp)
                    .height(48.dp),
            ) {
                Text(
                    if (chosen >= 0) "Begin with the ${infos[chosen].name}" else "Tap a weapon to choose it",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun WeaponCard(
    info: WeaponInfo,
    selected: Boolean,
    dimmed: Boolean,
    glow: Float,
    bob: Float,
    modifier: Modifier,
    onTap: () -> Unit,
) {
    val scale by animateFloatAsState(if (selected) 1.04f else 1f, tween(250), label = "scale")
    val fade by animateFloatAsState(if (dimmed) 0.5f else 1f, tween(250), label = "fade")
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = fade
            }
            .clip(shape)
            .background(Color(0xFF191720))
            .border(
                if (selected) 3.dp else 1.dp,
                if (selected) Palette.gold.copy(alpha = glow) else Color.White.copy(alpha = 0.18f),
                shape,
            )
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFFF6EFE2), Color(0xFFE6D9C2)))),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(info.accent.copy(alpha = 0.45f * glow), Color.Transparent),
                            center = center,
                            radius = size.minDimension * 0.75f,
                        ),
                        radius = size.minDimension * 0.75f,
                    )
                }
            }
            Image(
                painter = painterResource(info.art),
                contentDescription = info.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
                    .graphicsLayer { translationY = if (selected) bob.dp.toPx() else 0f },
            )
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(
                info.name,
                color = if (selected) Palette.gold else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            Text(info.style, color = Color(0xFFB9C6BE), fontSize = 11.sp, lineHeight = 14.sp)
            Spacer(Modifier.height(4.dp))
            StatBar("Power", info.power, info.accent)
            StatBar("Speed", info.speed, info.accent)
            StatBar("Reach", info.reach, info.accent)
        }
    }
}

@Composable
private fun StatBar(label: String, value: Float, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(14.dp)) {
        Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, modifier = Modifier.width(44.dp))
        Canvas(Modifier.weight(1f).height(6.dp)) {
            val r = CornerRadius(size.height / 2f)
            drawRoundRect(color = Color(0x33FFFFFF), cornerRadius = r)
            drawRoundRect(color = color, size = Size(size.width * value, size.height), cornerRadius = r)
        }
    }
}

/**
 * Wraps a HUD button so it can be dragged to a new spot. Outside edit mode it just applies
 * whatever offset was saved for [id]; in edit mode it also shows a gold outline and follows
 * the finger, saving the new spot as soon as the drag moves.
 */
@Composable
fun HudDraggable(
    id: String,
    editing: Boolean,
    layout: SnapshotStateMap<String, Offset>,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val savedOffset = layout[id] ?: Offset.Zero
    Box(
        modifier = Modifier
            .offset { IntOffset(savedOffset.x.roundToInt(), savedOffset.y.roundToInt()) }
            .then(
                if (editing) {
                    Modifier
                        .border(2.dp, Palette.gold, RoundedCornerShape(14.dp))
                        .pointerInput(id) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val next = (layout[id] ?: Offset.Zero) + drag
                                layout[id] = next
                                HudLayout.save(context, id, next)
                            }
                        }
                } else {
                    Modifier
                },
            ),
    ) {
        content()
    }
}

/** A round button that reacts the moment your thumb touches it. */
@Composable
fun HudButton(label: String, active: Boolean, size: Dp, fontSize: TextUnit = 14.sp, onPress: () -> Unit) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (active) Palette.gold.copy(alpha = 0.85f) else Color(0x66000000))
            .border(2.dp, Color.White.copy(alpha = if (active) 0.9f else 0.5f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (active) Color(0xFF1E2A22) else Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
        )
    }
}

/**
 * Bottom of the screen: your level badge, then (top to bottom) experience,
 * health with numbers, and stamina.
 */
@Composable
fun PlayerBars(game: Game, modifier: Modifier = Modifier) {
    val tick = game.hudTick
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xCC15131C))
                .border(2.dp, Palette.gold, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("LV", color = Palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 9.sp)
                Text("${if (tick >= 0L) game.level else 1}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Box(Modifier.size(width = 240.dp, height = 18.dp), contentAlignment = Alignment.Center) {
                XpToast(game)
            }
            if (tick >= 0L) {
                val lv = game.loot.level
                Text(
                    if (lv >= MAX_LEVEL) "MAX LEVEL" else "${game.loot.xp} / ${game.loot.xpNeeded(lv)} XP",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 9.sp,
                )
            }
            XpBar(game)
            Spacer(Modifier.height(3.dp))
            Box(contentAlignment = Alignment.Center) {
                HealthBar(game)
                Text(
                    "${game.health.toInt()} / ${game.maxHealth.toInt()}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 10.sp,
                )
            }
            Spacer(Modifier.height(3.dp))
            StaminaBar(game)
        }
    }
}

/** Thin gold bar: how close you are to the next level. */
@Composable
fun XpBar(game: Game) {
    Canvas(Modifier.size(width = 240.dp, height = 5.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(color = Color(0x88000000), cornerRadius = r)
        val f = game.xpFrac.coerceIn(0f, 1f)
        if (f > 0.005f) drawRoundRect(color = Palette.gold, size = Size(size.width * f, size.height), cornerRadius = r)
    }
}

/** "+48 XP" floating up for a moment after a kill. */
@Composable
fun XpToast(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.xpVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(1600)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(300), label = "xp")
    if (a > 0.01f) {
        Text(
            game.xpToast,
            color = Palette.gold,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.graphicsLayer {
                alpha = a
                translationY = (1f - a) * 12f
            },
        )
    }
}

/** Big and gold when you go up a level. */
@Composable
fun BoxScope.LevelUpBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.levelVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3000)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(400), label = "levelup")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .safeDrawingPadding()
            .padding(top = 70.dp)
            .graphicsLayer {
                alpha = a
                scaleX = 0.8f + 0.2f * a
                scaleY = 0.8f + 0.2f * a
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("LEVEL UP!", color = Palette.gold, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
        Text("You are now level ${game.level}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Health restored, and you're tougher", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

/** Your health, just above the stamina bar. */
@Composable
fun HealthBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 240.dp, height = 14.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val h = (game.health / game.maxHealth).coerceIn(0f, 1f)
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        if (h > 0.005f) {
            drawRoundRect(
                color = if (h < 0.3f) Color(0xFFFF4A3A) else Color(0xFFD83A34),
                size = Size(size.width * h, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(color = Color.White.copy(alpha = 0.5f), cornerRadius = CornerRadius(r), style = Stroke(1.5.dp.toPx()))
    }
}

/** A red glow round the edge of the screen when you're hit, and while you're badly hurt. */
@Composable
fun HurtFlash(game: Game) {
    Canvas(Modifier.fillMaxSize()) {
        if (game.hudTick < 0L) return@Canvas
        val low = if (game.health < 30f && !game.dead) 0.3f else 0f
        val k = kotlin.math.max(game.hurtFlash * 0.7f, low)
        if (k < 0.01f) return@Canvas
        drawRect(
            brush = Brush.radialGradient(
                listOf(Color.Transparent, Color(0xFFB0101A).copy(alpha = k)),
                center = center,
                radius = size.maxDimension * 0.62f,
            ),
        )
    }
}

/** The monster you're fighting: its name, level and health, at the top of the screen. */
@Composable
fun BoxScope.TargetPanel(game: Game) {
    val tick = game.hudTick
    val frac = game.targetFrac
    if (tick < 0L || frac < 0f) return
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .safeDrawingPadding()
            .padding(top = 6.dp)
            .background(Color(0xAA15131C), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val boss = game.targetBoss
            Text(
                if (boss) "\u2620\uFE0F  ${game.targetName}" else game.targetName,
                color = if (boss) Palette.gold else Color(0xFFFF8A7A),
                fontSize = if (boss) 17.sp else 14.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(8.dp))
            // Coloured by how it matches your level: red is too strong for you, grey is too weak to be worth it.
            val gap = game.targetLevel - game.level
            val lvColor = when {
                gap >= 8 -> Color(0xFFFF4A4A)
                gap >= 3 -> Color(0xFFFFA040)
                gap >= -3 -> Color(0xFFFFE070)
                gap >= -10 -> Color(0xFF7CE06A)
                else -> Color(0xFF9A9A9A)
            }
            Text("Lv ${game.targetLevel}", color = lvColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Canvas(Modifier.size(width = if (game.targetBoss) 280.dp else 200.dp, height = if (game.targetBoss) 11.dp else 8.dp)) {
            val r = CornerRadius(size.height / 2f)
            drawRoundRect(color = Color(0x88000000), cornerRadius = r)
            if (frac > 0.005f) drawRoundRect(color = Color(0xFFD83A34), size = Size(size.width * frac, size.height), cornerRadius = r)
        }
    }
}

/** The context button: shows up near a chest or a cave mouth. */
@Composable
fun BoxScope.ActionButton(game: Game) {
    val tick = game.hudTick
    val action = game.action
    if (tick < 0L || action == Game.ACTION_NONE) return
    val label = when (action) {
        Game.ACTION_OPEN -> "\uD83D\uDDDD\uFE0F  OPEN CHEST"
        Game.ACTION_ENTER -> "\uD83D\uDD26  ENTER CAVE"
        Game.ACTION_SEARCH -> "\uD83D\uDD0D  SEARCH BODY"
        Game.ACTION_TALK -> "\uD83D\uDCAC  TALK"
        Game.ACTION_RELIC -> "\u2728  TAKE RELIC"
        else -> "\u2600\uFE0F  LEAVE CAVE"
    }
    Box(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .safeDrawingPadding()
            .padding(bottom = 84.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Palette.gold)
            .border(2.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(24.dp))
            .pointerInput(Unit) { detectTapGestures(onPress = { game.interact() }) }
            .padding(horizontal = 22.dp, vertical = 11.dp),
    ) {
        Text(label, color = Color(0xFF1E2A22), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** What came out of the chest you just opened. */
@Composable
fun BoxScope.LootPopup(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.lootVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(4200)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(350), label = "loot")
    if (a < 0.01f) return
    val items = game.lastLoot
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .graphicsLayer {
                alpha = a
                scaleX = 0.9f + 0.1f * a
                scaleY = 0.9f + 0.1f * a
            }
            .background(Color(0xE615131C), RoundedCornerShape(16.dp))
            .border(1.5.dp, Palette.gold.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(game.lootTitle, color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        for (item in items) {
            val isGold = item.slot == Slot.POTION && item.vit < 0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (isGold) "\uD83E\uDE99" else Slot.ICONS[item.slot], fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    item.name,
                    color = if (isGold) Palette.gold else Color(Rarity.COLORS[item.rarity]),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("Open your bag \uD83C\uDF92 to wear it", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
    }
}

/** Fades to black and back when you go in or out of a cave. */
@Composable
fun CaveFade(game: Game) {
    Canvas(Modifier.fillMaxSize()) {
        if (game.hudTick < 0L) return@Canvas
        val f = game.fade
        if (f > 0.01f) drawRect(Color.Black.copy(alpha = kotlin.math.min(1f, f * 1.4f)))
    }
}

/** Your equipment: what you're wearing on the left, your bag on the right. Tap to wear or take off. */
@Composable
fun EquipmentPanel(game: Game, onClose: () -> Unit) {
    val loot = game.loot
    val version = loot.version
    val bag = remember(version) { loot.bagItems() }
    val worn = remember(version) { loot.wornItems() }
    val held = remember(version) { loot.wielded() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.94f)
                .fillMaxHeight()
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(14.dp),
        ) {
            // Worn items and totals.
            Column(Modifier.width(250.dp).fillMaxHeight().verticalScroll(rememberScrollState())) {
                Text("Equipment", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                // The weapon in your hands.
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Palette.gold.copy(alpha = 0.16f))
                        .border(1.dp, Palette.gold.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                ) {
                    Text(Slot.ICONS[Slot.WEAPON], fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Weapon in hand", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                        Text(
                            held?.name ?: "Nothing",
                            color = if (held != null) Color(Rarity.COLORS[held.rarity]) else Color.White.copy(alpha = 0.35f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                        )
                        if (held != null) Text(held.stats(), color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1)
                    }
                }
                for (slot in 0 until Slot.WORN) {
                    val w = worn[slot]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x22FFFFFF))
                            .pointerInput(slot, version) { detectTapGestures(onTap = { if (w != null) loot.unequip(slot) }) }
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                    ) {
                        Text(Slot.ICONS[slot], fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(Slot.NAMES[slot], color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                            Text(
                                w?.name ?: "Nothing",
                                color = if (w != null) Color(Rarity.COLORS[w.rarity]) else Color.White.copy(alpha = 0.35f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("\u2764\uFE0F  Health ${game.maxHealth.toInt()}", color = Color.White, fontSize = 13.sp)
                Text("\uD83D\uDEE1\uFE0F  Defense ${loot.defense}", color = Color.White, fontSize = 13.sp)
                Text("\u2694\uFE0F  Power ${loot.power}", color = Color.White, fontSize = 13.sp)
                Text("\uD83D\uDCA8  Speed +${loot.speed}%", color = Color.White, fontSize = 13.sp)
                Text("\uD83E\uDE99  Gold ${loot.gold}", color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            // The bag.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("Bag (${bag.size})", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(
                        onClick = onClose,
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
                Text("Tap to wear or wield it, or drink a potion. Tap something you're wearing to take it off. Gems sell to traders.", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    if (bag.isEmpty()) {
                        Text("Empty. Find hidden chests out in the wild and deep in caves!", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    }
                    bag.forEachIndexed { i, item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x22FFFFFF))
                                .border(1.dp, Color(Rarity.COLORS[item.rarity]).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .pointerInput(i, version) {
                                    detectTapGestures(onTap = {
                                        when (item.slot) {
                                            Slot.POTION -> game.drinkPotion(i)
                                            Slot.GEM -> {}
                                            else -> loot.equip(i)
                                        }
                                    })
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        ) {
                            Text(Slot.ICONS[item.slot], fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = Color(Rarity.COLORS[item.rarity]), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(
                                    "${Rarity.NAMES[item.rarity]}  \u00B7  ${item.stats()}",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                )
                            }
                            Text(
                                when (item.slot) {
                                    Slot.POTION -> "DRINK"
                                    Slot.WEAPON -> "WIELD"
                                    Slot.GEM -> "${item.value()}g"
                                    else -> "WEAR"
                                },
                                color = Palette.gold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Shown while you're knocked out. */
@Composable
fun BoxScope.DefeatOverlay(game: Game) {
    val tick = game.hudTick
    if (tick < 0L || !game.dead) return
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("You were defeated", color = Color(0xFFFF6A5A), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text("Waking up in Greenhollow\u2026", color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp)
        }
    }
}

/** The stamina bar. Turns red when you're out of breath. */
@Composable
fun StaminaBar(game: Game, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 240.dp, height = 12.dp)) {
        if (game.hudTick < 0L) return@Canvas
        val s = game.stamina
        val r = size.height / 2f
        drawRoundRect(color = Color(0x88000000), cornerRadius = CornerRadius(r))
        val fill = when {
            game.winded -> Color(0xFFE5534B)
            s < 0.3f -> Color(0xFFFFB347)
            else -> Color(0xFF7BD66F)
        }
        if (s > 0.01f) {
            drawRoundRect(
                color = fill,
                size = Size(size.width * s, size.height),
                cornerRadius = CornerRadius(r),
            )
        }
        drawRoundRect(
            color = Color.White.copy(alpha = 0.5f),
            cornerRadius = CornerRadius(r),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
}

/** The whole world on one screen. Places you've been are in colour, the rest is faded. */
@Composable
fun WorldMap(game: Game, onClose: () -> Unit) {
    val arrow = remember { Path() }
    val rank = game.loot.unlockedRank
    val sealed = remember(rank) { sealOverlay(game.world, rank) }
    val labelPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    val regionPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(5f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    val gridPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = 0xCCFFFFFF.toInt()
            textAlign = android.graphics.Paint.Align.CENTER
            setShadowLayer(3f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6101014))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxHeight()
                .aspectRatio(1f),
        ) {
            if (game.hudTick < 0L) return@Canvas
            val side = size.minDimension
            drawImage(
                image = game.minimapImage,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )
            drawRect(
                color = Palette.gold.copy(alpha = 0.8f),
                size = Size(side, side),
                style = Stroke(width = 2.dp.toPx()),
            )
            val scale = side / WORLD_SIZE

            // Region colours and borders.
            drawImage(
                image = game.regionOverlay,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )
            // Regions still sealed are shaded over.
            drawImage(
                image = sealed,
                dstSize = IntSize(side.toInt(), side.toInt()),
                filterQuality = FilterQuality.Low,
            )

            // Grid: numbers along the top, letters down the side.
            val cellPx = side / Game.MAP_GRID
            for (g in 1 until Game.MAP_GRID) {
                val t = g * cellPx
                drawLine(Color.White.copy(alpha = 0.16f), Offset(t, 0f), Offset(t, side), strokeWidth = 1f)
                drawLine(Color.White.copy(alpha = 0.16f), Offset(0f, t), Offset(side, t), strokeWidth = 1f)
            }
            gridPaint.textSize = 9.dp.toPx()
            drawIntoCanvas { c ->
                for (g in 0 until Game.MAP_GRID) {
                    val mid = (g + 0.5f) * cellPx
                    c.nativeCanvas.drawText(g.toString(), mid, 11.dp.toPx(), gridPaint)
                    c.nativeCanvas.drawText(('A' + g).toString(), 7.dp.toPx(), mid + 3.dp.toPx(), gridPaint)
                }
            }

            // Region names and how tough they are.
            drawIntoCanvas { c ->
                for (k in Zone.entries.indices) {
                    val zn = Zone.entries[k]
                    val lx = REGION_LABEL_X[k] * scale
                    val lz = REGION_LABEL_Z[k] * scale
                    regionPaint.textSize = 15.dp.toPx()
                    regionPaint.color = zn.mapColor or (0xFF shl 24)
                    c.nativeCanvas.drawText(zn.title.uppercase(), lx, lz, regionPaint)
                    regionPaint.textSize = 11.dp.toPx()
                    regionPaint.color = android.graphics.Color.WHITE
                    c.nativeCanvas.drawText(zn.levels, lx, lz + 14.dp.toPx(), regionPaint)
                    if (zoneRank(zn) > rank) {
                        regionPaint.color = 0xFFD8A8FF.toInt()
                        c.nativeCanvas.drawText("\uD83D\uDD12 SEALED", lx, lz + 28.dp.toPx(), regionPaint)
                    }
                }
            }

            // Quest markers: where to go, where to hand in, and new work waiting.
            val qm = game.marks
            var mi = 0
            while (mi < qm.size) {
                val mc = Offset(qm[mi] * scale, qm[mi + 1] * scale)
                val kind = qm[mi + 2].toInt()
                val col = when (kind) { 1 -> Color(0xFF5AE0C0); 2 -> Palette.gold; else -> Color(0xFFFFE070) }
                drawCircle(Palette.night, radius = 8.dp.toPx(), center = mc)
                drawPath(
                    Path().apply {
                        moveTo(mc.x, mc.y - 7.dp.toPx())
                        lineTo(mc.x + 6.dp.toPx(), mc.y + 5.dp.toPx())
                        lineTo(mc.x - 6.dp.toPx(), mc.y + 5.dp.toPx())
                        close()
                    },
                    color = col,
                )
                mi += 3
            }

            // Places: gold and named once found, a hollow ring until then.
            labelPaint.textSize = 10.dp.toPx()
            for (i in PLACES.indices) {
                val pl = PLACES[i]
                val c = Offset(pl.x * scale, pl.z * scale)
                if (game.discovered[i]) {
                    drawCircle(Palette.night, radius = 5.dp.toPx(), center = c)
                    drawCircle(Palette.gold, radius = 3.5.dp.toPx(), center = c)
                } else {
                    drawCircle(Color.White.copy(alpha = 0.7f), radius = 3.5.dp.toPx(), center = c, style = Stroke(width = 1.5.dp.toPx()))
                }
            }
            drawIntoCanvas { cv ->
                for (i in PLACES.indices) {
                    if (!game.discovered[i]) continue
                    val pl = PLACES[i]
                    cv.nativeCanvas.drawText(pl.name, pl.x * scale, pl.z * scale - 7.dp.toPx(), labelPaint)
                }
            }

            // Boss lairs: a red skull while the boss lives, a green tick once it's beaten.
            labelPaint.textSize = 11.dp.toPx()
            for (i in BOSSES.indices) {
                val bc = Offset(game.treasure.lairX[i] * scale, game.treasure.lairZ[i] * scale)
                val beaten = game.loot.bossBeaten(i)
                val dim = zoneRank(BOSSES[i].zone) > rank
                val ring = if (beaten) Color(0xFF3FA84A) else Color(0xFFD83A34)
                drawCircle(Palette.night.copy(alpha = if (dim) 0.5f else 1f), radius = 9.dp.toPx(), center = bc)
                drawCircle(ring.copy(alpha = if (dim) 0.45f else 1f), radius = 7.5.dp.toPx(), center = bc)
                drawIntoCanvas { cv ->
                    labelPaint.alpha = if (dim) 120 else 255
                    cv.nativeCanvas.drawText(if (beaten) "\u2714" else "\u2620", bc.x, bc.y + 4.dp.toPx(), labelPaint)
                    // The boss you need next gets its name on the map.
                    if (i == rank && !beaten) {
                        cv.nativeCanvas.drawText(BOSSES[i].name, bc.x, bc.y - 12.dp.toPx(), labelPaint)
                    }
                    labelPaint.alpha = 255
                }
            }

            // Scale bar: 500 m.
            val bar = 500f * scale
            val by = side - 14.dp.toPx()
            val bx = side - bar - 14.dp.toPx()
            drawLine(Color.White, Offset(bx, by), Offset(bx + bar, by), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx, by - 5.dp.toPx()), Offset(bx, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawLine(Color.White, Offset(bx + bar, by - 5.dp.toPx()), Offset(bx + bar, by + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
            labelPaint.textSize = 11.dp.toPx()
            drawIntoCanvas { it.nativeCanvas.drawText("500 m", bx + bar / 2f, by - 8.dp.toPx(), labelPaint) }

            // You are here.
            val px = game.x * scale
            val pz = game.z * scale
            val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
            drawCircle(Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(px, pz))
            rotate(degrees = deg, pivot = Offset(px, pz)) {
                val a = 9.dp.toPx()
                arrow.reset()
                arrow.moveTo(px, pz - a)
                arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
                arrow.lineTo(px, pz + a * 0.3f)
                arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
                arrow.close()
                drawPath(arrow, color = Palette.gold)
                drawPath(arrow, color = Palette.night, style = Stroke(width = 1.5.dp.toPx()))
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(20.dp),
        ) {
            Text("World map", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("2.9 km across", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text("You are in ${game.gridRef()}", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "Places found: ${game.discovered.count { it }} of ${PLACES.size}",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
            )
            Text("Bright: explored", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            val nextBoss = BOSSES.indices.firstOrNull { !game.loot.bossBeaten(it) }
            if (nextBoss != null) {
                Text("\u2620\uFE0F Next boss", color = Color(0xFFFF6A5A), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(BOSSES[nextBoss].name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("in ${BOSSES[nextBoss].zone.title}, Lv ${BOSSES[nextBoss].level}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                Text("Beat it to break the next seal", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
            } else {
                Text("Every boss beaten!", color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Box(
            Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(16.dp),
        ) {
            HudButton("✕", active = false, size = 52.dp, onPress = onClose)
        }
    }
}

/** A map of the area around you, filling in as you explore. North is up. */
@Composable
fun Minimap(game: Game, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    val arrow = remember { Path() }
    Canvas(
        modifier
            .size(116.dp)
            .clip(shape)
            .background(Palette.night)
            .border(2.dp, Palette.gold.copy(alpha = 0.7f), shape),
    ) {
        if (game.hudTick < 0L) return@Canvas
        val window = 110 // cells shown across, about 660 m
        val ci = (game.x / CELL).toInt()
        val cj = (game.z / CELL).toInt()
        val sx = (ci - window / 2).coerceIn(0, GRID - window)
        val sz = (cj - window / 2).coerceIn(0, GRID - window)
        drawImage(
            image = game.minimapImage,
            srcOffset = IntOffset(sx, sz),
            srcSize = IntSize(window, window),
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = FilterQuality.Low,
        )
        val scale = size.width / window
        val qm = game.marks
        var mi = 0
        while (mi < qm.size) {
            val mx = (qm[mi] / CELL - sx) * scale
            val mz = (qm[mi + 1] / CELL - sz) * scale
            if (mx in 0f..size.width && mz in 0f..size.height) {
                val kind = qm[mi + 2].toInt()
                val col = when (kind) { 1 -> Color(0xFF5AE0C0); 2 -> Palette.gold; else -> Color(0xFFFFE070) }
                drawCircle(col, radius = 4.dp.toPx(), center = Offset(mx, mz))
            }
            mi += 3
        }
        val px = (game.x / CELL - sx) * scale
        val pz = (game.z / CELL - sz) * scale
        val deg = -game.yaw * (180f / kotlin.math.PI.toFloat()) + 180f
        rotate(degrees = deg, pivot = Offset(px, pz)) {
            val a = 7.dp.toPx()
            arrow.reset()
            arrow.moveTo(px, pz - a)
            arrow.lineTo(px + a * 0.7f, pz + a * 0.7f)
            arrow.lineTo(px, pz + a * 0.3f)
            arrow.lineTo(px - a * 0.7f, pz + a * 0.7f)
            arrow.close()
            drawPath(arrow, color = Color.White)
            drawPath(arrow, color = Palette.night, style = Stroke(width = 1.dp.toPx()))
        }
    }
}

@Composable
fun BoxScope.ZoneBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val zone = game.zone
    LaunchedEffect(game.zoneVisit) {
        visible = true
        delay(2800)
        visible = false
    }
    val bannerAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(500),
        label = "zoneBanner",
    )
    if (bannerAlpha > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 36.dp)
                .graphicsLayer { alpha = bannerAlpha }
                .background(Color(0xCC15131C), RoundedCornerShape(16.dp))
                .padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(zone.title, color = Color(zone.mapColor or (0xFF shl 24)), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(zone.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Text(zone.levels, color = Palette.gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Pops up when you find a named place. */
@Composable
fun BoxScope.DiscoveryBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val name = game.lastDiscovered
    LaunchedEffect(game.discoverVisit) {
        if (game.discoverVisit == 0) return@LaunchedEffect
        visible = true
        delay(3200)
        visible = false
    }
    val a by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(400),
        label = "discovery",
    )
    if (a > 0.01f) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer { alpha = a }
                .background(Color(0xCC15131C), RoundedCornerShape(14.dp))
                .border(1.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(horizontal = 26.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("DISCOVERED", color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Which map square you're in. */
@Composable
fun GridRef(game: Game) {
    val tick = game.hudTick
    Text(
        if (tick >= 0L) game.gridRef() else "",
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(Color(0x99000000), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}

/** A dark, hatched layer over every region that's still sealed, for the big map. */
fun sealOverlay(world: World, rank: Int): ImageBitmap {
    val px = IntArray(GRID * GRID)
    for (j in 0 until GRID) {
        for (i in 0 until GRID) {
            val idx = j * GRID + i
            val zr = zoneRank(Zone.entries[world.regionMap[idx].toInt()])
            px[idx] = if (zr <= rank) 0 else if ((i + j) % 9 < 2) 0xB05A2A7A.toInt() else 0x8C000000.toInt()
        }
    }
    return android.graphics.Bitmap.createBitmap(GRID, GRID, android.graphics.Bitmap.Config.ARGB_8888).apply {
        setPixels(px, 0, GRID, 0, 0, GRID, GRID)
    }.asImageBitmap()
}

/**
 * Searching a fallen monster, like in Fallout: everything it was carrying in a list.
 * Tap something to take it, or take the lot.
 */
@Composable
fun SearchWindow(game: Game) {
    val v = game.searchVersion
    val body = game.searching ?: return
    val items = remember(v, body) { game.searchItems() }
    val gold = remember(v, body) { game.searchGold() }
    LaunchedEffect(body) {
        game.moveX = 0f
        game.moveY = 0f
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.62f)
                .fillMaxHeight(0.9f)
                .background(Color(0xF21B1812), RoundedCornerShape(16.dp))
                .border(2.dp, Palette.gold.copy(alpha = 0.75f), RoundedCornerShape(16.dp))
                .padding(14.dp),
        ) {
            Text("\uD83D\uDD0D  SEARCHING", color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text(game.searchName(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Tap something to take it", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                if (gold > 0) {
                    LootRow("\uD83E\uDE99", "$gold gold", Palette.gold, "Coins", "TAKE") { game.takeGold() }
                }
                items.forEachIndexed { i, item ->
                    LootRow(
                        Slot.ICONS[item.slot],
                        item.name,
                        Color(Rarity.COLORS[item.rarity]),
                        "${Rarity.NAMES[item.rarity]} ${Slot.NAMES[item.slot]}  \u00B7  ${item.stats()}",
                        "TAKE",
                    ) { game.takeItem(i) }
                }
                if (items.isEmpty() && gold == 0) {
                    Text("Nothing left on the body.", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (items.isNotEmpty() || gold > 0) {
                    Button(
                        onClick = { game.takeAll() },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("TAKE ALL", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(10.dp))
                }
                Button(
                    onClick = { game.closeSearch() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A342A), contentColor = Color.White),
                ) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** One line in the loot window. */
@Composable
private fun LootRow(icon: String, name: String, color: Color, detail: String, button: String, onTake: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .pointerInput(name, detail) { detectTapGestures(onTap = { onTake() }) }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(detail, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, maxLines = 1)
        }
        Text(button, color = Palette.gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** A boss steps out to fight you, or falls. */
@Composable
fun BoxScope.BossBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.bossVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(4000)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(450), label = "boss")
    if (a < 0.01f) return
    val defeated = game.bossTitle == "BOSS DEFEATED"
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .padding(bottom = 150.dp)
            .graphicsLayer {
                alpha = a
                scaleX = 0.85f + 0.15f * a
                scaleY = 0.85f + 0.15f * a
            }
            .background(Color(0xCC120C0C), RoundedCornerShape(16.dp))
            .border(1.5.dp, (if (defeated) Palette.gold else Color(0xFFD83A34)).copy(alpha = 0.85f), RoundedCornerShape(16.dp))
            .padding(horizontal = 26.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            if (defeated) game.bossTitle else "\u2620\uFE0F  ${game.bossTitle}",
            color = if (defeated) Palette.gold else Color(0xFFFF5A4A),
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp,
        )
        Text(game.bossLine, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** You walked into the seal round a region you haven't earned yet. */
@Composable
fun BoxScope.SealBanner(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.sealVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3800)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(400), label = "seal")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .align(Alignment.Center)
            .padding(horizontal = 60.dp)
            .graphicsLayer { alpha = a }
            .background(Color(0xDD1A1224), RoundedCornerShape(16.dp))
            .border(1.5.dp, Color(0xFFB080FF).copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("\uD83D\uDD12  SEALED", color = Color(0xFFD8A8FF), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Text(game.sealText, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

/** News about a quest: given, or ready to hand in. */
@Composable
fun QuestToast(game: Game) {
    var visible by remember { mutableStateOf(false) }
    val visit = game.questVisit
    LaunchedEffect(visit) {
        if (visit == 0) return@LaunchedEffect
        visible = true
        delay(3800)
        visible = false
    }
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(350), label = "quest")
    if (a < 0.01f) return
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 130.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            game.questToast,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .graphicsLayer { alpha = a }
                .background(Color(0xDD1E1B26), RoundedCornerShape(12.dp))
                .border(1.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .padding(horizontal = 18.dp, vertical = 9.dp)
                .widthIn(max = 280.dp),
        )
    }
}

/** Talking to a villager, trader, elder, guard or lord. Elders and lords may have a quest. */
@Composable
fun TalkWindow(game: Game) {
    val v = game.talkVersion
    val npc = game.talkingTo ?: return
    val quest = remember(v, npc) { game.talkQuest() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(16.dp)
                .fillMaxWidth(0.92f)
                .background(Color(0xF21E1B26), RoundedCornerShape(16.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                .padding(16.dp),
        ) {
            Text(npc.title, color = Palette.gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(npc.subtitle, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            if (quest != null) {
                Text(
                    when (quest.state) {
                        QState.READY -> "You've done it. Thank you, truly."
                        QState.ACTIVE -> quest.intro
                        else -> quest.intro
                    },
                    color = Color.White,
                    fontSize = 14.sp,
                )
                Spacer(Modifier.height(6.dp))
                if (quest.state != QState.READY) {
                    Text(quest.goal(), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Reward: ${quest.gold} gold, ${quest.xp} XP" + (if (quest.state == QState.NEW) ", and something good" else ""),
                        color = Palette.gold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            } else {
                Text(game.talkLine, color = Color.White, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (npc.role == NpcRole.TRADER) {
                    Button(
                        onClick = { game.openTrade() },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("BROWSE GOODS", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                } else if (quest != null && quest.state == QState.NEW) {
                    Button(
                        onClick = { game.acceptQuest(quest) },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("ACCEPT", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(10.dp))
                } else if (quest != null && quest.state == QState.READY) {
                    Button(
                        onClick = { game.handInQuest(quest) },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("HAND IN", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(10.dp))
                }
                Button(
                    onClick = { game.closeTalk() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A342A), contentColor = Color.White),
                ) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** A trader's stall: their goods to buy, and your bag to sell from. */
@Composable
fun TradeWindow(game: Game) {
    val v = game.talkVersion
    val npc = game.trading ?: return
    val loot = game.loot
    val stock = remember(v, npc) { game.tradeStock() }
    val bag = remember(v, loot.version) { loot.bagItems() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.94f)
                .fillMaxHeight()
                .background(Color(0xF01E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(14.dp),
        ) {
            // The trader's goods.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(npc.title, color = Palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("\uD83E\uDE99 ${loot.gold}", color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Text("Tap to buy", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    stock.forEachIndexed { i, item ->
                        val price = loot.buyPrice(item)
                        TradeRow(item, "${price}g", loot.gold >= price) { game.buy(i) }
                    }
                    if (stock.isEmpty()) Text("Sold out for now.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                }
            }
            Spacer(Modifier.width(14.dp))
            // Your bag.
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Your bag", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(
                        onClick = { game.closeTrade() },
                        colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
                Text("Tap to sell", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    if (bag.isEmpty()) Text("Nothing to sell.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    bag.forEachIndexed { i, item ->
                        TradeRow(item, "${loot.sellPrice(item)}g", true) { game.sell(i) }
                    }
                }
            }
        }
    }
}

@Composable
private fun TradeRow(item: Item, price: String, affordable: Boolean, onTap: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, Color(Rarity.COLORS[item.rarity]).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .pointerInput(item, price) { detectTapGestures(onTap = { if (affordable) onTap() }) }
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(Slot.ICONS[item.slot], fontSize = 18.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = Color(Rarity.COLORS[item.rarity]), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(item.stats(), color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1)
        }
        Text(price, color = if (affordable) Palette.gold else Color(0xFF8A5A5A), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** Monsters you've fought (Bestiary) and story fragments you've found (Chronicle). */
@Composable
fun BookPanel(game: Game, onClose: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val v = game.loot.version
    val discovered = remember(v) { game.loot.discoveredSet() }
    val loreHad = remember(v) { game.loot.loreSet() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.86f)
                .background(Color(0xF21E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Book", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                BookTab("Bestiary", tab == 0, Modifier.weight(1f)) { tab = 0 }
                Spacer(Modifier.width(8.dp))
                BookTab("Chronicle", tab == 1, Modifier.weight(1f)) { tab = 1 }
            }
            Spacer(Modifier.height(8.dp))
            if (tab == 0) BestiaryList(game, discovered) else ChronicleList(loreHad)
        }
    }
}

@Composable
private fun BookTab(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (on) Palette.gold.copy(alpha = 0.22f) else Color(0x22FFFFFF))
            .border(1.dp, if (on) Palette.gold else Color.White.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Palette.gold else Color.White.copy(alpha = 0.7f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ColumnScope.BestiaryList(game: Game, discovered: Set<Int>) {
    val total = remember { game.fauna.species.count { it.monster } }
    Text("${discovered.size} / $total monsters catalogued", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
        for (zone in ZONE_ORDER) {
            val entries = game.fauna.species.withIndex()
                .filter { it.value.monster && it.value.zones[0] == zone }
                .sortedBy { it.value.levelMin }
            if (entries.isEmpty()) continue
            Text(
                zone.title, color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
            )
            for ((idx, sp) in entries) {
                val known = idx in discovered
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x22FFFFFF))
                        .padding(10.dp),
                ) {
                    Row {
                        Text(
                            if (known) sp.name else "???",
                            color = if (known) Color.White else Color.White.copy(alpha = 0.35f),
                            fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                        )
                        Text("Lv ${sp.levelMin}-${sp.levelMax}", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                    }
                    if (known) {
                        Text(
                            "HP ${sp.hp}   Damage ${sp.damage.toInt()}   Defense ${(sp.defense * 100).toInt()}%",
                            color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp,
                        )
                        if (sp.ability != Ability.NONE) {
                            Text(
                                "${Ability.label(sp.ability)} \u2014 ${Ability.desc(sp.ability)}",
                                color = Color(0xFFE0A85A), fontSize = 11.sp,
                            )
                        }
                    } else {
                        Text("Fight one to learn what it can do.", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.ChronicleList(had: Set<Int>) {
    Text("${had.size} / ${LoreBook.fragments.size} memories found", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
        for (f in LoreBook.fragments) {
            val known = f.id in had
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x22FFFFFF))
                    .padding(10.dp),
            ) {
                Text(
                    if (known) f.title else "???",
                    color = if (known) Palette.gold else Color.White.copy(alpha = 0.35f),
                    fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    if (known) f.text else "A memory not yet found, somewhere in ${f.zone?.title ?: "the world"}.",
                    color = Color.White.copy(alpha = if (known) 0.75f else 0.4f), fontSize = 12.sp,
                )
            }
        }
    }
}

/** Your main missions and side quests: what's active, and what's ready to hand in. */
@Composable
fun QuestLogPanel(game: Game, onClose: () -> Unit) {
    val v = game.quests.version
    val list = remember(v) { game.quests.current() }
    val done = remember(v) { game.quests.finishedCount() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .padding(10.dp)
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.86f)
                .background(Color(0xF21E1B26), RoundedCornerShape(18.dp))
                .border(1.5.dp, Palette.gold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quest Log", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
            Text("$done quests completed", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                if (list.isEmpty()) {
                    Text(
                        "No active quests. Look for a notice board or an elder in any town, or the lord of a castle, marked with a gold sign over their head.",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                    )
                }
                for (q in list) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (q.main) Palette.gold.copy(alpha = 0.12f) else Color(0x22FFFFFF))
                            .border(
                                1.dp,
                                (if (q.state == QState.READY) Color(0xFF5AE0C0) else Palette.gold).copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp),
                            )
                            .padding(10.dp),
                    ) {
                        Row {
                            Text(
                                if (q.main) "\u2694\uFE0F MAIN" else "SIDE",
                                color = if (q.main) Palette.gold else Color.White.copy(alpha = 0.5f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.weight(1f),
                            )
                            if (q.state == QState.READY) {
                                Text("READY TO HAND IN", color = Color(0xFF5AE0C0), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Text(q.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(q.goal(), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        Text("${q.gold} gold  \u00B7  ${q.xp} XP", color = Palette.gold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
