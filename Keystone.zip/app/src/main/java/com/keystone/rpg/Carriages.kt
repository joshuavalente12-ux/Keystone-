package com.keystone.rpg

import kotlin.math.atan2
import kotlin.math.hypot

/** A stretch of road where a carriage sometimes turns up under attack. */
class CarriageSpot(val x: Float, val z: Float, val yaw: Float, val zone: Zone)

private const val CARRIAGE_NOTICE_RANGE = 55f // how close you need to be to notice one at all
private const val CARRIAGE_FIGHT_RANGE = 130f // how far you can wander before an active fight gives up on you
private const val CARRIAGE_ROLL_COOLDOWN = 25f // seconds before an idle spot you passed can roll again
private const val CARRIAGE_SAVE_COOLDOWN = 360f // seconds before a spot you've already saved can trigger again
private const val CARRIAGE_TRIGGER_CHANCE = 0.4f
private const val CARRIAGE_FOE_MIN = 2
private const val CARRIAGE_FOE_MAX = 4
private const val MIN_SPOT_GAP = 110f

/**
 * Carriages ambushed on the road. The spots themselves are fixed landmarks spread along
 * every road in the world, but whether one is actually under attack when you reach it comes
 * down to a roll and a cooldown, so it never feels scripted. Wade in, clear out whatever's
 * attacking it, and the driver rewards you for the trouble.
 */
class Carriages(world: World, private val fauna: Fauna) {
    val spots: List<CarriageSpot> = buildSpots(world)

    private val active = BooleanArray(spots.size)
    private val spawnedAny = BooleanArray(spots.size)
    private val cooldown = FloatArray(spots.size)
    private val rnd = java.util.Random(9001)

    /** Called once, the instant a triggered carriage's attackers are all down. */
    var onSaved: ((CarriageSpot) -> Unit)? = null

    /** The spot of the fight you're standing in the middle of right now, or null. */
    var nearActive: CarriageSpot? = null
        private set

    fun update(dt: Float, px: Float, pz: Float) {
        nearActive = null
        for (i in spots.indices) {
            if (cooldown[i] > 0f) cooldown[i] -= dt
            val s = spots[i]
            val d = hypot(s.x - px, s.z - pz)
            if (active[i]) {
                if (d > CARRIAGE_FIGHT_RANGE) {
                    active[i] = false
                    for (c in fauna.foes) if (c.ambush == i) c.active = false
                    continue
                }
                var alive = 0
                for (c in fauna.foes) if (c.active && c.ambush == i) alive++
                if (spawnedAny[i] && alive == 0) {
                    active[i] = false
                    cooldown[i] = CARRIAGE_SAVE_COOLDOWN
                    onSaved?.invoke(s)
                } else if (d < CARRIAGE_FIGHT_RANGE) {
                    nearActive = s
                }
                continue
            }
            if (cooldown[i] > 0f || d > CARRIAGE_NOTICE_RANGE) continue
            // You're close to an idle spot: roll whether it's under attack right now.
            cooldown[i] = CARRIAGE_ROLL_COOLDOWN
            if (rnd.nextFloat() >= CARRIAGE_TRIGGER_CHANCE) continue
            val count = CARRIAGE_FOE_MIN + rnd.nextInt(CARRIAGE_FOE_MAX - CARRIAGE_FOE_MIN + 1)
            var spawned = 0
            for (k in 0 until count) if (fauna.spawnAmbushFoe(s.x, s.z, s.zone, i)) spawned++
            if (spawned > 0) {
                active[i] = true
                spawnedAny[i] = true
            }
        }
    }
}

/** Samples the world's road network for spots to place carriages, spread across every region. */
private fun buildSpots(world: World): List<CarriageSpot> {
    val lines = world.roadLines
    val segCount = lines.size / 4
    val probe = Probe()
    val out = ArrayList<CarriageSpot>()
    var i = 0
    while (i < segCount) {
        val x0 = lines[i * 4]
        val z0 = lines[i * 4 + 1]
        val x1 = lines[i * 4 + 2]
        val z1 = lines[i * 4 + 3]
        val mx = (x0 + x1) * 0.5f
        val mz = (z0 + z1) * 0.5f
        world.probe(mx, mz, probe)
        val clear = probe.site > 30f && probe.mountain < 0.3f
        val farEnough = out.none { hypot(it.x - mx, it.z - mz) < MIN_SPOT_GAP }
        if (clear && farEnough) {
            out.add(CarriageSpot(mx, mz, atan2(x1 - x0, z1 - z0), probe.zone))
        }
        i += 5
    }
    return out
}
