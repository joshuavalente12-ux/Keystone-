package com.keystone.rpg

/**
 * The bolts a staff or wand throws and the arrows a bow looses, in a colour for each element:
 * 0 Arcane (the plain blue bolt and grey arrowhead), 1 Thunder, 2 Ice, 3 Fire, 4 Void, 5 Rot.
 * Built to the same size and shape as the hero's own, so they swap in as they fly.
 */
class ElementMissiles {
    val meshes = ArrayList<CreaturePart>()
    val bolt: Array<CreaturePart>
    val arrow: Array<CreaturePart>

    init {
        bolt = Array(COUNT) { e -> make { m -> buildBolt(m, e) } }
        arrow = Array(COUNT) { e -> make { m -> buildArrow(m, e) } }
    }

    private fun make(draw: (MeshBuilder) -> Unit): CreaturePart {
        val m = MeshBuilder(4096)
        m.hd = true
        draw(m)
        val cp = CreaturePart(0, 0f, 0f, 0f, 0f, m.finish(), m.vertexCount)
        meshes.add(cp)
        return cp
    }

    /** A small glowing orb with a short tail, tinted for its element. */
    private fun buildBolt(m: MeshBuilder, e: Int) {
        m.blob(0f, 0f, 0f, 0.075f, 0.075f, 0.075f, CORE[e], 470, 0.5f, FLAG_GLOW)
        m.blob(0f, -0.12f, 0f, 0.04f, 0.1f, 0.04f, TAIL[e], 471, 0.35f, FLAG_GLOW)
        if (e != 0) {
            // A few sparks trailing off behind it.
            m.blob(0.03f, -0.22f, 0.02f, 0.022f, 0.022f, 0.022f, TAIL[e], 472, 0.3f, FLAG_GLOW)
            m.blob(-0.03f, -0.3f, -0.02f, 0.016f, 0.016f, 0.016f, CORE[e], 473, 0.3f, FLAG_GLOW)
        }
    }

    /** A thin shaft, a point and three fletches, drawn point-first; the point glows for every element but Arcane. */
    private fun buildArrow(m: MeshBuilder, e: Int) {
        val shaft = 0x8A6438
        val fletch = 0xD8D0B8
        m.limb(0f, -0.4f, 0f, 0f, 0.5f, 0f, 0.016f, 0.016f, shaft, FLAG_FUR)
        if (e == 0) {
            m.spike(0f, 0.5f, 0f, 0.022f, 0.22f, 0f, 0f, 0x9A9EA6, FLAG_TIP)
        } else {
            m.spike(0f, 0.5f, 0f, 0.026f, 0.24f, 0f, 0f, TAIL[e], FLAG_GLOW)
            // A bead of the element just behind the point, and a trail off the fletching.
            m.blob(0f, 0.46f, 0f, 0.04f, 0.05f, 0.04f, CORE[e], 474, 0.3f, FLAG_GLOW)
            m.blob(0f, -0.5f, 0f, 0.03f, 0.05f, 0.03f, TAIL[e], 475, 0.3f, FLAG_GLOW)
        }
        for (a in floatArrayOf(0f, 2.094f, 4.188f)) {
            val cx = kotlin.math.cos(a) * 0.03f
            val cz = kotlin.math.sin(a) * 0.03f
            m.triN(0f, -0.4f, 0f, cx, 0f, cz, cx * 2f, -0.56f, cz * 2f, cx, 0f, cz, 0f, -0.3f, 0f, cx, 0f, cz, fletch, FLAG_FUR)
        }
    }

    companion object {
        const val COUNT = 6
        private const val FLAG_TIP = 254
        private val CORE = intArrayOf(0xCFE8FF, 0xFFF7B0, 0xE6FBFF, 0xFFE27A, 0xEBC8FF, 0xD8F58A)
        private val TAIL = intArrayOf(0x6AB8FF, 0xFFD23A, 0x6FDCFF, 0xFF5A14, 0x7A32C8, 0x4E8A22)
    }
}
