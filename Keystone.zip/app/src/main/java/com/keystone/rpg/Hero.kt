package com.keystone.rpg

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** How each piece of the hero moves. */
object HeroPart {
    const val PELVIS = 0
    const val TORSO = 1
    const val HEAD = 2
    const val ARM_L = 3
    const val ARM_R = 4
    const val FOREARM_L = 5
    const val FOREARM_R = 6
    const val THIGH_L = 7
    const val THIGH_R = 8
    const val SHIN_L = 9
    const val SHIN_R = 10
    const val KUNAI = 11
    const val HALBERD = 12
    const val SWORD = 13
}

/** The three weapon classes you can start with. */
object WeaponClass {
    const val KUNAI = 0
    const val HALBERD = 1
    const val SWORD = 2
}

/** Brushed metal, for the belt buckle. */
private const val FLAG_BUCKLE = 254

private const val SKIN = 0xC8977A
private const val HAIR = 0x4A2F1E
private const val SHIRT = 0xD9CFB6
private const val PANTS = 0x5B4633
private const val BELT = 0x3A2616
private const val LEATHER = 0x6E4A2C
private const val BRASS = 0xB09868

/** Makes the whole body a touch smaller, so the eyes sit at the same height as first person. */
private const val BODY_SCALE = 0.94f

/**
 * The player, seen from behind in third person: a traveller in a loose linen shirt,
 * brown trousers and leather sandals, with short brown hair and a goatee.
 * Built from rounded pieces that hang from each other (hip, knee, shoulder, elbow),
 * so the walk and run swing naturally.
 */
class Hero {
    val parts = ArrayList<CreaturePart>()
    /** The Bloodsworn Kunai, also drawn on its own when thrown. */
    lateinit var kunai: CreaturePart
        private set

    init {
        build()
    }

    private fun part(
        kind: Int, px: Float, py: Float, pz: Float, parent: CreaturePart?, draw: (MeshBuilder) -> Unit,
    ): CreaturePart {
        val m = MeshBuilder(4096)
        m.hd = true
        draw(m)
        val cp = CreaturePart(kind, px, py, pz, 0f, m.finish(), m.vertexCount, parent)
        parts.add(cp)
        return cp
    }

    private fun build() {
        // Hips: the shirt hangs over them, with a leather belt round the waist.
        val pelvis = part(HeroPart.PELVIS, 0f, 1.0f, 0f, null) { m ->
            m.blob(0f, -0.03f, 0f, 0.17f, 0.12f, 0.125f, PANTS, 201, 0.02f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.005f, 0.185f, 0.11f, 0.135f, SHIRT, 202, 0.03f, FLAG_FUR)
            m.blob(0f, 0.07f, 0f, 0.172f, 0.028f, 0.124f, BELT, 203, 0f, FLAG_FUR)
            m.blob(0f, 0.07f, 0.122f, 0.028f, 0.022f, 0.012f, BRASS, 204, 0f, FLAG_BUCKLE)
            // A small pouch on the belt.
            m.blob(0.15f, 0.02f, 0.05f, 0.035f, 0.05f, 0.05f, LEATHER, 205, 0.05f, FLAG_FUR)
        }

        val torso = part(HeroPart.TORSO, 0f, 0.1f, 0f, pelvis) { m ->
            m.blob(0f, 0.08f, 0f, 0.158f, 0.13f, 0.108f, SHIRT, 211, 0.03f, FLAG_FUR)
            m.blob(0f, 0.28f, 0.004f, 0.19f, 0.165f, 0.118f, SHIRT, 212, 0.03f, FLAG_FUR)
            m.blob(0f, 0.41f, -0.005f, 0.215f, 0.07f, 0.105f, SHIRT, 213, 0.02f, FLAG_FUR)
            // Open collar with a little skin showing, and the lacing.
            m.blob(0f, 0.43f, 0.07f, 0.045f, 0.05f, 0.04f, SKIN, 214, 0f, FLAG_FUR)
            m.limb(-0.03f, 0.43f, 0.108f, 0.02f, 0.37f, 0.118f, 0.005f, 0.005f, BELT, FLAG_FUR)
            m.limb(0.03f, 0.43f, 0.108f, -0.02f, 0.37f, 0.118f, 0.005f, 0.005f, BELT, FLAG_FUR)
            // Loose folds of cloth.
            m.limb(-0.08f, 0.2f, 0.11f, -0.1f, 0.02f, 0.1f, 0.012f, 0.01f, shadeRgb(SHIRT, 0.93f), FLAG_FUR)
            m.limb(0.07f, 0.22f, 0.112f, 0.09f, 0.03f, 0.1f, 0.012f, 0.01f, shadeRgb(SHIRT, 0.93f), FLAG_FUR)
            // Neck.
            m.limb(0f, 0.42f, 0f, 0f, 0.57f, 0.012f, 0.056f, 0.05f, SKIN, FLAG_FUR)
        }

        part(HeroPart.HEAD, 0f, 0.56f, 0.01f, torso) { m ->
            // Skull, jaw and face.
            m.blob(0f, 0.13f, 0.01f, 0.1f, 0.12f, 0.11f, SKIN, 221, 0f, FLAG_FUR)
            m.blob(0f, 0.05f, 0.03f, 0.085f, 0.07f, 0.085f, SKIN, 222, 0f, FLAG_FUR)
            m.blob(0f, 0.165f, 0.1f, 0.075f, 0.018f, 0.025f, shadeRgb(SKIN, 0.98f), 223, 0f, FLAG_FUR)
            m.blob(0f, 0.105f, 0.12f, 0.017f, 0.032f, 0.022f, shadeRgb(SKIN, 0.97f), 224, 0f, FLAG_FUR)
            m.blob(-0.018f, 0.082f, 0.125f, 0.01f, 0.008f, 0.008f, shadeRgb(SKIN, 0.9f), 225, 0f, FLAG_FUR)
            m.blob(0.018f, 0.082f, 0.125f, 0.01f, 0.008f, 0.008f, shadeRgb(SKIN, 0.9f), 226, 0f, FLAG_FUR)
            m.blob(0f, 0.058f, 0.114f, 0.026f, 0.006f, 0.007f, 0x8A4A40, 227, 0f, FLAG_FUR)
            // Cheeks.
            m.blob(-0.05f, 0.09f, 0.085f, 0.03f, 0.025f, 0.025f, SKIN, 228, 0f, FLAG_FUR)
            m.blob(0.05f, 0.09f, 0.085f, 0.03f, 0.025f, 0.025f, SKIN, 229, 0f, FLAG_FUR)
            // Eyes, irises and brows.
            for (side in intArrayOf(-1, 1)) {
                val ex = side * 0.038f
                m.blob(ex, 0.14f, 0.107f, 0.017f, 0.011f, 0.012f, 0xF0EDE6, 230 + side, 0f, FLAG_SOLID)
                m.blob(ex, 0.14f, 0.117f, 0.0085f, 0.0085f, 0.004f, 0x3A2816, 232 + side, 0f, FLAG_SOLID)
                m.blob(ex, 0.163f, 0.117f, 0.023f, 0.006f, 0.008f, HAIR, 234 + side, 0f, FLAG_FUR)
                // Ears.
                m.blob(side * 0.1f, 0.12f, 0.005f, 0.015f, 0.03f, 0.022f, shadeRgb(SKIN, 0.96f), 236 + side, 0f, FLAG_FUR)
            }
            // Short brown hair: a close cap over the top and back, with a few tousled tufts.
            m.blob(0f, 0.16f, -0.012f, 0.108f, 0.105f, 0.118f, HAIR, 240, 0.02f, FLAG_FUR)
            m.blob(0f, 0.1f, -0.035f, 0.097f, 0.09f, 0.09f, HAIR, 241, 0.02f, FLAG_FUR)
            for (i in 0 until 7) {
                val a = i * 0.9f
                val r = 0.035f + (i % 3) * 0.018f
                m.blob(
                    sin(a) * r, 0.245f - (i % 3) * 0.012f, cos(a) * r - 0.01f,
                    0.038f, 0.022f, 0.038f, shadeRgb(HAIR, 0.92f + 0.05f * (i % 3)), 242 + i, 0.1f, FLAG_FUR,
                )
            }
            // Goatee: moustache, the sides round the mouth, and a pointed chin beard.
            m.blob(0f, 0.074f, 0.11f, 0.035f, 0.009f, 0.013f, HAIR, 250, 0f, FLAG_FUR)
            m.limb(-0.03f, 0.072f, 0.106f, -0.027f, 0.022f, 0.108f, 0.009f, 0.009f, HAIR, FLAG_FUR)
            m.limb(0.03f, 0.072f, 0.106f, 0.027f, 0.022f, 0.108f, 0.009f, 0.009f, HAIR, FLAG_FUR)
            m.blob(0f, 0.012f, 0.09f, 0.036f, 0.038f, 0.032f, HAIR, 251, 0.05f, FLAG_FUR)
            m.blob(0f, -0.018f, 0.1f, 0.018f, 0.022f, 0.016f, shadeRgb(HAIR, 0.94f), 252, 0f, FLAG_FUR)
        }

        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            val upper = part(if (side < 0) HeroPart.ARM_L else HeroPart.ARM_R, s * 0.215f, 0.41f, 0f, torso) { m ->
                m.blob(0f, 0f, 0f, 0.07f, 0.07f, 0.07f, SHIRT, 260 + side, 0.02f, FLAG_FUR)
                m.limb(0f, -0.01f, 0f, s * 0.015f, -0.26f, 0f, 0.06f, 0.052f, SHIRT, FLAG_FUR)
                m.limb(s * 0.03f, -0.05f, 0.03f, s * 0.035f, -0.2f, 0.035f, 0.01f, 0.01f, shadeRgb(SHIRT, 0.92f), FLAG_FUR)
            }
            val fore = part(if (side < 0) HeroPart.FOREARM_L else HeroPart.FOREARM_R, s * 0.015f, -0.27f, 0f, upper) { m ->
                // Rolled-up sleeve, then bare forearm and hand.
                m.blob(0f, -0.015f, 0f, 0.056f, 0.032f, 0.056f, shadeRgb(SHIRT, 0.95f), 262 + side, 0.05f, FLAG_FUR)
                m.limb(0f, -0.03f, 0f, 0f, -0.24f, 0.01f, 0.04f, 0.031f, SKIN, FLAG_FUR)
                m.blob(0f, -0.3f, 0.012f, 0.022f, 0.052f, 0.042f, SKIN, 264 + side, 0f, FLAG_FUR)
                m.limb(-s * 0.012f, -0.27f, 0.045f, -s * 0.02f, -0.32f, 0.06f, 0.012f, 0.009f, SKIN, FLAG_FUR)
                // Fingers curled together.
                m.blob(0f, -0.345f, 0.018f, 0.02f, 0.03f, 0.036f, shadeRgb(SKIN, 0.97f), 266 + side, 0f, FLAG_FUR)
            }
            // The weapon goes in the hand on the -x side (his right, as seen from behind).
            if (side < 0) {
                kunai = part(HeroPart.KUNAI, 0f, -0.3f, 0.012f, fore) { m -> buildKunai(m) }
                part(HeroPart.HALBERD, 0f, -0.3f, 0.012f, fore) { m -> buildHalberd(m) }
                part(HeroPart.SWORD, 0f, -0.3f, 0.012f, fore) { m -> buildSword(m) }
            }
            val thigh = part(if (side < 0) HeroPart.THIGH_L else HeroPart.THIGH_R, s * 0.095f, -0.04f, 0f, pelvis) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.43f, 0.01f, 0.085f, 0.06f, PANTS, FLAG_FUR)
                m.limb(s * 0.05f, -0.1f, 0.06f, s * 0.045f, -0.35f, 0.05f, 0.012f, 0.01f, shadeRgb(PANTS, 0.9f), FLAG_FUR)
            }
            part(if (side < 0) HeroPart.SHIN_L else HeroPart.SHIN_R, 0f, -0.44f, 0.01f, thigh) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.39f, -0.01f, 0.06f, 0.044f, PANTS, FLAG_FUR)
                m.blob(0f, -0.37f, -0.01f, 0.052f, 0.035f, 0.052f, shadeRgb(PANTS, 0.95f), 270 + side, 0.08f, FLAG_FUR)
                m.limb(0f, -0.39f, -0.01f, 0f, -0.46f, -0.01f, 0.034f, 0.034f, SKIN, FLAG_FUR)
                // Bare foot on a leather sole, with straps over the top and round the ankle.
                m.blob(0f, -0.487f, 0.05f, 0.042f, 0.03f, 0.1f, SKIN, 272 + side, 0f, FLAG_FUR)
                m.blob(0f, -0.497f, 0.14f, 0.038f, 0.02f, 0.03f, shadeRgb(SKIN, 0.97f), 274 + side, 0f, FLAG_FUR)
                m.blob(0f, -0.515f, 0.055f, 0.05f, 0.012f, 0.118f, LEATHER, 276 + side, 0f, FLAG_FUR)
                m.limb(-0.045f, -0.482f, 0.09f, 0.045f, -0.482f, 0.09f, 0.009f, 0.009f, shadeRgb(LEATHER, 0.85f), FLAG_FUR)
                m.limb(-0.043f, -0.49f, 0.03f, 0.043f, -0.47f, 0.02f, 0.009f, 0.009f, shadeRgb(LEATHER, 0.85f), FLAG_FUR)
                m.blob(0f, -0.44f, -0.01f, 0.039f, 0.011f, 0.039f, shadeRgb(LEATHER, 0.85f), 278 + side, 0f, FLAG_FUR)
            }
        }
    }

    // ---------- Weapons: grip at the origin, blade pointing up +y, flat side facing ±z ----------

    /** Bloodsworn Kunai: a huge kunai with a blood-soaked tip, a spiked ring and a red sash. */
    private fun buildKunai(m: MeshBuilder) {
        val steel = 0x9A9EA6
        val blood = 0xB0141A
        // Wrapped grip.
        m.limb(0f, -0.11f, 0f, 0f, 0.13f, 0f, 0.03f, 0.028f, 0x8A5A3A, FLAG_FUR)
        for (i in 0 until 6) m.blob(0f, -0.09f + i * 0.042f, 0f, 0.033f, 0.008f, 0.033f, 0x5A3822, 300 + i, 0f, FLAG_FUR)
        // Diamond blade with a raised ridge, the top running red.
        val baseY = 0.14f
        val wideY = 0.42f
        val tipY = 1.0f
        val w = 0.13f
        for (face in intArrayOf(-1, 1)) {
            val rz = face * 0.036f
            val nz = face.toFloat()
            m.triNC(0f, baseY, 0f, 0f, 0f, nz, steel, -w, wideY, 0f, -0.3f, 0f, nz, steel, 0f, wideY, rz, 0f, 0f, nz, shadeRgb(steel, 1.1f), FLAG_BUCKLE)
            m.triNC(0f, baseY, 0f, 0f, 0f, nz, steel, 0f, wideY, rz, 0f, 0f, nz, shadeRgb(steel, 1.1f), w, wideY, 0f, 0.3f, 0f, nz, steel, FLAG_BUCKLE)
            m.triNC(-w, wideY, 0f, -0.3f, 0f, nz, steel, 0f, tipY, 0f, 0f, 0.2f, nz, blood, 0f, wideY, rz, 0f, 0f, nz, mixRgb(steel, blood, 0.35f), FLAG_BUCKLE)
            m.triNC(0f, wideY, rz, 0f, 0f, nz, mixRgb(steel, blood, 0.35f), 0f, tipY, 0f, 0f, 0.2f, nz, blood, w, wideY, 0f, 0.3f, 0f, nz, steel, FLAG_BUCKLE)
        }
        // Spiked ring at the bottom.
        val ry = -0.22f
        for (i in 0 until 14) {
            val a = i * 6.2831855f / 14f
            m.blob(kotlin.math.cos(a) * 0.085f, ry + sin(a) * 0.085f, 0f, 0.022f, 0.022f, 0.022f, steel, 310 + i, 0f, FLAG_BUCKLE)
        }
        m.limb(-0.1f, ry, 0f, -0.3f, ry, 0f, 0.035f, 0.002f, steel, FLAG_BUCKLE)
        m.limb(0.1f, ry, 0f, 0.3f, ry, 0f, 0.035f, 0.002f, steel, FLAG_BUCKLE)
        m.limb(0f, ry - 0.1f, 0f, 0f, ry - 0.26f, 0f, 0.03f, 0.002f, steel, FLAG_BUCKLE)
        // The red sling sash, tied through the ring and hanging in two tails.
        val sash = 0x8A1018
        m.blob(0f, ry - 0.08f, 0f, 0.05f, 0.035f, 0.03f, sash, 330, 0.1f, FLAG_FUR)
        m.limb(0f, ry - 0.09f, 0f, -0.14f, ry - 0.24f, 0.02f, 0.028f, 0.024f, sash, FLAG_FUR)
        m.limb(-0.14f, ry - 0.24f, 0.02f, -0.3f, ry - 0.34f, 0f, 0.024f, 0.02f, sash, FLAG_FUR)
        m.limb(-0.3f, ry - 0.34f, 0f, -0.42f, ry - 0.5f, 0.03f, 0.02f, 0.008f, sash, FLAG_FUR)
        m.limb(0.02f, ry - 0.09f, 0f, 0.1f, ry - 0.3f, -0.02f, 0.026f, 0.022f, sash, FLAG_FUR)
        m.limb(0.1f, ry - 0.3f, -0.02f, 0.08f, ry - 0.52f, 0f, 0.022f, 0.008f, sash, FLAG_FUR)
    }

    /** Rotroot Halberd: a twisted, infected tree trunk with an axe head at each end and an eye in the middle. */
    private fun buildHalberd(m: MeshBuilder) {
        val wood = 0x8A5A3A
        val steel = 0x7C8088
        val crack = 0xF08AD0
        // Gnarled shaft: a chain of slightly crooked pieces.
        val ys = floatArrayOf(-0.42f, -0.15f, 0.12f, 0.4f, 0.68f, 0.95f, 1.18f, 1.34f)
        val xs = floatArrayOf(0f, 0.012f, -0.01f, 0f, 0.015f, -0.012f, 0.01f, 0f)
        val rs = floatArrayOf(0.042f, 0.046f, 0.05f, 0.058f, 0.05f, 0.056f, 0.07f, 0.05f)
        for (i in 0 until ys.size - 1) {
            m.limb(xs[i], ys[i], 0f, xs[i + 1], ys[i + 1], 0.005f * (i % 2), rs[i], rs[i + 1], shadeRgb(wood, 0.95f + 0.06f * (i % 2)), FLAG_FUR)
        }
        // The eye in the knot at the middle, glowing faintly purple.
        m.blob(0f, 0.4f, 0f, 0.08f, 0.14f, 0.075f, wood, 340, 0.1f, FLAG_FUR)
        m.blob(0f, 0.4f, 0.06f, 0.028f, 0.075f, 0.022f, 0x9A8AC8, 341, 0f, FLAG_GLOW)
        m.blob(0f, 0.4f, -0.06f, 0.028f, 0.075f, 0.022f, 0x9A8AC8, 342, 0f, FLAG_GLOW)
        // Green cloth wraps with trailing strips.
        for (wy in floatArrayOf(0.05f, 0.76f)) {
            m.blob(0f, wy, 0f, 0.066f, 0.04f, 0.066f, 0x9AD27A, 343, 0.15f, FLAG_FUR)
            m.limb(0.05f, wy - 0.02f, 0.02f, 0.08f, wy - 0.26f, 0.03f, 0.016f, 0.01f, 0xC8C890, FLAG_FUR)
            m.limb(0.08f, wy - 0.26f, 0.03f, 0.06f, wy - 0.4f, 0.02f, 0.01f, 0.004f, 0x7ACC5A, FLAG_FUR)
        }
        // Roots splaying out and gripping the top head.
        for (i in 0 until 6) {
            val a = i * 1.047f
            val cx = kotlin.math.cos(a)
            val cz = sin(a)
            m.limb(0f, 1.18f, 0f, cx * 0.12f, 1.3f, cz * 0.12f, 0.022f, 0.012f, wood, FLAG_FUR)
            m.limb(cx * 0.12f, 1.3f, cz * 0.12f, cx * 0.06f, 1.42f, cz * 0.06f, 0.012f, 0.004f, wood, FLAG_FUR)
        }
        // Splintered bottom end.
        for (i in 0 until 5) {
            val a = i * 1.2566f
            m.spike(kotlin.math.cos(a) * 0.02f, -0.46f, sin(a) * 0.02f, 0.012f, 0.08f, kotlin.math.cos(a) * 0.3f, sin(a) * 0.3f, wood, FLAG_SOLID)
        }
        axeHead(m, 1.48f, 1f, steel, crack)
        axeHead(m, -0.52f, -1f, steel, crack)
    }

    /** A double-bitted axe head centred at height [hy]; its spike points up ([dir] = 1) or down (-1). */
    private fun axeHead(m: MeshBuilder, hy: Float, dir: Float, steel: Int, crack: Int) {
        m.box(0f, hy, 0f, 0.05f, 0.13f, 0.035f, 0f, shadeRgb(steel, 0.85f), FLAG_BUCKLE)
        for (side in intArrayOf(-1, 1)) {
            val sx = side.toFloat()
            val px = floatArrayOf(0.05f, 0.2f, 0.3f, 0.24f, 0.3f, 0.2f, 0.05f)
            val py = floatArrayOf(0.13f, 0.2f, 0.25f, 0f, -0.25f, -0.2f, -0.13f)
            for (face in intArrayOf(-1, 1)) {
                val fz = face * 0.012f
                for (k in 0 until px.size - 1) {
                    m.triN(
                        sx * 0.05f, hy, fz, 0f, 0f, face.toFloat(),
                        sx * px[k], hy + py[k], fz, 0f, 0f, face.toFloat(),
                        sx * px[k + 1], hy + py[k + 1], fz, 0f, 0f, face.toFloat(),
                        if (k == 2 || k == 3) shadeRgb(steel, 1.15f) else steel, FLAG_BUCKLE,
                    )
                }
                // Glowing pink cracks across the blade.
                m.limb(sx * 0.08f, hy + 0.05f, fz * 1.4f, sx * 0.18f, hy + 0.12f, fz * 1.4f, 0.004f, 0.004f, crack, FLAG_GLOW)
                m.limb(sx * 0.12f, hy - 0.02f, fz * 1.4f, sx * 0.22f, hy - 0.1f, fz * 1.4f, 0.004f, 0.004f, crack, FLAG_GLOW)
            }
            // Blade edges.
            m.limb(sx * 0.3f, hy + 0.25f, 0f, sx * 0.24f, hy, 0f, 0.012f, 0.012f, shadeRgb(steel, 1.2f), FLAG_BUCKLE)
            m.limb(sx * 0.24f, hy, 0f, sx * 0.3f, hy - 0.25f, 0f, 0.012f, 0.012f, shadeRgb(steel, 1.2f), FLAG_BUCKLE)
        }
        m.limb(0f, hy + dir * 0.13f, 0f, 0f, hy + dir * 0.36f, 0f, 0.035f, 0.002f, steel, FLAG_BUCKLE)
    }

    /** Mind, Body & Soul Sword: an eye in the blade, beast hearts in the guard, a brain in the pommel. */
    private fun buildSword(m: MeshBuilder) {
        val steel = 0x8C9098
        val leather = 0x8A5A32
        // Grip with a spiral wrap.
        m.limb(0f, -0.12f, 0f, 0f, 0.2f, 0f, 0.028f, 0.03f, leather, FLAG_FUR)
        for (i in 0 until 6) m.blob(0f, -0.09f + i * 0.05f, 0f, 0.032f, 0.008f, 0.032f, 0x5A3822, 350 + i, 0f, FLAG_FUR)
        // Pommel ring holding a glowing pink brain.
        val py = -0.2f
        for (i in 0 until 14) {
            val a = i * 6.2831855f / 14f
            m.blob(kotlin.math.cos(a) * 0.07f, py + sin(a) * 0.07f, 0f, 0.022f, 0.022f, 0.022f, leather, 360 + i, 0f, FLAG_FUR)
        }
        m.blob(0f, py, 0f, 0.046f, 0.044f, 0.03f, 0xE88AB0, 380, 0.3f, FLAG_GLOW)
        // Crossguard with a beast heart glowing red in each end.
        m.limb(-0.2f, 0.22f, 0f, 0.2f, 0.22f, 0f, 0.03f, 0.03f, leather, FLAG_FUR)
        for (side in intArrayOf(-1, 1)) {
            val hx = side * 0.24f
            for (i in 0 until 10) {
                val a = i * 0.6283f
                m.blob(hx + kotlin.math.cos(a) * 0.05f, 0.22f + sin(a) * 0.05f, 0f, 0.016f, 0.016f, 0.016f, leather, 381 + i, 0f, FLAG_FUR)
            }
            m.blob(hx, 0.22f, 0f, 0.032f, 0.036f, 0.024f, 0xE0302A, 392 + side, 0.15f, FLAG_GLOW)
        }
        m.spike(0f, 0.2f, 0f, 0.022f, 0.12f, 0f, 0f, 0xB8BCC4, FLAG_BUCKLE)
        // Broad blade with a fuller down the middle, and a pointed tip.
        m.box(0f, 0.76f, 0f, 0.085f, 0.5f, 0.013f, 0f, steel, FLAG_BUCKLE)
        m.box(0f, 0.7f, 0.013f, 0.008f, 0.38f, 0.002f, 0f, 0x6A6E76, FLAG_BUCKLE)
        m.box(0f, 0.7f, -0.013f, 0.008f, 0.38f, 0.002f, 0f, 0x6A6E76, FLAG_BUCKLE)
        for (face in intArrayOf(-1, 1)) {
            val fz = face * 0.013f
            m.triN(-0.085f, 1.26f, fz, 0f, 0f, face.toFloat(), 0.085f, 1.26f, fz, 0f, 0f, face.toFloat(), 0f, 1.42f, 0f, 0f, 0.3f, face.toFloat(), steel, FLAG_BUCKLE)
        }
        m.triN(-0.085f, 1.26f, 0.013f, -1f, 0.5f, 0f, -0.085f, 1.26f, -0.013f, -1f, 0.5f, 0f, 0f, 1.42f, 0f, -1f, 0.5f, 0f, steel, FLAG_BUCKLE)
        m.triN(0.085f, 1.26f, 0.013f, 1f, 0.5f, 0f, 0.085f, 1.26f, -0.013f, 1f, 0.5f, 0f, 0f, 1.42f, 0f, 1f, 0.5f, 0f, steel, FLAG_BUCKLE)
        // The eye, set in a round frame through the blade, glowing green.
        val ey = 0.66f
        for (i in 0 until 16) {
            val a = i * 0.3927f
            m.blob(kotlin.math.cos(a) * 0.1f, ey + sin(a) * 0.1f, 0f, 0.026f, 0.026f, 0.026f, 0x5A5E66, 400 + i, 0f, FLAG_BUCKLE)
        }
        m.blob(0f, ey, 0f, 0.09f, 0.09f, 0.03f, 0xE8F4E4, 420, 0f, FLAG_SOLID)
        for (face in intArrayOf(-1, 1)) {
            m.blob(0f, ey, face * 0.026f, 0.05f, 0.05f, 0.012f, 0x3AC84A, 421, 0f, FLAG_GLOW)
            m.blob(0f, ey, face * 0.034f, 0.018f, 0.018f, 0.006f, 0x101010, 422, 0f, FLAG_SOLID)
        }
    }

    /** Whether to draw this piece right now: only the weapon you chose, and not while it's flying. */
    fun visible(g: Game, part: CreaturePart): Boolean = when (part.kind) {
        HeroPart.KUNAI -> g.weaponClass == WeaponClass.KUNAI && g.weaponInHand
        HeroPart.HALBERD -> g.weaponClass == WeaponClass.HALBERD
        HeroPart.SWORD -> g.weaponClass == WeaponClass.SWORD
        else -> true
    }

    /** Builds the model matrix for one piece of the hero, as he is standing or moving right now. */
    fun pose(g: Game, part: CreaturePart, out: FloatArray) {
        val m = g.moveAmount
        val run = g.runAmount
        val ph = g.stridePhase
        val air = g.airAmount
        val bob = (abs(cos(ph)) - 0.6f) * 0.05f * m * (1f - air)
        figure(g, m, run, ph, air)
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, g.x, g.feet + bob, g.z)
        Matrix.rotateM(out, 0, deg(g.bodyYaw + spin), 0f, 1f, 0f)
        // Dodge roll: a full forward somersault about the middle of the body, in the way he's rolling.
        val dp = g.dodgePhase
        if (dp >= 0f) {
            val pivot = 0.7f * BODY_SCALE
            Matrix.translateM(out, 0, 0f, pivot, 0f)
            Matrix.rotateM(out, 0, 360f * smooth01(dp.coerceIn(0f, 1f)), 1f, 0f, 0f)
            Matrix.translateM(out, 0, 0f, -pivot, 0f)
        }
        Matrix.scaleM(out, 0, BODY_SCALE, BODY_SCALE, BODY_SCALE)
        apply(g, part, out, m, run, ph, air)
    }

    // The upper body for this frame: walking pose blended with the attack animation.
    private val cur = FloatArray(K_COUNT)
    private val walkPose = FloatArray(K_COUNT)
    private val attackPose = FloatArray(K_COUNT)
    private var spin = 0f
    private var figuredAt = -1f

    private fun figure(g: Game, m: Float, run: Float, ph: Float, air: Float) {
        // Same frame (the other parts): already worked out.
        if (g.time == figuredAt) return
        figuredAt = g.time
        val walkA = (0.5f * m + 0.3f * run) * (1f - air)
        val breathe = sin(g.time * 1.8f)
        val wc = g.weaponClass
        val swingW = sin(ph) * walkA          // the -x (weapon) side leg
        val swingO = sin(ph + PI_F) * walkA   // the +x side leg
        walkPose[K_TW] = -sin(ph) * 0.2f * m
        walkPose[K_LN] = 0.06f * m + 0.2f * run
        walkPose[K_AAZ] = 0f
        walkPose[K_AEL] = -swingW * 0.9f * (if (wc == WeaponClass.HALBERD) 0.4f else 1f) + breathe * 0.015f * (1f - m) - air * 0.5f
        walkPose[K_AOUT] = 0.08f + air * 0.45f + run * 0.05f
        walkPose[K_ABEND] = 0.22f + 0.35f * m + 0.95f * run * (if (wc == WeaponClass.HALBERD) 0.3f else 1f) + air * 0.6f
        walkPose[K_WX] = when (wc) {
            WeaponClass.HALBERD -> -0.12f - walkPose[K_ABEND] + 0.22f
            WeaponClass.SWORD -> 2.2f
            else -> 2.3f
        }
        walkPose[K_WR] = if (wc == WeaponClass.HALBERD) 0f else 1.5707964f
        walkPose[K_OAZ] = 0f
        walkPose[K_OEL] = -swingO * 0.9f + breathe * 0.015f * (1f - m) - air * 0.5f
        walkPose[K_OOUT] = 0.08f + air * 0.45f + run * 0.05f
        walkPose[K_OBEND] = 0.22f + 0.35f * m + 0.95f * run + air * 0.6f
        val p = g.attackPhase
        if (p < 0f) {
            walkPose.copyInto(cur)
            spin = 0f
            return
        }
        val keys = when (wc) {
            WeaponClass.KUNAI -> KUNAI_KEYS
            WeaponClass.HALBERD -> HALBERD_KEYS
            else -> SWORD_KEYS
        }
        // Find the two keyframes either side of p, and ease between them.
        val n = keys.size / K_STRIDE
        var i = 0
        while (i < n - 2 && keys[(i + 1) * K_STRIDE] <= p) i++
        val a = i * K_STRIDE
        val b = a + K_STRIDE
        val span = keys[b] - keys[a]
        val t = smooth01(if (span > 1e-4f) (p - keys[a]) / span else 1f)
        for (k in 0 until K_COUNT) attackPose[k] = keys[a + 1 + k] + (keys[b + 1 + k] - keys[a + 1 + k]) * t
        // Blend in quickly at the start and out at the end. Spinning isn't blended (a full turn is no turn).
        val w = min(1f, min(p / 0.08f, (1f - p) / 0.12f))
        for (k in 0 until K_COUNT) cur[k] = walkPose[k] + (attackPose[k] - walkPose[k]) * w
        spin = attackPose[K_SP]
        cur[K_SP] = 0f
    }

    private fun apply(g: Game, part: CreaturePart, out: FloatArray, m: Float, run: Float, ph: Float, air: Float) {
        val parent = part.parent
        if (parent != null) apply(g, parent, out, m, run, ph, air)
        Matrix.translateM(out, 0, part.px, part.py, part.pz)
        when (part.kind) {
            HeroPart.PELVIS -> {
                Matrix.rotateM(out, 0, deg(sin(ph) * 0.12f * m), 0f, 1f, 0f)
            }
            HeroPart.TORSO -> {
                Matrix.rotateM(out, 0, deg(cur[K_TW]), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_LN] + sin(g.time * 1.8f) * 0.01f), 1f, 0f, 0f)
            }
            HeroPart.HEAD -> {
                val look = sin(g.time * 0.37f) * 0.12f * (1f - m)
                Matrix.rotateM(out, 0, deg(look - cur[K_TW] * 0.5f), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(-cur[K_LN] * 0.7f + sin(g.time * 0.23f) * 0.03f), 1f, 0f, 0f)
            }
            HeroPart.ARM_L -> {
                // Weapon arm (-x side): inward is towards +x.
                Matrix.rotateM(out, 0, deg(cur[K_AAZ]), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_AEL]), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(-cur[K_AOUT]), 0f, 0f, 1f)
            }
            HeroPart.ARM_R -> {
                Matrix.rotateM(out, 0, deg(-cur[K_OAZ]), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_OEL]), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_OOUT]), 0f, 0f, 1f)
            }
            HeroPart.FOREARM_L -> Matrix.rotateM(out, 0, deg(-cur[K_ABEND]), 1f, 0f, 0f)
            HeroPart.FOREARM_R -> Matrix.rotateM(out, 0, deg(-cur[K_OBEND]), 1f, 0f, 0f)
            HeroPart.KUNAI, HeroPart.HALBERD, HeroPart.SWORD -> {
                Matrix.rotateM(out, 0, deg(cur[K_WX]), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_WR]), 0f, 1f, 0f)
            }
            HeroPart.THIGH_L, HeroPart.THIGH_R -> {
                val left = part.kind == HeroPart.THIGH_L
                val walkA = (0.5f * m + 0.3f * run) * (1f - air)
                val swing = sin(ph + (if (left) 0f else PI_F)) * walkA
                val tuck = air * (if (left) -0.55f else -0.25f)
                Matrix.rotateM(out, 0, deg(swing + tuck), 1f, 0f, 0f)
            }
            HeroPart.SHIN_L, HeroPart.SHIN_R -> {
                val left = part.kind == HeroPart.SHIN_L
                val lift = max(0f, -cos(ph + (if (left) 0f else PI_F)))
                val knee = 0.04f + lift * (0.9f * m + 0.6f * run) * (1f - air) + air * (if (left) 1.0f else 0.6f)
                Matrix.rotateM(out, 0, deg(knee), 1f, 0f, 0f)
            }
            else -> {}
        }
    }

    private fun deg(radians: Float): Float = radians * 57.29578f

    private fun smooth01(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}

private const val PI_F = 3.1415927f
private const val HALF_PI = 1.5707964f

// Pose channels, in keyframe order after the time.
private const val K_SP = 0      // whole-body spin
private const val K_TW = 1      // torso twist (positive brings the weapon shoulder forward)
private const val K_LN = 2      // lean forward
private const val K_AAZ = 3     // weapon arm: swing across the body
private const val K_AEL = 4     // weapon arm: raise (0 down, -1.57 straight ahead, -3.1 straight up)
private const val K_AOUT = 5    // weapon arm: out to the side
private const val K_ABEND = 6   // weapon elbow bend
private const val K_WX = 7      // wrist: tip the weapon
private const val K_WR = 8      // wrist: roll the weapon about its own length
private const val K_OAZ = 9     // other arm, same four
private const val K_OEL = 10
private const val K_OOUT = 11
private const val K_OBEND = 12
private const val K_COUNT = 13
private const val K_STRIDE = 14

// Each row: time (0..1 through the attack), then the 13 channels above.
//                           time  spin   twist lean   aAz    aEl    aOut  aBend  wX           wRoll    oAz   oEl   oOut  oBend
private val SWORD_KEYS = floatArrayOf(
    0.00f, 0f, -0.3f, 0.05f, -0.4f, -0.8f, 0.3f, 0.8f, 2.4f, HALF_PI, 0.2f, -0.6f, 0.3f, 1.4f,
    0.10f, 0f, -0.9f, 0.05f, -1.2f, -1.5f, 0f, 0.3f, PI_F, 0f, 0.2f, -0.6f, 0.3f, 1.4f,
    0.22f, 0f, 0.3f, 0.1f, 0.2f, -1.5f, 0f, 0.1f, PI_F, 0f, 0.2f, -0.6f, 0.3f, 1.4f,
    0.32f, 0f, 0.8f, 0.1f, 1.0f, -1.4f, 0f, 0.4f, PI_F, 0f, 0.2f, -0.6f, 0.3f, 1.4f,
    0.40f, 0f, 0.9f, 0.05f, 1.2f, -1.2f, 0f, 0.8f, PI_F, 0f, 0.2f, -0.6f, 0.3f, 1.4f,
    0.52f, 0f, 0.0f, 0.1f, 0.0f, -1.7f, 0f, 0.1f, PI_F, 0f, 0.2f, -0.6f, 0.3f, 1.4f,
    0.60f, 0f, -0.8f, 0.05f, -1.1f, -1.9f, 0f, 0.3f, PI_F, 0f, 0.2f, -0.6f, 0.3f, 1.4f,
    0.70f, 0f, -0.2f, -0.15f, 0.1f, -3.0f, 0f, 1.0f, PI_F, HALF_PI, -0.1f, -2.4f, 0.2f, 0.9f,
    0.84f, 0f, 0.15f, 0.35f, 0.15f, -0.9f, 0f, 0.0f, PI_F, HALF_PI, 0.3f, -1.0f, 0.1f, 0.4f,
    1.00f, 0f, 0.0f, 0.05f, 0.0f, -0.3f, 0.08f, 0.4f, 2.4f, HALF_PI, 0.0f, -0.2f, 0.1f, 0.4f,
)

private val HALBERD_KEYS = floatArrayOf(
    0.00f, 0f, 0f, 0f, -0.3f, -0.7f, 0.2f, 0.6f, -0.1f, 0f, 0.3f, -0.7f, 0.2f, 0.9f,
    0.08f, -0.5f, -0.6f, 0.05f, -1.4f, -1.45f, 0f, 0.15f, PI_F + 0.15f, HALF_PI, 0f, -0.9f, 0.9f, 0.3f,
    0.30f, 2.51f, 0.2f, 0.05f, -1.4f, -1.45f, 0f, 0.15f, PI_F + 0.15f, HALF_PI, 0f, -0.9f, 0.9f, 0.3f,
    0.48f, 6.2832f, 0f, 0f, -1.3f, -1.5f, 0f, 0.2f, PI_F + 0.15f, HALF_PI, 0f, -0.9f, 0.9f, 0.3f,
    0.64f, 6.2832f, -0.15f, -0.2f, 0.1f, -2.9f, 0f, 0.6f, PI_F - 0.5f, HALF_PI, -0.2f, -2.7f, 0.1f, 0.8f,
    0.80f, 6.2832f, 0.1f, 0.4f, 0.15f, -1.0f, 0f, 0f, PI_F - 0.5f, HALF_PI, 0.3f, -1.1f, 0.1f, 0.3f,
    1.00f, 6.2832f, 0f, 0f, 0f, 0f, 0.08f, 0.22f, -0.12f, 0f, 0f, 0f, 0.08f, 0.22f,
)

private val KUNAI_KEYS = floatArrayOf(
    0.00f, 0f, 0f, 0f, 0f, -0.4f, 0.1f, 0.6f, 2.3f, HALF_PI, 0f, -0.3f, 0.1f, 0.6f,
    0.28f, 0f, -0.7f, -0.1f, -1.0f, -2.7f, 0.3f, 1.3f, PI_F, HALF_PI, 0.2f, -1.4f, 0.2f, 0.2f,
    0.45f, 0f, 0.5f, 0.25f, 0.1f, -1.4f, 0f, 0.1f, PI_F, HALF_PI, 0f, -0.4f, 0.2f, 1.2f,
    0.70f, 0f, 0.7f, 0.3f, 0.4f, -0.6f, 0f, 0.3f, PI_F, HALF_PI, 0f, -0.3f, 0.2f, 1.1f,
    1.00f, 0f, 0f, 0f, 0f, -0.1f, 0.08f, 0.3f, 2.3f, HALF_PI, 0f, 0f, 0.08f, 0.22f,
)
