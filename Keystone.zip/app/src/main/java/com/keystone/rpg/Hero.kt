package com.keystone.rpg

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** How each piece of the hero moves. */
object HeroPart {
    const val PELVIS = 0
    const val TORSO = 1
    const val HEAD = 2
    const val ARM_L = 3
    const val ARM_R = 4
    const val FOREARM_L = 5
    const val FOREARM_R = 6
    const val THIGH_L = 7
    const val THIGH_R = 8
    const val SHIN_L = 9
    const val SHIN_R = 10
    const val KUNAI = 11
    const val HALBERD = 12
    const val SWORD = 13
    const val AXE = 14
    const val PICK = 15
    /** The Warrior's base combat axe (not the woodcutting tool, which is [AXE] above). */
    const val W_AXE = 16
    const val BOW = 17
    const val STAFF = 18
    /** Flying-only visuals: never drawn by the normal held-weapon pass, see [visible]. */
    const val ARROW_FLY = 19
    const val BOLT_FLY = 20
}

/** The weapon kinds in the game. Each class (see [HeroClass]) is locked to some of these. */
object WeaponClass {
    const val KUNAI = 0
    const val HALBERD = 1
    const val SWORD = 2
    const val AXE = 3
    const val BOW = 4
    const val STAFF = 5
}

/** Brushed metal, for the belt buckle. */
private const val FLAG_BUCKLE = 254

private const val SKIN = 0xC8977A
private const val HAIR = 0x4A2F1E
private const val SHIRT = 0xD9CFB6
private const val PANTS = 0x5B4633
private const val BELT = 0x3A2616
private const val LEATHER = 0x6E4A2C
private const val BRASS = 0xB09868
/** Armour by tier: leather, oakguard, frostforged, sunforged, voidcrystal. */
private val ARMOUR_RGB = intArrayOf(0x7A5230, 0x7E8A6A, 0xA8C4D8, 0xD8A84A, 0x6A4A9A)

/** Mixes two colours: [t] = 0 gives [a], 1 gives [b]. */
private fun blendRgb(a: Int, b: Int, t: Float): Int {
    fun ch(sh: Int): Int = (((a shr sh) and 255) * (1f - t) + ((b shr sh) and 255) * t).toInt().coerceIn(0, 255)
    return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

/** Makes the whole body a touch smaller, so the eyes sit at the same height as first person. */
private const val BODY_SCALE = 0.94f

/**
 * The player, seen from behind in third person: a traveller in a loose linen shirt,
 * brown trousers and leather sandals, with short brown hair and a goatee.
 * Built from rounded pieces that hang from each other (hip, knee, shoulder, elbow),
 * so the walk and run swing naturally.
 */
class Hero(private val look: HeroLook = HeroLook(), private val worn: Array<Item?> = arrayOfNulls(Slot.WORN)) {
    val parts = ArrayList<CreaturePart>()
    /** The Bloodsworn Kunai, also drawn on its own when thrown. */
    lateinit var kunai: CreaturePart
    lateinit var arrow: CreaturePart
    lateinit var bolt: CreaturePart
        private set

    init {
        build()
    }

    private fun part(
        kind: Int, px: Float, py: Float, pz: Float, parent: CreaturePart?, draw: (MeshBuilder) -> Unit,
    ): CreaturePart {
        val m = MeshBuilder(4096)
        m.hd = true
        draw(m)
        val cp = CreaturePart(kind, px, py, pz, 0f, m.finish(), m.vertexCount, parent)
        parts.add(cp)
        return cp
    }

    /** Armour colour by the item's tier: leather, oakguard, frostforged, sunforged, voidcrystal. */
    private fun metal(it: Item): Int = ARMOUR_RGB[(it.tier - 1).coerceIn(0, ARMOUR_RGB.size - 1)]
    private fun metalFlag(it: Item): Int = if (it.tier <= 1) FLAG_FUR else FLAG_BUCKLE
    /** Trim in the item's rarity colour; legendary and mythic trim glows. */
    private fun trim(it: Item): Int = (Rarity.COLORS[it.rarity.coerceIn(0, Rarity.MAX)] and 0xFFFFFFL).toInt()
    private fun trimFlag(it: Item): Int = if (it.rarity >= 4) FLAG_GLOW else FLAG_BUCKLE

    private fun build() {
        val skin = HeroLook.SKIN[look.skin]
        val hair = HeroLook.HAIR[look.hair]
        val iris = HeroLook.EYE[look.eyeColor]
        val bw = HeroLook.BODY_W[look.body]
        val bd = HeroLook.BODY_D[look.body]
        val belly = HeroLook.BELLY[look.body]
        val armT = HeroLook.ARM_T[look.arms]
        val foreT = 1f + (armT - 1f) * 0.8f
        val legT = HeroLook.LEG_T[look.legs]
        val footS = HeroLook.FOOT_S[look.feet]
        val footW = 0.9f + (footS - 0.85f) * 0.55f
        val helm = worn.getOrNull(Slot.HEAD)
        val chest = worn.getOrNull(Slot.BODY)
        val gloves = worn.getOrNull(Slot.HANDS)
        val boots = worn.getOrNull(Slot.FEET)
        val ring = worn.getOrNull(Slot.RING)
        val amulet = worn.getOrNull(Slot.AMULET)

        // Hips: the shirt hangs over them, with a leather belt round the waist.
        val pelvis = part(HeroPart.PELVIS, 0f, 1.0f, 0f, null) { m ->
            m.blob(0f, -0.03f, 0f, 0.17f * bw, 0.12f, 0.125f * bd, PANTS, 201, 0.02f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.005f, 0.185f * bw, 0.11f, 0.135f * bd * belly, SHIRT, 202, 0.03f, FLAG_FUR)
            m.blob(0f, 0.07f, 0f, 0.172f * bw, 0.028f, 0.124f * bd * belly, BELT, 203, 0f, FLAG_FUR)
            m.blob(0f, 0.07f, 0.122f * bd * belly, 0.028f, 0.022f, 0.012f, BRASS, 204, 0f, FLAG_BUCKLE)
            // A small pouch on the belt.
            m.blob(0.15f * bw, 0.02f, 0.05f, 0.035f, 0.05f, 0.05f, LEATHER, 205, 0.05f, FLAG_FUR)
            // Body armour: plates over the hips, edged in the rarity colour.
            if (chest != null) {
                m.blob(0f, -0.06f, 0.005f, 0.197f * bw, 0.1f, 0.146f * bd * belly, metal(chest), 206, 0.01f, metalFlag(chest))
                m.blob(0f, -0.15f, 0.005f, 0.199f * bw, 0.013f, 0.148f * bd * belly, trim(chest), 207, 0f, trimFlag(chest))
            }
        }

        val torso = part(HeroPart.TORSO, 0f, 0.1f, 0f, pelvis) { m ->
            m.blob(0f, 0.08f, 0f, 0.158f * bw * belly, 0.13f, 0.108f * bd * belly, SHIRT, 211, 0.03f, FLAG_FUR)
            m.blob(0f, 0.28f, 0.004f, 0.19f * bw, 0.165f, 0.118f * bd, SHIRT, 212, 0.03f, FLAG_FUR)
            m.blob(0f, 0.41f, -0.005f, 0.215f * bw, 0.07f, 0.105f * bd, SHIRT, 213, 0.02f, FLAG_FUR)
            // Open collar with a little skin showing, and the lacing.
            m.blob(0f, 0.43f, 0.07f * bd, 0.045f, 0.05f, 0.04f, skin, 214, 0f, FLAG_FUR)
            m.limb(-0.03f, 0.43f, 0.108f * bd, 0.02f, 0.37f, 0.118f * bd, 0.005f, 0.005f, BELT, FLAG_FUR)
            m.limb(0.03f, 0.43f, 0.108f * bd, -0.02f, 0.37f, 0.118f * bd, 0.005f, 0.005f, BELT, FLAG_FUR)
            // Loose folds of cloth.
            m.limb(-0.08f, 0.2f, 0.11f * bd, -0.1f, 0.02f, 0.1f * bd, 0.012f, 0.01f, shadeRgb(SHIRT, 0.93f), FLAG_FUR)
            m.limb(0.07f, 0.22f, 0.112f * bd, 0.09f, 0.03f, 0.1f * bd, 0.012f, 0.01f, shadeRgb(SHIRT, 0.93f), FLAG_FUR)
            // Neck.
            m.limb(0f, 0.42f, 0f, 0f, 0.57f, 0.012f, 0.056f, 0.05f, skin, FLAG_FUR)
            var front = 0.118f * bd
            // Body armour: a breastplate over the shirt, a gorget at the collar, trim and (for the
            // finer pieces) an emblem on the chest.
            if (chest != null) {
                val mc = metal(chest)
                val mf = metalFlag(chest)
                m.blob(0f, 0.09f, 0f, 0.168f * bw * belly, 0.135f, 0.117f * bd * belly, mc, 215, 0.01f, mf)
                m.blob(0f, 0.28f, 0.006f, 0.202f * bw, 0.17f, 0.128f * bd, mc, 216, 0.01f, mf)
                m.blob(0f, 0.41f, -0.004f, 0.226f * bw, 0.075f, 0.113f * bd, shadeRgb(mc, 0.92f), 217, 0.01f, mf)
                m.blob(0f, 0.465f, 0f, 0.07f, 0.03f, 0.07f, shadeRgb(mc, 0.85f), 218, 0f, mf)
                m.blob(0f, -0.04f, 0f, 0.17f * bw * belly, 0.014f, 0.119f * bd * belly, trim(chest), 219, 0f, trimFlag(chest))
                if (chest.rarity >= 3) {
                    m.blob(0f, 0.3f, 0.13f * bd, 0.035f, 0.045f, 0.012f, trim(chest), 220, 0f, trimFlag(chest))
                }
                front = 0.13f * bd
            }
            // An amulet on a gold chain, its stone in the rarity colour.
            if (amulet != null) {
                m.limb(-0.055f, 0.45f, 0.06f * bd, 0f, 0.33f, front + 0.004f, 0.004f, 0.004f, 0xC8A040, FLAG_BUCKLE)
                m.limb(0.055f, 0.45f, 0.06f * bd, 0f, 0.33f, front + 0.004f, 0.004f, 0.004f, 0xC8A040, FLAG_BUCKLE)
                m.blob(0f, 0.315f, front + 0.008f, 0.022f, 0.028f, 0.01f, 0xC8A040, 221, 0f, FLAG_BUCKLE)
                m.blob(0f, 0.315f, front + 0.016f, 0.013f, 0.017f, 0.007f, trim(amulet), 222, 0f, FLAG_GLOW)
            }
        }

        part(HeroPart.HEAD, 0f, 0.56f, 0.01f, torso) { m -> buildHead(m, skin, hair, iris, helm) }

        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            val upper = part(if (side < 0) HeroPart.ARM_L else HeroPart.ARM_R, s * 0.215f * bw, 0.41f, 0f, torso) { m ->
                m.blob(0f, 0f, 0f, 0.07f * armT, 0.07f * armT, 0.07f * armT, SHIRT, 260 + side, 0.02f, FLAG_FUR)
                m.limb(0f, -0.01f, 0f, s * 0.015f, -0.26f, 0f, 0.06f * armT, 0.052f * armT, SHIRT, FLAG_FUR)
                m.limb(s * 0.03f * armT, -0.05f, 0.03f * armT, s * 0.035f * armT, -0.2f, 0.035f * armT, 0.01f, 0.01f, shadeRgb(SHIRT, 0.92f), FLAG_FUR)
                // Body armour: a shoulder plate with a rim in the rarity colour.
                if (chest != null) {
                    m.blob(s * 0.01f, 0.025f, 0f, 0.088f * armT, 0.06f, 0.086f * armT, metal(chest), 280 + side, 0.01f, metalFlag(chest))
                    m.blob(s * 0.01f, -0.02f, 0f, 0.09f * armT, 0.012f, 0.088f * armT, trim(chest), 282 + side, 0f, trimFlag(chest))
                }
            }
            val fore = part(if (side < 0) HeroPart.FOREARM_L else HeroPart.FOREARM_R, s * 0.015f, -0.27f, 0f, upper) { m ->
                // Rolled-up sleeve, then bare forearm and hand.
                m.blob(0f, -0.015f, 0f, 0.056f * armT, 0.032f, 0.056f * armT, shadeRgb(SHIRT, 0.95f), 262 + side, 0.05f, FLAG_FUR)
                m.limb(0f, -0.03f, 0f, 0f, -0.24f, 0.01f, 0.04f * foreT, 0.031f * foreT, skin, FLAG_FUR)
                m.blob(0f, -0.3f, 0.012f, 0.022f, 0.052f, 0.042f, skin, 264 + side, 0f, FLAG_FUR)
                m.limb(-s * 0.012f, -0.27f, 0.045f, -s * 0.02f, -0.32f, 0.06f, 0.012f, 0.009f, skin, FLAG_FUR)
                // Fingers curled together.
                m.blob(0f, -0.345f, 0.018f, 0.02f, 0.03f, 0.036f, shadeRgb(skin, 0.97f), 266 + side, 0f, FLAG_FUR)
                // Gloves: a gauntlet over the forearm and hand, with a cuff in the rarity colour.
                if (gloves != null) {
                    val gc = metal(gloves)
                    val gf = metalFlag(gloves)
                    m.limb(0f, -0.11f, 0f, 0f, -0.25f, 0.01f, 0.048f * foreT, 0.04f * foreT, gc, gf)
                    m.blob(0f, -0.3f, 0.014f, 0.027f, 0.057f, 0.047f, gc, 284 + side, 0f, gf)
                    m.blob(0f, -0.345f, 0.02f, 0.024f, 0.034f, 0.04f, shadeRgb(gc, 0.92f), 286 + side, 0f, gf)
                    m.blob(0f, -0.11f, 0f, 0.052f * foreT, 0.018f, 0.052f * foreT, trim(gloves), 288 + side, 0f, trimFlag(gloves))
                }
                // A ring on the weapon hand: a gold band with a stone in the rarity colour.
                if (ring != null && side < 0) {
                    val r0 = if (gloves != null) 0.028f else 0.023f
                    m.blob(0f, -0.335f, 0.04f, r0, 0.008f, r0, 0xC8A040, 290, 0f, FLAG_BUCKLE)
                    m.blob(0f, -0.335f, 0.04f + r0 + 0.004f, 0.009f, 0.009f, 0.007f, trim(ring), 291, 0f, FLAG_GLOW)
                }
            }
            // The weapon goes in the hand on the -x side (his right, as seen from behind).
            if (side < 0) {
                kunai = part(HeroPart.KUNAI, 0f, -0.3f, 0.012f, fore) { m -> buildKunai(m) }
                part(HeroPart.HALBERD, 0f, -0.3f, 0.012f, fore) { m -> buildHalberd(m) }
                part(HeroPart.SWORD, 0f, -0.3f, 0.012f, fore) { m -> buildSword(m) }
                part(HeroPart.AXE, 0f, -0.3f, 0.012f, fore) { m -> buildAxe(m) }
                part(HeroPart.PICK, 0f, -0.3f, 0.012f, fore) { m -> buildPick(m) }
                part(HeroPart.W_AXE, 0f, -0.3f, 0.012f, fore) { m -> buildWarAxe(m) }
                part(HeroPart.BOW, 0f, -0.3f, 0.012f, fore) { m -> buildBow(m) }
                part(HeroPart.STAFF, 0f, -0.3f, 0.012f, fore) { m -> buildStaff(m) }
                arrow = part(HeroPart.ARROW_FLY, 0f, -0.3f, 0.012f, fore) { m -> buildArrowFly(m) }
                bolt = part(HeroPart.BOLT_FLY, 0f, -0.3f, 0.012f, fore) { m -> buildStaffBolt(m) }
            }
            val thigh = part(if (side < 0) HeroPart.THIGH_L else HeroPart.THIGH_R, s * 0.095f * (0.9f + 0.1f * bw), -0.04f, 0f, pelvis) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.43f, 0.01f, 0.085f * legT, 0.06f * legT, PANTS, FLAG_FUR)
                m.limb(s * 0.05f * legT, -0.1f, 0.06f * legT, s * 0.045f * legT, -0.35f, 0.05f * legT, 0.012f, 0.01f, shadeRgb(PANTS, 0.9f), FLAG_FUR)
            }
            part(if (side < 0) HeroPart.SHIN_L else HeroPart.SHIN_R, 0f, -0.44f, 0.01f, thigh) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.39f, -0.01f, 0.06f * legT, 0.044f * legT, PANTS, FLAG_FUR)
                m.blob(0f, -0.37f, -0.01f, 0.052f * legT, 0.035f, 0.052f * legT, shadeRgb(PANTS, 0.95f), 270 + side, 0.08f, FLAG_FUR)
                if (boots != null) {
                    // Boots: up the shin, over the whole foot, with a cuff in the rarity colour.
                    val bc = metal(boots)
                    val bf = metalFlag(boots)
                    m.limb(0f, -0.2f, -0.01f, 0f, -0.47f, -0.01f, 0.064f * legT, 0.05f * legT, bc, bf)
                    m.blob(0f, -0.485f, 0.05f * footS, 0.052f * footW, 0.042f, 0.112f * footS, bc, 292 + side, 0f, bf)
                    m.blob(0f, -0.497f, 0.145f * footS, 0.045f * footW, 0.026f, 0.036f, shadeRgb(bc, 0.9f), 294 + side, 0f, bf)
                    m.blob(0f, -0.52f, 0.055f * footS, 0.055f * footW, 0.01f, 0.122f * footS, 0x2A1A10, 296 + side, 0f, FLAG_FUR)
                    m.blob(0f, -0.2f, -0.01f, 0.068f * legT, 0.018f, 0.068f * legT, trim(boots), 298 + side, 0f, trimFlag(boots))
                } else {
                    m.limb(0f, -0.39f, -0.01f, 0f, -0.46f, -0.01f, 0.034f, 0.034f, skin, FLAG_FUR)
                    // Bare foot on a leather sole, with straps over the top and round the ankle.
                    m.blob(0f, -0.487f, 0.05f * footS, 0.042f * footW, 0.03f, 0.1f * footS, skin, 272 + side, 0f, FLAG_FUR)
                    m.blob(0f, -0.497f, 0.14f * footS, 0.038f * footW, 0.02f, 0.03f, shadeRgb(skin, 0.97f), 274 + side, 0f, FLAG_FUR)
                    m.blob(0f, -0.515f, 0.055f * footS, 0.05f * footW, 0.012f, 0.118f * footS, LEATHER, 276 + side, 0f, FLAG_FUR)
                    m.limb(-0.045f * footW, -0.482f, 0.09f * footS, 0.045f * footW, -0.482f, 0.09f * footS, 0.009f, 0.009f, shadeRgb(LEATHER, 0.85f), FLAG_FUR)
                    m.limb(-0.043f * footW, -0.49f, 0.03f * footS, 0.043f * footW, -0.47f, 0.02f * footS, 0.009f, 0.009f, shadeRgb(LEATHER, 0.85f), FLAG_FUR)
                    m.blob(0f, -0.44f, -0.01f, 0.039f, 0.011f, 0.039f, shadeRgb(LEATHER, 0.85f), 278 + side, 0f, FLAG_FUR)
                }
            }
        }
    }

    /** The head: face shape, ears, nose, eyes, hair and beard as chosen, and a helmet if you wear one. */
    private fun buildHead(m: MeshBuilder, skin: Int, hair: Int, iris: Int, helm: Item?) {
        // Skull and jaw, shaped by the face.
        val skullRx = when (look.face) { 1 -> 0.108f; 3 -> 0.094f; 4 -> 0.106f; else -> 0.1f }
        val skullRy = when (look.face) { 3 -> 0.13f; else -> 0.12f }
        val jawRx = when (look.face) { 1 -> 0.095f; 2 -> 0.096f; 3 -> 0.078f; 4 -> 0.068f; else -> 0.085f }
        val jawRy = when (look.face) { 1 -> 0.064f; 3 -> 0.082f; else -> 0.07f }
        val jawY = when (look.face) { 3 -> 0.035f; else -> 0.05f }
        m.blob(0f, 0.13f, 0.01f, skullRx, skullRy, 0.11f, skin, 221, 0f, FLAG_FUR)
        m.blob(0f, jawY, 0.03f, jawRx, jawRy, 0.085f, skin, 222, 0f, FLAG_FUR)
        if (look.face == 2) {
            // Square: strong corners to the jaw.
            for (sd in intArrayOf(-1, 1)) m.blob(sd * 0.06f, 0.035f, 0.055f, 0.035f, 0.03f, 0.035f, skin, 223 + sd, 0f, FLAG_FUR)
        }
        if (look.face == 4) {
            // Heart: a narrow, pointed chin.
            m.blob(0f, 0.0f, 0.085f, 0.025f, 0.025f, 0.02f, skin, 226, 0f, FLAG_FUR)
        }
        m.blob(0f, 0.165f, 0.1f, 0.075f, 0.018f, 0.025f, shadeRgb(skin, 0.98f), 227, 0f, FLAG_FUR)
        // Nose.
        when (look.nose) {
            1 -> m.blob(0f, 0.1f, 0.118f, 0.014f, 0.02f, 0.018f, shadeRgb(skin, 0.97f), 224, 0f, FLAG_FUR)
            2 -> {
                m.blob(0f, 0.103f, 0.118f, 0.022f, 0.032f, 0.022f, shadeRgb(skin, 0.97f), 224, 0f, FLAG_FUR)
                for (sd in intArrayOf(-1, 1)) m.blob(sd * 0.022f, 0.082f, 0.122f, 0.013f, 0.01f, 0.01f, shadeRgb(skin, 0.9f), 228 + sd, 0f, FLAG_FUR)
            }
            3 -> {
                m.blob(0f, 0.1f, 0.126f, 0.017f, 0.04f, 0.022f, shadeRgb(skin, 0.97f), 224, 0f, FLAG_FUR)
                m.blob(0f, 0.072f, 0.132f, 0.015f, 0.012f, 0.012f, shadeRgb(skin, 0.95f), 228, 0f, FLAG_FUR)
            }
            4 -> {
                m.blob(0f, 0.105f, 0.12f, 0.016f, 0.034f, 0.022f, shadeRgb(skin, 0.97f), 224, 0f, FLAG_FUR)
                m.blob(0f, 0.118f, 0.136f, 0.012f, 0.014f, 0.012f, shadeRgb(skin, 0.95f), 228, 0f, FLAG_FUR)
                m.blob(0f, 0.082f, 0.135f, 0.011f, 0.01f, 0.01f, shadeRgb(skin, 0.93f), 229, 0f, FLAG_FUR)
            }
            else -> {
                m.blob(0f, 0.105f, 0.12f, 0.017f, 0.032f, 0.022f, shadeRgb(skin, 0.97f), 224, 0f, FLAG_FUR)
                m.blob(-0.018f, 0.082f, 0.125f, 0.01f, 0.008f, 0.008f, shadeRgb(skin, 0.9f), 225, 0f, FLAG_FUR)
                m.blob(0.018f, 0.082f, 0.125f, 0.01f, 0.008f, 0.008f, shadeRgb(skin, 0.9f), 226, 0f, FLAG_FUR)
            }
        }
        m.blob(0f, 0.058f, 0.114f, 0.026f, 0.006f, 0.007f, 0x8A4A40, 227, 0f, FLAG_FUR)
        // Cheeks.
        val cheek = if (look.face == 1) 0.034f else 0.03f
        m.blob(-0.05f, 0.09f, 0.085f, cheek, 0.025f, 0.025f, skin, 228, 0f, FLAG_FUR)
        m.blob(0.05f, 0.09f, 0.085f, cheek, 0.025f, 0.025f, skin, 229, 0f, FLAG_FUR)
        // Eyes, irises and brows.
        val eyeRx = when (look.eyes) { 2 -> 0.02f; 3 -> 0.021f; else -> 0.017f }
        val eyeRy = when (look.eyes) { 1 -> 0.006f; 2 -> 0.015f; 3 -> 0.009f; else -> 0.011f }
        val irisR = when (look.eyes) { 1 -> 0.006f; 2 -> 0.011f; else -> 0.0085f }
        for (side in intArrayOf(-1, 1)) {
            val ex = side * 0.038f
            m.blob(ex, 0.14f, 0.107f, eyeRx, eyeRy, 0.012f, 0xF0EDE6, 230 + side, 0f, FLAG_SOLID)
            m.blob(ex, 0.14f, 0.117f, irisR, min(irisR, eyeRy), 0.004f, iris, 232 + side, 0f, FLAG_SOLID)
            m.blob(ex, 0.163f, 0.117f, 0.023f, 0.006f, 0.008f, hair, 234 + side, 0f, FLAG_FUR)
            // Ears.
            val ex2 = side * (if (look.ears == 2) 0.104f else 0.1f)
            when (look.ears) {
                1 -> m.blob(ex2, 0.12f, 0.005f, 0.012f, 0.022f, 0.017f, shadeRgb(skin, 0.96f), 236 + side, 0f, FLAG_FUR)
                2 -> m.blob(ex2, 0.12f, 0.0f, 0.02f, 0.042f, 0.03f, shadeRgb(skin, 0.96f), 236 + side, 0f, FLAG_FUR)
                3 -> {
                    m.blob(ex2, 0.12f, 0.005f, 0.015f, 0.03f, 0.022f, shadeRgb(skin, 0.96f), 236 + side, 0f, FLAG_FUR)
                    m.limb(ex2, 0.14f, 0.0f, side * 0.13f, 0.21f, -0.035f, 0.013f, 0.003f, shadeRgb(skin, 0.96f), FLAG_FUR)
                }
                else -> m.blob(ex2, 0.12f, 0.005f, 0.015f, 0.03f, 0.022f, shadeRgb(skin, 0.96f), 236 + side, 0f, FLAG_FUR)
            }
        }
        // Hair (most of it hidden under a helmet).
        val stubble = blendRgb(skin, hair, 0.35f)
        if (helm == null) {
            when (look.hairStyle) {
                1 -> m.blob(0f, 0.15f, -0.008f, skullRx + 0.004f, 0.106f, 0.114f, stubble, 240, 0f, FLAG_FUR)
                3 -> {
                    m.blob(0f, 0.15f, -0.008f, skullRx + 0.004f, 0.106f, 0.114f, stubble, 240, 0f, FLAG_FUR)
                    for (i in 0 until 7) {
                        val z = 0.09f - i * 0.035f
                        val h = 0.05f - kotlin.math.abs(i - 2.5f) * 0.006f
                        m.blob(0f, 0.25f + h * 0.4f - kotlin.math.abs(z) * 0.3f, z, 0.016f, h, 0.022f, shadeRgb(hair, 0.93f + 0.03f * (i % 2)), 242 + i, 0.05f, FLAG_FUR)
                    }
                }
                else -> {
                    // Short (and the base of long hair and a ponytail): a close cap with tousled tufts.
                    m.blob(0f, 0.16f, -0.012f, skullRx + 0.008f, 0.105f, 0.118f, hair, 240, 0.02f, FLAG_FUR)
                    m.blob(0f, 0.1f, -0.035f, skullRx - 0.003f, 0.09f, 0.09f, hair, 241, 0.02f, FLAG_FUR)
                    for (i in 0 until 7) {
                        val a = i * 0.9f
                        val r = 0.035f + (i % 3) * 0.018f
                        m.blob(
                            sin(a) * r, 0.245f - (i % 3) * 0.012f, cos(a) * r - 0.01f,
                            0.038f, 0.022f, 0.038f, shadeRgb(hair, 0.92f + 0.05f * (i % 3)), 242 + i, 0.1f, FLAG_FUR,
                        )
                    }
                }
            }
        }
        // Long hair falls to the shoulders, and a ponytail hangs at the back, helmet or not.
        if (look.hairStyle == 2) {
            m.blob(0f, 0.04f, -0.07f, 0.1f, 0.15f, 0.06f, hair, 249, 0.04f, FLAG_FUR)
            for (sd in intArrayOf(-1, 1)) {
                m.limb(sd * 0.085f, 0.15f, -0.01f, sd * 0.095f, -0.07f, -0.03f, 0.03f, 0.024f, shadeRgb(hair, 0.95f), FLAG_FUR)
            }
        }
        if (look.hairStyle == 4) {
            m.blob(0f, 0.17f, -0.11f, 0.03f, 0.03f, 0.03f, shadeRgb(hair, 0.85f), 249, 0f, FLAG_FUR)
            m.limb(0f, 0.16f, -0.12f, 0f, -0.06f, -0.16f, 0.028f, 0.012f, hair, FLAG_FUR)
        }
        // Beard.
        when (look.beard) {
            1 -> {
                // Goatee: moustache, the sides round the mouth, and a pointed chin beard.
                m.blob(0f, 0.074f, 0.11f, 0.035f, 0.009f, 0.013f, hair, 250, 0f, FLAG_FUR)
                m.limb(-0.03f, 0.072f, 0.106f, -0.027f, 0.022f, 0.108f, 0.009f, 0.009f, hair, FLAG_FUR)
                m.limb(0.03f, 0.072f, 0.106f, 0.027f, 0.022f, 0.108f, 0.009f, 0.009f, hair, FLAG_FUR)
                m.blob(0f, 0.012f, 0.09f, 0.036f, 0.038f, 0.032f, hair, 251, 0.05f, FLAG_FUR)
                m.blob(0f, -0.018f, 0.1f, 0.018f, 0.022f, 0.016f, shadeRgb(hair, 0.94f), 252, 0f, FLAG_FUR)
            }
            2 -> m.blob(0f, jawY - 0.002f, 0.034f, jawRx + 0.004f, jawRy + 0.004f, 0.088f, stubble, 250, 0f, FLAG_FUR)
            3, 4 -> {
                m.blob(0f, jawY - 0.01f, 0.038f, jawRx + 0.012f, jawRy + 0.012f, 0.095f, hair, 250, 0.06f, FLAG_FUR)
                m.blob(0f, 0.074f, 0.115f, 0.04f, 0.011f, 0.016f, shadeRgb(hair, 0.92f), 251, 0f, FLAG_FUR)
                if (look.beard == 4) {
                    m.blob(0f, -0.04f, 0.085f, 0.055f, 0.075f, 0.04f, hair, 252, 0.08f, FLAG_FUR)
                    m.blob(0f, -0.11f, 0.09f, 0.03f, 0.04f, 0.025f, shadeRgb(hair, 0.94f), 253, 0.05f, FLAG_FUR)
                }
            }
            5 -> {
                m.blob(0f, 0.074f, 0.112f, 0.04f, 0.011f, 0.015f, hair, 250, 0f, FLAG_FUR)
                m.limb(-0.035f, 0.072f, 0.108f, -0.04f, 0.04f, 0.105f, 0.01f, 0.006f, hair, FLAG_FUR)
                m.limb(0.035f, 0.072f, 0.108f, 0.04f, 0.04f, 0.105f, 0.01f, 0.006f, hair, FLAG_FUR)
            }
        }
        // Helmet: a domed cap with a rim and nose guard, cheek plates on the better ones, and a crest
        // in the rarity colour on the finest.
        if (helm != null) {
            val hc = metal(helm)
            val hf = metalFlag(helm)
            m.blob(0f, 0.17f, -0.005f, skullRx + 0.022f, 0.115f, 0.13f, hc, 254, 0.01f, hf)
            m.blob(0f, 0.125f, -0.005f, skullRx + 0.026f, 0.016f, 0.134f, trim(helm), 255, 0f, trimFlag(helm))
            if (helm.tier >= 2) {
                m.blob(0f, 0.12f, 0.132f, 0.009f, 0.035f, 0.008f, shadeRgb(hc, 0.9f), 256, 0f, hf)
                for (sd in intArrayOf(-1, 1)) m.blob(sd * 0.085f, 0.085f, 0.04f, 0.022f, 0.05f, 0.05f, hc, 257 + sd, 0f, hf)
            }
            if (helm.rarity >= 3) {
                for (i in 0 until 5) {
                    m.blob(0f, 0.29f - kotlin.math.abs(i - 2) * 0.012f, 0.06f - i * 0.04f, 0.012f, 0.03f, 0.022f, trim(helm), 260 + i, 0f, trimFlag(helm))
                }
            }
        }
    }

    // ---------- Weapons: grip at the origin, blade pointing up +y, flat side facing ±z ----------

    /** Bloodsworn Kunai: a huge kunai with a blood-soaked tip, a spiked ring and a red sash. */
    private fun buildKunai(m: MeshBuilder) {
        val steel = 0x9A9EA6
        val blood = 0xB0141A
        // Wrapped grip.
        m.limb(0f, -0.11f, 0f, 0f, 0.13f, 0f, 0.03f, 0.028f, 0x8A5A3A, FLAG_FUR)
        for (i in 0 until 6) m.blob(0f, -0.09f + i * 0.042f, 0f, 0.033f, 0.008f, 0.033f, 0x5A3822, 300 + i, 0f, FLAG_FUR)
        // Diamond blade with a raised ridge, the top running red.
        val baseY = 0.14f
        val wideY = 0.42f
        val tipY = 1.0f
        val w = 0.13f
        for (face in intArrayOf(-1, 1)) {
            val rz = face * 0.036f
            val nz = face.toFloat()
            m.triNC(0f, baseY, 0f, 0f, 0f, nz, steel, -w, wideY, 0f, -0.3f, 0f, nz, steel, 0f, wideY, rz, 0f, 0f, nz, shadeRgb(steel, 1.1f), FLAG_BUCKLE)
            m.triNC(0f, baseY, 0f, 0f, 0f, nz, steel, 0f, wideY, rz, 0f, 0f, nz, shadeRgb(steel, 1.1f), w, wideY, 0f, 0.3f, 0f, nz, steel, FLAG_BUCKLE)
            m.triNC(-w, wideY, 0f, -0.3f, 0f, nz, steel, 0f, tipY, 0f, 0f, 0.2f, nz, blood, 0f, wideY, rz, 0f, 0f, nz, mixRgb(steel, blood, 0.35f), FLAG_BUCKLE)
            m.triNC(0f, wideY, rz, 0f, 0f, nz, mixRgb(steel, blood, 0.35f), 0f, tipY, 0f, 0f, 0.2f, nz, blood, w, wideY, 0f, 0.3f, 0f, nz, steel, FLAG_BUCKLE)
        }
        // Spiked ring at the bottom.
        val ry = -0.22f
        for (i in 0 until 14) {
            val a = i * 6.2831855f / 14f
            m.blob(kotlin.math.cos(a) * 0.085f, ry + sin(a) * 0.085f, 0f, 0.022f, 0.022f, 0.022f, steel, 310 + i, 0f, FLAG_BUCKLE)
        }
        m.limb(-0.1f, ry, 0f, -0.3f, ry, 0f, 0.035f, 0.002f, steel, FLAG_BUCKLE)
        m.limb(0.1f, ry, 0f, 0.3f, ry, 0f, 0.035f, 0.002f, steel, FLAG_BUCKLE)
        m.limb(0f, ry - 0.1f, 0f, 0f, ry - 0.26f, 0f, 0.03f, 0.002f, steel, FLAG_BUCKLE)
        // The red sling sash, tied through the ring and hanging in two tails.
        val sash = 0x8A1018
        m.blob(0f, ry - 0.08f, 0f, 0.05f, 0.035f, 0.03f, sash, 330, 0.1f, FLAG_FUR)
        m.limb(0f, ry - 0.09f, 0f, -0.14f, ry - 0.24f, 0.02f, 0.028f, 0.024f, sash, FLAG_FUR)
        m.limb(-0.14f, ry - 0.24f, 0.02f, -0.3f, ry - 0.34f, 0f, 0.024f, 0.02f, sash, FLAG_FUR)
        m.limb(-0.3f, ry - 0.34f, 0f, -0.42f, ry - 0.5f, 0.03f, 0.02f, 0.008f, sash, FLAG_FUR)
        m.limb(0.02f, ry - 0.09f, 0f, 0.1f, ry - 0.3f, -0.02f, 0.026f, 0.022f, sash, FLAG_FUR)
        m.limb(0.1f, ry - 0.3f, -0.02f, 0.08f, ry - 0.52f, 0f, 0.022f, 0.008f, sash, FLAG_FUR)
    }

    /** Rotroot Halberd: a twisted, infected tree trunk with an axe head at each end and an eye in the middle. */
    private fun buildHalberd(m: MeshBuilder) {
        val wood = 0x8A5A3A
        val steel = 0x7C8088
        val crack = 0xF08AD0
        // Gnarled shaft: a chain of slightly crooked pieces.
        val ys = floatArrayOf(-0.42f, -0.15f, 0.12f, 0.4f, 0.68f, 0.95f, 1.18f, 1.34f)
        val xs = floatArrayOf(0f, 0.012f, -0.01f, 0f, 0.015f, -0.012f, 0.01f, 0f)
        val rs = floatArrayOf(0.042f, 0.046f, 0.05f, 0.058f, 0.05f, 0.056f, 0.07f, 0.05f)
        for (i in 0 until ys.size - 1) {
            m.limb(xs[i], ys[i], 0f, xs[i + 1], ys[i + 1], 0.005f * (i % 2), rs[i], rs[i + 1], shadeRgb(wood, 0.95f + 0.06f * (i % 2)), FLAG_FUR)
        }
        // The eye in the knot at the middle, glowing faintly purple.
        m.blob(0f, 0.4f, 0f, 0.08f, 0.14f, 0.075f, wood, 340, 0.1f, FLAG_FUR)
        m.blob(0f, 0.4f, 0.06f, 0.028f, 0.075f, 0.022f, 0x9A8AC8, 341, 0f, FLAG_GLOW)
        m.blob(0f, 0.4f, -0.06f, 0.028f, 0.075f, 0.022f, 0x9A8AC8, 342, 0f, FLAG_GLOW)
        // Green cloth wraps with trailing strips.
        for (wy in floatArrayOf(0.05f, 0.76f)) {
            m.blob(0f, wy, 0f, 0.066f, 0.04f, 0.066f, 0x9AD27A, 343, 0.15f, FLAG_FUR)
            m.limb(0.05f, wy - 0.02f, 0.02f, 0.08f, wy - 0.26f, 0.03f, 0.016f, 0.01f, 0xC8C890, FLAG_FUR)
            m.limb(0.08f, wy - 0.26f, 0.03f, 0.06f, wy - 0.4f, 0.02f, 0.01f, 0.004f, 0x7ACC5A, FLAG_FUR)
        }
        // Roots splaying out and gripping the top head.
        for (i in 0 until 6) {
            val a = i * 1.047f
            val cx = kotlin.math.cos(a)
            val cz = sin(a)
            m.limb(0f, 1.18f, 0f, cx * 0.12f, 1.3f, cz * 0.12f, 0.022f, 0.012f, wood, FLAG_FUR)
            m.limb(cx * 0.12f, 1.3f, cz * 0.12f, cx * 0.06f, 1.42f, cz * 0.06f, 0.012f, 0.004f, wood, FLAG_FUR)
        }
        // Splintered bottom end.
        for (i in 0 until 5) {
            val a = i * 1.2566f
            m.spike(kotlin.math.cos(a) * 0.02f, -0.46f, sin(a) * 0.02f, 0.012f, 0.08f, kotlin.math.cos(a) * 0.3f, sin(a) * 0.3f, wood, FLAG_SOLID)
        }
        axeHead(m, 1.48f, 1f, steel, crack)
        axeHead(m, -0.52f, -1f, steel, crack)
    }

    /** A double-bitted axe head centred at height [hy]; its spike points up ([dir] = 1) or down (-1). */
    private fun axeHead(m: MeshBuilder, hy: Float, dir: Float, steel: Int, crack: Int) {
        m.box(0f, hy, 0f, 0.05f, 0.13f, 0.035f, 0f, shadeRgb(steel, 0.85f), FLAG_BUCKLE)
        for (side in intArrayOf(-1, 1)) {
            val sx = side.toFloat()
            val px = floatArrayOf(0.05f, 0.2f, 0.3f, 0.24f, 0.3f, 0.2f, 0.05f)
            val py = floatArrayOf(0.13f, 0.2f, 0.25f, 0f, -0.25f, -0.2f, -0.13f)
            for (face in intArrayOf(-1, 1)) {
                val fz = face * 0.012f
                for (k in 0 until px.size - 1) {
                    m.triN(
                        sx * 0.05f, hy, fz, 0f, 0f, face.toFloat(),
                        sx * px[k], hy + py[k], fz, 0f, 0f, face.toFloat(),
                        sx * px[k + 1], hy + py[k + 1], fz, 0f, 0f, face.toFloat(),
                        if (k == 2 || k == 3) shadeRgb(steel, 1.15f) else steel, FLAG_BUCKLE,
                    )
                }
                // Glowing pink cracks across the blade.
                m.limb(sx * 0.08f, hy + 0.05f, fz * 1.4f, sx * 0.18f, hy + 0.12f, fz * 1.4f, 0.004f, 0.004f, crack, FLAG_GLOW)
                m.limb(sx * 0.12f, hy - 0.02f, fz * 1.4f, sx * 0.22f, hy - 0.1f, fz * 1.4f, 0.004f, 0.004f, crack, FLAG_GLOW)
            }
            // Blade edges.
            m.limb(sx * 0.3f, hy + 0.25f, 0f, sx * 0.24f, hy, 0f, 0.012f, 0.012f, shadeRgb(steel, 1.2f), FLAG_BUCKLE)
            m.limb(sx * 0.24f, hy, 0f, sx * 0.3f, hy - 0.25f, 0f, 0.012f, 0.012f, shadeRgb(steel, 1.2f), FLAG_BUCKLE)
        }
        m.limb(0f, hy + dir * 0.13f, 0f, 0f, hy + dir * 0.36f, 0f, 0.035f, 0.002f, steel, FLAG_BUCKLE)
    }

    /** Mind, Body & Soul Sword: an eye in the blade, beast hearts in the guard, a brain in the pommel. */
    /** A woodsman's axe: an ash handle with a wedge of a head, built with its grip at the hand. */
    private fun buildAxe(m: MeshBuilder) {
        val wood = 0x8A6A44
        val head = 0x7E8288
        m.limb(0f, -0.14f, 0f, 0f, 0.62f, 0f, 0.022f, 0.026f, wood, FLAG_FUR)
        m.blob(0f, -0.15f, 0f, 0.03f, 0.03f, 0.03f, shadeRgb(wood, 0.8f), 430, 0f, FLAG_FUR)
        for (i in 0 until 4) m.blob(0f, -0.08f + i * 0.045f, 0f, 0.03f, 0.008f, 0.03f, 0x5A3822, 431 + i, 0f, FLAG_FUR)
        // The head: a thick back, flaring out to a wide cutting edge.
        m.box(0f, 0.56f, 0f, 0.045f, 0.06f, 0.035f, 0f, head, FLAG_BUCKLE)
        m.box(0.12f, 0.56f, 0f, 0.08f, 0.075f, 0.018f, 0f, head, FLAG_BUCKLE)
        m.box(0.2f, 0.56f, 0f, 0.02f, 0.11f, 0.012f, 0f, 0xB8BCC4, FLAG_BLADE)
    }

    /** A pickaxe: a long handle and a curved iron head, pointed at both ends. */
    private fun buildPick(m: MeshBuilder) {
        val wood = 0x8A6A44
        val head = 0x6E7278
        m.limb(0f, -0.14f, 0f, 0f, 0.66f, 0f, 0.022f, 0.026f, wood, FLAG_FUR)
        m.blob(0f, -0.15f, 0f, 0.03f, 0.03f, 0.03f, shadeRgb(wood, 0.8f), 440, 0f, FLAG_FUR)
        for (i in 0 until 4) m.blob(0f, -0.08f + i * 0.045f, 0f, 0.03f, 0.008f, 0.03f, 0x5A3822, 441 + i, 0f, FLAG_FUR)
        m.box(0f, 0.62f, 0f, 0.04f, 0.045f, 0.035f, 0f, head, FLAG_BUCKLE)
        for (s in intArrayOf(-1, 1)) {
            m.limb(0f, 0.62f, 0f, s * 0.2f, 0.58f, 0f, 0.03f, 0.022f, head, FLAG_BUCKLE)
            m.limb(s * 0.2f, 0.58f, 0f, s * 0.3f, 0.5f, 0f, 0.022f, 0.006f, 0xA8ACB2, FLAG_BUCKLE)
        }
    }

    /** The Warrior's starting and common combat axe: an ordinary handle, a proper war-axe head. */
    private fun buildWarAxe(m: MeshBuilder) {
        val wood = 0x7A5838
        val steel = 0x868A92
        m.limb(0f, -0.14f, 0f, 0f, 0.42f, 0f, 0.026f, 0.03f, wood, FLAG_FUR)
        for (i in 0 until 5) m.blob(0f, -0.09f + i * 0.045f, 0f, 0.034f, 0.008f, 0.034f, 0x5A3822, 450 + i, 0f, FLAG_FUR)
        axeHead(m, 0.5f, 1f, steel, 0x9AAAC0)
    }

    /** A crude bow of bent wood and taut string: the Archer's starting and common weapon. */
    private fun buildBow(m: MeshBuilder) {
        val wood = 0x8A6438
        val string = 0xE8E0CC
        val ys = floatArrayOf(-0.62f, -0.3f, 0f, 0.3f, 0.62f)
        val xs = floatArrayOf(0.02f, 0.14f, 0.18f, 0.14f, 0.02f)
        for (i in 0 until ys.size - 1) {
            m.limb(xs[i], ys[i], 0f, xs[i + 1], ys[i + 1], 0f, 0.028f - 0.006f * kotlin.math.abs(i - 1.5f), 0.022f, wood, FLAG_FUR)
        }
        // Grip wrap at the centre.
        for (i in 0 until 4) m.blob(0.18f, -0.07f + i * 0.045f, 0f, 0.03f, 0.008f, 0.03f, 0x5A3822, 460 + i, 0f, FLAG_FUR)
        m.limb(0.02f, -0.62f, 0f, 0.02f, 0.62f, 0f, 0.006f, 0.006f, string, FLAG_BUCKLE)
    }

    /** A flying arrow: a thin shaft, a point and three fletches, drawn point-first. */
    private fun buildArrowFly(m: MeshBuilder) {
        val shaft = 0x8A6438
        val head = 0x9A9EA6
        val fletch = 0xD8D0B8
        m.limb(0f, -0.4f, 0f, 0f, 0.5f, 0f, 0.016f, 0.016f, shaft, FLAG_FUR)
        m.spike(0f, 0.5f, 0f, 0.022f, 0.22f, 0f, 0f, head, FLAG_BUCKLE)
        for (a in floatArrayOf(0f, 2.094f, 4.188f)) {
            val cx = kotlin.math.cos(a) * 0.03f
            val cz = kotlin.math.sin(a) * 0.03f
            m.triN(0f, -0.4f, 0f, cx, 0f, cz, cx * 2f, -0.56f, cz * 2f, cx, 0f, cz, 0f, -0.3f, 0f, cx, 0f, cz, fletch, FLAG_FUR)
        }
    }

    /** A staff's flying bolt: a small glowing orb with a short tail. */
    private fun buildStaffBolt(m: MeshBuilder) {
        m.blob(0f, 0f, 0f, 0.075f, 0.075f, 0.075f, 0xCFE8FF, 470, 0.5f, FLAG_GLOW)
        m.blob(0f, -0.12f, 0f, 0.04f, 0.1f, 0.04f, 0x6AB8FF, 471, 0.35f, FLAG_GLOW)
    }

    /** A worn, plain staff with a small crystal set in the top: the Mage's starting and common weapon. */
    private fun buildStaff(m: MeshBuilder) {
        val wood = 0x5A4430
        m.limb(0f, -0.5f, 0f, 0f, 0.85f, 0f, 0.026f, 0.02f, wood, FLAG_FUR)
        for (i in 0 until 5) m.blob(0f, -0.3f + i * 0.045f, 0f, 0.032f, 0.008f, 0.032f, 0x3A2A1C, 480 + i, 0f, FLAG_FUR)
        for (s in intArrayOf(-1, 1)) m.limb(0f, 0.75f, 0f, s * 0.07f, 0.9f, 0f, 0.014f, 0.006f, wood, FLAG_FUR)
        m.blob(0f, 0.95f, 0f, 0.055f, 0.07f, 0.05f, 0x6AB8FF, 485, 0.5f, FLAG_GLOW)
    }

    private fun buildSword(m: MeshBuilder) {
        val steel = 0x8C9098
        val leather = 0x8A5A32
        // Grip with a spiral wrap.
        m.limb(0f, -0.12f, 0f, 0f, 0.2f, 0f, 0.028f, 0.03f, leather, FLAG_FUR)
        for (i in 0 until 6) m.blob(0f, -0.09f + i * 0.05f, 0f, 0.032f, 0.008f, 0.032f, 0x5A3822, 350 + i, 0f, FLAG_FUR)
        // Pommel ring holding a glowing pink brain.
        val py = -0.2f
        for (i in 0 until 14) {
            val a = i * 6.2831855f / 14f
            m.blob(kotlin.math.cos(a) * 0.07f, py + sin(a) * 0.07f, 0f, 0.022f, 0.022f, 0.022f, leather, 360 + i, 0f, FLAG_FUR)
        }
        m.blob(0f, py, 0f, 0.046f, 0.044f, 0.03f, 0xE88AB0, 380, 0.3f, FLAG_GLOW)
        // Crossguard with a beast heart glowing red in each end.
        m.limb(-0.2f, 0.22f, 0f, 0.2f, 0.22f, 0f, 0.03f, 0.03f, leather, FLAG_FUR)
        for (side in intArrayOf(-1, 1)) {
            val hx = side * 0.24f
            for (i in 0 until 10) {
                val a = i * 0.6283f
                m.blob(hx + kotlin.math.cos(a) * 0.05f, 0.22f + sin(a) * 0.05f, 0f, 0.016f, 0.016f, 0.016f, leather, 381 + i, 0f, FLAG_FUR)
            }
            m.blob(hx, 0.22f, 0f, 0.032f, 0.036f, 0.024f, 0xE0302A, 392 + side, 0.15f, FLAG_GLOW)
        }
        m.spike(0f, 0.2f, 0f, 0.022f, 0.12f, 0f, 0f, 0xB8BCC4, FLAG_BUCKLE)
        // Broad blade with a fuller down the middle, and a pointed tip.
        m.box(0f, 0.76f, 0f, 0.085f, 0.5f, 0.013f, 0f, steel, FLAG_BUCKLE)
        m.box(0f, 0.7f, 0.013f, 0.008f, 0.38f, 0.002f, 0f, 0x6A6E76, FLAG_BUCKLE)
        m.box(0f, 0.7f, -0.013f, 0.008f, 0.38f, 0.002f, 0f, 0x6A6E76, FLAG_BUCKLE)
        for (face in intArrayOf(-1, 1)) {
            val fz = face * 0.013f
            m.triN(-0.085f, 1.26f, fz, 0f, 0f, face.toFloat(), 0.085f, 1.26f, fz, 0f, 0f, face.toFloat(), 0f, 1.42f, 0f, 0f, 0.3f, face.toFloat(), steel, FLAG_BUCKLE)
        }
        m.triN(-0.085f, 1.26f, 0.013f, -1f, 0.5f, 0f, -0.085f, 1.26f, -0.013f, -1f, 0.5f, 0f, 0f, 1.42f, 0f, -1f, 0.5f, 0f, steel, FLAG_BUCKLE)
        m.triN(0.085f, 1.26f, 0.013f, 1f, 0.5f, 0f, 0.085f, 1.26f, -0.013f, 1f, 0.5f, 0f, 0f, 1.42f, 0f, 1f, 0.5f, 0f, steel, FLAG_BUCKLE)
        // The eye, set in a round frame through the blade, glowing green.
        val ey = 0.66f
        for (i in 0 until 16) {
            val a = i * 0.3927f
            m.blob(kotlin.math.cos(a) * 0.1f, ey + sin(a) * 0.1f, 0f, 0.026f, 0.026f, 0.026f, 0x5A5E66, 400 + i, 0f, FLAG_BUCKLE)
        }
        m.blob(0f, ey, 0f, 0.09f, 0.09f, 0.03f, 0xE8F4E4, 420, 0f, FLAG_SOLID)
        for (face in intArrayOf(-1, 1)) {
            m.blob(0f, ey, face * 0.026f, 0.05f, 0.05f, 0.012f, 0x3AC84A, 421, 0f, FLAG_GLOW)
            m.blob(0f, ey, face * 0.034f, 0.018f, 0.018f, 0.006f, 0x101010, 422, 0f, FLAG_SOLID)
        }
    }

    /** Whether to draw this piece right now: only the weapon you chose, and not while it's flying. */
    fun visible(g: Game, part: CreaturePart): Boolean = when (part.kind) {
        HeroPart.KUNAI -> g.weaponClass == WeaponClass.KUNAI && g.weaponInHand && g.heldTool == 0
        HeroPart.HALBERD -> g.weaponClass == WeaponClass.HALBERD && g.heldTool == 0
        HeroPart.SWORD -> g.weaponClass == WeaponClass.SWORD && g.heldTool == 0
        HeroPart.AXE -> g.heldTool == 1
        HeroPart.PICK -> g.heldTool == 2
        HeroPart.W_AXE -> g.weaponClass == WeaponClass.AXE && g.weaponInHand && g.heldTool == 0
        HeroPart.BOW -> g.weaponClass == WeaponClass.BOW && g.weaponInHand && g.heldTool == 0
        HeroPart.STAFF -> g.weaponClass == WeaponClass.STAFF && g.weaponInHand && g.heldTool == 0
        // Drawn by hand, directly, while flying: never through the ordinary held-weapon pass.
        HeroPart.ARROW_FLY, HeroPart.BOLT_FLY -> false
        else -> true
    }

    /** Builds the model matrix for one piece of the hero, as he is standing or moving right now. */
    fun pose(g: Game, part: CreaturePart, out: FloatArray) {
        val m = g.moveAmount
        val run = g.runAmount
        val ph = g.stridePhase
        val air = g.airAmount
        val rolling = g.dodgePhase >= 0f
        figure(g, m, run, ph, air)
        // Sitting on a chair: the hips drop to the seat.
        val sit = g.sitAmount
        val bob = (if (rolling) 0f else (abs(cos(ph)) - 0.6f) * (0.045f * m + 0.07f * run) * (1f - air) - crouch * 0.05f) -
            (0.045f * stance + 0.035f * lunge) - 0.42f * sit
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, g.x, g.feet + bob, g.z)
        Matrix.rotateM(out, 0, deg(g.bodyYaw + spin), 0f, 1f, 0f)
        // Dodge roll: a full forward somersault about the middle of the body, in the way he's rolling.
        val dp = g.dodgePhase
        if (dp >= 0f) {
            val pivot = 0.7f * BODY_SCALE
            Matrix.translateM(out, 0, 0f, pivot, 0f)
            Matrix.rotateM(out, 0, 360f * smooth01(dp.coerceIn(0f, 1f)), 1f, 0f, 0f)
            Matrix.translateM(out, 0, 0f, -pivot, 0f)
        }
        Matrix.scaleM(out, 0, BODY_SCALE, BODY_SCALE, BODY_SCALE)
        apply(g, part, out, m, run, ph, air)
    }

    // The upper body for this frame: walking pose blended with the attack animation.
    private val cur = FloatArray(K_COUNT)
    private val walkPose = FloatArray(K_COUNT)
    private val attackPose = FloatArray(K_COUNT)
    private var spin = 0f
    private var figuredAt = -1f
    /** 0..1: knees and arms pulled in during a dodge roll. */
    private var tuck = 0f
    /** Extra knee lift for deep ground (snow and sand). */
    private var trudge = 1f
    /** How far he stoops under a low cave roof. */
    private var crouch = 0f
    /** 0..1: feet planted apart in a fighting stance while attacking. */
    private var stance = 0f
    /** 0..1: stepping and sinking into a blow as it lands. */
    private var lunge = 0f
    /** 0..1: weight rocking back just before a blow. */
    private var coil = 0f

    private fun figure(g: Game, m: Float, run: Float, ph: Float, air: Float) {
        // Same frame (the other parts): already worked out.
        if (g.time == figuredAt) return
        figuredAt = g.time
        val dp = g.dodgePhase
        tuck = if (dp >= 0f) sin(dp.coerceIn(0f, 1f) * PI_F).coerceAtLeast(0f) else 0f
        val zone = g.currentZone
        trudge = when {
            g.inCave >= 0 -> 1f
            zone == Zone.SNOW -> 1.4f
            zone == Zone.DESERT -> 1.2f
            else -> 1f
        }
        crouch = if (g.inCave >= 0) 1f else 0f
        val walkA = (0.5f * m + 0.3f * run) * (1f - air)
        val breathe = sin(g.time * 1.8f)
        val wc = g.animClass
        val swingW = sin(ph) * walkA          // the -x (weapon) side leg
        val swingO = sin(ph + PI_F) * walkA   // the +x side leg
        // Shoulders turn against the hips; running leans you into it, with a little bounce.
        walkPose[K_TW] = -sin(ph) * (0.16f * m + 0.1f * run)
        walkPose[K_LN] = 0.05f * m + 0.3f * run + sin(ph * 2f) * 0.03f * run + (trudge - 1f) * 0.2f * m + crouch * 0.12f
        // Running, the arms pump bent at the elbow and drift in towards the middle.
        walkPose[K_AAZ] = 0.12f * run * (if (wc == WeaponClass.HALBERD) 0.3f else 1f)
        walkPose[K_AEL] = -swingW * (0.8f + 0.4f * run) * (if (wc == WeaponClass.HALBERD) 0.4f else 1f) + breathe * 0.015f * (1f - m) - air * 0.5f
        walkPose[K_AOUT] = 0.08f + air * 0.45f + run * 0.05f
        walkPose[K_ABEND] = 0.22f + 0.35f * m + 0.95f * run * (if (wc == WeaponClass.HALBERD) 0.3f else 1f) + air * 0.6f
        walkPose[K_WX] = when (wc) {
            WeaponClass.HALBERD -> -0.12f - walkPose[K_ABEND] + 0.22f
            WeaponClass.SWORD -> 2.2f
            else -> 2.3f
        }
        walkPose[K_WR] = if (wc == WeaponClass.HALBERD) 0f else 1.5707964f
        walkPose[K_OAZ] = 0.12f * run
        walkPose[K_OEL] = -swingO * (0.8f + 0.4f * run) + breathe * 0.015f * (1f - m) - air * 0.5f
        walkPose[K_OOUT] = 0.08f + air * 0.45f + run * 0.05f
        walkPose[K_OBEND] = 0.22f + 0.35f * m + 0.95f * run + air * 0.6f
        // Dodge roll: arms hug in tight, chin down.
        if (tuck > 0f) {
            walkPose[K_AEL] += (-1.2f - walkPose[K_AEL]) * tuck
            walkPose[K_ABEND] += (1.9f - walkPose[K_ABEND]) * tuck
            walkPose[K_OEL] += (-1.2f - walkPose[K_OEL]) * tuck
            walkPose[K_OBEND] += (1.9f - walkPose[K_OBEND]) * tuck
            walkPose[K_LN] += 0.6f * tuck
        }
        val p = g.attackPhase
        if (p < 0f) {
            walkPose.copyInto(cur)
            spin = 0f
            stance = 0f
            lunge = 0f
            coil = 0f
            return
        }
        val keys = when (wc) {
            WeaponClass.KUNAI, WeaponClass.BOW, WeaponClass.STAFF -> KUNAI_KEYS
            WeaponClass.HALBERD -> HALBERD_KEYS
            else -> SWORD_KEYS
        }
        // Find the two keyframes either side of p, and ease between them.
        val n = keys.size / K_STRIDE
        var i = 0
        while (i < n - 2 && keys[(i + 1) * K_STRIDE] <= p) i++
        val a = i * K_STRIDE
        val b = a + K_STRIDE
        val span = keys[b] - keys[a]
        val t = smooth01(if (span > 1e-4f) (p - keys[a]) / span else 1f)
        for (k in 0 until K_COUNT) attackPose[k] = keys[a + 1 + k] + (keys[b + 1 + k] - keys[a + 1 + k]) * t
        // Blend in quickly at the start and out at the end. Spinning isn't blended (a full turn is no turn).
        val w = min(1f, min(p / 0.08f, (1f - p) / 0.12f))
        for (k in 0 until K_COUNT) cur[k] = walkPose[k] + (attackPose[k] - walkPose[k]) * w
        // The legs do the work: feet planted apart, weight rocking back before each blow,
        // then a step and a sink into it as it lands.
        var hitP = 0f
        var windP = 0f
        for (h in g.attackHits) {
            val a = (p - h) / 0.07f
            hitP = max(hitP, kotlin.math.exp(-a * a))
            val b = (p - (h - 0.1f)) / 0.06f
            windP = max(windP, kotlin.math.exp(-b * b))
        }
        stance = w * (1f - air) * (1f - tuck) * (1f - 0.6f * m)
        lunge = hitP * stance
        coil = windP * stance
        spin = attackPose[K_SP]
        cur[K_SP] = 0f
    }

    private fun apply(g: Game, part: CreaturePart, out: FloatArray, m: Float, run: Float, ph: Float, air: Float) {
        val parent = part.parent
        if (parent != null) apply(g, parent, out, m, run, ph, air)
        Matrix.translateM(out, 0, part.px, part.py, part.pz)
        when (part.kind) {
            HeroPart.PELVIS -> {
                // Hips turn with each stride and drop a little on the side of the swinging leg.
                // In a swing the hips lead the shoulders round.
                Matrix.rotateM(out, 0, deg(sin(ph) * (0.12f * m + 0.05f * run) + cur[K_TW] * 0.3f * stance), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(sin(ph) * (0.05f * m + 0.02f * run) * (1f - tuck)), 0f, 0f, 1f)
            }
            HeroPart.TORSO -> {
                Matrix.rotateM(out, 0, deg(cur[K_TW] * (1f - 0.3f * stance)), 0f, 1f, 0f)
                // The chest rolls back against the hips so the shoulders stay nearly level.
                Matrix.rotateM(out, 0, deg(-sin(ph) * 0.04f * m * (1f - tuck)), 0f, 0f, 1f)
                Matrix.rotateM(out, 0, deg(cur[K_LN] + sin(g.time * (1.8f + run * 1.6f)) * (0.01f + run * 0.012f)), 1f, 0f, 0f)
            }
            HeroPart.HEAD -> {
                val look = sin(g.time * 0.37f) * 0.12f * (1f - m)
                Matrix.rotateM(out, 0, deg(look - cur[K_TW] * 0.6f - sin(ph) * 0.05f * m), 0f, 1f, 0f)
                // Eyes stay on the horizon: the head tips back against the lean, except when tucking.
                Matrix.rotateM(out, 0, deg(-cur[K_LN] * 0.8f + sin(g.time * 0.23f) * 0.03f + tuck * 1.0f), 1f, 0f, 0f)
            }
            HeroPart.ARM_L -> {
                // Weapon arm (-x side): inward is towards +x.
                Matrix.rotateM(out, 0, deg(cur[K_AAZ]), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_AEL]), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(-cur[K_AOUT]), 0f, 0f, 1f)
            }
            HeroPart.ARM_R -> {
                Matrix.rotateM(out, 0, deg(-cur[K_OAZ]), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_OEL]), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_OOUT]), 0f, 0f, 1f)
            }
            HeroPart.FOREARM_L -> Matrix.rotateM(out, 0, deg(-cur[K_ABEND]), 1f, 0f, 0f)
            HeroPart.FOREARM_R -> Matrix.rotateM(out, 0, deg(-cur[K_OBEND]), 1f, 0f, 0f)
            HeroPart.KUNAI, HeroPart.HALBERD, HeroPart.SWORD, HeroPart.AXE, HeroPart.PICK,
            HeroPart.W_AXE, HeroPart.BOW, HeroPart.STAFF -> {
                Matrix.rotateM(out, 0, deg(cur[K_WX]), 1f, 0f, 0f)
                Matrix.rotateM(out, 0, deg(cur[K_WR]), 0f, 1f, 0f)
                // Each weapon is built with its grip at the hand, so it shrinks in place.
                val ws = when (part.kind) {
                    HeroPart.KUNAI -> KUNAI_HAND_SCALE
                    HeroPart.SWORD -> SWORD_SCALE
                    HeroPart.BOW -> BOW_SCALE
                    else -> 1f
                }
                if (ws != 1f) Matrix.scaleM(out, 0, ws, ws, ws)
            }
            HeroPart.THIGH_L, HeroPart.THIGH_R -> {
                val left = part.kind == HeroPart.THIGH_L
                val walkA = (0.5f * m + 0.3f * run) * (1f - air)
                val swing = sin(ph + (if (left) 0f else PI_F)) * walkA * (1f - tuck)
                // Running drives the knees up in front; a cave roof makes you bend at the hip.
                val drive = -0.18f * run * (1f - air) - crouch * 0.25f
                val jumpTuck = air * (if (left) -0.55f else -0.25f)
                // Fighting stance: the weapon-side leg braces back, the other steps forward into the blow.
                val fight = if (left) 0.26f * stance + 0.1f * lunge else -(0.38f * stance + 0.14f * lunge - 0.08f * coil)
                // Sitting: thighs level, knees out in front.
                Matrix.rotateM(out, 0, deg(swing + drive + jumpTuck - 1.7f * tuck + fight - 1.55f * g.sitAmount), 1f, 0f, 0f)
            }
            HeroPart.SHIN_L, HeroPart.SHIN_R -> {
                val left = part.kind == HeroPart.SHIN_L
                val a = ph + (if (left) 0f else PI_F)
                // Swing leg: knee folds to carry the foot through (higher in snow and sand, a heel kick when running).
                val lift = max(0f, -cos(a))
                // Stance leg: a soft bend as the weight comes onto it.
                val give = max(0f, cos(a)) * (0.12f * m + 0.2f * run)
                val knee = 0.05f + (lift * (0.85f * m + 0.85f * run) * trudge + give) * (1f - air) * (1f - tuck) +
                    air * (if (left) 1.0f else 0.6f) + crouch * 0.4f + 2.3f * tuck +
                    (if (left) 0.18f * stance + 0.1f * lunge else 0.55f * stance + 0.25f * lunge) +
                    1.5f * g.sitAmount
                Matrix.rotateM(out, 0, deg(knee), 1f, 0f, 0f)
            }
            else -> {}
        }
    }

    private fun deg(radians: Float): Float = radians * 57.29578f

    private fun smooth01(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}

private const val PI_F = 3.1415927f

/** Weapon sizes: the kunai is a real throwing knife, the sword a little trimmed; the halberd stays as it is. */
internal const val KUNAI_HAND_SCALE = 0.42f
/** A thrown kunai is drawn a bit bigger than in the hand, so you can follow it through the air. */
internal const val KUNAI_FLY_SCALE = 0.6f
internal const val SWORD_SCALE = 0.8f
/** The bow is a bigger shape than a sword; drawn a bit smaller so it sits right in the hand. */
internal const val BOW_SCALE = 0.85f
private const val HALF_PI = 1.5707964f

// Pose channels, in keyframe order after the time.
private const val K_SP = 0      // whole-body spin
private const val K_TW = 1      // torso twist (positive brings the weapon shoulder forward)
private const val K_LN = 2      // lean forward
private const val K_AAZ = 3     // weapon arm: swing across the body
private const val K_AEL = 4     // weapon arm: raise (0 down, -1.57 straight ahead, -3.1 straight up)
private const val K_AOUT = 5    // weapon arm: out to the side
private const val K_ABEND = 6   // weapon elbow bend
private const val K_WX = 7      // wrist: tip the weapon
private const val K_WR = 8      // wrist: roll the weapon about its own length
private const val K_OAZ = 9     // other arm, same four
private const val K_OEL = 10
private const val K_OOUT = 11
private const val K_OBEND = 12
private const val K_COUNT = 13
private const val K_STRIDE = 14

// Each row: time (0..1 through the attack), then the 13 channels above.
//                           time  spin   twist lean   aAz    aEl    aOut  aBend  wX           wRoll    oAz   oEl   oOut  oBend
private val SWORD_KEYS = floatArrayOf(
    // Slash 1: coil back with the blade cocked high, hips lead, arm whips through, wrist snaps last.
    0.00f, 0f, -0.3f, 0.05f, -0.4f, -0.8f, 0.3f, 0.8f, 2.4f, HALF_PI, 0.2f, -0.6f, 0.3f, 1.4f,
    0.10f, 0f, -1.0f, -0.06f, -1.3f, -1.8f, 0.1f, 0.9f, PI_F + 0.15f, 0f, 0.5f, -1.1f, 0.3f, 0.6f,
    0.17f, 0f, -0.3f, 0.08f, -0.7f, -1.6f, 0f, 0.45f, PI_F + 0.05f, 0f, 0.3f, -0.9f, 0.3f, 0.8f,
    0.22f, 0f, 0.45f, 0.2f, 0.25f, -1.45f, 0f, 0.1f, PI_F - 0.1f, 0f, -0.1f, -0.6f, 0.3f, 1.2f,
    0.32f, 0f, 0.95f, 0.15f, 1.25f, -1.2f, 0f, 0.45f, PI_F - 0.2f, 0f, -0.3f, -0.4f, 0.3f, 1.4f,
    // Slash 2: the blade chambers across the body, then a rising backhand.
    0.40f, 0f, 1.0f, 0.02f, 1.35f, -1.3f, 0f, 0.95f, PI_F + 0.1f, 0f, 0.2f, -0.8f, 0.3f, 1.0f,
    0.47f, 0f, 0.4f, 0.1f, 0.7f, -1.55f, 0f, 0.5f, PI_F + 0.05f, 0f, 0.1f, -0.7f, 0.3f, 1.1f,
    0.52f, 0f, -0.25f, 0.2f, -0.1f, -1.75f, 0f, 0.1f, PI_F - 0.1f, 0f, 0.3f, -0.9f, 0.3f, 0.9f,
    0.60f, 0f, -0.85f, 0.1f, -1.1f, -2.05f, 0f, 0.35f, PI_F - 0.15f, 0f, 0.4f, -1.0f, 0.3f, 0.8f,
    // Overhead chop: both arms up, back arched, then the whole body drops behind the blow.
    0.70f, 0f, -0.25f, -0.18f, 0.05f, -3.0f, 0f, 1.2f, PI_F + 0.3f, HALF_PI, -0.1f, -2.5f, 0.2f, 1.0f,
    0.79f, 0f, 0.0f, 0.12f, 0.1f, -2.2f, 0f, 0.55f, PI_F + 0.1f, HALF_PI, 0.1f, -1.9f, 0.2f, 0.7f,
    0.84f, 0f, 0.2f, 0.45f, 0.15f, -1.0f, 0f, 0.0f, PI_F - 0.2f, HALF_PI, 0.3f, -1.1f, 0.1f, 0.4f,
    0.92f, 0f, 0.15f, 0.4f, 0.12f, -0.7f, 0f, 0.1f, PI_F - 0.35f, HALF_PI, 0.25f, -0.8f, 0.1f, 0.4f,
    1.00f, 0f, 0.0f, 0.05f, 0.0f, -0.3f, 0.08f, 0.4f, 2.4f, HALF_PI, 0.0f, -0.2f, 0.1f, 0.4f,
)

private val HALBERD_KEYS = floatArrayOf(
    // Coil the other way first, then a full spinning sweep with the weight low.
    0.00f, 0f, 0f, 0f, -0.3f, -0.7f, 0.2f, 0.6f, -0.1f, 0f, 0.3f, -0.7f, 0.2f, 0.9f,
    0.08f, -0.6f, -0.8f, 0.12f, -1.4f, -1.45f, 0f, 0.3f, PI_F + 0.15f, HALF_PI, 0f, -0.9f, 0.9f, 0.3f,
    0.30f, 2.51f, 0.3f, 0.1f, -1.4f, -1.45f, 0f, 0.15f, PI_F + 0.15f, HALF_PI, 0f, -0.9f, 0.9f, 0.3f,
    0.48f, 6.2832f, 0f, 0.05f, -1.3f, -1.5f, 0f, 0.2f, PI_F + 0.15f, HALF_PI, 0f, -0.9f, 0.9f, 0.3f,
    // Heave it high over the head, arch back, and bring it down with the whole body.
    0.62f, 6.2832f, -0.2f, -0.25f, 0.1f, -3.0f, 0f, 0.7f, PI_F - 0.5f, HALF_PI, -0.2f, -2.8f, 0.1f, 0.8f,
    0.72f, 6.2832f, 0f, 0.1f, 0.12f, -2.1f, 0f, 0.3f, PI_F - 0.5f, HALF_PI, 0f, -2.0f, 0.1f, 0.5f,
    0.80f, 6.2832f, 0.1f, 0.5f, 0.15f, -1.0f, 0f, 0f, PI_F - 0.5f, HALF_PI, 0.3f, -1.1f, 0.1f, 0.3f,
    0.90f, 6.2832f, 0.05f, 0.45f, 0.1f, -0.8f, 0f, 0.05f, PI_F - 0.5f, HALF_PI, 0.25f, -0.9f, 0.1f, 0.3f,
    1.00f, 6.2832f, 0f, 0f, 0f, 0f, 0.08f, 0.22f, -0.12f, 0f, 0f, 0f, 0.08f, 0.22f,
)

private val KUNAI_KEYS = floatArrayOf(
    // Throw: the free hand points at the target, the knife goes back behind the ear with the weight
    // on the back foot, then hips, shoulder, elbow and wrist whip through in turn and follow across.
    0.00f, 0f, 0f, 0f, 0f, -0.4f, 0.1f, 0.6f, 2.3f, HALF_PI, 0f, -0.3f, 0.1f, 0.6f,
    0.14f, 0f, -0.45f, -0.02f, -0.5f, -1.6f, 0.2f, 0.9f, 2.8f, HALF_PI, 0.3f, -1.4f, 0.15f, 0.3f,
    0.30f, 0f, -0.9f, -0.12f, -0.9f, -2.8f, 0.35f, 1.6f, PI_F + 0.3f, HALF_PI, 0.25f, -1.6f, 0.2f, 0.1f,
    0.40f, 0f, -0.1f, 0.1f, -0.4f, -2.4f, 0.15f, 1.0f, PI_F + 0.1f, HALF_PI, 0.1f, -1.0f, 0.2f, 1.0f,
    0.45f, 0f, 0.6f, 0.3f, 0.1f, -1.5f, 0f, 0.1f, PI_F - 0.3f, HALF_PI, -0.1f, -0.4f, 0.2f, 1.4f,
    0.62f, 0f, 0.9f, 0.35f, 0.6f, -0.7f, 0f, 0.3f, PI_F - 0.4f, HALF_PI, -0.1f, -0.3f, 0.2f, 1.2f,
    1.00f, 0f, 0f, 0f, 0f, -0.1f, 0.08f, 0.3f, 2.3f, HALF_PI, 0f, 0f, 0.08f, 0.22f,
)
