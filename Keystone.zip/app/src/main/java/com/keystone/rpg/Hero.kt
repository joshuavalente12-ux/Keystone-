package com.keystone.rpg

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** How each piece of the hero moves. */
object HeroPart {
    const val PELVIS = 0
    const val TORSO = 1
    const val HEAD = 2
    const val ARM_L = 3
    const val ARM_R = 4
    const val FOREARM_L = 5
    const val FOREARM_R = 6
    const val THIGH_L = 7
    const val THIGH_R = 8
    const val SHIN_L = 9
    const val SHIN_R = 10
}

/** Brushed metal, for the belt buckle. */
private const val FLAG_BUCKLE = 254

private const val SKIN = 0xC8977A
private const val HAIR = 0x4A2F1E
private const val SHIRT = 0xD9CFB6
private const val PANTS = 0x5B4633
private const val BELT = 0x3A2616
private const val LEATHER = 0x6E4A2C
private const val BRASS = 0xB09868

/** Makes the whole body a touch smaller, so the eyes sit at the same height as first person. */
private const val BODY_SCALE = 0.94f

/**
 * The player, seen from behind in third person: a traveller in a loose linen shirt,
 * brown trousers and leather sandals, with short brown hair and a goatee.
 * Built from rounded pieces that hang from each other (hip, knee, shoulder, elbow),
 * so the walk and run swing naturally.
 */
class Hero {
    val parts = ArrayList<CreaturePart>()

    init {
        build()
    }

    private fun part(
        kind: Int, px: Float, py: Float, pz: Float, parent: CreaturePart?, draw: (MeshBuilder) -> Unit,
    ): CreaturePart {
        val m = MeshBuilder(4096)
        m.hd = true
        draw(m)
        val cp = CreaturePart(kind, px, py, pz, 0f, m.finish(), m.vertexCount, parent)
        parts.add(cp)
        return cp
    }

    private fun build() {
        // Hips: the shirt hangs over them, with a leather belt round the waist.
        val pelvis = part(HeroPart.PELVIS, 0f, 1.0f, 0f, null) { m ->
            m.blob(0f, -0.03f, 0f, 0.17f, 0.12f, 0.125f, PANTS, 201, 0.02f, FLAG_FUR)
            m.blob(0f, -0.02f, 0.005f, 0.185f, 0.11f, 0.135f, SHIRT, 202, 0.03f, FLAG_FUR)
            m.blob(0f, 0.07f, 0f, 0.172f, 0.028f, 0.124f, BELT, 203, 0f, FLAG_FUR)
            m.blob(0f, 0.07f, 0.122f, 0.028f, 0.022f, 0.012f, BRASS, 204, 0f, FLAG_BUCKLE)
            // A small pouch on the belt.
            m.blob(0.15f, 0.02f, 0.05f, 0.035f, 0.05f, 0.05f, LEATHER, 205, 0.05f, FLAG_FUR)
        }

        val torso = part(HeroPart.TORSO, 0f, 0.1f, 0f, pelvis) { m ->
            m.blob(0f, 0.08f, 0f, 0.158f, 0.13f, 0.108f, SHIRT, 211, 0.03f, FLAG_FUR)
            m.blob(0f, 0.28f, 0.004f, 0.19f, 0.165f, 0.118f, SHIRT, 212, 0.03f, FLAG_FUR)
            m.blob(0f, 0.41f, -0.005f, 0.215f, 0.07f, 0.105f, SHIRT, 213, 0.02f, FLAG_FUR)
            // Open collar with a little skin showing, and the lacing.
            m.blob(0f, 0.43f, 0.07f, 0.045f, 0.05f, 0.04f, SKIN, 214, 0f, FLAG_FUR)
            m.limb(-0.03f, 0.43f, 0.108f, 0.02f, 0.37f, 0.118f, 0.005f, 0.005f, BELT, FLAG_FUR)
            m.limb(0.03f, 0.43f, 0.108f, -0.02f, 0.37f, 0.118f, 0.005f, 0.005f, BELT, FLAG_FUR)
            // Loose folds of cloth.
            m.limb(-0.08f, 0.2f, 0.11f, -0.1f, 0.02f, 0.1f, 0.012f, 0.01f, shadeRgb(SHIRT, 0.93f), FLAG_FUR)
            m.limb(0.07f, 0.22f, 0.112f, 0.09f, 0.03f, 0.1f, 0.012f, 0.01f, shadeRgb(SHIRT, 0.93f), FLAG_FUR)
            // Neck.
            m.limb(0f, 0.42f, 0f, 0f, 0.57f, 0.012f, 0.056f, 0.05f, SKIN, FLAG_FUR)
        }

        part(HeroPart.HEAD, 0f, 0.56f, 0.01f, torso) { m ->
            // Skull, jaw and face.
            m.blob(0f, 0.13f, 0.01f, 0.1f, 0.12f, 0.11f, SKIN, 221, 0f, FLAG_FUR)
            m.blob(0f, 0.05f, 0.03f, 0.085f, 0.07f, 0.085f, SKIN, 222, 0f, FLAG_FUR)
            m.blob(0f, 0.165f, 0.1f, 0.075f, 0.018f, 0.025f, shadeRgb(SKIN, 0.98f), 223, 0f, FLAG_FUR)
            m.blob(0f, 0.105f, 0.12f, 0.017f, 0.032f, 0.022f, shadeRgb(SKIN, 0.97f), 224, 0f, FLAG_FUR)
            m.blob(-0.018f, 0.082f, 0.125f, 0.01f, 0.008f, 0.008f, shadeRgb(SKIN, 0.9f), 225, 0f, FLAG_FUR)
            m.blob(0.018f, 0.082f, 0.125f, 0.01f, 0.008f, 0.008f, shadeRgb(SKIN, 0.9f), 226, 0f, FLAG_FUR)
            m.blob(0f, 0.058f, 0.114f, 0.026f, 0.006f, 0.007f, 0x8A4A40, 227, 0f, FLAG_FUR)
            // Cheeks.
            m.blob(-0.05f, 0.09f, 0.085f, 0.03f, 0.025f, 0.025f, SKIN, 228, 0f, FLAG_FUR)
            m.blob(0.05f, 0.09f, 0.085f, 0.03f, 0.025f, 0.025f, SKIN, 229, 0f, FLAG_FUR)
            // Eyes, irises and brows.
            for (side in intArrayOf(-1, 1)) {
                val ex = side * 0.038f
                m.blob(ex, 0.14f, 0.107f, 0.017f, 0.011f, 0.012f, 0xF0EDE6, 230 + side, 0f, FLAG_SOLID)
                m.blob(ex, 0.14f, 0.117f, 0.0085f, 0.0085f, 0.004f, 0x3A2816, 232 + side, 0f, FLAG_SOLID)
                m.blob(ex, 0.163f, 0.117f, 0.023f, 0.006f, 0.008f, HAIR, 234 + side, 0f, FLAG_FUR)
                // Ears.
                m.blob(side * 0.1f, 0.12f, 0.005f, 0.015f, 0.03f, 0.022f, shadeRgb(SKIN, 0.96f), 236 + side, 0f, FLAG_FUR)
            }
            // Short brown hair: a close cap over the top and back, with a few tousled tufts.
            m.blob(0f, 0.16f, -0.012f, 0.108f, 0.105f, 0.118f, HAIR, 240, 0.02f, FLAG_FUR)
            m.blob(0f, 0.1f, -0.035f, 0.097f, 0.09f, 0.09f, HAIR, 241, 0.02f, FLAG_FUR)
            for (i in 0 until 7) {
                val a = i * 0.9f
                val r = 0.035f + (i % 3) * 0.018f
                m.blob(
                    sin(a) * r, 0.245f - (i % 3) * 0.012f, cos(a) * r - 0.01f,
                    0.038f, 0.022f, 0.038f, shadeRgb(HAIR, 0.92f + 0.05f * (i % 3)), 242 + i, 0.1f, FLAG_FUR,
                )
            }
            // Goatee: moustache, the sides round the mouth, and a pointed chin beard.
            m.blob(0f, 0.074f, 0.11f, 0.035f, 0.009f, 0.013f, HAIR, 250, 0f, FLAG_FUR)
            m.limb(-0.03f, 0.072f, 0.106f, -0.027f, 0.022f, 0.108f, 0.009f, 0.009f, HAIR, FLAG_FUR)
            m.limb(0.03f, 0.072f, 0.106f, 0.027f, 0.022f, 0.108f, 0.009f, 0.009f, HAIR, FLAG_FUR)
            m.blob(0f, 0.012f, 0.09f, 0.036f, 0.038f, 0.032f, HAIR, 251, 0.05f, FLAG_FUR)
            m.blob(0f, -0.018f, 0.1f, 0.018f, 0.022f, 0.016f, shadeRgb(HAIR, 0.94f), 252, 0f, FLAG_FUR)
        }

        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            val upper = part(if (side < 0) HeroPart.ARM_L else HeroPart.ARM_R, s * 0.215f, 0.41f, 0f, torso) { m ->
                m.blob(0f, 0f, 0f, 0.07f, 0.07f, 0.07f, SHIRT, 260 + side, 0.02f, FLAG_FUR)
                m.limb(0f, -0.01f, 0f, s * 0.015f, -0.26f, 0f, 0.06f, 0.052f, SHIRT, FLAG_FUR)
                m.limb(s * 0.03f, -0.05f, 0.03f, s * 0.035f, -0.2f, 0.035f, 0.01f, 0.01f, shadeRgb(SHIRT, 0.92f), FLAG_FUR)
            }
            part(if (side < 0) HeroPart.FOREARM_L else HeroPart.FOREARM_R, s * 0.015f, -0.27f, 0f, upper) { m ->
                // Rolled-up sleeve, then bare forearm and hand.
                m.blob(0f, -0.015f, 0f, 0.056f, 0.032f, 0.056f, shadeRgb(SHIRT, 0.95f), 262 + side, 0.05f, FLAG_FUR)
                m.limb(0f, -0.03f, 0f, 0f, -0.24f, 0.01f, 0.04f, 0.031f, SKIN, FLAG_FUR)
                m.blob(0f, -0.3f, 0.012f, 0.022f, 0.052f, 0.042f, SKIN, 264 + side, 0f, FLAG_FUR)
                m.limb(-s * 0.012f, -0.27f, 0.045f, -s * 0.02f, -0.32f, 0.06f, 0.012f, 0.009f, SKIN, FLAG_FUR)
                // Fingers curled together.
                m.blob(0f, -0.345f, 0.018f, 0.02f, 0.03f, 0.036f, shadeRgb(SKIN, 0.97f), 266 + side, 0f, FLAG_FUR)
            }
            val thigh = part(if (side < 0) HeroPart.THIGH_L else HeroPart.THIGH_R, s * 0.095f, -0.04f, 0f, pelvis) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.43f, 0.01f, 0.085f, 0.06f, PANTS, FLAG_FUR)
                m.limb(s * 0.05f, -0.1f, 0.06f, s * 0.045f, -0.35f, 0.05f, 0.012f, 0.01f, shadeRgb(PANTS, 0.9f), FLAG_FUR)
            }
            part(if (side < 0) HeroPart.SHIN_L else HeroPart.SHIN_R, 0f, -0.44f, 0.01f, thigh) { m ->
                m.limb(0f, 0f, 0f, 0f, -0.39f, -0.01f, 0.06f, 0.044f, PANTS, FLAG_FUR)
                m.blob(0f, -0.37f, -0.01f, 0.052f, 0.035f, 0.052f, shadeRgb(PANTS, 0.95f), 270 + side, 0.08f, FLAG_FUR)
                m.limb(0f, -0.39f, -0.01f, 0f, -0.46f, -0.01f, 0.034f, 0.034f, SKIN, FLAG_FUR)
                // Bare foot on a leather sole, with straps over the top and round the ankle.
                m.blob(0f, -0.487f, 0.05f, 0.042f, 0.03f, 0.1f, SKIN, 272 + side, 0f, FLAG_FUR)
                m.blob(0f, -0.497f, 0.14f, 0.038f, 0.02f, 0.03f, shadeRgb(SKIN, 0.97f), 274 + side, 0f, FLAG_FUR)
                m.blob(0f, -0.515f, 0.055f, 0.05f, 0.012f, 0.118f, LEATHER, 276 + side, 0f, FLAG_FUR)
                m.limb(-0.045f, -0.482f, 0.09f, 0.045f, -0.482f, 0.09f, 0.009f, 0.009f, shadeRgb(LEATHER, 0.85f), FLAG_FUR)
                m.limb(-0.043f, -0.49f, 0.03f, 0.043f, -0.47f, 0.02f, 0.009f, 0.009f, shadeRgb(LEATHER, 0.85f), FLAG_FUR)
                m.blob(0f, -0.44f, -0.01f, 0.039f, 0.011f, 0.039f, shadeRgb(LEATHER, 0.85f), 278 + side, 0f, FLAG_FUR)
            }
        }
    }

    /** Builds the model matrix for one piece of the hero, as he is standing or moving right now. */
    fun pose(g: Game, part: CreaturePart, out: FloatArray) {
        val m = g.moveAmount
        val run = g.runAmount
        val ph = g.stridePhase
        val air = g.airAmount
        val bob = (abs(cos(ph)) - 0.6f) * 0.05f * m * (1f - air)
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, g.x, g.feet + bob, g.z)
        Matrix.rotateM(out, 0, deg(g.bodyYaw), 0f, 1f, 0f)
        Matrix.scaleM(out, 0, BODY_SCALE, BODY_SCALE, BODY_SCALE)
        apply(g, part, out, m, run, ph, air)
    }

    private fun apply(g: Game, part: CreaturePart, out: FloatArray, m: Float, run: Float, ph: Float, air: Float) {
        val parent = part.parent
        if (parent != null) apply(g, parent, out, m, run, ph, air)
        Matrix.translateM(out, 0, part.px, part.py, part.pz)
        val t = g.time
        val walkA = (0.5f * m + 0.3f * run) * (1f - air)
        val breathe = sin(t * 1.8f)
        when (part.kind) {
            HeroPart.PELVIS -> {
                Matrix.rotateM(out, 0, deg(sin(ph) * 0.12f * m), 0f, 1f, 0f)
            }
            HeroPart.TORSO -> {
                val lean = 0.06f * m + 0.2f * run
                Matrix.rotateM(out, 0, deg(-sin(ph) * 0.2f * m), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(lean + breathe * 0.01f), 1f, 0f, 0f)
            }
            HeroPart.HEAD -> {
                val lean = 0.06f * m + 0.2f * run
                val look = sin(t * 0.37f) * 0.12f * (1f - m)
                Matrix.rotateM(out, 0, deg(look), 0f, 1f, 0f)
                Matrix.rotateM(out, 0, deg(-lean * 0.7f + sin(t * 0.23f) * 0.03f), 1f, 0f, 0f)
            }
            HeroPart.ARM_L, HeroPart.ARM_R -> {
                val left = part.kind == HeroPart.ARM_L
                val legSwing = sin(ph + (if (left) 0f else PI_F)) * walkA
                val swing = -legSwing * 0.9f + breathe * 0.015f * (1f - m) - air * 0.5f
                val outward = (0.08f + air * 0.45f + run * 0.05f) * (if (left) -1f else 1f)
                Matrix.rotateM(out, 0, deg(outward), 0f, 0f, 1f)
                Matrix.rotateM(out, 0, deg(swing), 1f, 0f, 0f)
            }
            HeroPart.FOREARM_L, HeroPart.FOREARM_R -> {
                val bend = 0.22f + 0.35f * m + 0.95f * run + air * 0.6f
                Matrix.rotateM(out, 0, deg(-bend), 1f, 0f, 0f)
            }
            HeroPart.THIGH_L, HeroPart.THIGH_R -> {
                val left = part.kind == HeroPart.THIGH_L
                val swing = sin(ph + (if (left) 0f else PI_F)) * walkA
                val tuck = air * (if (left) -0.55f else -0.25f)
                Matrix.rotateM(out, 0, deg(swing + tuck), 1f, 0f, 0f)
            }
            HeroPart.SHIN_L, HeroPart.SHIN_R -> {
                val left = part.kind == HeroPart.SHIN_L
                val lift = max(0f, -cos(ph + (if (left) 0f else PI_F)))
                val knee = 0.04f + lift * (0.9f * m + 0.6f * run) * (1f - air) + air * (if (left) 1.0f else 0.6f)
                Matrix.rotateM(out, 0, deg(knee), 1f, 0f, 0f)
            }
            else -> {}
        }
    }

    private fun deg(radians: Float): Float = radians * 57.29578f
}

private const val PI_F = 3.1415927f
