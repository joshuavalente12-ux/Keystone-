package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

enum class Zone(val title: String, val subtitle: String, val levels: String, val mapColor: Int) {
    MEADOW("Greenhollow", "Where every journey begins", "Level 1–20", 0x7ED957),
    FOREST("Whisperwood", "The trees are watching", "Level 30–40", 0xE0605A),
    DESERT("Sunscar Dunes", "Sand, sun and old bones", "Level 90–100", 0xF2C46D),
    SNOW("Frostpeak Highlands", "Cold enough to crack stone", "Level 60–70", 0x74E0E6),
    CAVES("The Hollow Deep", "Light fades, crystals glow", "Level 110–150", 0xB48CFF),
}

/** Metres per terrain cell. */
const val CELL = 6f

/** Cells along each side. 485 x 6 m = 2.91 km a side, about 8.47 square km. */
const val GRID = 485

const val WORLD_SIZE = GRID * CELL

/** Kinds of named places. */
object Site {
    const val TOWN = 0
    const val RUIN = 1
    const val TOWER = 2
    const val VAULT = 3
    const val CAMP = 4
    const val SHRINE = 5
    const val CASTLE = 6
}

class Place(val name: String, val kind: Int, val x: Float, val z: Float, val radius: Float) {
    var baseY = 0f
}

/** Every named place on the map. You start in Greenhollow, bottom-left. */
val PLACES = listOf(
    Place("Greenhollow", Site.TOWN, 300f, 2610f, 34f),
    Place("Millbrook", Site.TOWN, 880f, 2240f, 34f),
    Place("Old Watch", Site.TOWER, 380f, 1790f, 14f),
    Place("Keystone Vault", Site.VAULT, 1180f, 2690f, 16f),
    Place("Crossroads Inn", Site.CAMP, 1250f, 1830f, 16f),
    Place("Thornwick", Site.TOWN, 650f, 880f, 34f),
    Place("Mossgate Ruins", Site.RUIN, 300f, 330f, 18f),
    Place("Hunter's Camp", Site.CAMP, 1080f, 360f, 16f),
    Place("Whisper Shrine", Site.SHRINE, 230f, 1230f, 16f),
    Place("Highcrest", Site.TOWN, 1560f, 900f, 34f),
    Place("Frostwatch", Site.TOWER, 1820f, 330f, 14f),
    Place("Glacier Vault", Site.VAULT, 1380f, 1360f, 16f),
    Place("Frost Shrine", Site.SHRINE, 1760f, 1300f, 16f),
    Place("Sandholm", Site.TOWN, 2360f, 820f, 34f),
    Place("Sunken Temple", Site.RUIN, 2640f, 300f, 18f),
    Place("Oasis Camp", Site.CAMP, 2120f, 1460f, 16f),
    Place("Dune Shrine", Site.SHRINE, 2690f, 1360f, 16f),
    Place("Emberfall", Site.RUIN, 1940f, 2240f, 18f),
    Place("Crystal Mine", Site.VAULT, 2580f, 2020f, 16f),
    Place("Ashen Camp", Site.CAMP, 1620f, 2680f, 16f),
    Place("Deep Shrine", Site.SHRINE, 2620f, 2680f, 16f),
    Place("Greenhollow Keep", Site.CASTLE, 560f, 2000f, 64f),
    Place("Briarfield", Site.TOWN, 640f, 2760f, 34f),
    Place("Thornkeep", Site.CASTLE, 560f, 500f, 64f),
    Place("Fernhollow", Site.TOWN, 380f, 960f, 34f),
    Place("Frosthold", Site.CASTLE, 1230f, 1080f, 64f),
    Place("Icebrook", Site.TOWN, 1700f, 620f, 34f),
    Place("Sunspire Fort", Site.CASTLE, 2640f, 860f, 64f),
    Place("Dustwell", Site.TOWN, 2160f, 540f, 34f),
    Place("Duskhold", Site.CASTLE, 2250f, 2560f, 64f),
    Place("Gloomhaven", Site.TOWN, 2300f, 1880f, 34f),
    // ----- Added later: more villages and camps, each with a trading post and its own quests. -----
    // Greenhollow
    Place("Applebrook", Site.TOWN, 280f, 2240f, 34f),
    Place("Ferrow's Rest", Site.CAMP, 880f, 1840f, 16f),
    Place("Shepherd's Camp", Site.CAMP, 580f, 2400f, 16f),
    // Whisperwood
    Place("Lanternwick", Site.TOWN, 620f, 1320f, 34f),
    Place("Mosswater Camp", Site.CAMP, 280f, 660f, 16f),
    Place("Hollowbough Camp", Site.CAMP, 780f, 280f, 16f),
    // Frostpeak Highlands
    Place("Kettlefrost", Site.TOWN, 980f, 1500f, 34f),
    Place("Ridgefire Camp", Site.CAMP, 1260f, 700f, 16f),
    Place("Bearpelt Camp", Site.CAMP, 1880f, 960f, 16f),
    // Sunscar Dunes
    Place("Qarim's Wells", Site.TOWN, 2240f, 1140f, 34f),
    Place("Saltwind Camp", Site.CAMP, 2320f, 280f, 16f),
    Place("Scorpion Camp", Site.CAMP, 2540f, 580f, 16f),
    // The Hollow Deep
    Place("Lumen Hollow", Site.TOWN, 1740f, 1800f, 34f),
    Place("Cinderdeep", Site.TOWN, 1460f, 2240f, 34f),
    Place("Shardlight Camp", Site.CAMP, 2620f, 2340f, 16f),
    Place("Ashveil Camp", Site.CAMP, 1920f, 2560f, 16f),
    Place("Gloomroot Camp", Site.CAMP, 2240f, 2180f, 16f),
    Place("Voidwatch Camp", Site.CAMP, 2560f, 1720f, 16f),
)

/** Places from here on were added later; their quests are hand-written (see Quests). */
const val FIRST_NEW_PLACE = 31

/** Which places are joined by a road. */
private val ROADS = intArrayOf(
    21, 2, 21, 1, 22, 0, 22, 3, 23, 6, 23, 5, 24, 5, 24, 8, 25, 9, 25, 11, 26, 9, 26, 10,
    27, 13, 27, 16, 28, 13, 28, 10, 29, 17, 29, 20, 30, 17, 30, 18,
    0, 1, 0, 2, 1, 3, 1, 4, 2, 8, 2, 5, 5, 6, 5, 7, 5, 9, 4, 9, 4, 11, 11, 12, 9, 10,
    7, 10, 9, 13, 13, 14, 13, 16, 11, 15, 15, 16, 15, 17, 4, 17, 17, 18, 17, 19, 3, 19,
    18, 20, 10, 14,
    // Roads out to the villages and camps added later, each to a neighbour in its own region.
    31, 21, 32, 1, 33, 0, 34, 8, 35, 24, 36, 23, 37, 11, 38, 25, 39, 9,
    40, 13, 41, 28, 42, 27, 43, 17, 44, 17, 45, 18, 46, 17, 47, 30, 48, 30,
)

/** Where each region is centred (x, z) and how far it reaches (bigger = larger). Order matches Zone. */
private val REGION_X = floatArrayOf(420f, 560f, 2380f, 1480f, 2180f)
private val REGION_Z = floatArrayOf(2330f, 720f, 760f, 1060f, 2260f)
private val REGION_W = floatArrayOf(140f, 70f, 60f, 60f, 40f)

/** Where each region's name goes on the map (kept clear of place names). */
val REGION_LABEL_X = floatArrayOf(420f, 560f, 2420f, 1450f, 2150f)
val REGION_LABEL_Z = floatArrayOf(2330f, 560f, 1080f, 1030f, 2440f)

private const val POND_X = 430f
private const val POND_Z = 2520f
private const val OASIS_X = 2165f
private const val OASIS_Z = 1505f
private const val BUCKET = 200f

/** Kinds of things that stand on the ground. */
object Kind {
    const val NONE = 0
    const val PINE = 1
    const val TREE = 2
    const val PALM = 3
    const val CACTUS = 4
    const val ROCK = 5
    const val CRYSTAL = 6
    const val FLOWERS = 7
    const val STONE = 8
    const val PILLAR = 9
    const val SHRINE = 10
    const val BRIDGE = 11
    const val HOUSE = 12
    const val WALL = 13
    const val TOWER = 14
    const val VAULT = 15
    const val TENT = 16
    const val FIRE = 17
    const val WELL = 18
    const val DEAD = 19
    /** The Grain Rot's big waterfall. */
    const val FALLS = 20
}

/** Everything the map knows about one spot. Reused so we don't make garbage. */
class Probe {
    var zone = Zone.MEADOW
    val regionDist = FloatArray(5)
    var mountain = 0f
    var trail = 999f
    var site = 999f
    var siteCenter = 999f
    var siteKind = -1
    var siteIndex = -1
    var mesa = 0f
    var river = 999f
}

/** One thing standing on the map. Reused so we don't make garbage. */
class Placed {
    var kind = Kind.NONE
    var x = 0f
    var z = 0f
    var y = 0f
    var size = 1f
    var v = 0f
    var radius = 0f
}

/** A built feature: houses, walls, towers, stones, the bridges and so on. */
class Landmark(
    val kind: Int, val x: Float, val z: Float, val angle: Float, val radius: Float,
    val size: Float = 1f, val v: Float = 0f, val y: Float = 0f,
)

/**
 * The whole world, 2.9 km across, laid out like a real map: five regions with
 * rising danger, twenty-one named places joined by winding roads, mountain
 * ranges, a river with bridges, lakes and an oasis.
 */
class World(private val seed: Int = 1337, private val realm: Boolean = false) {
    private val n = GRID + 1
    val heights = FloatArray(n * n)

    // Road pieces, and a grid of buckets so we only check the nearby ones.
    private val segX0: FloatArray
    private val segZ0: FloatArray
    private val segX1: FloatArray
    private val segZ1: FloatArray
    private val nb = (WORLD_SIZE / BUCKET).toInt() + 1
    private val buckets = Array(nb * nb) { IntArray(0) }

    /** Road shapes for drawing on the map: pairs of points. */
    val roadLines: FloatArray

    private val bridgeX = ArrayList<Float>()
    private val bridgeZ = ArrayList<Float>()
    private val bridgeDX = ArrayList<Float>()
    private val bridgeDZ = ArrayList<Float>()
    private val bridgeY = ArrayList<Float>()
    private val bridgeHalf = ArrayList<Float>()
    private var bridgesReady = false

    val landmarks = ArrayList<Landmark>()

    /**
     * Spots along the roads, well clear of towns, bridges, water and mountains, where a carriage
     * might be caught by monsters: x, z and the way the road runs there (yaw). Empty in the Grain Rot.
     */
    val carriageSpots: List<FloatArray> by lazy {
        val out = ArrayList<FloatArray>()
        if (!realm) {
            val p = Probe()
            for (s in segX0.indices) {
                val k = s % 10
                if (k < 2 || k > 7) continue
                val dx = segX1[s] - segX0[s]
                val dz = segZ1[s] - segZ0[s]
                if (hypot(dx, dz) < 1f) continue
                val mx = (segX0[s] + segX1[s]) * 0.5f
                val mz = (segZ0[s] + segZ1[s]) * 0.5f
                probe(mx, mz, p)
                if (p.site < 70f || p.mountain > 0.25f || terrainAt(mx, mz) < 0.8f || onBridge(mx, mz)) continue
                out.add(floatArrayOf(mx, mz, atan2(dx, dz)))
            }
        }
        out
    }

    /**
     * Trees and rocks that have been chopped down or broken up: world cell (j * GRID + i) to
     * when it grows back (milliseconds). Read by the chunk builder's thread too.
     */
    val harvested = java.util.concurrent.ConcurrentHashMap<Int, Long>()
    /** Chunks that need building again because something in them changed. */
    val dirtyChunks = java.util.concurrent.ConcurrentLinkedQueue<Int>()
    /** Everything the player has built. Set by the game once it's ready. */
    @Volatile var base: Base? = null
    /**
     * The thick woods and rock fields only appear once chests, caves and lairs have been laid out,
     * so those always land in the same spots, and never inside [denseBlock] (cells round them).
     */
    @Volatile var denseReady = false
    val denseBlock = HashSet<Int>()

    /** Keeps the thick woods clear of a circle round (x, z). Call before [denseReady] is set. */
    fun keepClear(x: Float, z: Float, r: Float) {
        val i0 = ((x - r) / CELL).toInt()
        val i1 = ((x + r) / CELL).toInt()
        val j0 = ((z - r) / CELL).toInt()
        val j1 = ((z + r) / CELL).toInt()
        for (j in j0..j1) for (i in i0..i1) if (i in 0 until GRID && j in 0 until GRID) denseBlock.add(j * GRID + i)
    }

    /** Asks for the chunk holding world cell (i, j) to be built again. */
    fun markDirty(i: Int, j: Int) {
        if (i < 0 || j < 0 || i >= GRID || j >= GRID) return
        dirtyChunks.add((j / CHUNK_CELLS) * CHUNKS + i / CHUNK_CELLS)
    }

    /** Buildings you can walk into, one list per place (empty for most). */
    val structures = ArrayList<Structure>()
    /** The Grain Rot's villages: x, z of each centre (empty in the main world). */
    val realmVillages = ArrayList<FloatArray>()
    /** Each village's first house: x, z and the way its door faces (frontX, frontZ). */
    val realmHouses = ArrayList<FloatArray>()

    /** Which way each place faces: the angle of its first road (towns, camps, castles). */
    val siteFront = FloatArray(PLACES.size)
    /** Where each town's and castle's market stall is: x, z, and the way it faces (fx, fz). */
    val stallSpot = HashMap<Int, FloatArray>()
    /** Where each town's notice board is: x, z, fx, fz. */
    val boardSpot = HashMap<Int, FloatArray>()
    /** The wizard's house in Greenhollow: x, z and the way its door faces (frontX, frontZ). Null until built. */
    @Volatile var wizardHouse: FloatArray? = null
    /** Story houses by place number (0 Greenhollow, 5 Thornwick, 9 Highcrest, 13 Sandholm, 24 Fernhollow): x, z, frontX, frontZ. */
    val homes = HashMap<Int, FloatArray>()

    /** You start in Greenhollow's square, a few steps from the well, facing the road to Millbrook. */
    val spawnYaw = if (realm) ROT_SPAWN_YAW else atan2(PLACES[1].x - PLACES[0].x, PLACES[1].z - PLACES[0].z)
    val spawnX = if (realm) ROT_SPAWN_X else PLACES[0].x + sin(spawnYaw) * 6f
    val spawnZ = if (realm) ROT_SPAWN_Z else PLACES[0].z + cos(spawnYaw) * 6f

    /** Colour of every cell for the maps, and which region it's in. */
    val mapColors = IntArray(GRID * GRID)

    /** True for the Grain Rot's own land. */
    val isGrainMap: Boolean get() = realm
    val regionMap = ByteArray(GRID * GRID)

    private var flattenReady = false
    private val tmpProbe = Probe()

    init {
        // Winding roads between places.
        val xs0 = ArrayList<Float>()
        val zs0 = ArrayList<Float>()
        val xs1 = ArrayList<Float>()
        val zs1 = ArrayList<Float>()
        var e = 0
        while (!realm && e < ROADS.size) {
            val a = PLACES[ROADS[e]]
            val b = PLACES[ROADS[e + 1]]
            val dx = b.x - a.x
            val dz = b.z - a.z
            val len = hypot(dx, dz)
            val nx = -dz / len
            val nz = dx / len
            val amp = (hash(ROADS[e], ROADS[e + 1], 50) - 0.5f) * 0.18f * len
            val amp2 = (hash(ROADS[e], ROADS[e + 1], 51) - 0.5f) * 0.06f * len
            var px = a.x
            var pz = a.z
            for (k in 1..10) {
                val t = k / 10f
                val off = amp * sin(3.1415927f * t) + amp2 * sin(6.2831855f * t)
                val qx = a.x + dx * t + nx * off
                val qz = a.z + dz * t + nz * off
                xs0.add(px)
                zs0.add(pz)
                xs1.add(qx)
                zs1.add(qz)
                px = qx
                pz = qz
            }
            e += 2
        }
        segX0 = xs0.toFloatArray()
        segZ0 = zs0.toFloatArray()
        segX1 = xs1.toFloatArray()
        segZ1 = zs1.toFloatArray()
        roadLines = FloatArray(segX0.size * 4)
        val lists = Array(nb * nb) { ArrayList<Int>() }
        for (s in segX0.indices) {
            roadLines[s * 4] = segX0[s]
            roadLines[s * 4 + 1] = segZ0[s]
            roadLines[s * 4 + 2] = segX1[s]
            roadLines[s * 4 + 3] = segZ1[s]
            val bi0 = ((min(segX0[s], segX1[s]) - 40f) / BUCKET).toInt().coerceIn(0, nb - 1)
            val bi1 = ((max(segX0[s], segX1[s]) + 40f) / BUCKET).toInt().coerceIn(0, nb - 1)
            val bj0 = ((min(segZ0[s], segZ1[s]) - 40f) / BUCKET).toInt().coerceIn(0, nb - 1)
            val bj1 = ((max(segZ0[s], segZ1[s]) + 40f) / BUCKET).toInt().coerceIn(0, nb - 1)
            for (bj in bj0..bj1) for (bi in bi0..bi1) lists[bj * nb + bi].add(s)
        }
        for (b in lists.indices) buckets[b] = lists[b].toIntArray()

        // Bridges wherever a road crosses the river.
        for (s in segX0.indices) {
            val a = segX0[s] - riverX(segZ0[s])
            val b = segX1[s] - riverX(segZ1[s])
            if ((a < 0f) == (b < 0f)) continue
            val t = a / (a - b)
            val bx = segX0[s] + (segX1[s] - segX0[s]) * t
            val bz = segZ0[s] + (segZ1[s] - segZ0[s]) * t
            val len = hypot(segX1[s] - segX0[s], segZ1[s] - segZ0[s])
            bridgeX.add(bx)
            bridgeZ.add(bz)
            bridgeDX.add((segX1[s] - segX0[s]) / len)
            bridgeDZ.add((segZ1[s] - segZ0[s]) / len)
            bridgeY.add(BRIDGE_MIN)
        }
        val p = Probe()
        for (b in bridgeX.indices) {
            // Long enough to reach solid bank on both sides, however slanted the crossing.
            var reach = 0f
            for (sgn in intArrayOf(1, -1)) {
                var d = 0f
                while (d < 60f) {
                    val px = bridgeX[b] + bridgeDX[b] * d * sgn
                    val pz = bridgeZ[b] + bridgeDZ[b] * d * sgn
                    if (abs(px - riverX(pz)) >= 16f) break
                    d += 0.5f
                }
                reach = max(reach, d)
            }
            val half = max(16f, reach + 3f)
            bridgeHalf.add(half)
            val h1 = heightAt(bridgeX[b] + bridgeDX[b] * (half + 4f), bridgeZ[b] + bridgeDZ[b] * (half + 4f), p)
            val h2 = heightAt(bridgeX[b] - bridgeDX[b] * (half + 4f), bridgeZ[b] - bridgeDZ[b] * (half + 4f), p)
            bridgeY[b] = max(BRIDGE_MIN, (h1 + h2) * 0.5f + 0.3f)
        }
        bridgesReady = true

        // Level ground for each place to sit on.
        if (!realm) for (pl in PLACES) pl.baseY = max(2f, heightAt(pl.x, pl.z, p))
        flattenReady = true

        for (j in 0 until n) {
            for (i in 0 until n) {
                heights[j * n + i] = heightAt(i * CELL, j * CELL, p)
            }
        }
        if (realm) buildRealmLandmarks() else buildLandmarks()
        paintMap(p)
    }

    // ---------- Layout ----------

    private fun riverX(z: Float): Float = if (realm) -99999f else 820f + 110f * sin(z / 380f) + 40f * sin(z / 130f + 1f)

    private fun roadDist(x: Float, z: Float): Float {
        val bi = (x / BUCKET).toInt().coerceIn(0, nb - 1)
        val bj = (z / BUCKET).toInt().coerceIn(0, nb - 1)
        var d = 999f
        for (s in buckets[bj * nb + bi]) {
            d = min(d, segDist(x, z, segX0[s], segZ0[s], segX1[s], segZ1[s]))
        }
        return d
    }

    /** The direction round a place furthest from any road (and from [avoid], if given). */
    private fun clearAngle(roads: FloatArray, avoid: Float): Float {
        var best = 0f
        var bestD = -1f
        for (k in 0 until 24) {
            val a = k * 6.2831855f / 24f + 0.13f
            var d = 9f
            for (r in roads) d = min(d, angleGap(a, r))
            if (avoid > -50f) d = min(d, angleGap(a, avoid) * 0.6f)
            if (d > bestD) {
                bestD = d
                best = a
            }
        }
        return best
    }

    private fun angleGap(a: Float, b: Float): Float {
        var d = abs(a - b) % 6.2831855f
        if (d > 3.1415927f) d = 6.2831855f - d
        return d
    }

    /** Directions (angles) of the roads leaving place [i]. */
    private fun roadAngles(i: Int): FloatArray {
        val out = ArrayList<Float>()
        var e = 0
        while (e < ROADS.size) {
            val other = when (i) {
                ROADS[e] -> ROADS[e + 1]
                ROADS[e + 1] -> ROADS[e]
                else -> -1
            }
            if (other >= 0) out.add(atan2(PLACES[other].z - PLACES[i].z, PLACES[other].x - PLACES[i].x))
            e += 2
        }
        return out.toFloatArray()
    }

    private fun nearRoad(angle: Float, roads: FloatArray, gap: Float): Boolean {
        for (r in roads) {
            var d = abs(angle - r) % 6.2831855f
            if (d > 3.1415927f) d = 6.2831855f - d
            if (d < gap) return true
        }
        return false
    }

    /** The Grain Rot's castle on its mountain, and the waterfall beside it. */
    private fun buildRealmLandmarks() {
        val gx = ROT_SPAWN_X - ROT_CASTLE_X
        val gz = ROT_GATE_Z - ROT_CASTLE_Z
        val gl = hypot(gx, gz)
        val st = Structure(ROT_CASTLE_X, ROT_CASTLE_Z, 64f)
        buildRotCastle(st, ROT_CASTLE_X, terrainAt(ROT_CASTLE_X, ROT_CASTLE_Z), ROT_CASTLE_Z, gx / gl, gz / gl, 7717, ::terrainAt)
        structures.add(st)
        buildRealmVillages()
        buildRealmArena()
        buildRealmForts()
        val mid = (ROT_FALLS_TOP + ROT_FALLS_BOTTOM) * 0.5f
        landmarks.add(
            Landmark(
                Kind.FALLS, ROT_CASTLE_X + cos(ROT_FALLS_ANGLE) * mid, ROT_CASTLE_Z + sin(ROT_FALLS_ANGLE) * mid,
                ROT_FALLS_ANGLE, 0f,
            ),
        )
    }

    /**
     * Five villages on the open ground near the gate. Each centre is picked by searching rings round
     * the gate for flat, mountain-free ground, at least 110 m from the others, then a well, six
     * houses, a market stall and a notice board are built round it.
     */
    private fun buildRealmVillages() {
        val cx = ROT_SPAWN_X
        val cz = ROT_GATE_Z
        class Cand(val x: Float, val z: Float, val score: Float)
        val cands = ArrayList<Cand>()
        for (ring in 0 until 6) {
            val r = 120f + ring * 40f
            for (s in 0 until 24) {
                val a = s * 6.2831855f / 24f + ring * 0.13f
                val x = cx + cos(a) * r
                val z = cz + sin(a) * r
                if (rotEdge(x, z) < 160f) continue
                if (hypot(x - ROT_CASTLE_X, z - ROT_CASTLE_Z) < 400f) continue
                var lo = 1e9f
                var hi = -1e9f
                var bad = false
                for (k in 0 until 9) {
                    val sx = if (k == 0) x else x + cos(k * 0.7854f) * 34f
                    val sz = if (k == 0) z else z + sin(k * 0.7854f) * 34f
                    probe(sx, sz, tmpProbe)
                    if (tmpProbe.mountain > 0f) bad = true
                    val y = terrainAt(sx, sz)
                    if (y < 1.5f) bad = true
                    if (y < lo) lo = y
                    if (y > hi) hi = y
                }
                if (bad) continue
                cands.add(Cand(x, z, (hi - lo) + r * 0.004f))
            }
        }
        cands.sortBy { it.score }
        val names = arrayOf("Greywick", "Mourne", "Dunmere", "Harrowby", "Fallowmere")
        for (c in cands) {
            if (realmVillages.size >= 5) break
            var clear = true
            for (v in realmVillages) if (hypot(v[0] - c.x, v[1] - c.z) < 110f) clear = false
            if (!clear) continue
            realmVillages.add(floatArrayOf(c.x, c.z))
            val idx = realmVillages.size - 1
            val st = Structure(c.x, c.z, 45f)
            buildWell(st, c.x, terrainAt(c.x, c.z), c.z, Style.GREEN)
            for (k in 0 until 6) {
                val a = 0.4f + idx * 0.9f + k * 6.2831855f / 6f
                val r = 20f + 3f * hash(idx, k, 71)
                val hx = c.x + cos(a) * r
                val hz = c.z + sin(a) * r
                buildHouse(st, hx, terrainAt(hx, hz), hz, -cos(a), -sin(a), Style.GREEN, 7000 + idx * 97 + k * 13)
                if (k == 0) realmHouses.add(floatArrayOf(hx, hz, -cos(a), -sin(a)))
            }
            val sa = 0.4f + idx * 0.9f + 0.52f
            val sx = c.x + cos(sa) * 11f
            val sz = c.z + sin(sa) * 11f
            buildStall(st, sx, terrainAt(sx, sz), sz, -cos(sa), -sin(sa), Style.GREEN, 7000 + idx * 17)
            val ba = sa + 2.4f
            val bx = c.x + cos(ba) * 10f
            val bz = c.z + sin(ba) * 10f
            buildBoard(st, bx, terrainAt(bx, bz), bz, -cos(ba), -sin(ba))
            structures.add(st)
        }
    }

    /**
     * The dirt arena: a ring of timber posts round the bare dirt with four wide gateways, taller
     * banner posts either side of each gate and a torch on every fourth post. Meant to double later
     * as the player-versus-player / player-versus-enemy ground.
     */
    private fun buildRealmArena() {
        val ay = terrainAt(ROT_ARENA_X, ROT_ARENA_Z)
        val st = Structure(ROT_ARENA_X, ROT_ARENA_Z, 125f)
        val k = Kit(st, ROT_ARENA_X, ay, ROT_ARENA_Z, 1f, 0f)
        val count = 52
        for (i in 0 until count) {
            val a = i * 6.2831855f / count
            val q = a / 1.5707964f
            val d = abs(q - kotlin.math.round(q))
            if (d < 0.09f) continue
            val pu = cos(a) * (ROT_ARENA_R + 4f)
            val pw = sin(a) * (ROT_ARENA_R + 4f)
            if (d < 0.17f) {
                k.prism(pu, -1f, pw, 0.95f, 0.8f, 7.5f, 8, 0x4A3A28, FLAG_WOOD, true, 0.8f)
                banner(k, pu, 6f, pw, -a, 0x8A1A1A)
            } else {
                k.prism(pu, -1f, pw, 0.55f, 0.45f, 4.2f, 8, 0x5A4630, FLAG_WOOD, true, 0.45f)
                if (i % 4 == 0) torch(k, pu, 3.4f, pw, -a)
            }
        }
        structures.add(st)
    }

    /** The two servants' strongholds: a ring of black posts with four gaps, a dark spire in the middle, torches and banners. */
    private fun buildRealmForts() {
        for (f in 0 until 2) {
            val fx = if (f == 0) ROT_FORT1_X else ROT_FORT2_X
            val fz = if (f == 0) ROT_FORT1_Z else ROT_FORT2_Z
            val fy = terrainAt(fx, fz)
            val st = Structure(fx, fz, 48f)
            val k = Kit(st, fx, fy, fz, 1f, 0f)
            k.prism(0f, -1f, 0f, 3.6f, 2.4f, 16f, 8, 0x2A2622, FLAG_STONE, true, 3.2f)
            torch(k, 4.2f, 2.4f, 0f, 0f)
            torch(k, -4.2f, 2.4f, 0f, 3.1f)
            torch(k, 0f, 2.4f, 4.2f, 1.5f)
            torch(k, 0f, 2.4f, -4.2f, -1.5f)
            val count = 28
            for (i in 0 until count) {
                val a = i * 6.2831855f / count
                val q = a / 1.5707964f
                val d = abs(q - kotlin.math.round(q))
                if (d < 0.1f) continue
                val pu = cos(a) * (ROT_FORT_R - 4f)
                val pw = sin(a) * (ROT_FORT_R - 4f)
                if (d < 0.2f) {
                    k.prism(pu, -1f, pw, 0.95f, 0.8f, 8f, 8, 0x1E1A18, FLAG_WOOD, true, 0.8f)
                    banner(k, pu, 6.5f, pw, -a, 0x4A2A6A)
                } else {
                    k.prism(pu, -1f, pw, 0.6f, 0.5f, 4.6f, 8, 0x2A2420, FLAG_WOOD, true, 0.5f)
                    if (i % 3 == 0) torch(k, pu, 3.6f, pw, -a)
                }
            }
            structures.add(st)
        }
    }

    /** Rocks of three sizes, a few trees and flowers: the open field. Nothing on the castle mountain. */
    private fun realmObject(i: Int, j: Int, x: Float, z: Float, h: Float, out: Placed): Boolean {
        if (hypot(x - ROT_CASTLE_X, z - ROT_CASTLE_Z) < 320f) return false
        for (v in realmVillages) if (hypot(x - v[0], z - v[1]) < 48f) return false
        if (hypot(x - ROT_ARENA_X, z - ROT_ARENA_Z) < 125f) return false
        if (hypot(x - ROT_FORT1_X, z - ROT_FORT1_Z) < 50f || hypot(x - ROT_FORT2_X, z - ROT_FORT2_Z) < 50f) return false
        if (rotTrailDist(x, z) < 6f) return false
        val y = terrainAt(x, z)
        if (y < 1.2f) return false
        val v = hash(i, j, seed + 203)
        val kind: Int
        val size: Float
        when {
            h < 0.030f -> { kind = Kind.ROCK; size = 0.45f + 0.25f * v }
            h < 0.048f -> { kind = Kind.ROCK; size = 1.1f + 0.4f * v }
            h < 0.056f -> { kind = Kind.ROCK; size = 2.2f + 0.9f * v }
            h < 0.075f -> { kind = Kind.TREE; size = 0.9f + 0.4f * v }
            h < 0.140f -> { kind = Kind.FLOWERS; size = 0.8f + 0.5f * v }
            else -> return false
        }
        out.kind = kind
        out.x = x
        out.z = z
        out.y = y
        out.v = v
        out.size = size
        out.radius = when (kind) {
            Kind.ROCK -> 1.1f * size
            Kind.TREE -> 0.7f * size
            else -> 0f
        }
        return true
    }

    private fun buildLandmarks() {
        for ((idx, pl) in PLACES.withIndex()) {
            val roads = roadAngles(idx)
            val first = if (roads.isNotEmpty()) roads[0] else 0f
            siteFront[idx] = first
            when (pl.kind) {
                Site.TOWN -> {
                    val st = Structure(pl.x, pl.z, pl.radius)
                    probe(pl.x, pl.z, tmpProbe)
                    val style = Style.of(tmpProbe.zone)
                    buildWell(st, pl.x, terrainAt(pl.x, pl.z), pl.z, style)
                    for (k in 0 until 9) {
                        val a = first + 0.35f + k * 6.2831855f / 9f
                        if (nearRoad(a, roads, 0.42f)) continue
                        val r = 23f + 3f * hash(idx, k, 70)
                        val hx = pl.x + cos(a) * r
                        val hz = pl.z + sin(a) * r
                        // Houses face the middle of town.
                        // Story houses: Greenhollow's first is the wizard's; the first in Thornwick and in Fernhollow belong to Chapter Two's people.
                        val fix = (idx == 0 || idx == 5 || idx == 9 || idx == 13 || idx == 24) && !homes.containsKey(idx)
                        if (fix) {
                            val spot = floatArrayOf(hx, hz, -cos(a), -sin(a))
                            homes[idx] = spot
                            if (idx == 0) wizardHouse = spot
                        }
                        buildHouse(st, hx, terrainAt(hx, hz), hz, -cos(a), -sin(a), style, idx * 97 + k * 13 + 5, fix && idx == 0, fix)
                    }
                    // A market stall and a notice board in the square, clear of the roads.
                    val a1 = clearAngle(roads, -99f)
                    val a2 = clearAngle(roads, a1)
                    val sx = pl.x + cos(a1) * 11f
                    val sz = pl.z + sin(a1) * 11f
                    buildStall(st, sx, terrainAt(sx, sz), sz, -cos(a1), -sin(a1), style, idx * 17 + 3)
                    stallSpot[idx] = floatArrayOf(sx, sz, -cos(a1), -sin(a1))
                    val bx = pl.x + cos(a2) * 10f
                    val bz = pl.z + sin(a2) * 10f
                    buildBoard(st, bx, terrainAt(bx, bz), bz, -cos(a2), -sin(a2))
                    boardSpot[idx] = floatArrayOf(bx, bz, -cos(a2), -sin(a2))
                    structures.add(st)
                }
                Site.CASTLE -> {
                    val st = Structure(pl.x, pl.z, pl.radius)
                    probe(pl.x, pl.z, tmpProbe)
                    // The gate faces the first road in.
                    buildCastle(st, pl.x, terrainAt(pl.x, pl.z), pl.z, cos(first), sin(first), Style.of(tmpProbe.zone), idx * 131 + 7, ::terrainAt)
                    val fx = cos(first)
                    val fz = sin(first)
                    stallSpot[idx] = floatArrayOf(
                        castleX(pl.x, fx, fz, CASTLE_STALL_U, CASTLE_STALL_W), castleZ(pl.z, fx, fz, CASTLE_STALL_U, CASTLE_STALL_W), -fz, fx,
                    )
                    structures.add(st)
                }
                Site.RUIN -> {
                    for (k in 0 until 11) {
                        val a = first + 0.3f + k * 6.2831855f / 11f
                        if (nearRoad(a, roads, 0.35f)) continue
                        val r = 11f + 3f * hash(idx, k, 73)
                        landmarks.add(
                            Landmark(Kind.WALL, pl.x + cos(a) * r, pl.z + sin(a) * r, a + 1.5708f, 1.5f, 0.4f + hash(idx, k, 74), hash(idx, k, 75)),
                        )
                    }
                    for (k in 0 until 4) {
                        val a = k * 1.5708f + 0.78f
                        landmarks.add(Landmark(Kind.PILLAR, pl.x + cos(a) * 5f, pl.z + sin(a) * 5f, a, 0.7f, 0.5f + hash(idx, k, 76), 0f))
                    }
                }
                Site.TOWER -> landmarks.add(Landmark(Kind.TOWER, pl.x, pl.z, first, 2.8f))
                Site.VAULT -> landmarks.add(Landmark(Kind.VAULT, pl.x, pl.z, first, 8.5f))
                Site.CAMP -> {
                    landmarks.add(Landmark(Kind.FIRE, pl.x, pl.z, 0f, 0.8f))
                    for (k in 0 until 5) {
                        val a = first + 0.6f + k * 6.2831855f / 5f
                        if (nearRoad(a, roads, 0.5f)) continue
                        landmarks.add(Landmark(Kind.TENT, pl.x + cos(a) * 7f, pl.z + sin(a) * 7f, a, 1.7f, 1f, hash(idx, k, 77)))
                    }
                    // A trading post: a market stall in a gap between the tents, clear of the roads.
                    var sa = first + 0.6f + 0.6283185f
                    for (k in 0 until 5) {
                        val a = first + 0.6f + 0.6283185f + k * 6.2831855f / 5f
                        if (!nearRoad(a, roads, 0.45f)) {
                            sa = a
                            break
                        }
                    }
                    val st = Structure(pl.x, pl.z, pl.radius)
                    probe(pl.x, pl.z, tmpProbe)
                    val sx = pl.x + cos(sa) * 5f
                    val sz = pl.z + sin(sa) * 5f
                    buildStall(st, sx, terrainAt(sx, sz), sz, -cos(sa), -sin(sa), Style.of(tmpProbe.zone), idx * 17 + 3)
                    stallSpot[idx] = floatArrayOf(sx, sz, -cos(sa), -sin(sa))
                    structures.add(st)
                }
                Site.SHRINE -> {
                    landmarks.add(Landmark(Kind.SHRINE, pl.x, pl.z, 0f, 3.2f))
                    for (s in 0 until 8) {
                        val a = first + (22.5f + 45f * s) * 0.017453292f
                        landmarks.add(Landmark(Kind.STONE, pl.x + 12f * cos(a), pl.z + 12f * sin(a), a, 0.9f))
                    }
                }
            }
        }
        for (b in bridgeX.indices) {
            landmarks.add(
                Landmark(Kind.BRIDGE, bridgeX[b], bridgeZ[b], atan2(bridgeDZ[b], bridgeDX[b]), 0f, 1f, bridgeHalf[b], bridgeY[b]),
            )
        }
    }

    fun nearBridge(x: Float, z: Float): Boolean {
        for (b in bridgeX.indices) {
            val r = if (b < bridgeHalf.size) bridgeHalf[b] + 6f else 26f
            if (hypot(x - bridgeX[b], z - bridgeZ[b]) < r) return true
        }
        return false
    }

    /** Height of the bridge deck under (x, z), or null if there's no bridge here. */
    fun bridgeAt(x: Float, z: Float): Float? {
        for (b in bridgeX.indices) {
            val dx = x - bridgeX[b]
            val dz = z - bridgeZ[b]
            val along = dx * bridgeDX[b] + dz * bridgeDZ[b]
            val across = -dx * bridgeDZ[b] + dz * bridgeDX[b]
            val half = if (b < bridgeHalf.size) bridgeHalf[b] else BRIDGE_HALF_LEN
            if (abs(along) < half && abs(across) < 2.6f) return bridgeY[b]
        }
        return null
    }

    fun onBridge(x: Float, z: Float): Boolean = bridgeAt(x, z) != null

    // ---------- What is at a spot ----------

    fun probe(x: Float, z: Float, p: Probe) {
        if (realm) {
            rotProbe(x, z, seed, p)
            return
        }
        // Regions have wobbly, natural borders.
        val wx = x + (valueNoise(x / 420f, z / 420f, seed + 61) - 0.5f) * 520f
        val wz = z + (valueNoise(x / 420f, z / 420f, seed + 62) - 0.5f) * 520f
        var best = 1e9f
        var zi = 0
        for (k in 0 until 5) {
            val d = hypot(wx - REGION_X[k], wz - REGION_Z[k]) - REGION_W[k]
            p.regionDist[k] = d
            if (d < best) {
                best = d
                zi = k
            }
        }
        p.zone = Zone.entries[zi]

        p.trail = roadDist(x, z)
        var sd = 1e9f
        var sc = 1e9f
        var si = -1
        for (i in PLACES.indices) {
            val pl = PLACES[i]
            val c = hypot(x - pl.x, z - pl.z)
            val d = c - pl.radius
            if (d < sd) {
                sd = d
                sc = c
                si = i
            }
        }
        p.site = sd
        p.siteCenter = sc
        p.siteIndex = si
        p.siteKind = if (si >= 0) PLACES[si].kind else -1

        // Mountains: all round the edge, plus winding ranges across the land.
        val edge = min(min(x, z), min(WORLD_SIZE - x, WORLD_SIZE - z))
        val mBorder = ((75f - edge + (valueNoise(x / 80f, z / 80f, seed + 3) - 0.5f) * 30f) / 28f)
            .coerceIn(0f, 1f)
        val n2 = 0.65f * valueNoise(x / 520f, z / 520f, seed + 60) + 0.35f * valueNoise(x / 190f, z / 190f, seed + 63)
        val ridge = 1f - abs(n2 * 2f - 1f)
        val th = if (p.zone == Zone.SNOW) 0.86f else 0.9f
        val mRange = smooth(th, th + 0.06f, ridge) * smooth(10f, 30f, p.trail) * smooth(10f, 40f, p.site)
        p.mountain = max(mBorder, mRange)

        val mesaN = 0.7f * valueNoise(x / 110f, z / 110f, seed + 16) +
            0.3f * valueNoise(x / 40f, z / 40f, seed + 17)
        p.mesa = smooth(0.6f, 0.65f, mesaN) * smooth(10f, 24f, p.trail) * smooth(10f, 30f, p.site)
        p.river = abs(x - riverX(z))
    }

    private fun zoneHeight(zone: Int, x: Float, z: Float, hills: Float, p: Probe): Float = when (zone) {
        1 -> 12f + hills
        2 -> 12f + hills * 0.6f +
            3.5f * sin((x * 0.7f + z * 0.3f) / 38f + valueNoise(x / 120f, z / 120f, seed + 14) * 6f)
        3 -> {
            val r = 1f - abs(valueNoise(x / 90f, z / 90f, seed + 15) * 2f - 1f)
            24f + hills * 1.4f + 22f * r * r * r
        }
        4 -> 4f + hills * 0.3f + p.mesa * (38f + (valueNoise(x / 15f, z / 15f, seed + 18) - 0.5f) * 4f)
        else -> 8f + hills * 0.5f
    }

    private fun heightAt(x: Float, z: Float, p: Probe): Float {
        probe(x, z, p)
        if (realm) return rotHeight(x, z, seed, p)
        val hills = (valueNoise(x / 220f, z / 220f, seed + 11) - 0.5f) * 22f +
            (valueNoise(x / 70f, z / 70f, seed + 12) - 0.5f) * 7f +
            (valueNoise(x / 25f, z / 25f, seed + 13) - 0.5f) * 1.5f

        // Blend neighbouring regions so borders are gentle slopes, not steps.
        var dMin = 1e9f
        for (k in 0 until 5) dMin = min(dMin, p.regionDist[k])
        var h = 0f
        var wSum = 0f
        var forestW = 0f
        for (k in 0 until 5) {
            val w = 1f - ((p.regionDist[k] - dMin) / 80f)
            if (w <= 0f) continue
            h += w * zoneHeight(k, x, z, hills, p)
            wSum += w
            if (k == 1) forestW = w
        }
        h /= wSum
        forestW /= wSum

        // Water.
        val rw = 1f - smooth(4f, 16f, p.river)
        h += (-2.5f - h) * rw
        val lake = smooth(0.7f, 0.76f, valueNoise(x / 150f, z / 150f, seed + 21)) * forestW *
            smooth(6f, 14f, p.trail) * smooth(0f, 10f, p.site)
        h += (-3f - h) * lake
        val pond = 1f - smooth(6f, 24f, hypot(x - POND_X, z - POND_Z))
        h += (-3f - h) * pond
        val oasis = 1f - smooth(5f, 22f, hypot(x - OASIS_X, z - OASIS_Z))
        h += (-3f - h) * oasis

        // Level ground for towns and camps.
        if (flattenReady && p.siteIndex >= 0) {
            val pl = PLACES[p.siteIndex]
            val f = smooth(pl.radius + 20f, pl.radius + 2f, p.siteCenter)
            h += (pl.baseY - h) * f
        }

        // Shape the banks so the ground meets each end of a bridge flush with its deck.
        if (bridgesReady) {
            for (b in bridgeX.indices) {
                val dx = x - bridgeX[b]
                val dz = z - bridgeZ[b]
                val along = abs(dx * bridgeDX[b] + dz * bridgeDZ[b])
                val across = abs(-dx * bridgeDZ[b] + dz * bridgeDX[b])
                val half = bridgeHalf[b]
                if (across > 12f || along < half - 7f || along > half + 18f) continue
                val wOut = smooth(half + 18f, half + 4f, along)
                val wIn = smooth(half - 7f, half - 4f, along)
                val wSide = smooth(12f, 5f, across)
                val wgt = wOut * wIn * wSide
                if (wgt > 0f) h += (bridgeY[b] - 0.05f - h) * wgt
            }
        }

        // Keep roads dry, except at the bridges, which do the job there.
        if (!nearBridge(x, z)) {
            val tw = smooth(8f, 4f, p.trail)
            if (tw > 0f && h < 1.2f) h += (1.2f - h) * tw
        }

        if (p.mountain > 0f) {
            val crag = 1f - abs(valueNoise(x / 35f, z / 35f, seed + 41) * 2f - 1f)
            h += p.mountain.pow(1.3f) * (40f + 60f * valueNoise(x / 60f, z / 60f, seed + 40)) +
                25f * p.mountain * crag
        }
        return h
    }

    // ---------- Things standing on the ground ----------

    /**
     * Whether cell (i, j) has something standing in it, and if so what. Always gives
     * the same answer for the same cell, so drawing and bumping into things agree.
     */
    fun objectAt(i: Int, j: Int, out: Placed, p: Probe, ignoreCut: Boolean = false): Boolean {
        out.kind = Kind.NONE
        if (i < 0 || j < 0 || i >= GRID || j >= GRID) return false
        if (!ignoreCut && harvested.containsKey(j * GRID + i)) return false
        var h = hash(i, j, seed + 200)
        if (h > 0.66f) return false
        val x = (i + 0.2f + 0.6f * hash(i, j, seed + 201)) * CELL
        val z = (j + 0.2f + 0.6f * hash(i, j, seed + 202)) * CELL
        if (realm && hypot(x - ROT_SPAWN_X, z - ROT_GATE_Z) < 18f) return false
        probe(x, z, p)
        if (p.mountain > 0.12f || p.trail < 5.5f || p.site < 6f || p.river < 12f) return false
        if (nearBridge(x, z)) return false
        if (realm) return realmObject(i, j, x, z, h, out)
        // Woods close in around towns and camps, leaving open ground inside.
        if (p.site < 70f && p.zone != Zone.DESERT && p.siteKind != Site.SHRINE) h *= 0.55f
        // Thick stands of trees and rocky outcrops out in the wilds: where you go for wood and stone.
        var dense = Kind.NONE
        if (denseReady && p.site > 90f && !denseBlock.contains(j * GRID + i)) {
            val r = hash(i, j, seed + 204)
            // Rock fields and thick woods cover much of the open country (more of it than before).
            val rocky = smooth(0.55f, 0.72f, valueNoise(x / 95f, z / 95f, seed + 310))
            if (rocky > 0f && r < 0.5f * rocky && !(p.zone == Zone.CAVES && p.mesa > 0.1f)) {
                dense = Kind.ROCK
            } else {
                val woods = smooth(0.5f, 0.7f, valueNoise(x / 130f, z / 130f, seed + 300))
                if (woods > 0f) {
                    dense = when (p.zone) {
                        Zone.SNOW -> if (r < 0.6f * woods) Kind.PINE else Kind.NONE
                        Zone.FOREST -> if (r < 0.28f * woods) Kind.TREE else if (r < 0.6f * woods) Kind.PINE else Kind.NONE
                        // Sunscar: scattered palm groves. The Hollow Deep: stands of dead trees.
                        Zone.DESERT -> if (r < 0.22f * woods && p.mesa < 0.1f) Kind.PALM else Kind.NONE
                        Zone.CAVES -> if (r < 0.3f * woods && p.mesa < 0.1f) Kind.DEAD else Kind.NONE
                        else -> if (r < 0.34f * woods) Kind.TREE else if (r < 0.6f * woods) Kind.PINE else Kind.NONE
                    }
                }
            }
            // Never grow new woods or rocks through something you've built.
            if (dense != Kind.NONE) {
                val near = try {
                    base?.anyNear(x, z, 1.5f) == true
                } catch (e: RuntimeException) {
                    false
                }
                if (near) dense = Kind.NONE
            }
        }
        if (h > 0.36f && dense == Kind.NONE) return false
        val y = terrainAt(x, z)
        if (y < 0.6f) return false
        val kind = if (dense != Kind.NONE) dense else when (p.zone) {
            Zone.MEADOW -> when {
                h < 0.06f -> Kind.TREE
                h < 0.07f -> Kind.PINE
                h < 0.08f -> Kind.ROCK
                h < 0.19f -> Kind.FLOWERS
                else -> Kind.NONE
            }
            Zone.FOREST -> when {
                h < 0.19f -> Kind.TREE
                h < 0.25f -> Kind.PINE
                h < 0.29f -> Kind.DEAD
                h < 0.30f -> Kind.ROCK
                h < 0.34f -> Kind.FLOWERS
                else -> Kind.NONE
            }
            Zone.DESERT -> {
                val od = hypot(x - OASIS_X, z - OASIS_Z)
                when {
                    od > 22f && od < 40f && h < 0.35f -> Kind.PALM
                    h < 0.025f -> Kind.CACTUS
                    h < 0.034f -> Kind.DEAD
                    h < 0.046f -> Kind.ROCK
                    else -> Kind.NONE
                }
            }
            Zone.SNOW -> when {
                h < 0.14f -> Kind.PINE
                h < 0.18f -> Kind.DEAD
                h < 0.20f -> Kind.ROCK
                else -> Kind.NONE
            }
            Zone.CAVES -> when {
                p.mesa > 0.1f -> Kind.NONE
                h < 0.025f -> Kind.CRYSTAL
                h < 0.06f -> Kind.DEAD
                h < 0.085f -> Kind.ROCK
                else -> Kind.NONE
            }
        }
        if (kind == Kind.NONE) return false
        val v = hash(i, j, seed + 203)
        out.kind = kind
        out.x = x
        out.z = z
        out.y = y
        out.v = v
        out.size = 0.8f + 0.5f * v
        out.radius = when (kind) {
            Kind.TREE -> 0.7f
            Kind.PINE -> 0.6f
            Kind.PALM -> 0.5f
            Kind.CACTUS -> 0.7f
            Kind.ROCK -> 1.1f
            Kind.CRYSTAL -> 0.9f
            Kind.DEAD -> 0.45f
            else -> 0f
        } * out.size
        return true
    }

    // ---------- Ground height and collision ----------

    /** Height of the drawn ground at a point: follows the exact same triangles as the mesh. */
    fun terrainAt(x: Float, z: Float): Float {
        val gx = (x / CELL).coerceIn(0f, GRID - 0.001f)
        val gz = (z / CELL).coerceIn(0f, GRID - 0.001f)
        val i = gx.toInt()
        val j = gz.toInt()
        val fx = gx - i
        val fz = gz - j
        val h00 = heights[j * n + i]
        val h10 = heights[j * n + i + 1]
        val h01 = heights[(j + 1) * n + i]
        val h11 = heights[(j + 1) * n + i + 1]
        return if (fx > fz) {
            h00 + (h10 - h00) * fx + (h11 - h10) * fz
        } else {
            h00 + (h11 - h01) * fx + (h01 - h00) * fz
        }
    }

    fun height(i: Int, j: Int): Float =
        heights[j.coerceIn(0, GRID) * n + i.coerceIn(0, GRID)]

    /**
     * What your feet stand on: the ground, a bridge deck, or a floor or stair inside
     * a building. [feet] is where your feet are now, so you only step up onto things
     * that are low enough, and can walk underneath upper floors.
     */
    fun groundAt(x: Float, z: Float, feet: Float = 1e6f): Float {
        val t = terrainAt(x, z)
        val b = bridgeAt(x, z)
        var best = if (b != null) max(t, b) else t
        for (st in structures) {
            val dx = x - st.cx
            val dz = z - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (w in st.walks) {
                val h = w.heightAt(x, z)
                if (h.isNaN()) continue
                // Upper floors only once you've climbed to them; a bottom floor always holds you up.
                if ((w.ground || h <= feet + 0.65f) && h > best) best = h
            }
        }
        val bs = base
        if (bs != null) best = bs.ground(x, z, feet, best)
        return best
    }

    /**
     * What you're standing on, for footsteps and rain: 0 = open ground,
     * 1 = a floor in a house, 2 = a floor in a castle, 3 = a bridge deck.
     */
    fun floorUnder(x: Float, z: Float, feet: Float): Int {
        // Something you built: 1 under a roof, 5 an open wooden deck, 6 an open stone foundation.
        val built = base?.under(x, z, feet) ?: 0
        if (built != 0) return built
        val t = terrainAt(x, z)
        val b = bridgeAt(x, z)
        if (b != null && b > t - 0.1f && abs(feet - b) < 0.35f) return 3
        for (st in structures) {
            val dx = x - st.cx
            val dz = z - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (w in st.walks) {
                val h = w.heightAt(x, z)
                if (h.isNaN() || abs(feet - h) > 0.35f) continue
                for (pl in PLACES) {
                    if (pl.kind == Site.CASTLE && abs(pl.x - st.cx) < 60f && abs(pl.z - st.cz) < 60f) return 2
                }
                return 1
            }
        }
        return 0
    }

    fun isBlocked(x: Float, z: Float, p: Probe): Boolean {
        if (x < 3f || z < 3f || x > WORLD_SIZE - 3f || z > WORLD_SIZE - 3f) return true
        if (realm) return rotEdge(x, z) < 6f || terrainAt(x, z) < -1.0f
        probe(x, z, p)
        // Mountains can be climbed, all but the very crest of the great ring round the edge of the world.
        val edge = min(min(x, z), min(WORLD_SIZE - x, WORLD_SIZE - z))
        if (p.mountain > 0.5f && edge < 32f) return true
        if (p.zone == Zone.CAVES && p.mesa > 0.5f) return true
        if (terrainAt(x, z) < -1.0f && !onBridge(x, z)) return true
        return false
    }

    /** True if a body of [radius] at (x, z) would bump into a tree, rock, wall, etc. */
    fun hitsObstacle(x: Float, z: Float, radius: Float, tmp: Placed, p: Probe, feet: Float = 0f): Boolean {
        if (base?.hits(x, z, radius, feet) == true) return true
        for (st in structures) {
            val dx = x - st.cx
            val dz = z - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (so in st.solids) if (so.hits(x, z, radius, feet)) return true
        }
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        for (j in cj - 1..cj + 1) {
            for (i in ci - 1..ci + 1) {
                if (!objectAt(i, j, tmp, p)) continue
                if (tmp.radius <= 0f) continue
                val rr = radius + tmp.radius
                val dx = x - tmp.x
                val dz = z - tmp.z
                if (dx * dx + dz * dz < rr * rr) return true
            }
        }
        for (lm in landmarks) {
            if (lm.radius <= 0f) continue
            val rr = radius + lm.radius
            val dx = x - lm.x
            val dz = z - lm.z
            if (dx * dx + dz * dz < rr * rr) return true
        }
        return false
    }

    /**
     * Whether a patch of [radius] round (x, z) is free to build on: no tree or rock, no standing
     * stone or wall, not inside a town building, and not in deep water or up a sheer cliff.
     */
    fun clearForBuilding(x: Float, z: Float, radius: Float, tmp: Placed, p: Probe): Boolean {
        if (isBlocked(x, z, p)) return false
        if (p.mountain > 0.35f) return false
        for (st in structures) {
            val dx = x - st.cx
            val dz = z - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (so in st.solids) if (so.hits(x, z, radius, so.y0)) return false
            for (w in st.walks) if (!w.heightAt(x, z).isNaN()) return false
        }
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        for (j in cj - 1..cj + 1) {
            for (i in ci - 1..ci + 1) {
                if (!objectAt(i, j, tmp, p)) continue
                if (tmp.radius <= 0f) continue
                val rr = radius + tmp.radius
                val dx = x - tmp.x
                val dz = z - tmp.z
                if (dx * dx + dz * dz < rr * rr) return false
            }
        }
        for (lm in landmarks) {
            if (lm.radius <= 0f) continue
            val rr = radius + lm.radius
            val dx = x - lm.x
            val dz = z - lm.z
            if (dx * dx + dz * dz < rr * rr) return false
        }
        if (nearBridge(x, z)) return false
        return true
    }

    // ---------- Maps ----------

    private fun paintMap(p: Probe) {
        val tmp = Placed()
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val x = (i + 0.5f) * CELL
                val z = (j + 0.5f) * CELL
                probe(x, z, p)
                regionMap[j * GRID + i] = p.zone.ordinal.toByte()
                val y = terrainAt(x, z)
                var c = if (y < 0f) {
                    mixRgb(0x5AAFC8, 0x2A5E8A, (-y / 3f).coerceIn(0f, 1f))
                } else {
                    val slope = abs(height(i + 1, j) - height(i, j)) + abs(height(i, j + 1) - height(i, j))
                    groundColor(p, x, z, y, if (slope > 6f) 0.6f else 0.95f)
                }
                val shade = (1f + (height(i + 1, j + 1) - height(i, j)) * 0.04f).coerceIn(0.7f, 1.25f)
                c = shadeRgb(c, shade)
                if (objectAt(i, j, tmp, p)) {
                    c = when (tmp.kind) {
                        Kind.TREE, Kind.PINE, Kind.PALM -> 0x2F5A2A
                        Kind.DEAD -> 0x5A4A3A
                        Kind.CACTUS -> 0x4E8A4A
                        Kind.CRYSTAL -> 0xB482FF
                        Kind.ROCK -> shadeRgb(c, 0.8f)
                        else -> c
                    }
                }
                mapColors[j * GRID + i] = c or (0xFF shl 24)
            }
        }
        // Roads, drawn over the top.
        for (s in segX0.indices) {
            val len = hypot(segX1[s] - segX0[s], segZ1[s] - segZ0[s])
            val steps = (len / 3f).toInt() + 1
            for (k in 0..steps) {
                val t = k.toFloat() / steps
                val ci = ((segX0[s] + (segX1[s] - segX0[s]) * t) / CELL).toInt()
                val cj = ((segZ0[s] + (segZ1[s] - segZ0[s]) * t) / CELL).toInt()
                if (ci in 0 until GRID && cj in 0 until GRID) mapColors[cj * GRID + ci] = 0xFF6E5A40.toInt()
            }
        }
    }

    companion object {
        const val BRIDGE_MIN = 1.3f
        const val BRIDGE_HALF_LEN = 22f
    }
}

/**
 * The ground colour at a spot. [flatness] is how level the ground is, 1 = flat,
 * lower = steep, which shows bare rock.
 */
fun groundColor(p: Probe, x: Float, z: Float, y: Float, flatness: Float): Int {
    val tint = valueNoise(x / 60f, z / 60f, 30)
    if (p.mountain > 0.3f || flatness < 0.72f) {
        val rock = when (p.zone) {
            Zone.DESERT -> mixRgb(0xA87A52, 0xC08E60, tint)
            Zone.CAVES -> mixRgb(0x4A4058, 0x5A4E66, tint)
            Zone.FOREST -> mixRgb(0x6E7A64, 0x80806E, tint)
            else -> mixRgb(0x807C76, 0x96918A, tint)
        }
        val snowLine = when (p.zone) {
            Zone.SNOW -> 34f
            Zone.DESERT -> 999f
            else -> 72f
        }
        return if (y > snowLine + (tint - 0.5f) * 10f) 0xEEF2F6 else rock
    }
    if (p.zone == Zone.CAVES && p.mesa > 0.4f) return mixRgb(0x4A4058, 0x5A4E66, tint)
    // Paved squares in towns and at shrines, trampled dirt round camps and ruins.
    if (p.siteCenter < 8f && (p.siteKind == Site.TOWN || p.siteKind == Site.SHRINE)) return 0x9C968A
    if (p.site < -4f && p.siteKind != Site.SHRINE && p.siteKind != Site.TOWER) {
        return if (p.siteKind == Site.RUIN) mixRgb(0x8C8474, 0x9E9484, tint) else mixRgb(0x8A7050, 0x9C8260, tint)
    }
    if (y < 0.9f) return if (y < 0f) 0x7A6A50 else 0xB8A47A
    if (p.trail < 4.5f) {
        return when (p.zone) {
            Zone.FOREST -> 0x7E6848
            Zone.DESERT -> 0xB8966A
            Zone.SNOW -> 0x9A9A96
            Zone.CAVES -> 0x7A6E74
            Zone.MEADOW -> 0x9C8460
        }
    }
    return when (p.zone) {
        Zone.MEADOW -> mixRgb(0x6FA84A, 0x93B652, tint)
        Zone.FOREST -> mixRgb(0x4A7A38, 0x5E8A3C, tint)
        Zone.DESERT -> mixRgb(0xD9B77A, 0xE8CB92, tint)
        Zone.SNOW -> mixRgb(0xE4EBF3, 0xF8FAFD, tint)
        Zone.CAVES -> mixRgb(0x6A5A6E, 0x7E6A74, tint)
    }
}

/** What the ground at a spot is made of, for its surface texture. Follows [groundColor]. */
fun groundFlag(p: Probe, x: Float, z: Float, y: Float, flatness: Float): Int {
    if (p.mountain > 0.3f || flatness < 0.72f) {
        val tint = valueNoise(x / 60f, z / 60f, 30)
        val snowLine = when (p.zone) {
            Zone.SNOW -> 34f
            Zone.DESERT -> 999f
            else -> 72f
        }
        return if (y > snowLine + (tint - 0.5f) * 10f) FLAG_SNOW else FLAG_ROCK
    }
    if (p.zone == Zone.CAVES && p.mesa > 0.4f) return FLAG_ROCK
    if (p.siteCenter < 8f && (p.siteKind == Site.TOWN || p.siteKind == Site.SHRINE)) return FLAG_STONE
    if (p.site < -4f && p.siteKind != Site.SHRINE && p.siteKind != Site.TOWER) {
        return if (p.siteKind == Site.RUIN) FLAG_STONE else FLAG_DIRT
    }
    if (y < 0.9f) return FLAG_SAND
    if (p.trail < 4.5f) return FLAG_DIRT
    return when (p.zone) {
        Zone.MEADOW, Zone.FOREST -> FLAG_GRASS
        Zone.DESERT -> FLAG_SAND
        Zone.SNOW -> FLAG_SNOW
        Zone.CAVES -> FLAG_DIRT
    }
}

internal fun smooth(e0: Float, e1: Float, x: Float): Float {
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun segDist(px: Float, pz: Float, ax: Float, az: Float, bx: Float, bz: Float): Float {
    val dx = bx - ax
    val dz = bz - az
    val t = (((px - ax) * dx + (pz - az) * dz) / (dx * dx + dz * dz)).coerceIn(0f, 1f)
    return hypot(px - (ax + dx * t), pz - (az + dz * t))
}

internal fun mixRgb(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    val ar = (a shr 16) and 255
    val ag = (a shr 8) and 255
    val ab = a and 255
    val r = ar + (((b shr 16) and 255) - ar) * k
    val g = ag + (((b shr 8) and 255) - ag) * k
    val bl = ab + ((b and 255) - ab) * k
    return (r.toInt() shl 16) or (g.toInt() shl 8) or bl.toInt()
}

internal fun shadeRgb(c: Int, f: Float): Int {
    val r = (((c shr 16) and 255) * f).toInt().coerceIn(0, 255)
    val g = (((c shr 8) and 255) * f).toInt().coerceIn(0, 255)
    val b = ((c and 255) * f).toInt().coerceIn(0, 255)
    return (r shl 16) or (g shl 8) or b
}

internal fun hash(x: Int, y: Int, seed: Int): Float {
    var h = x * 374761393 + y * 668265263 + seed * 1442695041
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    return (h and 0x7fffffff).toFloat() / 2147483647f
}

internal fun valueNoise(x: Float, y: Float, seed: Int): Float {
    val xf = kotlin.math.floor(x)
    val yf = kotlin.math.floor(y)
    val x0 = xf.toInt()
    val y0 = yf.toInt()
    val fx = x - xf
    val fy = y - yf
    val sx = fx * fx * (3f - 2f * fx)
    val sy = fy * fy * (3f - 2f * fy)
    val a = hash(x0, y0, seed)
    val b = hash(x0 + 1, y0, seed)
    val c = hash(x0, y0 + 1, seed)
    val d = hash(x0 + 1, y0 + 1, seed)
    val top = a + (b - a) * sx
    val bottom = c + (d - c) * sx
    return top + (bottom - top) * sy
}
