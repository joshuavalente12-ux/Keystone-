package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin

/** Tile types. Plain ints keep the map small and fast. */
object T {
    const val GRASS = 0
    const val FLOWERS = 1
    const val TREE = 2
    const val WATER = 3
    const val SAND = 4
    const val CACTUS = 5
    const val SNOW = 6
    const val PINE = 7
    const val CAVE_FLOOR = 8
    const val CAVE_WALL = 9
    const val MOUNTAIN = 10
    const val PATH = 11
    const val GATE = 12
    const val FOREST_FLOOR = 13
    const val BOULDER = 14
    const val ICE = 15
    const val CRYSTAL = 16
}

enum class Zone(val title: String, val subtitle: String) {
    MEADOW("Greenhollow Meadow", "Where every journey begins"),
    FOREST("Whisperwood", "The trees are watching"),
    DESERT("Sunscar Dunes", "Sand, sun and old bones"),
    SNOW("Frostpeak", "Cold enough to crack stone"),
    CAVES("The Hollow Deep", "Light fades, crystals glow"),
}

/**
 * One big seamless map. The meadow sits in the middle, ringed by mountains.
 * Four gates in the ring lead to four zones, split from each other by ridges:
 * forest to the north, desert east, snow south, caves west.
 * Later the gates become locked doors that need keys.
 */
class World(val size: Int = 128, seed: Int = 1337) {
    val tiles = IntArray(size * size)
    private val zones = IntArray(size * size)

    val spawnX = size / 2f + 0.5f
    val spawnY = size / 2f + 0.5f

    init {
        val c = size / 2f
        for (y in 0 until size) {
            for (x in 0 until size) {
                val i = y * size + x
                val dx = x + 0.5f - c
                val dy = y + 0.5f - c
                val r = hypot(dx, dy)
                val a = atan2(dy, dx)
                val meadowR = 17f + 1.6f * sin(3f * a) + 1.1f * sin(5f * a + 1.3f)
                val ringOuter = meadowR + 2.2f
                val n = fbm(x.toFloat(), y.toFloat(), seed)
                val h = hash(x, y, seed + 31)

                val zone = when {
                    r < ringOuter -> Zone.MEADOW
                    abs(dy) >= abs(dx) && dy < 0f -> Zone.FOREST
                    abs(dx) > abs(dy) && dx > 0f -> Zone.DESERT
                    abs(dy) >= abs(dx) -> Zone.SNOW
                    else -> Zone.CAVES
                }
                zones[i] = zone.ordinal

                tiles[i] = when {
                    x < 2 || y < 2 || x >= size - 2 || y >= size - 2 -> T.MOUNTAIN
                    r >= meadowR && r < ringOuter ->
                        if (abs(dx) < 1f || abs(dy) < 1f) T.GATE else T.MOUNTAIN
                    r < meadowR -> meadowTile(dx, dy, r, n, h)
                    abs(abs(dx) - abs(dy)) < 1.3f -> T.MOUNTAIN
                    onZonePath(zone, dx, dy, r) -> T.PATH
                    else -> zoneTile(zone, n, h)
                }
            }
        }
    }

    private fun meadowTile(dx: Float, dy: Float, r: Float, n: Float, h: Float): Int = when {
        r < 2.6f -> T.PATH
        abs(dx) < 1f || abs(dy) < 1f -> T.PATH
        hypot(dx + 8f, dy - 6f) < 3.2f -> T.WATER
        r > 7f && n > 0.64f -> T.TREE
        r > 5f && h > 0.965f -> T.TREE
        h > 0.86f -> T.FLOWERS
        else -> T.GRASS
    }

    /** A winding trail leading out from each gate so every zone has a clear way in. */
    private fun onZonePath(zone: Zone, dx: Float, dy: Float, r: Float): Boolean {
        if (r > 56f) return false
        return when (zone) {
            Zone.FOREST, Zone.SNOW -> abs(dx - 3f * sin(dy / 6f)) < 1.1f
            Zone.DESERT, Zone.CAVES -> abs(dy - 3f * sin(dx / 6f)) < 1.1f
            Zone.MEADOW -> false
        }
    }

    private fun zoneTile(zone: Zone, n: Float, h: Float): Int = when (zone) {
        Zone.FOREST -> when {
            n < 0.30f -> T.WATER
            n > 0.58f || h > 0.90f -> T.TREE
            h > 0.84f -> T.FLOWERS
            else -> T.FOREST_FLOOR
        }
        Zone.DESERT -> when {
            n > 0.66f -> T.BOULDER
            n < 0.27f -> T.WATER
            h > 0.94f -> T.CACTUS
            else -> T.SAND
        }
        Zone.SNOW -> when {
            n > 0.62f || h > 0.93f -> T.PINE
            n < 0.34f -> T.ICE
            else -> T.SNOW
        }
        Zone.CAVES -> when {
            n > 0.60f -> T.CAVE_WALL
            h > 0.965f -> T.CRYSTAL
            else -> T.CAVE_FLOOR
        }
        Zone.MEADOW -> T.GRASS
    }

    fun tile(x: Int, y: Int): Int =
        if (x < 0 || y < 0 || x >= size || y >= size) T.MOUNTAIN else tiles[y * size + x]

    fun zoneIndex(x: Int, y: Int): Int =
        if (x < 0 || y < 0 || x >= size || y >= size) 0 else zones[y * size + x]

    fun zoneAt(x: Int, y: Int): Zone = Zone.entries[zoneIndex(x, y)]

    fun isSolid(x: Int, y: Int): Boolean = when (tile(x, y)) {
        T.TREE, T.WATER, T.CACTUS, T.PINE, T.CAVE_WALL, T.MOUNTAIN, T.BOULDER -> true
        else -> false
    }

    /** A stable 0..1 value per tile, used for small visual differences. */
    fun variation(x: Int, y: Int): Float = hash(x, y, 99)
}

internal fun hash(x: Int, y: Int, seed: Int): Float {
    var h = x * 374761393 + y * 668265263 + seed * 1442695041
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    return (h and 0x7fffffff).toFloat() / 2147483647f
}

private fun valueNoise(x: Float, y: Float, seed: Int): Float {
    val xf = floor(x)
    val yf = floor(y)
    val x0 = xf.toInt()
    val y0 = yf.toInt()
    val fx = x - xf
    val fy = y - yf
    val sx = fx * fx * (3f - 2f * fx)
    val sy = fy * fy * (3f - 2f * fy)
    val a = hash(x0, y0, seed)
    val b = hash(x0 + 1, y0, seed)
    val c = hash(x0, y0 + 1, seed)
    val d = hash(x0 + 1, y0 + 1, seed)
    val top = a + (b - a) * sx
    val bottom = c + (d - c) * sx
    return top + (bottom - top) * sy
}

private fun fbm(x: Float, y: Float, seed: Int): Float =
    0.6f * valueNoise(x / 8f, y / 8f, seed) + 0.4f * valueNoise(x / 3.5f, y / 3.5f, seed + 7)
