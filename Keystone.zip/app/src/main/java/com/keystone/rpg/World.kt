package com.keystone.rpg

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

enum class Zone(val title: String, val subtitle: String) {
    MEADOW("Greenhollow Meadow", "Where every journey begins"),
    FOREST("Whisperwood", "The trees are watching"),
    DESERT("Sunscar Dunes", "Sand, sun and old bones"),
    SNOW("Frostpeak", "Cold enough to crack stone"),
    CAVES("The Hollow Deep", "Light fades, crystals glow"),
}

/** Metres per terrain cell. */
const val CELL = 6f

/** Cells along each side. 485 x 6 m = 2.91 km a side, about 8.47 square km. */
const val GRID = 485

const val WORLD_SIZE = GRID * CELL

/** How far from the corner each zone's stone circle stands. */
const val SHRINE_R = 1700f

/** Where you start: tucked into the top-left corner of the map. */
const val START_X = 120f
const val START_Z = 120f

/** Height of the bridge deck you walk on. */
const val BRIDGE_Y = 1.3f

private const val PI_HALF = 1.5707964f
private const val WEDGE = 0.3926991f // 22.5 degrees

private const val POND_X = 310f
private const val POND_Z = 160f
private const val OASIS_X = 263f
private const val OASIS_Z = 861f

/** The zones fan out from the corner in four slices, starting along the top edge. */
private val WEDGE_ZONE = arrayOf(Zone.SNOW, Zone.FOREST, Zone.CAVES, Zone.DESERT)

/** Kinds of things that stand on the ground. */
object Kind {
    const val NONE = 0
    const val PINE = 1
    const val TREE = 2
    const val PALM = 3
    const val CACTUS = 4
    const val ROCK = 5
    const val CRYSTAL = 6
    const val FLOWERS = 7
    const val STONE = 8
    const val PILLAR = 9
    const val SHRINE = 10
    const val BRIDGE = 11
}

/** Everything the map knows about one spot. Reused so we don't make garbage. */
class Probe {
    var r = 0f
    var a = 0f
    var aw = 0f
    var ringR = 0f
    var wedge = 0
    var zone = Zone.MEADOW
    var mountain = 0f
    var trail = 999f
    var shrine = 999f
    var mesa = 0f
    var frozen = 0f
    var river = 999f
}

/** One thing standing on the map. Reused so we don't make garbage. */
class Placed {
    var kind = Kind.NONE
    var x = 0f
    var z = 0f
    var y = 0f
    var size = 1f
    var v = 0f
    var radius = 0f
}

/** A hand-placed feature: standing stones, gate pillars, shrines, the bridge. */
class Landmark(val kind: Int, val x: Float, val z: Float, val angle: Float, val radius: Float)

/**
 * The whole world, 2.9 km across. You start in the top-left corner in a meadow ringed
 * by mountains. Four gates lead out to four zones fanning away from the corner:
 * Frostpeak along the top, Whisperwood, The Hollow Deep canyon lands, and the
 * Sunscar Dunes down the left side. Each zone has a trail ending in a stone circle
 * with a keyhole shrine, where keys will go later.
 */
class World(private val seed: Int = 1337) {
    private val n = GRID + 1
    val heights = FloatArray(n * n)

    private val gateAngle = FloatArray(4) { (it + 0.5f) * WEDGE }
    private val gateR = FloatArray(4)
    private val gateX = FloatArray(4)
    private val gateZ = FloatArray(4)
    private val shrineX = FloatArray(4)
    private val shrineZ = FloatArray(4)

    var bridgeX = 0f
        private set
    var bridgeZ = 0f
        private set
    var bridgeDirX = 1f
        private set
    var bridgeDirZ = 0f
        private set

    val landmarks = ArrayList<Landmark>()

    val spawnX = START_X
    val spawnZ = START_Z
    /** You start facing down the trail towards the Whisperwood gate. */
    var spawnYaw = 0f
        private set

    /** Colour of every cell for the minimap. */
    val mapColors = IntArray(GRID * GRID)

    init {
        for (k in 0 until 4) {
            gateR[k] = ringRadius(gateAngle[k]) + 22f
            gateX[k] = gateR[k] * cos(gateAngle[k])
            gateZ[k] = gateR[k] * sin(gateAngle[k])
            val sa = gateAngle[k] + trailOffset(k, SHRINE_R) / SHRINE_R
            shrineX[k] = SHRINE_R * cos(sa)
            shrineZ[k] = SHRINE_R * sin(sa)
        }
        spawnYaw = atan2(gateX[1] - START_X, gateZ[1] - START_Z)
        findBridge()
        buildLandmarks()
        val p = Probe()
        for (j in 0 until n) {
            for (i in 0 until n) {
                heights[j * n + i] = heightAt(i * CELL, j * CELL, p)
            }
        }
        paintMap(p)
    }

    // ---------- Layout ----------

    private fun ringRadius(a: Float): Float = 430f + 18f * sin(a * 9f + 1f) + 10f * sin(a * 23f)

    private fun riverRadius(a: Float): Float = 1080f + 60f * sin(a * 14f)

    /** How far the winding trail in slice [k] swings sideways, [r] metres from the corner. */
    private fun trailOffset(k: Int, r: Float): Float {
        val t = r - gateR[k]
        return 25f * sin(t / 90f + k) * (t / 60f).coerceIn(0f, 1f) -
            25f * sin(k.toFloat()) * (t / 60f).coerceIn(0f, 1f)
    }

    private fun findBridge() {
        var best = 1e9f
        var bestR = 1000f
        var r = 850f
        while (r < 1350f) {
            val ang = gateAngle[1] + trailOffset(1, r) / r
            val d = abs(r - riverRadius(ang))
            if (d < best) {
                best = d
                bestR = r
            }
            r += 1f
        }
        val a0 = gateAngle[1] + trailOffset(1, bestR - 4f) / (bestR - 4f)
        val a1 = gateAngle[1] + trailOffset(1, bestR + 4f) / (bestR + 4f)
        val x0 = (bestR - 4f) * cos(a0)
        val z0 = (bestR - 4f) * sin(a0)
        val x1 = (bestR + 4f) * cos(a1)
        val z1 = (bestR + 4f) * sin(a1)
        val len = hypot(x1 - x0, z1 - z0)
        bridgeDirX = (x1 - x0) / len
        bridgeDirZ = (z1 - z0) / len
        val ab = gateAngle[1] + trailOffset(1, bestR) / bestR
        bridgeX = bestR * cos(ab)
        bridgeZ = bestR * sin(ab)
    }

    private fun buildLandmarks() {
        // A ring of old stones around where you start, with gaps facing the gates.
        for (deg in floatArrayOf(45f, 150f, 195f, 240f, 285f, 330f)) {
            val ang = deg * 0.017453292f
            landmarks.add(Landmark(Kind.STONE, START_X + 14f * cos(ang), START_Z + 14f * sin(ang), ang, 0.9f))
        }
        for (k in 0 until 4) {
            // Two tall pillars mark each gate.
            val lx = -sin(gateAngle[k])
            val lz = cos(gateAngle[k])
            landmarks.add(Landmark(Kind.PILLAR, gateX[k] + lx * 11f, gateZ[k] + lz * 11f, gateAngle[k], 1.4f))
            landmarks.add(Landmark(Kind.PILLAR, gateX[k] - lx * 11f, gateZ[k] - lz * 11f, gateAngle[k], 1.4f))
            // The shrine and its circle of stones, gaps lined up with the trail.
            landmarks.add(Landmark(Kind.SHRINE, shrineX[k], shrineZ[k], 0f, 3.2f))
            val toward = atan2(-shrineZ[k], -shrineX[k])
            for (s in 0 until 8) {
                val ang = toward + (22.5f + 45f * s) * 0.017453292f
                landmarks.add(
                    Landmark(Kind.STONE, shrineX[k] + 12f * cos(ang), shrineZ[k] + 12f * sin(ang), ang, 0.9f),
                )
            }
        }
        landmarks.add(Landmark(Kind.BRIDGE, bridgeX, bridgeZ, atan2(bridgeDirZ, bridgeDirX), 0f))
    }

    fun nearBridge(x: Float, z: Float): Boolean = hypot(x - bridgeX, z - bridgeZ) < 24f

    fun onBridge(x: Float, z: Float): Boolean {
        val dx = x - bridgeX
        val dz = z - bridgeZ
        val along = dx * bridgeDirX + dz * bridgeDirZ
        val across = -dx * bridgeDirZ + dz * bridgeDirX
        return abs(along) < 18f && abs(across) < 2.6f
    }

    // ---------- What is at a spot ----------

    fun probe(x: Float, z: Float, p: Probe) {
        val r = sqrt(x * x + z * z)
        val a = atan2(z, x).coerceIn(0f, PI_HALF)
        val ringR = ringRadius(a)
        val aw = (a + (valueNoise(x / 140f, z / 140f, seed + 5) - 0.5f) * 0.07f)
            .coerceIn(0f, PI_HALF - 0.0001f)
        val wedge = (aw / WEDGE).toInt().coerceIn(0, 3)
        val inMeadow = r < ringR + 22f
        p.r = r
        p.a = a
        p.aw = aw
        p.ringR = ringR
        p.wedge = wedge
        p.zone = if (inMeadow) Zone.MEADOW else WEDGE_ZONE[wedge]

        // Mountains ringing the meadow, with a gap at each gate.
        var mRing = ((34f - abs(r - (ringR + 22f))) / 14f).coerceIn(0f, 1f)
        if (mRing > 0f) {
            var gateLat = 999f
            for (k in 0 until 4) gateLat = min(gateLat, abs(r * (a - gateAngle[k])))
            mRing *= smooth(8f, 16f, gateLat)
        }
        // Ridges between the zones.
        var mRidge = 0f
        if (r > ringR) {
            val width = 26f + 14f * valueNoise(x / 90f, z / 90f, seed + 9)
            for (b in 1..3) {
                val lat = r * abs(aw - b * WEDGE)
                mRidge = max(mRidge, ((width - lat) / 14f).coerceIn(0f, 1f))
            }
            mRidge *= smooth(ringR, ringR + 30f, r)
        }
        // Mountains all around the edge of the world.
        val edge = min(min(x, z), min(WORLD_SIZE - x, WORLD_SIZE - z))
        val mBorder = ((75f - edge + (valueNoise(x / 80f, z / 80f, seed + 3) - 0.5f) * 30f) / 28f)
            .coerceIn(0f, 1f)
        p.mountain = max(mRing, max(mRidge, mBorder))

        var trail = 999f
        if (inMeadow) {
            for (k in 0 until 4) trail = min(trail, segDist(x, z, START_X, START_Z, gateX[k], gateZ[k]))
        }
        if (r >= gateR[wedge] - 30f && r <= SHRINE_R) {
            trail = min(trail, abs(r * (a - gateAngle[wedge]) - trailOffset(wedge, r)))
        }
        p.trail = trail
        p.shrine = if (inMeadow) 999f else hypot(x - shrineX[wedge], z - shrineZ[wedge])

        val mesaN = 0.7f * valueNoise(x / 110f, z / 110f, seed + 16) +
            0.3f * valueNoise(x / 40f, z / 40f, seed + 17)
        p.mesa = smooth(0.6f, 0.65f, mesaN) * smooth(10f, 24f, trail) *
            smooth(22f, 34f, p.shrine) * smooth(ringR + 40f, ringR + 90f, r)
        p.frozen = 1f - smooth(6f, 11f, abs(r - (1250f + 50f * sin(a * 16f + 1f))))
        p.river = abs(r - riverRadius(a))
    }

    private fun zoneHeight(zone: Zone, x: Float, z: Float, hills: Float, p: Probe): Float = when (zone) {
        Zone.FOREST -> 12f + hills
        Zone.DESERT -> 12f + hills * 0.6f +
            3.5f * sin((x * 0.7f + z * 0.3f) / 38f + valueNoise(x / 120f, z / 120f, seed + 14) * 6f)
        Zone.SNOW -> {
            val ridge = 1f - abs(valueNoise(x / 90f, z / 90f, seed + 15) * 2f - 1f)
            24f + hills * 1.6f + 30f * ridge * ridge * ridge
        }
        Zone.CAVES -> 4f + hills * 0.3f +
            p.mesa * (38f + (valueNoise(x / 15f, z / 15f, seed + 18) - 0.5f) * 4f)
        Zone.MEADOW -> 8f + hills * 0.45f
    }

    private fun heightAt(x: Float, z: Float, p: Probe): Float {
        probe(x, z, p)
        val hills = (valueNoise(x / 220f, z / 220f, seed + 11) - 0.5f) * 22f +
            (valueNoise(x / 70f, z / 70f, seed + 12) - 0.5f) * 7f +
            (valueNoise(x / 25f, z / 25f, seed + 13) - 0.5f) * 1.5f

        // Blend with the neighbouring zone near a border so there are no sudden steps.
        val k = p.wedge
        var hz = zoneHeight(WEDGE_ZONE[k], x, z, hills, p)
        val frac = p.aw / WEDGE - k
        var k2 = -1
        var lat = 0f
        if (frac < 0.5f && k > 0) {
            k2 = k - 1
            lat = p.r * (p.aw - k * WEDGE)
        } else if (frac >= 0.5f && k < 3) {
            k2 = k + 1
            lat = p.r * ((k + 1) * WEDGE - p.aw)
        }
        if (k2 >= 0) {
            val t = 0.5f * (1f - (lat / 30f).coerceIn(0f, 1f))
            if (t > 0f) hz += (zoneHeight(WEDGE_ZONE[k2], x, z, hills, p) - hz) * t
        }
        val wm = smooth(p.ringR + 45f, p.ringR + 5f, p.r)
        var h = wm * (8f + hills * 0.45f) + (1f - wm) * hz

        // Water.
        when (p.zone) {
            Zone.FOREST -> {
                val rw = 1f - smooth(4f, 16f, p.river)
                h += (-2.5f - h) * rw
                val lake = smooth(0.7f, 0.76f, valueNoise(x / 150f, z / 150f, seed + 21))
                h += (-3f - h) * lake
            }
            Zone.MEADOW -> {
                val w = 1f - smooth(6f, 26f, hypot(x - POND_X, z - POND_Z))
                h += (-3f - h) * w
            }
            Zone.DESERT -> {
                val w = 1f - smooth(5f, 22f, hypot(x - OASIS_X, z - OASIS_Z))
                h += (-3f - h) * w
            }
            Zone.SNOW -> h -= p.frozen * 1.5f
            Zone.CAVES -> Unit
        }

        // Keep trails dry, except at the bridge, which does the job there.
        if (!nearBridge(x, z)) {
            val tw = smooth(8f, 4f, p.trail)
            if (tw > 0f && h < 1.2f) h += (1.2f - h) * tw
        }

        if (p.mountain > 0f) {
            val crag = 1f - abs(valueNoise(x / 35f, z / 35f, seed + 41) * 2f - 1f)
            h += p.mountain.pow(1.3f) * (40f + 60f * valueNoise(x / 60f, z / 60f, seed + 40)) +
                25f * p.mountain * crag
        }
        return h
    }

    // ---------- Things standing on the ground ----------

    /**
     * Whether cell (i, j) has something standing in it, and if so what. Always gives
     * the same answer for the same cell, so drawing and bumping into things agree.
     */
    fun objectAt(i: Int, j: Int, out: Placed, p: Probe): Boolean {
        out.kind = Kind.NONE
        if (i < 0 || j < 0 || i >= GRID || j >= GRID) return false
        val h = hash(i, j, seed + 200)
        if (h > 0.36f) return false
        val x = (i + 0.2f + 0.6f * hash(i, j, seed + 201)) * CELL
        val z = (j + 0.2f + 0.6f * hash(i, j, seed + 202)) * CELL
        probe(x, z, p)
        if (p.mountain > 0.12f || p.trail < 5.5f || p.shrine < 18f || p.frozen > 0.1f) return false
        if (hypot(x - START_X, z - START_Z) < 22f || nearBridge(x, z)) return false
        val y = terrainAt(x, z)
        if (y < 0.6f) return false
        val kind = when (p.zone) {
            Zone.MEADOW -> when {
                h < 0.035f -> Kind.TREE
                h < 0.045f -> Kind.ROCK
                h < 0.13f -> Kind.FLOWERS
                else -> Kind.NONE
            }
            Zone.FOREST -> when {
                h < 0.20f -> Kind.TREE
                h < 0.27f -> Kind.PINE
                h < 0.285f -> Kind.ROCK
                h < 0.33f -> Kind.FLOWERS
                else -> Kind.NONE
            }
            Zone.DESERT -> {
                val od = hypot(x - OASIS_X, z - OASIS_Z)
                when {
                    od > 22f && od < 40f && h < 0.35f -> Kind.PALM
                    h < 0.018f -> Kind.CACTUS
                    h < 0.03f -> Kind.ROCK
                    else -> Kind.NONE
                }
            }
            Zone.SNOW -> when {
                h < 0.13f -> Kind.PINE
                h < 0.15f -> Kind.ROCK
                else -> Kind.NONE
            }
            Zone.CAVES -> when {
                p.mesa > 0.1f -> Kind.NONE
                h < 0.025f -> Kind.CRYSTAL
                h < 0.05f -> Kind.ROCK
                else -> Kind.NONE
            }
        }
        if (kind == Kind.NONE) return false
        val v = hash(i, j, seed + 203)
        out.kind = kind
        out.x = x
        out.z = z
        out.y = y
        out.v = v
        out.size = 0.8f + 0.5f * v
        out.radius = when (kind) {
            Kind.TREE -> 0.7f
            Kind.PINE -> 0.6f
            Kind.PALM -> 0.5f
            Kind.CACTUS -> 0.7f
            Kind.ROCK -> 1.1f
            Kind.CRYSTAL -> 0.9f
            else -> 0f
        } * out.size
        return true
    }

    // ---------- Ground height and collision ----------

    /** Height of the drawn ground at a point: follows the exact same triangles as the mesh. */
    fun terrainAt(x: Float, z: Float): Float {
        val gx = (x / CELL).coerceIn(0f, GRID - 0.001f)
        val gz = (z / CELL).coerceIn(0f, GRID - 0.001f)
        val i = gx.toInt()
        val j = gz.toInt()
        val fx = gx - i
        val fz = gz - j
        val h00 = heights[j * n + i]
        val h10 = heights[j * n + i + 1]
        val h01 = heights[(j + 1) * n + i]
        val h11 = heights[(j + 1) * n + i + 1]
        return if (fx > fz) {
            h00 + (h10 - h00) * fx + (h11 - h10) * fz
        } else {
            h00 + (h11 - h01) * fx + (h01 - h00) * fz
        }
    }

    fun height(i: Int, j: Int): Float =
        heights[j.coerceIn(0, GRID) * n + i.coerceIn(0, GRID)]

    /** What your feet stand on: the ground, or the bridge deck. */
    fun groundAt(x: Float, z: Float): Float {
        val t = terrainAt(x, z)
        return if (onBridge(x, z)) max(t, BRIDGE_Y) else t
    }

    fun isBlocked(x: Float, z: Float, p: Probe): Boolean {
        if (x < 3f || z < 3f || x > WORLD_SIZE - 3f || z > WORLD_SIZE - 3f) return true
        probe(x, z, p)
        if (p.mountain > 0.5f) return true
        if (p.zone == Zone.CAVES && p.mesa > 0.5f) return true
        if (terrainAt(x, z) < -1.0f && !onBridge(x, z)) return true
        return false
    }

    /** True if a body of [radius] at (x, z) would bump into a tree, rock, stone, etc. */
    fun hitsObstacle(x: Float, z: Float, radius: Float, tmp: Placed, p: Probe): Boolean {
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        for (j in cj - 1..cj + 1) {
            for (i in ci - 1..ci + 1) {
                if (!objectAt(i, j, tmp, p)) continue
                if (tmp.radius <= 0f) continue
                val rr = radius + tmp.radius
                val dx = x - tmp.x
                val dz = z - tmp.z
                if (dx * dx + dz * dz < rr * rr) return true
            }
        }
        for (lm in landmarks) {
            if (lm.radius <= 0f) continue
            val rr = radius + lm.radius
            val dx = x - lm.x
            val dz = z - lm.z
            if (dx * dx + dz * dz < rr * rr) return true
        }
        return false
    }

    // ---------- Minimap ----------

    private fun paintMap(p: Probe) {
        val tmp = Placed()
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val x = (i + 0.5f) * CELL
                val z = (j + 0.5f) * CELL
                probe(x, z, p)
                val y = terrainAt(x, z)
                var c = if (y < 0f) {
                    mixRgb(0x5AAFC8, 0x2A5E8A, (-y / 3f).coerceIn(0f, 1f))
                } else {
                    val slope = abs(height(i + 1, j) - height(i, j)) + abs(height(i, j + 1) - height(i, j))
                    groundColor(p, x, z, y, if (slope > 6f) 0.6f else 0.95f)
                }
                // Light from the top left, like the sun in the game.
                val shade = (1f + (height(i + 1, j + 1) - height(i, j)) * 0.04f).coerceIn(0.7f, 1.25f)
                c = shadeRgb(c, shade)
                if (objectAt(i, j, tmp, p)) {
                    c = when (tmp.kind) {
                        Kind.TREE, Kind.PINE, Kind.PALM -> 0x2F5A2A
                        Kind.CACTUS -> 0x4E8A4A
                        Kind.CRYSTAL -> 0xB482FF
                        Kind.ROCK -> shadeRgb(c, 0.8f)
                        else -> c
                    }
                }
                mapColors[j * GRID + i] = c or (0xFF shl 24)
            }
        }
        for (lm in landmarks) {
            if (lm.kind != Kind.SHRINE && lm.kind != Kind.PILLAR) continue
            val ci = (lm.x / CELL).toInt()
            val cj = (lm.z / CELL).toInt()
            for (dj in -1..1) {
                for (di in -1..1) {
                    val ii = ci + di
                    val jj = cj + dj
                    if (ii in 0 until GRID && jj in 0 until GRID) mapColors[jj * GRID + ii] = 0xFFFFC940.toInt()
                }
            }
        }
    }
}

/**
 * The ground colour at a spot. [flatness] is how level the ground is, 1 = flat,
 * lower = steep, which shows bare rock.
 */
fun groundColor(p: Probe, x: Float, z: Float, y: Float, flatness: Float): Int {
    val tint = valueNoise(x / 60f, z / 60f, 30)
    if (p.mountain > 0.3f || flatness < 0.72f) {
        val rock = when (p.zone) {
            Zone.DESERT -> mixRgb(0xA87A52, 0xC08E60, tint)
            Zone.CAVES -> mixRgb(0x4A4058, 0x5A4E66, tint)
            Zone.FOREST -> mixRgb(0x6E7A64, 0x80806E, tint)
            else -> mixRgb(0x807C76, 0x96918A, tint)
        }
        val snowLine = when (p.zone) {
            Zone.SNOW -> 34f
            Zone.DESERT -> 999f
            else -> 72f
        }
        return if (y > snowLine + (tint - 0.5f) * 10f) 0xEEF2F6 else rock
    }
    if (p.zone == Zone.CAVES && p.mesa > 0.4f) return mixRgb(0x4A4058, 0x5A4E66, tint)
    if (p.shrine < 7f) return 0x9C968A
    if (y < 0.9f) return if (y < 0f) 0x7A6A50 else 0xB8A47A
    if (p.trail < 4.5f) {
        return when (p.zone) {
            Zone.FOREST -> 0x7E6444
            Zone.DESERT -> 0xC9A06A
            Zone.SNOW -> 0xB0B6C0
            Zone.CAVES -> 0x8A7A80
            Zone.MEADOW -> 0xA8875C
        }
    }
    if (p.zone == Zone.SNOW && p.frozen > 0.5f) return 0xBFE0F0
    return when (p.zone) {
        Zone.MEADOW -> mixRgb(0x6FA84A, 0x93B652, tint)
        Zone.FOREST -> mixRgb(0x4A7A38, 0x5E8A3C, tint)
        Zone.DESERT -> mixRgb(0xD9B77A, 0xE8CB92, tint)
        Zone.SNOW -> mixRgb(0xE4EBF3, 0xF8FAFD, tint)
        Zone.CAVES -> mixRgb(0x6A5A6E, 0x7E6A74, tint)
    }
}

internal fun smooth(e0: Float, e1: Float, x: Float): Float {
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun segDist(px: Float, pz: Float, ax: Float, az: Float, bx: Float, bz: Float): Float {
    val dx = bx - ax
    val dz = bz - az
    val t = (((px - ax) * dx + (pz - az) * dz) / (dx * dx + dz * dz)).coerceIn(0f, 1f)
    return hypot(px - (ax + dx * t), pz - (az + dz * t))
}

internal fun mixRgb(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    val ar = (a shr 16) and 255
    val ag = (a shr 8) and 255
    val ab = a and 255
    val r = ar + (((b shr 16) and 255) - ar) * k
    val g = ag + (((b shr 8) and 255) - ag) * k
    val bl = ab + ((b and 255) - ab) * k
    return (r.toInt() shl 16) or (g.toInt() shl 8) or bl.toInt()
}

internal fun shadeRgb(c: Int, f: Float): Int {
    val r = (((c shr 16) and 255) * f).toInt().coerceIn(0, 255)
    val g = (((c shr 8) and 255) * f).toInt().coerceIn(0, 255)
    val b = ((c and 255) * f).toInt().coerceIn(0, 255)
    return (r shl 16) or (g shl 8) or b
}

internal fun hash(x: Int, y: Int, seed: Int): Float {
    var h = x * 374761393 + y * 668265263 + seed * 1442695041
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    return (h and 0x7fffffff).toFloat() / 2147483647f
}

internal fun valueNoise(x: Float, y: Float, seed: Int): Float {
    val xf = kotlin.math.floor(x)
    val yf = kotlin.math.floor(y)
    val x0 = xf.toInt()
    val y0 = yf.toInt()
    val fx = x - xf
    val fy = y - yf
    val sx = fx * fx * (3f - 2f * fx)
    val sy = fy * fy * (3f - 2f * fy)
    val a = hash(x0, y0, seed)
    val b = hash(x0 + 1, y0, seed)
    val c = hash(x0, y0 + 1, seed)
    val d = hash(x0 + 1, y0 + 1, seed)
    val top = a + (b - a) * sx
    val bottom = c + (d - c) * sx
    return top + (bottom - top) * sy
}
