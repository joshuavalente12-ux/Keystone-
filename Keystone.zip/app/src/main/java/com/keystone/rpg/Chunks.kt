package com.keystone.rpg

import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** The world is cut into square chunks that are built and drawn separately. */
const val CHUNK_CELLS = 32
const val CHUNK_M = CHUNK_CELLS * CELL
const val CHUNKS = (GRID + CHUNK_CELLS - 1) / CHUNK_CELLS

private const val TAU = 6.2831855f

class BuiltChunk(val key: Int, val data: ByteBuffer?, val vertexCount: Int)

/**
 * Builds chunk meshes on a background thread, so walking around never stutters.
 * Finished chunks wait in [done] until the drawing thread uploads them.
 */
class ChunkBuilder(private val world: World) {
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "chunk-builder").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY - 1
        }
    }
    private val pending: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    val done = ConcurrentLinkedQueue<BuiltChunk>()

    // Only ever touched by the builder thread.
    private val p = Probe()
    private val placed = Placed()

    fun request(key: Int) {
        if (!pending.add(key)) return
        executor.execute {
            val chunk = try {
                build(key)
            } catch (t: Throwable) {
                BuiltChunk(key, null, 0)
            }
            done.add(chunk)
        }
    }

    /** Called once a chunk is on the graphics card (or thrown away). */
    fun uploaded(key: Int) {
        pending.remove(key)
    }

    fun isPending(key: Int): Boolean = pending.contains(key)

    private fun build(key: Int): BuiltChunk {
        val cx = key % CHUNKS
        val cz = key / CHUNKS
        val i0 = cx * CHUNK_CELLS
        val j0 = cz * CHUNK_CELLS
        val i1 = min(i0 + CHUNK_CELLS, GRID)
        val j1 = min(j0 + CHUNK_CELLS, GRID)
        val m = MeshBuilder(16384)
        terrain(m, i0, j0, i1, j1)
        for (j in j0 until j1) {
            for (i in i0 until i1) {
                if (world.objectAt(i, j, placed, p)) {
                    val zone = p.zone
                    addShadow(m, placed)
                    addObject(m, placed, zone)
                } else {
                    addGrass(m, i, j)
                }
            }
        }
        for (lm in world.landmarks) {
            val li = (lm.x / CELL).toInt()
            val lj = (lm.z / CELL).toInt()
            if (li in i0 until i1 && lj in j0 until j1) addLandmark(m, lm)
        }
        return BuiltChunk(key, m.finish(), m.vertexCount)
    }

    /**
     * The ground for a chunk. Every corner gets its own colour and its own sunlight
     * from the slope around it, so hills look smooth and ground types blend softly.
     */
    private fun terrain(m: MeshBuilder, i0: Int, j0: Int, i1: Int, j1: Int) {
        val w = i1 - i0 + 1
        val h = j1 - j0 + 1
        val col = IntArray(w * h)
        for (vj in 0 until h) {
            for (vi in 0 until w) {
                val i = i0 + vi
                val j = j0 + vj
                val x = i * CELL
                val z = j * CELL
                val y = world.height(i, j)
                val dhx = (world.height(i + 1, j) - world.height(i - 1, j)) / (2f * CELL)
                val dhz = (world.height(i, j + 1) - world.height(i, j - 1)) / (2f * CELL)
                val len = sqrt(dhx * dhx + 1f + dhz * dhz)
                val nx = -dhx / len
                val ny = 1f / len
                val nz = -dhz / len
                world.probe(x, z, p)
                val base = shadeRgb(groundColor(p, x, z, y, ny), 0.95f + 0.1f * hash(i, j, 5))
                val sun = max(0f, nx * SUN_X + ny * SUN_Y + nz * SUN_Z)
                col[vj * w + vi] = shadeRgb(base, 0.46f + 0.62f * sun + 0.05f * ny)
            }
        }
        for (j in j0 until j1) {
            for (i in i0 until i1) {
                val vi = i - i0
                val vj = j - j0
                val x0 = i * CELL
                val z0 = j * CELL
                val x1 = x0 + CELL
                val z1 = z0 + CELL
                val h00 = world.height(i, j)
                val h10 = world.height(i + 1, j)
                val h01 = world.height(i, j + 1)
                val h11 = world.height(i + 1, j + 1)
                val c00 = col[vj * w + vi]
                val c10 = col[vj * w + vi + 1]
                val c01 = col[(vj + 1) * w + vi]
                val c11 = col[(vj + 1) * w + vi + 1]
                m.rawTri(x0, h00, z0, c00, x1, h10, z0, c10, x1, h11, z1, c11, FLAG_TERRAIN)
                m.rawTri(x0, h00, z0, c00, x1, h11, z1, c11, x0, h01, z1, c01, FLAG_TERRAIN)

                val low = min(min(h00, h10), min(h01, h11))
                if (low < 0f) {
                    val deep = (-low / 3f).coerceIn(0f, 1f)
                    val water = mixRgb(0x4AA8C0, 0x1E4E78, deep)
                    val mx = x0 + CELL * 0.5f
                    val mz = z0 + CELL * 0.5f
                    m.quad(x0, 0f, z0, x1, 0f, z0, x1, 0f, z1, x0, 0f, z1, water, FLAG_WATER, mx, -1000f, mz)
                }
            }
        }
    }

    /** A few blades of grass in a cell, where the ground is grassy. */
    private fun addGrass(m: MeshBuilder, i: Int, j: Int) {
        val g = hash(i, j, 900)
        if (g > 0.75f) return
        val x = (i + 0.15f + 0.7f * hash(i, j, 901)) * CELL
        val z = (j + 0.15f + 0.7f * hash(i, j, 902)) * CELL
        world.probe(x, z, p)
        val chance = when (p.zone) {
            Zone.MEADOW -> 0.75f
            Zone.FOREST -> 0.6f
            Zone.CAVES -> 0.12f
            Zone.DESERT -> 0.08f
            Zone.SNOW -> 0f
        }
        if (g > chance) return
        if (p.mountain > 0.15f || p.trail < 4.5f || p.site < 3f || p.mesa > 0.2f || p.river < 10f) return
        val y = world.terrainAt(x, z)
        if (y < 0.8f) return
        val (base, tip) = when (p.zone) {
            Zone.DESERT -> 0x8C7A4A to 0xC8B07A
            Zone.CAVES -> 0x4E4458 to 0x7A6A80
            Zone.FOREST -> 0x2E5424 to 0x6A9A40
            else -> 0x3E6A2A to 0x8CBA52
        }
        val count = 3 + (hash(i, j, 903) * 3f).toInt()
        for (k in 0 until count) {
            val bx = x + (hash(k, i * 31 + j, 904) - 0.5f) * 1.6f
            val bz = z + (hash(k, i * 31 + j, 905) - 0.5f) * 1.6f
            val a = hash(k, i * 31 + j, 906) * TAU
            val height = 0.45f + 0.5f * hash(k, i * 31 + j, 907)
            m.blade(bx, world.terrainAt(bx, bz) - 0.05f, bz, height, cos(a), sin(a), base, tip)
        }
    }

    /** A soft dark patch on the ground where a tree or rock blocks the sun. */
    private fun addShadow(m: MeshBuilder, o: Placed) {
        val r = when (o.kind) {
            Kind.TREE -> 2.6f * o.size
            Kind.PINE -> 2.0f * o.size * (1f + o.v * 0.4f)
            Kind.PALM -> 2.2f * o.size
            Kind.CACTUS -> 1.0f * o.size
            else -> return
        }
        val cx = o.x + 0.55f * r
        val cz = o.z + 0.45f * r
        world.probe(cx, cz, p)
        val cy = world.terrainAt(cx, cz)
        val dark = shadeRgb(groundColor(p, cx, cz, cy, 1f), 0.58f)
        val sides = 8
        for (k in 0 until sides) {
            val a0 = k * TAU / sides
            val a1 = (k + 1) * TAU / sides
            val x0 = cx + cos(a0) * r
            val z0 = cz + sin(a0) * r * 0.85f
            val x1 = cx + cos(a1) * r
            val z1 = cz + sin(a1) * r * 0.85f
            m.rawTri(
                cx, cy + 0.07f, cz, dark,
                x0, world.terrainAt(x0, z0) + 0.07f, z0, dark,
                x1, world.terrainAt(x1, z1) + 0.07f, z1, dark,
                FLAG_TERRAIN,
            )
        }
    }

    private fun addObject(m: MeshBuilder, o: Placed, zone: Zone) {
        val x = o.x
        val z = o.z
        val y = o.y
        val s = o.size
        val v = o.v
        val seed = (x * 7f + z * 13f).toInt()
        when (o.kind) {
            Kind.PINE -> {
                val t = s * (1f + v * 0.4f)
                val snowy = zone == Zone.SNOW
                val green = if (snowy) 0x2E5A4A else if (v > 0.5f) 0x2E5A3C else 0x36664A
                m.prism(x, y - 0.2f, z, 0.28f * t, 0.2f * t, 1.8f * t, 5, 0x5E4028, v * 6f, false)
                m.cone(x, y + 1.0f * t, z, 2.4f * t, 2.8f * t, 7, shadeRgb(green, 0.9f), v * 5f)
                m.cone(x, y + 2.2f * t, z, 1.95f * t, 2.6f * t, 7, green, v * 5f + 0.45f)
                m.cone(x, y + 3.4f * t, z, 1.45f * t, 2.4f * t, 7, shadeRgb(green, 1.07f), v * 5f + 0.9f)
                m.cone(
                    x, y + 4.6f * t, z, 0.95f * t, 2.1f * t, 7,
                    if (snowy) 0xEEF3F8 else shadeRgb(green, 1.14f), v * 5f + 1.35f,
                )
            }
            Kind.TREE -> {
                val col = if (zone == Zone.FOREST) {
                    when {
                        v > 0.88f -> 0xC8742A
                        v > 0.45f -> 0x3E7034
                        else -> 0x557A2E
                    }
                } else {
                    if (v > 0.6f) 0x6A9A3A else 0x5A8E3C
                }
                m.prism(x, y - 0.2f, z, 0.38f * s, 0.28f * s, 3.0f * s, 5, 0x6A4A30, v * 6f, false)
                m.blob(x, y + 3.7f * s, z, 2.4f * s, 1.9f * s, 2.4f * s, shadeRgb(col, 0.92f), seed, 0.22f)
                m.blob(
                    x + 0.9f * s, y + 4.7f * s, z - 0.6f * s, 1.7f * s, 1.5f * s, 1.7f * s,
                    col, seed + 1, 0.2f,
                )
                if (v > 0.4f) {
                    m.blob(
                        x - 0.8f * s, y + 5.1f * s, z + 0.5f * s, 1.3f * s, 1.2f * s, 1.3f * s,
                        shadeRgb(col, 1.12f), seed + 2, 0.2f,
                    )
                }
            }
            Kind.PALM -> {
                val lean = v * TAU
                val lx = cos(lean) * 0.35f * s
                val lz = sin(lean) * 0.35f * s
                var bx = x
                var by = y - 0.2f
                var bz = z
                for (k in 0 until 3) {
                    m.prism(bx, by, bz, 0.3f * s, 0.26f * s, 2.3f * s, 4, 0x8A6A44, 0f, false)
                    bx += lx
                    by += 2.2f * s
                    bz += lz
                }
                for (k in 0 until 7) {
                    val f = k * TAU / 7f + v * 3f
                    val c = cos(f)
                    val sn = sin(f)
                    val tipX = bx + c * 3.4f * s
                    val tipY = by - 1.4f * s
                    val tipZ = bz + sn * 3.4f * s
                    val midX = bx + c * 1.8f * s
                    val midY = by + 0.4f * s
                    val midZ = bz + sn * 1.8f * s
                    val sx = -sn * 0.7f * s
                    val sz = c * 0.7f * s
                    m.tri(bx, by, bz, midX + sx, midY, midZ + sz, tipX, tipY, tipZ, 0x4E8E3A, FLAG_SOLID, bx, by - 3f, bz)
                    m.tri(bx, by, bz, tipX, tipY, tipZ, midX - sx, midY, midZ - sz, 0x5A9A42, FLAG_SOLID, bx, by - 3f, bz)
                }
            }
            Kind.CACTUS -> {
                val col = 0x5E9A5A
                m.prism(x, y - 0.2f, z, 0.5f * s, 0.45f * s, 3.8f * s, 6, col, v, false)
                m.cone(x, y + 3.6f * s, z, 0.45f * s, 0.5f * s, 6, col, v)
                m.box(x + 0.6f * s, y + 1.6f * s, z, 0.4f * s, 0.22f * s, 0.22f * s, 0f, col)
                m.prism(x + 0.95f * s, y + 1.4f * s, z, 0.28f * s, 0.25f * s, 1.6f * s, 5, col, 0f, true)
                m.box(x, y + 2.2f * s, z - 0.6f * s, 0.22f * s, 0.22f * s, 0.4f * s, 0f, col)
                m.prism(x, y + 2.0f * s, z - 0.95f * s, 0.28f * s, 0.25f * s, 1.3f * s, 5, col, 0f, true)
            }
            Kind.ROCK -> {
                val col = when (zone) {
                    Zone.DESERT -> 0xB08A62
                    Zone.CAVES -> 0x5A4E66
                    Zone.SNOW -> 0x8A8C92
                    Zone.FOREST -> 0x7A806E
                    Zone.MEADOW -> 0x8C8A84
                }
                m.blob(x, y + 0.3f * s, z, 1.3f * s, 0.9f * s, 1.1f * s, col, seed, 0.3f)
                if (v > 0.5f) {
                    m.blob(x + 1.3f * s, y + 0.05f * s, z + 0.6f * s, 0.6f * s, 0.45f * s, 0.55f * s, shadeRgb(col, 0.9f), seed + 3, 0.3f)
                }
            }
            Kind.CRYSTAL -> {
                m.spike(x, y - 0.2f, z, 0.35f * s, 2.6f * s, 0.05f, -0.08f, 0xB482FF, FLAG_GLOW)
                m.spike(x + 0.6f * s, y - 0.2f, z + 0.3f * s, 0.25f * s, 1.7f * s, 0.25f, 0.1f, 0xC8A0FF, FLAG_GLOW)
                m.spike(x - 0.5f * s, y - 0.2f, z + 0.4f * s, 0.22f * s, 1.4f * s, -0.25f, 0.15f, 0x9A6CF0, FLAG_GLOW)
            }
            Kind.FLOWERS -> {
                for (k in 0 until 5) {
                    val fx = x + (hash(k, seed, 11) - 0.5f) * 3f
                    val fz = z + (hash(k, seed, 12) - 0.5f) * 3f
                    val fy = world.terrainAt(fx, fz)
                    val col = FLOWER_COLORS[(hash(k, seed, 13) * 4f).toInt().coerceIn(0, 3)]
                    m.tri(fx - 0.14f, fy, fz, fx + 0.14f, fy, fz, fx, fy + 0.4f, fz, col, FLAG_GLOW, fx, fy - 5f, fz)
                    m.tri(fx, fy, fz - 0.14f, fx, fy, fz + 0.14f, fx, fy + 0.4f, fz, col, FLAG_GLOW, fx, fy - 5f, fz)
                }
            }
            else -> Unit
        }
    }

    private fun addLandmark(m: MeshBuilder, lm: Landmark) {
        val x = lm.x
        val z = lm.z
        val y = world.terrainAt(x, z)
        val v = lm.v
        when (lm.kind) {
            Kind.STONE -> m.prism(x, y - 0.5f, z, 0.75f, 0.5f, 4.4f, 4, 0x8E8C86, lm.angle, true)
            Kind.PILLAR -> {
                val h = 2f + 3.5f * lm.size
                m.prism(x, y - 0.3f, z, 0.55f, 0.5f, h, 6, 0xA49E92, lm.angle, true)
                m.box(x, y + 0.2f, z, 0.8f, 0.5f, 0.8f, lm.angle, 0x8C877D)
            }
            Kind.WALL -> {
                val h = 1.2f + 3f * lm.size
                val col = mixRgb(0x8A847A, 0xA09A8E, v)
                m.box(x, y + h * 0.5f - 0.4f, z, 1.9f, h * 0.5f + 0.4f, 0.35f, lm.angle, col)
                if (v > 0.5f) m.blob(x + 1.2f, y + 0.2f, z + 1.0f, 0.7f, 0.4f, 0.6f, col, (x * 3f).toInt(), 0.3f)
            }
            Kind.HOUSE -> addHouse(m, x, y, z, lm.angle, lm.size, v)
            Kind.WELL -> {
                m.prism(x, y - 0.3f, z, 1.1f, 1.1f, 1.2f, 8, 0x8C877D, 0f, false)
                m.prism(x, y + 0.8f, z, 0.85f, 0.85f, 0.05f, 8, 0x2A4A6A, 0f, true)
                m.box(x + 0.95f, y + 1.3f, z, 0.1f, 1.3f, 0.1f, 0f, 0x5A3E22)
                m.box(x - 0.95f, y + 1.3f, z, 0.1f, 1.3f, 0.1f, 0f, 0x5A3E22)
                m.cone(x, y + 2.5f, z, 1.6f, 1.0f, 4, 0x7A3A2A, 0.785f)
            }
            Kind.TOWER -> {
                m.box(x, y + 5.5f, z, 2f, 6.2f, 2f, lm.angle, 0x7E7A72)
                m.box(x, y + 11.9f, z, 2.9f, 0.25f, 2.9f, lm.angle, 0x6A4A30)
                for (k in 0 until 4) {
                    val a = lm.angle + 0.785f + k * 1.5708f
                    m.box(x + cos(a) * 3.4f, y + 13.2f, z + sin(a) * 3.4f, 0.12f, 1.2f, 0.12f, 0f, 0x5A3E22)
                }
                m.cone(x, y + 14.3f, z, 3.6f, 3f, 4, 0x7A3A2A, lm.angle + 0.785f)
                // Door.
                val dx = cos(lm.angle)
                val dz = sin(lm.angle)
                m.box(x + dx * 2.02f, y + 1.1f, z + dz * 2.02f, 0.06f, 1.1f, 0.6f, lm.angle, 0x2A1E16)
            }
            Kind.VAULT -> {
                // A great rock with a round steel door facing the road.
                m.blob(x, y + 1.5f, z, 10f, 7f, 10f, 0x7A7670, (x + z).toInt(), 0.18f)
                val dx = cos(lm.angle)
                val dz = sin(lm.angle)
                val face = lm.angle + 1.5708f
                val cx = x + dx * 8.8f
                val cz = z + dz * 8.8f
                m.box(cx, y + 2.6f, cz, 2.6f, 2.6f, 0.6f, face, 0x5E646C)
                m.box(cx + dx * 0.35f, y + 2.6f, cz + dz * 0.35f, 2.0f, 2.0f, 0.4f, face, 0xC9A227)
                m.box(cx + dx * 0.6f, y + 2.6f, cz + dz * 0.6f, 0.5f, 0.5f, 0.3f, face, 0x3A3A3A)
                m.box(cx + dx * 1.5f, y + 0.05f, cz + dz * 1.5f, 2.2f, 0.1f, 1.5f, face, 0x6E6E6E)
            }
            Kind.TENT -> {
                val col = when {
                    v < 0.33f -> 0xA0703C
                    v < 0.66f -> 0x8A5A3A
                    else -> 0x6E7A4A
                }
                m.cone(x, y - 0.1f, z, 1.9f, 2.5f, 4, col, lm.angle)
                m.box(x, y + 2.45f, z, 0.05f, 0.25f, 0.05f, 0f, 0x5A3E22)
            }
            Kind.FIRE -> {
                for (k in 0 until 7) {
                    val a = k * TAU / 7f
                    m.blob(x + cos(a) * 0.8f, y + 0.1f, z + sin(a) * 0.8f, 0.25f, 0.18f, 0.25f, 0x6E6A64, k + 5, 0.2f)
                }
                m.box(x, y + 0.1f, z, 0.5f, 0.08f, 0.08f, 0.6f, 0x4A3222)
                m.box(x, y + 0.1f, z, 0.5f, 0.08f, 0.08f, -0.6f, 0x4A3222)
                m.cone(x, y + 0.1f, z, 0.5f, 1.1f, 5, 0xFF7A20, 0f, FLAG_GLOW)
                m.cone(x, y + 0.1f, z, 0.28f, 1.5f, 5, 0xFFD050, 0.6f, FLAG_GLOW)
            }
            Kind.SHRINE -> {
                val top = y + 0.6f
                m.prism(x, y - 1f, z, 3.2f, 3.0f, 1.6f, 8, 0x9C968A, 0f, true)
                // Gold ring.
                for (k in 0 until 8) {
                    val a0 = k * TAU / 8f
                    val a1 = (k + 1) * TAU / 8f
                    m.quad(
                        x + cos(a0) * 1.9f, top + 0.03f, z + sin(a0) * 1.9f,
                        x + cos(a1) * 1.9f, top + 0.03f, z + sin(a1) * 1.9f,
                        x + cos(a1) * 2.4f, top + 0.03f, z + sin(a1) * 2.4f,
                        x + cos(a0) * 2.4f, top + 0.03f, z + sin(a0) * 2.4f,
                        0xFFC940, FLAG_GLOW, x, top - 5f, z,
                    )
                }
                // Keyhole.
                for (k in 0 until 6) {
                    val a0 = k * TAU / 6f
                    val a1 = (k + 1) * TAU / 6f
                    m.tri(
                        x, top + 0.05f, z - 0.25f,
                        x + cos(a0) * 0.45f, top + 0.05f, z - 0.25f + sin(a0) * 0.45f,
                        x + cos(a1) * 0.45f, top + 0.05f, z - 0.25f + sin(a1) * 0.45f,
                        0x1A1622, FLAG_GLOW, x, top - 5f, z,
                    )
                }
                m.quad(
                    x - 0.18f, top + 0.05f, z,
                    x + 0.18f, top + 0.05f, z,
                    x + 0.32f, top + 0.05f, z + 0.9f,
                    x - 0.32f, top + 0.05f, z + 0.9f,
                    0x1A1622, FLAG_GLOW, x, top - 5f, z,
                )
                // A thin beam of light you can see from far away.
                m.prism(x, top, z, 0.35f, 0.05f, 70f, 4, 0xFFD966, 0f, false, FLAG_GLOW)
            }
            Kind.BRIDGE -> {
                val deck = lm.y
                val half = World.BRIDGE_HALF_LEN
                val dx = cos(lm.angle)
                val dz = sin(lm.angle)
                val ax = -dz
                val az = dx
                val planks = 15
                val plank = half * 2f / planks
                for (k in 0 until planks) {
                    val off = -half + plank * (k + 0.5f)
                    m.box(
                        x + dx * off, deck - 0.2f, z + dz * off, plank * 0.48f, 0.2f, 2.6f, lm.angle,
                        if (k % 2 == 0) 0x8A6238 else 0x9E7446,
                    )
                }
                for (side in intArrayOf(-1, 1)) {
                    val sx = ax * 2.5f * side
                    val sz = az * 2.5f * side
                    m.box(x + sx, deck + 0.9f, z + sz, half, 0.08f, 0.08f, lm.angle, 0x5A3E22)
                    var off = -half
                    while (off <= half + 0.1f) {
                        m.box(x + sx + dx * off, deck + 0.45f, z + sz + dz * off, 0.12f, 0.55f, 0.12f, lm.angle, 0x5A3E22)
                        off += 5.5f
                    }
                }
                val pierTop = deck - 0.4f
                for (off in floatArrayOf(-11f, 0f, 11f)) {
                    val pierH = (pierTop + 3f) * 0.5f
                    m.box(x + dx * off, pierTop - pierH, z + dz * off, 0.5f, pierH, 2.3f, lm.angle, 0x6E6A64)
                }
            }
            else -> Unit
        }
    }

    /** A little house with plaster walls, a pitched roof, a door and windows facing the square. */
    private fun addHouse(m: MeshBuilder, x: Float, y: Float, z: Float, angle: Float, size: Float, v: Float) {
        // "in" points from the house towards the middle of town; the door goes on that side.
        val inX = -cos(angle)
        val inZ = -sin(angle)
        // Long side runs across that direction.
        val face = angle + 1.5708f
        val ax = cos(face)
        val az = sin(face)
        val halfLong = 3.2f * size
        val halfDeep = 2.5f * size
        val wallH = 3.0f * size
        val wall = when {
            v < 0.33f -> 0xD8CDB4
            v < 0.66f -> 0xC2A07A
            else -> 0xB8B2A6
        }
        val roof = when {
            v < 0.25f -> 0x8A3A2A
            v < 0.5f -> 0x5A4A3A
            v < 0.75f -> 0x4E5A66
            else -> 0x7A5A2A
        }
        m.box(x, y + wallH * 0.5f - 0.3f, z, halfLong, wallH * 0.5f + 0.3f, halfDeep, face, wall)
        // Roof: two slopes meeting at a ridge, with triangle ends.
        val eave = y + wallH
        val ridge = eave + 2f * size
        val oL = halfLong + 0.35f
        val oD = halfDeep + 0.5f
        val lx = ax * oL
        val lz = az * oL
        val dx = inX * oD
        val dz = inZ * oD
        m.quad(
            x - lx + dx, eave, z - lz + dz, x + lx + dx, eave, z + lz + dz,
            x + lx, ridge, z + lz, x - lx, ridge, z - lz,
            roof, FLAG_SOLID, x, y, z,
        )
        m.quad(
            x - lx - dx, eave, z - lz - dz, x + lx - dx, eave, z + lz - dz,
            x + lx, ridge, z + lz, x - lx, ridge, z - lz,
            shadeRgb(roof, 0.92f), FLAG_SOLID, x, y, z,
        )
        val ex = ax * halfLong
        val ez = az * halfLong
        val gx = inX * halfDeep
        val gz = inZ * halfDeep
        m.tri(x + ex + gx, eave, z + ez + gz, x + ex - gx, eave, z + ez - gz, x + ex, ridge - 0.3f, z + ez, wall, FLAG_SOLID, x, y, z)
        m.tri(x - ex + gx, eave, z - ez + gz, x - ex - gx, eave, z - ez - gz, x - ex, ridge - 0.3f, z - ez, wall, FLAG_SOLID, x, y, z)
        // Door and windows on the town side.
        val fx = x + inX * (halfDeep + 0.04f)
        val fz = z + inZ * (halfDeep + 0.04f)
        m.box(fx, y + 1.05f, fz, 0.55f, 1.05f, 0.05f, face, 0x4A3020)
        m.box(fx + ax * 1.9f * size, y + 1.8f, fz + az * 1.9f * size, 0.45f, 0.4f, 0.05f, face, 0x2E3A48)
        m.box(fx - ax * 1.9f * size, y + 1.8f, fz - az * 1.9f * size, 0.45f, 0.4f, 0.05f, face, 0x2E3A48)
        // Chimney.
        if (v > 0.4f) m.box(x + ax * halfLong * 0.55f, ridge - 0.2f, z + az * halfLong * 0.55f, 0.35f, 1f, 0.35f, face, 0x7A6E62)
    }
}

private val FLOWER_COLORS = intArrayOf(0xFFE66D, 0xFF8FA3, 0xFFFFFF, 0xB9A6FF)
