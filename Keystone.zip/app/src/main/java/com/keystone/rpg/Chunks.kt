package com.keystone.rpg

import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** The world is cut into square chunks that are built and drawn separately. */
const val CHUNK_CELLS = 32
const val CHUNK_M = CHUNK_CELLS * CELL
const val CHUNKS = (GRID + CHUNK_CELLS - 1) / CHUNK_CELLS

private const val TAU = 6.2831855f

class BuiltChunk(val key: Int, val data: ByteBuffer?, val vertexCount: Int)

/**
 * Builds chunk meshes on a background thread, so walking around never stutters.
 * Finished chunks wait in [done] until the drawing thread uploads them.
 */
class ChunkBuilder(private val world: World) {
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "chunk-builder").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY - 1
        }
    }
    private val pending: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    val done = ConcurrentLinkedQueue<BuiltChunk>()

    // Only ever touched by the builder thread.
    private val p = Probe()
    private val placed = Placed()

    fun request(key: Int) {
        if (!pending.add(key)) return
        executor.execute {
            val chunk = try {
                build(key)
            } catch (t: Throwable) {
                BuiltChunk(key, null, 0)
            }
            done.add(chunk)
        }
    }

    /** Called once a chunk is on the graphics card (or thrown away). */
    fun uploaded(key: Int) {
        pending.remove(key)
    }

    fun isPending(key: Int): Boolean = pending.contains(key)

    private fun build(key: Int): BuiltChunk {
        val cx = key % CHUNKS
        val cz = key / CHUNKS
        val i0 = cx * CHUNK_CELLS
        val j0 = cz * CHUNK_CELLS
        val i1 = min(i0 + CHUNK_CELLS, GRID)
        val j1 = min(j0 + CHUNK_CELLS, GRID)
        val m = MeshBuilder(16384)
        terrain(m, i0, j0, i1, j1)
        for (j in j0 until j1) {
            for (i in i0 until i1) {
                if (world.objectAt(i, j, placed, p)) {
                    val zone = p.zone
                    addShadow(m, placed)
                    addObject(m, placed, zone)
                } else {
                    addGrass(m, i, j)
                }
            }
        }
        for (lm in world.landmarks) {
            val li = (lm.x / CELL).toInt()
            val lj = (lm.z / CELL).toInt()
            if (li in i0 until i1 && lj in j0 until j1) addLandmark(m, lm)
        }
        for (st in world.structures) {
            val si = (st.cx / CELL).toInt()
            val sj = (st.cz / CELL).toInt()
            if (si in i0 until i1 && sj in j0 until j1) addStructure(m, st)
        }
        return BuiltChunk(key, m.finish(), m.vertexCount)
    }

    /**
     * The ground for a chunk. Every corner gets its own colour and its own sunlight
     * from the slope around it, so hills look smooth and ground types blend softly.
     * Each triangle also knows what it's made of (grass, rock, sand, snow...) so the
     * shader can give it the right texture.
     */
    private fun terrain(m: MeshBuilder, i0: Int, j0: Int, i1: Int, j1: Int) {
        val w = i1 - i0 + 1
        val h = j1 - j0 + 1
        val col = IntArray(w * h)
        val mat = IntArray(w * h)
        val nrm = FloatArray(w * h * 3)
        for (vj in 0 until h) {
            for (vi in 0 until w) {
                val i = i0 + vi
                val j = j0 + vj
                val x = i * CELL
                val z = j * CELL
                val y = world.height(i, j)
                val dhx = (world.height(i + 1, j) - world.height(i - 1, j)) / (2f * CELL)
                val dhz = (world.height(i, j + 1) - world.height(i, j - 1)) / (2f * CELL)
                val len = sqrt(dhx * dhx + 1f + dhz * dhz)
                val nx = -dhx / len
                val ny = 1f / len
                val nz = -dhz / len
                world.probe(x, z, p)
                // Plain ground colour; the sun is worked out per pixel from the normal.
                col[vj * w + vi] = shadeRgb(groundColor(p, x, z, y, ny), 0.95f + 0.1f * hash(i, j, 5))
                val ni = (vj * w + vi) * 3
                nrm[ni] = nx
                nrm[ni + 1] = ny
                nrm[ni + 2] = nz
                mat[vj * w + vi] = groundFlag(p, x, z, y, ny)
            }
        }
        for (j in j0 until j1) {
            for (i in i0 until i1) {
                val vi = i - i0
                val vj = j - j0
                val x0 = i * CELL
                val z0 = j * CELL
                val x1 = x0 + CELL
                val z1 = z0 + CELL
                val h00 = world.height(i, j)
                val h10 = world.height(i + 1, j)
                val h01 = world.height(i, j + 1)
                val h11 = world.height(i + 1, j + 1)
                val a = vj * w + vi
                val b = vj * w + vi + 1
                val c = (vj + 1) * w + vi
                val d = (vj + 1) * w + vi + 1
                m.rawTriN(x0, h00, z0, col[a], a, x1, h10, z0, col[b], b, x1, h11, z1, col[d], d, pick(mat[a], mat[b], mat[d]), nrm)
                m.rawTriN(x0, h00, z0, col[a], a, x1, h11, z1, col[d], d, x0, h01, z1, col[c], c, pick(mat[a], mat[d], mat[c]), nrm)

                val low = min(min(h00, h10), min(h01, h11))
                if (low < 0f) {
                    val deep = (-low / 3f).coerceIn(0f, 1f)
                    val water = mixRgb(0x3E9CB4, 0x163E66, deep)
                    val mx = x0 + CELL * 0.5f
                    val mz = z0 + CELL * 0.5f
                    m.quad(x0, 0f, z0, x1, 0f, z0, x1, 0f, z1, x0, 0f, z1, water, FLAG_WATER, mx, -1000f, mz)
                }
            }
        }
    }

    /** The surface most corners of a triangle agree on. */
    private fun pick(a: Int, b: Int, c: Int): Int = if (b == c) b else a

    /**
     * Small plants in a cell: grass tufts, ferns, flowers or a bush, depending on
     * the region. They don't block you.
     */
    private fun addGrass(m: MeshBuilder, i: Int, j: Int) {
        val g = hash(i, j, 900)
        if (g > 0.9f) return
        val x = (i + 0.15f + 0.7f * hash(i, j, 901)) * CELL
        val z = (j + 0.15f + 0.7f * hash(i, j, 902)) * CELL
        world.probe(x, z, p)
        val chance = when (p.zone) {
            Zone.MEADOW -> 0.9f
            Zone.FOREST -> 0.8f
            Zone.CAVES -> 0.12f
            Zone.DESERT -> 0.08f
            Zone.SNOW -> 0.04f
        }
        if (g > chance) return
        if (p.mountain > 0.15f || p.trail < 4.5f || p.site < 3f || p.mesa > 0.2f || p.river < 10f) return
        val y = world.terrainAt(x, z)
        if (y < 0.8f) return
        val roll = hash(i, j, 910)
        val seed = i * 31 + j
        when {
            // Ferns: mostly under the trees in Whisperwood, a few in the meadow.
            (p.zone == Zone.FOREST && roll < 0.35f) || (p.zone == Zone.MEADOW && roll < 0.12f) -> {
                val fronds = 6 + (hash(i, j, 911) * 4f).toInt()
                val size = 0.8f + 0.6f * hash(i, j, 912)
                for (k in 0 until fronds) {
                    val a = k * TAU / fronds + hash(k, seed, 913) * 0.5f
                    m.frond(x, y - 0.05f, z, cos(a), sin(a), 1.3f * size, 0.55f * size, 0x2C5020, 0x6FA040)
                }
            }
            // Bushes.
            (p.zone == Zone.MEADOW || p.zone == Zone.FOREST) && roll < 0.24f -> {
                val s = 0.7f + 0.6f * hash(i, j, 914)
                val c = if (p.zone == Zone.FOREST) 0x3A6A2E else 0x4E8A36
                m.blob(x, y + 0.35f * s, z, 1.1f * s, 0.75f * s, 1.0f * s, c, seed, 0.3f, FLAG_LEAF)
                m.blob(x + 0.6f * s, y + 0.3f * s, z + 0.4f * s, 0.7f * s, 0.55f * s, 0.7f * s, shadeRgb(c, 1.12f), seed + 1, 0.3f, FLAG_LEAF)
            }
            // Wildflowers among the grass.
            p.zone == Zone.MEADOW && roll < 0.46f -> addFlowers(m, x, z, seed, 7)
            p.zone == Zone.FOREST && roll < 0.24f -> addFlowers(m, x, z, seed, 3)
            else -> {
                val (base, tip) = when (p.zone) {
                    Zone.DESERT -> 0x8C7A4A to 0xC8B07A
                    Zone.CAVES -> 0x4E4458 to 0x7A6A80
                    Zone.SNOW -> 0x6A7060 to 0xB8C0B0
                    Zone.FOREST -> 0x2E5424 to 0x6A9A40
                    Zone.MEADOW -> 0x3E6A2A to 0x8CBA52
                }
                val count = 4 + (hash(i, j, 903) * 4f).toInt()
                for (k in 0 until count) {
                    val bx = x + (hash(k, seed, 904) - 0.5f) * 1.6f
                    val bz = z + (hash(k, seed, 905) - 0.5f) * 1.6f
                    val a = hash(k, seed, 906) * TAU
                    val height = 0.45f + 0.5f * hash(k, seed, 907)
                    m.blade(bx, world.terrainAt(bx, bz) - 0.05f, bz, height, cos(a), sin(a), base, tip)
                }
            }
        }
    }

    /** A little patch of flowers: stems with bright heads. */
    private fun addFlowers(m: MeshBuilder, x: Float, z: Float, seed: Int, count: Int) {
        val colour = FLOWER_COLORS[(hash(seed, 7, 13) * FLOWER_COLORS.size).toInt().coerceIn(0, FLOWER_COLORS.size - 1)]
        for (k in 0 until count) {
            val fx = x + (hash(k, seed, 11) - 0.5f) * 2.2f
            val fz = z + (hash(k, seed, 12) - 0.5f) * 2.2f
            val fy = world.terrainAt(fx, fz)
            val h = 0.35f + 0.3f * hash(k, seed, 14)
            val a = hash(k, seed, 15) * TAU
            m.blade(fx, fy - 0.03f, fz, h, cos(a) * 0.3f, sin(a) * 0.3f, 0x3A6A2A, 0x5A8A3A)
            val hx = fx + cos(a) * 0.3f * h * 0.3f
            val hz = fz + sin(a) * 0.3f * h * 0.3f
            val c = if (hash(k, seed, 16) > 0.8f) 0xFFFFFF else colour
            m.spike(hx, fy + h - 0.06f, hz, 0.09f, 0.14f, 0f, 0f, c, FLAG_SOLID)
            m.spike(hx, fy + h + 0.02f, hz, 0.05f, 0.05f, 0f, 0f, 0xFFD84A, FLAG_SOLID)
        }
    }

    /** A soft dark patch on the ground where a tree or rock blocks the sun. */
    private fun addShadow(m: MeshBuilder, o: Placed) {
        val r = when (o.kind) {
            Kind.TREE -> 2.6f * o.size
            Kind.PINE -> 2.0f * o.size * (1f + o.v * 0.4f)
            Kind.PALM -> 2.2f * o.size
            Kind.CACTUS -> 1.0f * o.size
            Kind.ROCK -> 1.3f * o.size
            Kind.DEAD -> 1.4f * o.size
            else -> return
        }
        val cx = o.x + 0.55f * r
        val cz = o.z + 0.45f * r
        world.probe(cx, cz, p)
        val cy = world.terrainAt(cx, cz)
        val dark = shadeRgb(groundColor(p, cx, cz, cy, 1f), 0.5f)
        val flag = groundFlag(p, cx, cz, cy, 1f)
        val sides = 8
        for (k in 0 until sides) {
            val a0 = k * TAU / sides
            val a1 = (k + 1) * TAU / sides
            val x0 = cx + cos(a0) * r
            val z0 = cz + sin(a0) * r * 0.85f
            val x1 = cx + cos(a1) * r
            val z1 = cz + sin(a1) * r * 0.85f
            m.rawTri(
                cx, cy + 0.07f, cz, dark,
                x0, world.terrainAt(x0, z0) + 0.07f, z0, dark,
                x1, world.terrainAt(x1, z1) + 0.07f, z1, dark,
                flag,
            )
        }
    }

    private fun addObject(m: MeshBuilder, o: Placed, zone: Zone) {
        val x = o.x
        val z = o.z
        val y = o.y
        val s = o.size
        val v = o.v
        val seed = (x * 7f + z * 13f).toInt()
        when (o.kind) {
            Kind.PINE -> {
                val t = s * (1f + v * 0.4f)
                val snowy = zone == Zone.SNOW
                val green = if (snowy) 0x2A5244 else if (v > 0.5f) 0x2A5438 else 0x325E44
                m.prism(x, y - 0.2f, z, 0.3f * t, 0.12f * t, 5.5f * t, 5, 0x5A3E28, v * 6f, false, FLAG_BARK)
                val tiers = 4
                for (k in 0 until tiers) {
                    val ty = y + (1.0f + k * 1.2f) * t
                    val r = (2.4f - k * 0.48f) * t
                    val hgt = (2.8f - k * 0.18f) * t
                    m.cone(x, ty, z, r, hgt, 7, shadeRgb(green, 0.9f + k * 0.07f), v * 5f + k * 0.45f, FLAG_LEAF)
                    if (snowy) {
                        // Snow resting on each layer of branches.
                        m.cone(x, ty + hgt * 0.38f, z, r * 0.66f, hgt * 0.64f, 7, 0xF2F6FA, v * 5f + k * 0.45f + 0.2f, FLAG_SNOW)
                    }
                }
            }
            Kind.TREE -> {
                val col = if (zone == Zone.FOREST) {
                    when {
                        v > 0.88f -> 0xC8742A
                        v > 0.45f -> 0x3E7034
                        else -> 0x557A2E
                    }
                } else {
                    if (v > 0.6f) 0x6A9A3A else 0x5A8E3C
                }
                m.prism(x, y - 0.2f, z, 0.42f * s, 0.26f * s, 3.4f * s, 6, 0x6A4A30, v * 6f, false, FLAG_BARK)
                // Branches reaching up into the crown.
                m.limb(x, y + 2.6f * s, z, x + 1.1f * s, y + 4.3f * s, z - 0.6f * s, 0.16f * s, 0.07f * s, 0x6A4A30, FLAG_BARK)
                m.limb(x, y + 2.8f * s, z, x - 1.0f * s, y + 4.6f * s, z + 0.5f * s, 0.15f * s, 0.07f * s, 0x6A4A30, FLAG_BARK)
                m.blob(x, y + 3.7f * s, z, 2.4f * s, 1.9f * s, 2.4f * s, shadeRgb(col, 0.9f), seed, 0.22f, FLAG_LEAF)
                m.blob(
                    x + 0.9f * s, y + 4.7f * s, z - 0.6f * s, 1.7f * s, 1.5f * s, 1.7f * s,
                    col, seed + 1, 0.2f, FLAG_LEAF,
                )
                m.blob(
                    x - 0.8f * s, y + 5.1f * s, z + 0.5f * s, 1.4f * s, 1.3f * s, 1.4f * s,
                    shadeRgb(col, 1.12f), seed + 2, 0.2f, FLAG_LEAF,
                )
            }
            Kind.PALM -> {
                val lean = v * TAU
                val lx = cos(lean) * 0.35f * s
                val lz = sin(lean) * 0.35f * s
                var bx = x
                var by = y - 0.2f
                var bz = z
                for (k in 0 until 3) {
                    val nx = bx + lx
                    val ny = by + 2.3f * s
                    val nz = bz + lz
                    m.limb(bx, by, bz, nx, ny, nz, 0.3f * s, 0.25f * s, 0x8A6A44, FLAG_BARK)
                    bx = nx
                    by = ny
                    bz = nz
                }
                for (k in 0 until 8) {
                    val f = k * TAU / 8f + v * 3f
                    val c = cos(f)
                    val sn = sin(f)
                    val tipX = bx + c * 3.4f * s
                    val tipY = by - 1.4f * s
                    val tipZ = bz + sn * 3.4f * s
                    val midX = bx + c * 1.8f * s
                    val midY = by + 0.4f * s
                    val midZ = bz + sn * 1.8f * s
                    val sx = -sn * 0.7f * s
                    val sz = c * 0.7f * s
                    m.tri(bx, by, bz, midX + sx, midY, midZ + sz, tipX, tipY, tipZ, 0x4E8E3A, FLAG_LEAF, bx, by - 3f, bz)
                    m.tri(bx, by, bz, tipX, tipY, tipZ, midX - sx, midY, midZ - sz, 0x5A9A42, FLAG_LEAF, bx, by - 3f, bz)
                }
                m.blob(bx - 0.2f * s, by - 0.2f * s, bz, 0.22f * s, 0.25f * s, 0.22f * s, 0x5A3A20, seed, 0.1f)
                m.blob(bx + 0.2f * s, by - 0.25f * s, bz + 0.1f * s, 0.22f * s, 0.25f * s, 0.22f * s, 0x5A3A20, seed + 1, 0.1f)
            }
            Kind.CACTUS -> {
                val col = 0x5E9A5A
                m.prism(x, y - 0.2f, z, 0.5f * s, 0.45f * s, 3.8f * s, 8, col, v, false)
                m.cone(x, y + 3.6f * s, z, 0.45f * s, 0.5f * s, 8, col, v)
                m.box(x + 0.6f * s, y + 1.6f * s, z, 0.4f * s, 0.22f * s, 0.22f * s, 0f, col)
                m.prism(x + 0.95f * s, y + 1.4f * s, z, 0.28f * s, 0.25f * s, 1.6f * s, 6, col, 0f, true)
                m.box(x, y + 2.2f * s, z - 0.6f * s, 0.22f * s, 0.22f * s, 0.4f * s, 0f, col)
                m.prism(x, y + 2.0f * s, z - 0.95f * s, 0.28f * s, 0.25f * s, 1.3f * s, 6, col, 0f, true)
            }
            Kind.ROCK -> {
                val col = when (zone) {
                    Zone.DESERT -> 0xB08A62
                    Zone.CAVES -> 0x5A4E66
                    Zone.SNOW -> 0x8A8C92
                    Zone.FOREST -> 0x7A806E
                    Zone.MEADOW -> 0x8C8A84
                }
                m.rock(x, y + 0.35f * s, z, 1.35f * s, 1.0f * s, 1.15f * s, col, seed)
                if (zone == Zone.SNOW) {
                    m.blob(x - 0.1f * s, y + 1.08f * s, z, 0.95f * s, 0.3f * s, 0.8f * s, 0xF2F6FA, seed + 7, 0.2f, FLAG_SNOW)
                }
                if (v > 0.5f) {
                    m.rock(x + 1.3f * s, y + 0.1f * s, z + 0.6f * s, 0.65f * s, 0.5f * s, 0.6f * s, shadeRgb(col, 0.9f), seed + 3)
                }
            }
            Kind.CRYSTAL -> {
                m.spike(x, y - 0.2f, z, 0.35f * s, 2.6f * s, 0.05f, -0.08f, 0xB482FF, FLAG_GLOW)
                m.spike(x + 0.6f * s, y - 0.2f, z + 0.3f * s, 0.25f * s, 1.7f * s, 0.25f, 0.1f, 0xC8A0FF, FLAG_GLOW)
                m.spike(x - 0.5f * s, y - 0.2f, z + 0.4f * s, 0.22f * s, 1.4f * s, -0.25f, 0.15f, 0x9A6CF0, FLAG_GLOW)
            }
            Kind.FLOWERS -> addFlowers(m, x, z, seed, 7)
            Kind.DEAD -> {
                // A bare, weathered tree: a leaning trunk and crooked branches.
                val col = when (zone) {
                    Zone.CAVES -> 0x2E2830
                    Zone.SNOW -> 0x6A6258
                    Zone.DESERT -> 0x8A7456
                    else -> 0x5E5040
                }
                val t = s * (1f + v * 0.5f)
                val lean = v * TAU
                val topX = x + cos(lean) * 0.7f * t
                val topZ = z + sin(lean) * 0.7f * t
                val topY = y + 5.5f * t
                m.limb(x, y - 0.3f, z, topX, topY, topZ, 0.34f * t, 0.07f * t, col, FLAG_BARK)
                val droop = if (zone == Zone.CAVES) -0.25f else 0.55f
                for (k in 0 until 5) {
                    val hf = 0.35f + k * 0.13f
                    val bx = x + (topX - x) * hf
                    val by = y + (topY - y) * hf
                    val bz = z + (topZ - z) * hf
                    val a = k * 2.4f + v * 6f
                    val len = (2.0f - k * 0.25f) * t
                    val ex = bx + cos(a) * len
                    val ey = by + len * droop
                    val ez = bz + sin(a) * len
                    m.limb(bx, by, bz, ex, ey, ez, 0.12f * t, 0.035f * t, col, FLAG_BARK)
                    val a2 = a + 0.9f
                    m.limb(ex, ey, ez, ex + cos(a2) * len * 0.45f, ey + len * 0.3f * droop + 0.2f, ez + sin(a2) * len * 0.45f, 0.035f * t, 0.015f * t, col, FLAG_BARK)
                }
                if (zone == Zone.SNOW) {
                    m.blob(x, y + 0.1f, z, 0.9f * t, 0.25f, 0.9f * t, 0xF2F6FA, seed + 5, 0.2f, FLAG_SNOW)
                }
            }
            else -> Unit
        }
    }

    private fun addLandmark(m: MeshBuilder, lm: Landmark) {
        val x = lm.x
        val z = lm.z
        val y = world.terrainAt(x, z)
        val v = lm.v
        when (lm.kind) {
            Kind.STONE -> {
                m.prism(x, y - 0.5f, z, 0.75f, 0.5f, 4.4f, 4, 0x8E8C86, lm.angle, true, FLAG_STONE)
                m.blob(x - 0.3f, y + 0.1f, z + 0.2f, 0.5f, 0.2f, 0.4f, 0x5E7A3A, (x * 5f).toInt(), 0.3f, FLAG_LEAF)
            }
            Kind.PILLAR -> {
                val h = 2f + 3.5f * lm.size
                m.prism(x, y - 0.3f, z, 0.55f, 0.5f, h, 8, 0xA49E92, lm.angle, true, FLAG_STONE)
                m.box(x, y + 0.2f, z, 0.8f, 0.5f, 0.8f, lm.angle, 0x8C877D, FLAG_STONE)
                m.box(x, y + h - 0.1f, z, 0.75f, 0.2f, 0.75f, lm.angle, 0x8C877D, FLAG_STONE)
            }
            Kind.WALL -> {
                val h = 1.2f + 3f * lm.size
                val col = mixRgb(0x8A847A, 0xA09A8E, v)
                m.box(x, y + h * 0.5f - 0.4f, z, 1.9f, h * 0.5f + 0.4f, 0.35f, lm.angle, col, FLAG_STONE)
                m.rock(x + 1.2f, y + 0.2f, z + 1.0f, 0.7f, 0.45f, 0.6f, col, (x * 3f).toInt())
                if (v > 0.5f) m.blob(x - 0.6f, y + h * 0.9f, z, 0.9f, 0.3f, 0.5f, 0x4E7034, (z * 3f).toInt(), 0.3f, FLAG_LEAF)
            }
            Kind.TOWER -> {
                m.box(x, y + 0.4f, z, 2.5f, 0.9f, 2.5f, lm.angle, 0x6E6A62, FLAG_STONE)
                m.box(x, y + 6.1f, z, 2f, 5.8f, 2f, lm.angle, 0x7E7A72, FLAG_STONE)
                m.box(x, y + 11.9f, z, 2.9f, 0.25f, 2.9f, lm.angle, 0x6A4A30, FLAG_WOOD)
                for (k in 0 until 4) {
                    val a = lm.angle + 0.785f + k * 1.5708f
                    m.box(x + cos(a) * 3.4f, y + 13.2f, z + sin(a) * 3.4f, 0.12f, 1.2f, 0.12f, 0f, 0x5A3E22, FLAG_WOOD)
                }
                m.cone(x, y + 14.3f, z, 3.6f, 3f, 4, 0x7A3A2A, lm.angle + 0.785f, FLAG_ROOF)
                val dx = cos(lm.angle)
                val dz = sin(lm.angle)
                m.box(x + dx * 2.02f, y + 1.1f, z + dz * 2.02f, 0.06f, 1.1f, 0.6f, lm.angle, 0x4A3020, FLAG_WOOD)
                m.box(x + dx * 2.02f, y + 7f, z + dz * 2.02f, 0.06f, 0.5f, 0.25f, lm.angle, 0x1E1A16)
            }
            Kind.VAULT -> {
                m.blob(x, y + 1.5f, z, 10f, 7f, 10f, 0x7A7670, (x + z).toInt(), 0.18f, FLAG_ROCK)
                val dx = cos(lm.angle)
                val dz = sin(lm.angle)
                val face = lm.angle + 1.5708f
                val cx = x + dx * 8.8f
                val cz = z + dz * 8.8f
                m.box(cx, y + 2.6f, cz, 2.6f, 2.6f, 0.6f, face, 0x5E646C)
                m.box(cx + dx * 0.35f, y + 2.6f, cz + dz * 0.35f, 2.0f, 2.0f, 0.4f, face, 0xC9A227)
                m.box(cx + dx * 0.6f, y + 2.6f, cz + dz * 0.6f, 0.5f, 0.5f, 0.3f, face, 0x3A3A3A)
                m.box(cx + dx * 1.5f, y + 0.05f, cz + dz * 1.5f, 2.2f, 0.1f, 1.5f, face, 0x6E6E6E, FLAG_STONE)
            }
            Kind.TENT -> {
                val col = when {
                    v < 0.33f -> 0xA0703C
                    v < 0.66f -> 0x8A5A3A
                    else -> 0x6E7A4A
                }
                m.cone(x, y - 0.1f, z, 1.9f, 2.5f, 4, col, lm.angle, FLAG_PLASTER)
                m.box(x, y + 2.45f, z, 0.05f, 0.25f, 0.05f, 0f, 0x5A3E22, FLAG_WOOD)
            }
            Kind.FIRE -> {
                // Ring of stones, crossed logs, glowing embers and dancing flames.
                for (k in 0 until 9) {
                    val a = k * TAU / 9f
                    m.blob(x + cos(a) * 0.9f, y + 0.1f, z + sin(a) * 0.9f, 0.28f, 0.2f, 0.25f, 0x6E6A64, k + 5, 0.25f, FLAG_STONE)
                }
                m.limb(x - 0.6f, y + 0.12f, z - 0.2f, x + 0.6f, y + 0.12f, z + 0.2f, 0.1f, 0.1f, 0x4A3222, FLAG_BARK)
                m.limb(x - 0.2f, y + 0.18f, z + 0.6f, x + 0.2f, y + 0.18f, z - 0.6f, 0.1f, 0.1f, 0x4A3222, FLAG_BARK)
                m.prism(x, y + 0.02f, z, 0.62f, 0.55f, 0.06f, 8, 0xFF5A18, 0f, true, FLAG_FIRE)
                for (k in 0 until 5) {
                    val a = k * 1.2566f
                    val ox = cos(a) * 0.18f
                    val oz = sin(a) * 0.18f
                    m.flame(x + ox, y + 0.1f, z + oz, 0.32f, 1.0f + 0.35f * (k % 3), a, 0xFF6A10, 0xFFE070)
                }
                m.flame(x, y + 0.1f, z, 0.22f, 1.7f, 0.4f, 0xFFA030, 0xFFF4B0)
            }
            Kind.SHRINE -> {
                val top = y + 0.6f
                m.prism(x, y - 1f, z, 3.2f, 3.0f, 1.6f, 12, 0x9C968A, 0f, true, FLAG_STONE)
                for (k in 0 until 16) {
                    val a0 = k * TAU / 16f
                    val a1 = (k + 1) * TAU / 16f
                    m.quad(
                        x + cos(a0) * 1.9f, top + 0.03f, z + sin(a0) * 1.9f,
                        x + cos(a1) * 1.9f, top + 0.03f, z + sin(a1) * 1.9f,
                        x + cos(a1) * 2.4f, top + 0.03f, z + sin(a1) * 2.4f,
                        x + cos(a0) * 2.4f, top + 0.03f, z + sin(a0) * 2.4f,
                        0xFFC940, FLAG_GLOW, x, top - 5f, z,
                    )
                }
                for (k in 0 until 8) {
                    val a0 = k * TAU / 8f
                    val a1 = (k + 1) * TAU / 8f
                    m.tri(
                        x, top + 0.05f, z - 0.25f,
                        x + cos(a0) * 0.45f, top + 0.05f, z - 0.25f + sin(a0) * 0.45f,
                        x + cos(a1) * 0.45f, top + 0.05f, z - 0.25f + sin(a1) * 0.45f,
                        0x1A1622, FLAG_GLOW, x, top - 5f, z,
                    )
                }
                m.quad(
                    x - 0.18f, top + 0.05f, z,
                    x + 0.18f, top + 0.05f, z,
                    x + 0.32f, top + 0.05f, z + 0.9f,
                    x - 0.32f, top + 0.05f, z + 0.9f,
                    0x1A1622, FLAG_GLOW, x, top - 5f, z,
                )
                m.prism(x, top, z, 0.35f, 0.05f, 70f, 4, 0xFFD966, 0f, false, FLAG_GLOW)
            }
            Kind.BRIDGE -> {
                val deck = lm.y
                val half = if (lm.v > 0f) lm.v else World.BRIDGE_HALF_LEN
                val dx = cos(lm.angle)
                val dz = sin(lm.angle)
                val ax = -dz
                val az = dx
                val planks = (half * 2f / 2f).toInt()
                val plank = half * 2f / planks
                for (k in 0 until planks) {
                    val off = -half + plank * (k + 0.5f)
                    m.box(
                        x + dx * off, deck - 0.2f, z + dz * off, plank * 0.46f, 0.2f, 2.6f, lm.angle,
                        if (k % 3 == 0) 0x7E5A34 else if (k % 3 == 1) 0x8A6238 else 0x9E7446, FLAG_WOOD,
                    )
                }
                for (side in intArrayOf(-1, 1)) {
                    val sx = ax * 2.5f * side
                    val sz = az * 2.5f * side
                    m.box(x + sx, deck + 0.9f, z + sz, half, 0.08f, 0.08f, lm.angle, 0x5A3E22, FLAG_WOOD)
                    var off = -half
                    while (off <= half + 0.1f) {
                        m.box(x + sx + dx * off, deck + 0.45f, z + sz + dz * off, 0.12f, 0.55f, 0.12f, lm.angle, 0x5A3E22, FLAG_WOOD)
                        off += 5.5f
                    }
                }
                val pierTop = deck - 0.4f
                val piers = ((half - 4f) / 11f).toInt()
                for (pi in -piers..piers) {
                    val off = pi * 11f
                    val pierH = (pierTop + 3f) * 0.5f
                    m.box(x + dx * off, pierTop - pierH, z + dz * off, 0.5f, pierH, 2.3f, lm.angle, 0x6E6A64, FLAG_STONE)
                }
                // Stone abutments where each end sits into the bank.
                for (sgn in intArrayOf(-1, 1)) {
                    val off = sgn * (half - 1.6f)
                    val abH = 1.8f
                    m.box(x + dx * off, deck - 0.4f - abH, z + dz * off, 1.8f, abH, 2.9f, lm.angle, 0x7A756C, FLAG_STONE)
                }
            }
            else -> Unit
        }
    }

    /** Draws every part of a building. */
    private fun addStructure(m: MeshBuilder, st: Structure) {
        for (pt in st.parts) {
            val f = pt.f
            when (pt.type) {
                PartType.BOX -> m.box(f[0], f[1], f[2], f[3], f[4], f[5], f[6], pt.rgb, pt.flag)
                PartType.PRISM -> m.prism(f[0], f[1], f[2], f[3], f[4], f[5], f[6].toInt(), pt.rgb, f[7], f[8] > 0.5f, pt.flag)
                PartType.CONE -> m.cone(f[0], f[1], f[2], f[3], f[4], f[5].toInt(), pt.rgb, f[6], pt.flag)
                PartType.BLOB -> m.blob(f[0], f[1], f[2], f[3], f[4], f[5], pt.rgb, f[6].toInt(), 0.2f, pt.flag)
                PartType.QUAD -> m.quad(
                    f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10], f[11],
                    pt.rgb, pt.flag, f[12], f[13], f[14],
                )
                PartType.FLAME -> {
                    m.flame(f[0], f[1], f[2], f[3], f[4], f[5], 0xFF6A10, 0xFFE070)
                }
                PartType.LIMB -> m.limb(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], pt.rgb, pt.flag)
            }
        }
    }
}

private val FLOWER_COLORS = intArrayOf(0xFFE66D, 0xFF8FA3, 0xE85A8A, 0xB9A6FF, 0xFF9A40, 0x8AB4FF)
