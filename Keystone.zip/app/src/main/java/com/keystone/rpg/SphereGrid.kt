package com.keystone.rpg

import androidx.compose.ui.graphics.Color
import kotlin.math.abs

/** What a node on the grid gives you. Ordinary nodes cost 1 point, the big perks cost 3. */
enum class GridKind(val title: String, val tag: String, val info: String, val cost: Int, val color: Color) {
    START("Keystone", "KEY", "Where every path begins.", 0, Color(0xFFFFC940)),
    POWER("Strength", "STR", "+1 Power. Your hits do about 2.5% more damage.", 1, Color(0xFFE0574B)),
    DEFENSE("Defense", "DEF", "+2 Defense. Monsters hurt you less.", 1, Color(0xFF4B8FE0)),
    VITALITY("Vitality", "HP", "+10 maximum health.", 1, Color(0xFF58C46A)),
    SPEED("Swiftness", "SPD", "+2% movement and sprint speed.", 1, Color(0xFFE0C24B)),
    CRIT("Deadly Aim", "CRT", "+3% chance for a hit to land double damage.", 3, Color(0xFFFF7A3D)),
    BULWARK("Bulwark", "BLW", "+6 Defense.", 3, Color(0xFF7A6BE0)),
    REGEN("Second Wind", "RGN", "+2 health regained every second.", 3, Color(0xFF3DD6B0)),
    SCHOLAR("Scholar", "XP", "+4% experience from everything you defeat.", 3, Color(0xFFE05CC8)),
    MANA("Insight", "MP", "+8 maximum MP to fuel your staff.", 1, Color(0xFF6B8EE0)),
    LEAP("Double Jump", "JMP", "A second jump, in mid-air.", 3, Color(0xFF54E0C4)),
}

class GridNode(val id: Int, val col: Int, val row: Int, val kind: GridKind)

/** Everything the grid adds up to. */
class GridBonus(
    val power: Int,
    val defense: Int,
    val vitality: Int,
    val speed: Int,
    val crit: Int,
    val regen: Int,
    val xpPct: Int,
    val mana: Int,
    val doubleJump: Boolean,
)

/**
 * The board. It is the same for everybody: the same nodes in the same places every time.
 * You start at the Keystone in the middle and can only unlock a node that touches one you
 * already have. Once a node is unlocked it is yours for good.
 *
 * The four corners lean towards Strength (top left), Swiftness (top right), Defense
 * (bottom left) and Vitality (bottom right), with the big perks scattered through them.
 */
object SphereGrid {
    const val COLS = 17
    const val ROWS = 13
    const val CENTER_COL = 8
    const val CENTER_ROW = 6
    const val HOME = CENTER_ROW * COLS + CENTER_COL

    /**
     * Each class gets its own board: the same size and shape, but leaning towards different
     * stats, and with its own signature nodes scattered through more often than usual. Boards
     * are built once and cached. [heroClass] -1 (an old save, from before classes) gets the
     * original, even mix.
     */
    private val cache = HashMap<Int, List<GridNode>>()
    fun of(heroClass: Int): List<GridNode> = cache.getOrPut(heroClass) { build(heroClass) }
    /** The original, class-less board — kept for old saves and anywhere a class isn't known yet. */
    val nodes: List<GridNode> get() = of(-1)

    private fun build(heroClass: Int): List<GridNode> {
        val out = ArrayList<GridNode>(COLS * ROWS)
        // Same order as the corner numbers below: 0 Strength, 1 Defense, 2 Vitality, 3 Swiftness.
        val basics = listOf(GridKind.POWER, GridKind.DEFENSE, GridKind.VITALITY, GridKind.SPEED)
        val specials = listOf(GridKind.CRIT, GridKind.BULWARK, GridKind.REGEN, GridKind.SCHOLAR)
        // A Warrior trains broadly — Strength, Swiftness, Defense and Vitality all alike — so
        // he gets the plain, even corner spread with no lean of his own. An Archer's board
        // leans on Swiftness and Deadly Aim; a Mage's on Scholar and Second Wind (a caster
        // lives on sustain and xp, not raw toughness). An old, class-less save sees no bias.
        val signatureBasic = when (heroClass) {
            HeroClass.ARCHER -> GridKind.SPEED
            HeroClass.MAGE -> GridKind.SCHOLAR
            else -> null
        }
        val signatureSpecial = when (heroClass) {
            HeroClass.ARCHER -> GridKind.CRIT
            HeroClass.MAGE -> GridKind.REGEN
            else -> null
        }
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                val dx = c - CENTER_COL
                val dy = r - CENTER_ROW
                val corner = when {
                    dx < 0 && dy < 0 -> 0
                    dx >= 0 && dy < 0 -> 3
                    dx < 0 -> 1
                    else -> 2
                }
                val h = ((c * 73856093) xor (r * 19349663)) and 0x7fffffff
                val kind = when {
                    dx == 0 && dy == 0 -> GridKind.START
                    // The four nodes touching the Keystone: your first choice.
                    dx == 0 && dy == -1 -> GridKind.POWER
                    dx == 1 && dy == 0 -> GridKind.SPEED
                    dx == 0 && dy == 1 -> GridKind.VITALITY
                    dx == -1 && dy == 0 -> GridKind.DEFENSE
                    // An Archer always has exactly one Double Jump node to work towards, a
                    // few steps out along his home row.
                    heroClass == HeroClass.ARCHER && dx == 5 && dy == 0 -> GridKind.LEAP
                    // The class's own signature nodes turn up noticeably more than the rest.
                    abs(dx) + abs(dy) >= 2 && signatureSpecial != null && h % 7 == 0 -> signatureSpecial
                    // A Mage's MP grows alongside his Scholar and Second Wind lean, not instead of it.
                    heroClass == HeroClass.MAGE && abs(dx) + abs(dy) >= 2 && h % 9 == 0 -> GridKind.MANA
                    abs(dx) + abs(dy) >= 3 && h % 11 == 0 -> specials[corner]
                    signatureBasic != null && (h / 5) % 100 < 22 -> signatureBasic
                    (h / 7) % 100 < 18 -> basics[(h / 13) % 4]
                    else -> basics[corner]
                }
                out.add(GridNode(r * COLS + c, c, r, kind))
            }
        }
        return out
    }

    /** The nodes touching this one: left, right, above and below. */
    fun neighbors(id: Int): List<Int> {
        val c = id % COLS
        val r = id / COLS
        val out = ArrayList<Int>(4)
        if (c > 0) out.add(id - 1)
        if (c < COLS - 1) out.add(id + 1)
        if (r > 0) out.add(id - COLS)
        if (r < ROWS - 1) out.add(id + COLS)
        return out
    }

    /** True if [id] is not yet yours but touches the Keystone or a node that is. */
    fun reachable(id: Int, unlocked: Set<Int>): Boolean {
        if (id == HOME || id in unlocked) return false
        if (id < 0 || id >= COLS * ROWS) return false
        for (n in neighbors(id)) {
            if (n == HOME || n in unlocked) return true
        }
        return false
    }

    fun bonuses(unlocked: Set<Int>, heroClass: Int): GridBonus {
        var power = 0
        var defense = 0
        var vitality = 0
        var speed = 0
        var crit = 0
        var regen = 0
        var xp = 0
        var mana = 0
        var leap = false
        val board = of(heroClass)
        for (id in unlocked) {
            if (id < 0 || id >= board.size) continue
            when (board[id].kind) {
                GridKind.POWER -> power += 1
                GridKind.DEFENSE -> defense += 2
                GridKind.VITALITY -> vitality += 10
                GridKind.SPEED -> speed += 2
                GridKind.CRIT -> crit += 3
                GridKind.BULWARK -> defense += 6
                GridKind.REGEN -> regen += 2
                GridKind.SCHOLAR -> xp += 4
                GridKind.MANA -> mana += 8
                GridKind.LEAP -> leap = true
                GridKind.START -> {}
            }
        }
        return GridBonus(power, defense, vitality, speed, crit, regen, xp, mana, leap)
    }
}
