package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** One spoken line in a story scene. [speaker] is empty for narration. */
class StoryLine(val speaker: String, val text: String)

/** The story people in the world. */
object StoryRole {
    const val NONE = 0
    const val WIZARD = 1
    const val ELDER = 2
}

/** Where you are in the main story. Every step waits for something YOU do; nothing plays on a timer. */
object StoryStep {
    /** Woke up in Greenhollow: the wizard waits. */
    const val ARRIVED = 0
    /** Free to roam: ask villagers, then find the Elder. */
    const val ASK_AROUND = 1
    /** Spoke with the Elder: go back to the wizard. */
    const val FOUND_ELDER = 2
    /** Sent after Gorvak the Moss King. */
    const val HUNT_GORVAK = 3
    /** Gorvak is down and the memory has returned: tell the wizard. */
    const val RETURN_WIZARD = 4
    /** Chapter One is finished. */
    const val CH1_DONE = 5
}

/**
 * The main story (PROLONG). Holds which step you're on and plays short scripted scenes (a line at a time)
 * at the moments you trigger them. Between scenes you're back in the game, free to explore and fight.
 */
class Story(
    private val toast: (String) -> Unit,
    private val startMainQuest: () -> Unit,
    private val giveNecklace: () -> Unit,
    private val gorvakBeaten: () -> Boolean,
) {
    @Volatile var step = StoryStep.ARRIVED
        private set
    /** How many different Greenhollow villagers you've asked. */
    @Volatile var asked = 0
        private set
    private val askedIds = HashSet<Int>()
    private var ctx: Context? = null

    /** Changes whenever the scene or the step changes, so the screen redraws. */
    var version by mutableIntStateOf(0)
        private set
    @Volatile var scene: List<StoryLine>? = null
        private set
    @Volatile var sceneIdx = 0
        private set
    private var onEnd: (() -> Unit)? = null
    /** True while a scene is on screen (you can't move or be hurt). */
    val active: Boolean get() = scene != null

    /** Counts down to the flashback once Gorvak falls (negative = none pending). */
    private var flashDelay = -1f
    /** The cinematic just ended: play the wake-up scene as soon as the game is running. */
    @Volatile private var pendingWake = false

    /** What you call yourself: "You" until the flashback gives you your name. */
    private val me: String get() = if (step >= StoryStep.RETURN_WIZARD) "Josh" else "You"

    /** One line saying what to do next, shown on screen. */
    val objective: String get() = when (step) {
        StoryStep.ARRIVED -> "Speak with the wizard"
        StoryStep.ASK_AROUND ->
            if (asked < NEED_ASKED) "Ask the villagers if they know you ($asked/$NEED_ASKED)" else "Find the Elder by the notice board"
        StoryStep.FOUND_ELDER -> "Return to the wizard"
        StoryStep.HUNT_GORVAK -> "Defeat Gorvak the Moss King, east of Greenhollow"
        StoryStep.RETURN_WIZARD -> "Return to the wizard"
        else -> ""
    }

    // ---------- Saving ----------

    fun load(c: Context, gorvakDown: Boolean) {
        ctx = c.applicationContext
        scene = null
        onEnd = null
        sceneIdx = 0
        flashDelay = -1f
        askedIds.clear()
        val s = c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("story", null)
        if (s == null) {
            // A save from before the story existed: if Gorvak is already down, you only owe the wizard a visit.
            step = if (gorvakDown) StoryStep.RETURN_WIZARD else StoryStep.ARRIVED
        } else {
            val f = s.split('|')
            step = (f.getOrNull(0)?.toIntOrNull() ?: 0).coerceIn(0, StoryStep.CH1_DONE)
            for (t in (f.getOrNull(1) ?: "").split(',')) t.toIntOrNull()?.let { askedIds.add(it) }
        }
        asked = askedIds.size
        version++
    }

    private fun save() {
        if (SaveLock.blocked) return
        val c = ctx ?: return
        val s = "$step|" + askedIds.joinToString(",")
        c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().putString("story", s).apply()
    }

    private fun setStep(s: Int) {
        step = s
        save()
        version++
    }

    // ---------- Triggers (each one is something the player does) ----------

    /** The intro cinematic has ended. The wake-up scene plays once the game is running. */
    fun onIntroEnd() {
        pendingWake = true
    }

    /** Gorvak (or any boss) has just fallen. The flashback follows a few seconds later, only if the wizard sent you for him. */
    fun onBossKilled(boss: Int) {
        if (boss == 0 && step == StoryStep.HUNT_GORVAK) flashDelay = 3.5f
    }

    /** Called every game tick. */
    fun update(dt: Float) {
        if (pendingWake && !active) {
            pendingWake = false
            if (step == StoryStep.ARRIVED) wizardTalk()
        }
        if (flashDelay >= 0f && !active) {
            flashDelay -= dt
            if (flashDelay < 0f) {
                flashDelay = -1f
                play(sceneFlashback()) {
                    setStep(StoryStep.RETURN_WIZARD)
                    toast("A memory returns. Tell the wizard what you saw.")
                }
            }
        }
    }

    /**
     * You pressed TALK on [n]. True if a story scene took over; false means they talk the ordinary way
     * (a villager chatting, the Elder's quest, and so on).
     */
    fun talk(n: Npc): Boolean {
        if (active) return true
        return when {
            n.storyRole == StoryRole.WIZARD -> {
                wizardTalk()
                true
            }
            n.storyRole == StoryRole.ELDER -> elderTalk()
            n.role == NpcRole.VILLAGER && n.place == 0 && step == StoryStep.ASK_AROUND -> {
                villagerTalk(n)
                true
            }
            else -> false
        }
    }

    private fun wizardTalk() {
        when (step) {
            StoryStep.ARRIVED -> play(sceneWake()) {
                setStep(StoryStep.ASK_AROUND)
                toast("Ask around Greenhollow, then find the Elder.")
            }
            StoryStep.ASK_AROUND -> play(
                listOf(
                    StoryLine(WIZ, "Go on, ask around the village. Somebody may remember you. And somewhere in Greenhollow lives someone who knows more than he lets on: the Elder."),
                ),
            ) {}
            StoryStep.FOUND_ELDER -> play(sceneReport()) {
                setStep(StoryStep.HUNT_GORVAK)
                startMainQuest()
                // Already felled Gorvak before being asked? The memory comes back right away.
                if (gorvakBeaten()) flashDelay = 1.5f
            }
            StoryStep.HUNT_GORVAK -> play(
                listOf(
                    StoryLine(WIZ, "Gorvak the Moss King sleeps in a ring of standing stones, east of here. Be careful, and come back alive."),
                ),
            ) {}
            StoryStep.RETURN_WIZARD -> play(sceneKeystone()) {
                setStep(StoryStep.CH1_DONE)
                giveNecklace()
                toast("Received: Necklace of Courage")
            }
            else -> play(
                listOf(
                    StoryLine(WIZ, "The Whisperwoods await beyond the wall. Go gently, Josh. And remember, you're a very special boy."),
                ),
            ) {}
        }
    }

    /** The Elder: while you're asking around he has a story for you. Otherwise he's an ordinary quest-giver. */
    private fun elderTalk(): Boolean {
        if (step != StoryStep.ASK_AROUND) return false
        if (asked < NEED_ASKED) {
            play(
                listOf(
                    StoryLine(ELD, "A stranger, and not a soul who knows his face. Ask around the village first, friend. Then come and find me again."),
                ),
            ) {}
        } else {
            play(sceneElder()) {
                setStep(StoryStep.FOUND_ELDER)
                toast("Take what the Elder told you back to the wizard.")
            }
        }
        return true
    }

    private fun villagerTalk(n: Npc) {
        val first = askedIds.add(n.id)
        val reply = VILLAGER_REPLIES[n.id % VILLAGER_REPLIES.size]
        play(listOf(StoryLine(me, "Excuse me. Do you know me? I woke up here with no memory at all."), StoryLine(n.name, reply))) {
            if (first) {
                asked = askedIds.size
                save()
                version++
                if (asked == NEED_ASKED) toast("Several people have pointed you to the Elder by the notice board.")
            }
        }
    }

    // ---------- Playing a scene ----------

    private fun play(lines: List<StoryLine>, end: () -> Unit) {
        if (lines.isEmpty()) return
        sceneIdx = 0
        scene = lines
        onEnd = end
        version++
    }

    /** NEXT was pressed. Moves on one line; after the last, the scene ends and you're back in control. */
    fun next() {
        val s = scene ?: return
        if (sceneIdx < s.size - 1) {
            sceneIdx += 1
            version++
            return
        }
        val e = onEnd
        scene = null
        onEnd = null
        sceneIdx = 0
        version++
        e?.invoke()
    }

    // ---------- The scenes (Chapter One) ----------

    private fun sceneWake() = listOf(
        StoryLine("", "You wake in a strange bed. Your wounds are gone, but your mind is empty."),
        StoryLine(WIZ, "Easy now. The villagers carried you to my house. You were hurt badly when you came through that portal. I've mended your body."),
        StoryLine(WIZ, "Now tell me: who are you? Where did you come from? What brought you here?"),
        StoryLine(me, "I don't know. I don't remember anything."),
        StoryLine(WIZ, "Nothing at all? Hm. I was afraid of that. There is no spell that simply gives a memory back."),
        StoryLine(WIZ, "The only way I know is to go out into the world, face the bosses who rule each region, and recover your memory fragments one by one."),
        StoryLine(WIZ, "But first, two leads. Ask around the village, someone may remember you. And somewhere in Greenhollow lives a person who may know more: the Elder."),
    )

    private fun sceneElder() = listOf(
        StoryLine(ELD, "So the portal gave us a stranger with no past. I've lived over two hundred years, and I've seen this sickness spread. First the villagers, now you."),
        StoryLine(me, "Do you know why it's happening? Do you know who I am?"),
        StoryLine(ELD, "Who you are, I can't tell you. But I've heard this much: every missing memory is tied to one of the bosses who rule the regions. Defeat a boss, and a piece comes back."),
        StoryLine(ELD, "Who took the memories in the first place, nobody knows. Go and tell the wizard what I've told you."),
    )

    private fun sceneReport() = listOf(
        StoryLine(me, "The Elder says each memory is tied to a boss. Beat the boss, and a piece comes back."),
        StoryLine(WIZ, "That fits what I fear. Ever since whoever is behind this took hold, the regions have been cut off from one another by some kind of invisible wall: the Whisperwoods, the snow country, the desert, the dark deep. No one understands how it works."),
        StoryLine(WIZ, "I need you to go on this journey. Defeat the bosses, reopen the regions, and help bring the world back together like a family."),
        StoryLine(me, "If getting my memory back means bringing peace to everyone, then I'll do it."),
        StoryLine(WIZ, "Then start close to home. Gorvak the Moss King holds Greenhollow's own fragment, in a ring of standing stones east of here. Be careful."),
    )

    private fun sceneFlashback() = listOf(
        StoryLine("", "The Moss King falls. A memory rushes up, bright and sudden."),
        StoryLine("", "A name, spoken aloud: Josh. A small village, far from Greenhollow. That was home."),
        StoryLine("", "You were sent into the Grain Rot portal on purpose, to stop Nullfang. But Nullfang threw you back through, and the throw took your memory."),
        StoryLine("", "You still don't know why you were the one sent, or who sent you."),
        StoryLine("", "Back in Greenhollow, the villagers are remembering too. The whole village had been losing its memories."),
    )

    private fun sceneKeystone() = listOf(
        StoryLine(me, "Wizard, I remember. My name is Josh. I was sent into the Grain Rot to stop Nullfang, and he threw me back."),
        StoryLine(WIZ, "So the village's memories were stolen too. Now I understand. Josh, you are the Keystone: the last emperor, the one meant to knit this world back together."),
        StoryLine(WIZ, "Take this. A necklace that holds the power of courage. Where you're going, you may not come back alive."),
        StoryLine(WIZ, "Now it's time to go bring back our memories, and yours too. And remember, you're a very special boy."),
    )

    private companion object {
        const val WIZ = "The Wizard"
        const val ELD = "The Elder"
        /** How many villagers you have to ask before the Elder will talk. */
        const val NEED_ASKED = 2
        val VILLAGER_REPLIES = arrayOf(
            "I'm sorry, I've never seen you before. You're the one they carried in, aren't you? You should speak to the Elder by the notice board. He's lived here longer than anyone.",
            "No, stranger, I don't know you. Strange thing is, lately I can't remember half of what I did last week either. The Elder by the notice board might know why.",
            "I wish I could help. Everyone here has been forgetful lately. Ask the Elder, he's seen two hundred years of strange things.",
            "Never seen you before, I'm afraid. If anyone knows anything, it'll be the Elder near the notice board.",
        )
    }
}
