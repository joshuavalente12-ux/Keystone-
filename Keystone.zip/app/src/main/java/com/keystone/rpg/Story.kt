package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** One spoken line in a story scene. [speaker] is empty for narration. */
class StoryLine(val speaker: String, val text: String, val fx: Int = 0)

/** The story people in the world. */
object StoryRole {
    const val NONE = 0
    const val WIZARD = 1
    const val ELDER = 2
    /** The villager Josh saves in the Whisperwoods. */
    const val VILLAGER = 3
    /** The man who sits alone in his house in Fernhollow. */
    const val RECLUSE = 4
    /** Roger, the Elder of Frost Peak: the same old man as Greenhollow's Elder, though Josh doesn't know it yet. */
    const val ROGER = 5
    /** The Sand Dunes villager whose grandparents are lost in the caves. */
    const val DUNE_VILLAGER = 6
    const val GRANDMA = 7
    const val GRANDPA = 8
    /** The villager at the Oasis Camp with news of Josh's parents. */
    const val DUNE_NEWS = 9
    /** The Hollow Deep's king: Duskhold's lord. */
    const val KING = 10
    /** Villagers hidden in the Grain Rot. */
    const val REALM_VILLAGER = 11
    const val MOTHER = 12
    const val FATHER = 13
}

/** Where you are in the main story. Every step waits for something YOU do; nothing plays on a timer. */
object StoryStep {
    // ---- Chapter One: Greenhollow
    /** Woke up in Greenhollow: the wizard waits. */
    const val ARRIVED = 0
    /** Free to roam: ask villagers, then find the Elder. */
    const val ASK_AROUND = 1
    /** Spoke with the Elder: go back to the wizard. */
    const val FOUND_ELDER = 2
    /** Sent after Gorvak the Moss King. */
    const val HUNT_GORVAK = 3
    /** Gorvak is down and the memory has returned: tell the wizard. */
    const val RETURN_WIZARD = 4
    /** Chapter One is finished: the Whisperwoods are next. */
    const val CH1_DONE = 5

    // ---- Chapter Two: Whisperwoods
    /** Heard a cry for help: save the villager from the monsters. */
    const val CH2_RESCUE = 6
    /** The monsters are down: talk to the villager. */
    const val CH2_THANKS = 7
    /** In the villager's home: talk to him. */
    const val CH2_HOME = 8
    /** Find the man who sits alone in Fernhollow. */
    const val CH2_RECLUSE = 9
    /** Ask around the Whisperwoods, then go back to him. */
    const val CH2_ASK = 10
    /** Sent after the Hollow Elder. */
    const val CH2_BOSS = 11
    /** The Hollow Elder is down and the memory has returned: Frost Peak is next. */
    const val CH2_DONE = 12

    // ---- Chapter Three: Frost Peak Highlands
    /** Crossed into Frost Peak: find answers in its villages. */
    const val CH3_EXPLORE = 13
    /** Roger sent you after Grimtusk. */
    const val CH3_BOSS = 14
    /** Stood before Grimtusk and heard him gloat: now fight. */
    const val CH3_FIGHT = 15
    /** Grimtusk is down and the memory has returned: the Sand Dunes are next. */
    const val CH3_DONE = 16

    // ---- Chapter Four: Sand Dunes
    /** Crossed into the Sand Dunes: find the nearest village. */
    const val CH4_VILLAGE = 17
    /** Find the grandparents in the caves. */
    const val CH4_CAVE = 18
    /** The grandparents are home: tell their grandson. */
    const val CH4_RETURN = 19
    /** Sent after Khepri. */
    const val CH4_BOSS = 20
    /** Stood before Khepri and heard him gloat: now fight. */
    const val CH4_FIGHT = 21
    /** Khepri is down: a villager at the Oasis Camp has news. */
    const val CH4_NEWS = 22
    /** The news is in: Hollow Deep is next. */
    const val CH4_DONE = 23

    // ---- Chapter Five: Hollow Deep
    /** Crossed into the Hollow Deep: explore, and find the castle. */
    const val CH5_EXPLORE = 24
    /** The king asked for his people back: find the next village. */
    const val CH5_VILLAGE = 25
    /** The villagers told you of the boss: leave the village. */
    const val CH5_LEAVE = 26
    /** Roger told you the boss is your father. */
    const val CH5_BOSS = 27
    /** Stood before the boss and heard it taunt: now fight, carefully. */
    const val CH5_FIGHT = 28
    /** The curse is broken: find where the boss hid. */
    const val CH5_KEY = 29
    /** Found the GR key: tell the king his people are back. */
    const val CH5_KING = 30
    /** The king sent you home: speak to Roger and the wizard. */
    const val CH5_RETURN = 31
    /** The campaign is told: only the Grain Rot waits. */
    const val CH5_DONE = 32

    // ---- The Secret Ending: the Grain Rot
    /** Through the portal: walk deeper. */
    const val SE_ENTER = 33
    /** Remembered the city: find the village. */
    const val SE_VILLAGE = 34
    /** Learned of the servants: defeat the first. */
    const val SE_SERVANT1 = 35
    const val SE_SERVANT2 = 36
    /** Both servants are down: climb to the castle. */
    const val SE_CASTLE = 37
    /** Face Vely. */
    const val SE_VELY = 38
    /** Back in Greenhollow with your mother: Roger waits. */
    const val SE_HOME = 39
    /** The story is told. */
    const val SE_DONE = 40
}

/** What the story needs from the game itself (monsters, people, your pack). */
interface StoryHost {
    /** Puts the villager in the trees ahead of you with [count] monsters on him. */
    fun startRescue(count: Int): Boolean
    /** Story monsters still standing. */
    fun ambushLeft(): Int
    /** Takes you and the villager home, into his house in Thornwick. */
    fun goHome()
    /** Food, [gold] and a good rest. */
    fun reward(gold: Int)
    /** The id of the cave the grandparents are lost in (a desert cave), or -1. */
    fun grandparentCave(): Int
    /** Puts the grandparents deep in that cave ([inCave] true) or safe in their grandson's house. */
    fun placeGrandparents(inCave: Boolean)
    /** How far you are from place number [place]. */
    fun distToPlace(place: Int): Float
    /** The name of the cave where the boss hid, and whether you're standing at the spot inside it. */
    fun keyCaveName(): String
    fun atKeySpot(): Boolean
    /** Roger appears beside you, or goes home to the wizard's house in Greenhollow. */
    fun summonRoger()
    fun sendRogerHome()
    /** The king's gift: the Grain Rot armor. */
    fun giveArmor()
    /** Opens the Grain Rot realm and takes you in. */
    fun enterRealm()
    /** Are you inside the Grain Rot realm, and how far from its entrance. */
    fun inRealm(): Boolean
    fun realmDist(): Float
    /** Makes sure story boss [tag] (1 or 2) is standing in the realm; how far you are from it. */
    fun ensureBoss(tag: Int)
    fun tagDistance(tag: Int): Float
    /** Within [r] of the realm's deepest chamber, where Vely waits. */
    fun nearDeepest(r: Float): Boolean
    /** Puts the hidden villagers in the realm's first village chamber. */
    fun placeRealmVillagers()
    /** 0 = Nullfang as usual, 1 = nobody waits, 2 = Vely waits. */
    fun setRotLordMode(m: Int)
    /** Puts Josh's mother and father in the wizard's house. */
    fun placeFamily()
    /** Takes you from the realm back to the wizard's house in Greenhollow. */
    fun returnToGreenhollow()
    /** True if you're within [r] of the lair of boss [i]. */
    fun nearBoss(i: Int, r: Float): Boolean
}

/**
 * The main story (PROLONG). Holds which step you're on and plays short scripted scenes (a line at a time)
 * at the moments you trigger them. Between scenes you're back in the game, free to explore and fight.
 */
class Story(
    private val toast: (String) -> Unit,
    private val startMainQuest: (Int) -> Unit,
    private val giveNecklace: () -> Unit,
    private val bossBeaten: (Int) -> Boolean,
    private val wakeInHouse: () -> Unit,
) {
    /** Set by the game once it's built. */
    var host: StoryHost? = null

    @Volatile var step = StoryStep.ARRIVED
        private set
    /** How many different Greenhollow villagers you've asked. */
    @Volatile var asked = 0
        private set
    private val askedIds = HashSet<Int>()
    /** The same, for the Whisperwoods. */
    @Volatile var asked2 = 0
        private set
    private val askedIds2 = HashSet<Int>()
    private var ctx: Context? = null

    /** Changes whenever the scene or the step changes, so the screen redraws. */
    var version by mutableIntStateOf(0)
        private set
    @Volatile var scene: List<StoryLine>? = null
        private set
    @Volatile var sceneIdx = 0
        private set
    private var onEnd: (() -> Unit)? = null
    /** True while a scene is on screen (you can't move or be hurt). */
    val active: Boolean get() = scene != null || ending

    /** You hold the GR key: the Grain Rot gate opens for you at any level. */
    val keyOwned: Boolean get() = step >= StoryStep.CH5_DONE

    /** Vely is waiting in the realm's deepest chamber (so the realm's lord is called Vely, not Nullfang). */
    val velyActive: Boolean get() = step == StoryStep.SE_CASTLE || step == StoryStep.SE_VELY

    /** Counts down to a boss flashback once it falls (negative = none pending); [flashBoss] says which. */
    private var flashDelay = -1f
    private var flashBoss = -1
    /** The cinematic just ended: play the wake-up scene as soon as the game is running. */
    @Volatile private var pendingWake = false
    /** You're standing in the Whisperwoods. */
    @Volatile private var inForest = false
    /** You're standing in the Frost Peak Highlands. */
    @Volatile private var inSnow = false
    /** You're standing in the Sand Dunes. */
    @Volatile private var inDesert = false
    /** You're standing in the Hollow Deep. */
    @Volatile private var inDeep = false
    /** The final screen is up. */
    var ending by mutableStateOf(false)
        private set
    private var villagersPlaced = false
    private var pendingFamily = false
    private var taunted1 = false
    private var taunted2 = false
    /** Roger needs sending home to Greenhollow (the story is past the point where he's there). */
    private var pendingRogerHome = false
    /** You've already heard the grandparents call out from their cave. */
    private var heardCave = false
    /** The grandparents need putting where this step says they are. */
    private var pendingPlace = false
    /** The rescue fight needs (more) monsters put out. */
    private var pendingRescue = false
    /** How many of the rescue monsters you've put down. */
    @Volatile private var kills = 0

    /** What you call yourself: "You" until the flashback gives you your name. */
    private val me: String get() = if (step >= StoryStep.RETURN_WIZARD) "Josh" else "You"

    /** One line saying what to do next, shown on screen. */
    val objective: String get() = when (step) {
        StoryStep.ARRIVED -> "Speak with the wizard"
        StoryStep.ASK_AROUND ->
            if (asked < NEED_ASKED) "Ask the villagers if they know you ($asked/$NEED_ASKED)" else "Find the Elder by the notice board"
        StoryStep.FOUND_ELDER -> "Return to the wizard"
        StoryStep.HUNT_GORVAK -> "Defeat Gorvak the Moss King, east of Greenhollow"
        StoryStep.RETURN_WIZARD -> "Return to the wizard"
        StoryStep.CH1_DONE -> "Travel north into the Whisperwoods"
        StoryStep.CH2_RESCUE -> "Save the person crying for help ($kills/$AMBUSH_TOTAL)"
        StoryStep.CH2_THANKS -> "Talk to the villager you saved"
        StoryStep.CH2_HOME -> "Talk to the villager"
        StoryStep.CH2_RECLUSE -> "Find the man who sits alone, in Fernhollow"
        StoryStep.CH2_ASK ->
            if (asked2 < NEED_ASKED) "Ask Whisperwoods villagers if they know you ($asked2/$NEED_ASKED)" else "Return to the man in Fernhollow"
        StoryStep.CH2_BOSS -> "Defeat The Hollow Elder, deep in the Whisperwoods"
        StoryStep.CH2_DONE -> "Head east to the Frost Peak Highlands"
        StoryStep.CH3_EXPLORE -> "Search Frost Peak's villages for answers"
        StoryStep.CH3_BOSS, StoryStep.CH3_FIGHT -> "Defeat Grimtusk the Frost Tyrant, in the highlands south of Highcrest"
        StoryStep.CH3_DONE -> "Head east to the Sand Dunes"
        StoryStep.CH4_VILLAGE -> "Find the nearest village and learn what's happening"
        StoryStep.CH4_CAVE -> "Search the Sand Dunes' caves for the missing grandparents"
        StoryStep.CH4_RETURN -> "Take the news back to the villager in Sandholm"
        StoryStep.CH4_BOSS, StoryStep.CH4_FIGHT -> "Defeat Khepri the Sun Devourer, in the dunes"
        StoryStep.CH4_NEWS -> "Head south to the Oasis Camp: someone has news"
        StoryStep.CH4_DONE -> "Head south into the Hollow Deep"
        StoryStep.CH5_EXPLORE -> "Explore the Hollow Deep and find out what happened"
        StoryStep.CH5_VILLAGE -> "Head to the next village: Gloomhaven, north of Duskhold"
        StoryStep.CH5_LEAVE -> "Leave Gloomhaven and head for the caves"
        StoryStep.CH5_BOSS, StoryStep.CH5_FIGHT -> "Defeat the Hollow Deep's boss. Carefully."
        StoryStep.CH5_KEY -> "Search the Hollow Deep's caves where the boss hid (try ${host?.keyCaveName() ?: "the caves"})"
        StoryStep.CH5_KING -> "Return to the king in Duskhold"
        StoryStep.CH5_RETURN -> "Return to Greenhollow and speak with Roger and the wizard"
        StoryStep.CH5_DONE -> "Walk to the Grain Rot portal outside Greenhollow"
        StoryStep.SE_ENTER -> "Walk deeper into the Grain Rot"
        StoryStep.SE_VILLAGE -> "Find the village, deeper in the Grain Rot"
        StoryStep.SE_SERVANT1 -> "Find and defeat the first servant"
        StoryStep.SE_SERVANT2 -> "Find and defeat the second servant"
        StoryStep.SE_CASTLE -> "Climb to Vely's castle, in the deepest chamber"
        StoryStep.SE_VELY -> "Defeat Vely"
        StoryStep.SE_HOME -> "Talk to Roger in the wizard's house"
        else -> ""
    }

    // ---------- Saving ----------

    fun load(c: Context, gorvakDown: Boolean) {
        ctx = c.applicationContext
        scene = null
        onEnd = null
        sceneIdx = 0
        flashDelay = -1f
        flashBoss = -1
        pendingRescue = false
        kills = 0
        askedIds.clear()
        askedIds2.clear()
        val s = c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).getString("story", null)
        if (s == null) {
            // A save from before the story existed: if Gorvak is already down, you only owe the wizard a visit.
            step = if (gorvakDown) StoryStep.RETURN_WIZARD else StoryStep.ARRIVED
        } else {
            val f = s.split('|')
            step = (f.getOrNull(0)?.toIntOrNull() ?: 0).coerceIn(0, StoryStep.SE_DONE)
            for (t in (f.getOrNull(1) ?: "").split(',')) t.toIntOrNull()?.let { askedIds.add(it) }
            for (t in (f.getOrNull(2) ?: "").split(',')) t.toIntOrNull()?.let { askedIds2.add(it) }
        }
        asked = askedIds.size
        asked2 = askedIds2.size
        // Saved in the middle of the rescue: put the fight back.
        if (step == StoryStep.CH2_RESCUE) pendingRescue = true
        // The grandparents are in their cave, or home, depending on how far you got.
        heardCave = false
        pendingPlace = step >= StoryStep.CH4_CAVE
        // Roger is back in Greenhollow once the boss is down.
        pendingRogerHome = step >= StoryStep.CH5_KEY
        // The realm's villagers and servants are put back when you're next in it; the family is home from the end of the finale on.
        villagersPlaced = false
        taunted1 = false
        taunted2 = false
        pendingFamily = step >= StoryStep.SE_HOME
        ending = false
        version++
    }

    private fun save() {
        if (SaveLock.blocked) return
        val c = ctx ?: return
        val s = "$step|" + askedIds.joinToString(",") + "|" + askedIds2.joinToString(",")
        c.getSharedPreferences("keystone_save", Context.MODE_PRIVATE).edit().putString("story", s).apply()
    }

    private fun setStep(s: Int) {
        step = s
        save()
        version++
    }

    // ---------- Triggers (each one is something the player does) ----------

    /** The intro cinematic has ended. The wake-up scene plays once the game is running. */
    fun onIntroEnd() {
        pendingWake = true
    }

    /** You've crossed into [zone]. */
    fun onZone(zone: Zone) {
        inForest = zone == Zone.FOREST
        inSnow = zone == Zone.SNOW
        inDesert = zone == Zone.DESERT
        inDeep = zone == Zone.CAVES
    }

    /** You went into cave [id]. If it's the grandparents' cave, you hear them calling. */
    fun onCaveEnter(id: Int) {
        if (step == StoryStep.CH4_CAVE && !heardCave && !active && host?.grandparentCave() == id) {
            heardCave = true
            play(sceneCaveHear()) {}
        }
    }

    /** A region boss has just fallen. The flashback follows a few seconds later, only if the story sent you for it. */
    fun onBossKilled(boss: Int) {
        if (boss == 0 && step == StoryStep.HUNT_GORVAK) {
            flashBoss = 0
            flashDelay = 3.5f
        } else if (boss == 1 && step == StoryStep.CH2_BOSS) {
            flashBoss = 1
            flashDelay = 3.5f
        } else if (boss == 2 && (step == StoryStep.CH3_BOSS || step == StoryStep.CH3_FIGHT)) {
            flashBoss = 2
            flashDelay = 3.5f
        } else if (boss == 3 && (step == StoryStep.CH4_BOSS || step == StoryStep.CH4_FIGHT)) {
            flashBoss = 3
            flashDelay = 3.5f
        } else if (boss == 4 && (step == StoryStep.CH5_BOSS || step == StoryStep.CH5_FIGHT)) {
            flashBoss = 4
            flashDelay = 3.5f
        }
    }

    /** You pressed the Grain Rot portal. At the right moment the key scene takes over (true); otherwise the game does the usual. */
    fun onPortal(): Boolean {
        if (step != StoryStep.CH5_DONE || active) return false
        play(scenePortal()) {
            host?.enterRealm()
            setStep(StoryStep.SE_ENTER)
            toast("Walk deeper into the Grain Rot.")
        }
        return true
    }

    /** A story boss in the realm (a servant) was killed. */
    fun onTagKilled(tag: Int) {
        if (tag == 1 && step == StoryStep.SE_SERVANT1) {
            flashBoss = 11
            flashDelay = 2.5f
        } else if (tag == 2 && step == StoryStep.SE_SERVANT2) {
            flashBoss = 12
            flashDelay = 2.5f
        }
    }

    /** The realm's lord fell: if he was Vely, the truth comes out. */
    fun onVelyKilled() {
        if (step == StoryStep.SE_VELY) {
            flashBoss = 13
            flashDelay = 3.5f
        }
    }

    /** RETURN TO TITLE was pressed on the final screen. */
    fun finishEnding() {
        ending = false
    }

    private fun rotMode(): Int = when {
        step in StoryStep.SE_ENTER..StoryStep.SE_SERVANT2 -> 1
        step == StoryStep.SE_CASTLE || step == StoryStep.SE_VELY -> 2
        else -> 0
    }

    /** One of the monsters attacking the villager was killed. */
    fun onAmbushKill() {
        if (step == StoryStep.CH2_RESCUE) {
            kills++
            version++
        }
    }

    /** Called every game tick. */
    fun update(dt: Float) {
        if (pendingWake && !active) {
            pendingWake = false
            if (step == StoryStep.ARRIVED) {
                // New game: you come to beside the bed in the wizard's house.
                wakeInHouse()
                wizardTalk()
            }
        }
        // First step into the Whisperwoods: a cry for help.
        if (step == StoryStep.CH1_DONE && inForest && !active) {
            play(sceneScream()) {
                kills = 0
                pendingRescue = true
                setStep(StoryStep.CH2_RESCUE)
                toast("Someone is crying for help. Find them!")
            }
        }
        // First step into Frost Peak: the whole region at a glance.
        if (step == StoryStep.CH2_DONE && inSnow && !active) {
            play(sceneFrostEnter()) {
                setStep(StoryStep.CH3_EXPLORE)
                toast("Explore Frost Peak's villages and find out what's happening.")
            }
        }
        // Put the grandparents where the story says they are.
        if (pendingPlace) {
            val h = host
            if (h != null) {
                h.placeGrandparents(step == StoryStep.CH4_CAVE)
                pendingPlace = false
            }
        }
        // The Grain Rot: who waits in the realm depends on how far the story has got.
        host?.setRotLordMode(rotMode())
        if (pendingFamily) {
            val fh = host
            if (fh != null) {
                fh.placeFamily()
                pendingFamily = false
            }
        }
        val rh = host
        if (rh != null && !active && step >= StoryStep.SE_ENTER && step <= StoryStep.SE_VELY && rh.inRealm()) {
            if (!villagersPlaced) {
                rh.placeRealmVillagers()
                villagersPlaced = true
            }
            if (step == StoryStep.SE_ENTER && rh.realmDist() > 25f) {
                play(sceneCityFlash()) {
                    setStep(StoryStep.SE_VILLAGE)
                    toast("Find the village, deeper in the Grain Rot.")
                }
            } else if (step == StoryStep.SE_SERVANT1) {
                if (flashBoss < 0) rh.ensureBoss(1)
                if (!taunted1 && rh.tagDistance(1) < 26f) {
                    taunted1 = true
                    play(sceneServant1Taunt()) {}
                }
            } else if (step == StoryStep.SE_SERVANT2) {
                if (flashBoss < 0) rh.ensureBoss(2)
                if (!taunted2 && rh.tagDistance(2) < 26f) {
                    taunted2 = true
                    play(sceneServant2Taunt()) {}
                }
            } else if (step == StoryStep.SE_CASTLE && rh.nearDeepest(70f)) {
                play(sceneVelyTaunt()) {
                    setStep(StoryStep.SE_VELY)
                }
            }
        }
        // Roger goes home to Greenhollow once the boss is down.
        if (pendingRogerHome) {
            val h = host
            if (h != null) {
                h.sendRogerHome()
                pendingRogerHome = false
            }
        }
        // First step into the Hollow Deep: nothing at all.
        if (step == StoryStep.CH4_DONE && inDeep && !active) {
            play(sceneDeepEnter()) {
                setStep(StoryStep.CH5_EXPLORE)
                toast("Explore the Hollow Deep. Find out what happened here.")
            }
        }
        // Walk out of Gloomhaven and Roger catches up with you.
        if (step == StoryStep.CH5_LEAVE && !active && host?.distToPlace(30)?.let { it > 55f } == true) {
            host?.summonRoger()
            play(sceneRogerWarns()) {
                setStep(StoryStep.CH5_BOSS)
                startMainQuest(4)
                if (bossBeaten(4)) {
                    flashBoss = 4
                    flashDelay = 1.5f
                }
                toast("Defeat the Hollow Deep's boss, but not too hard.")
            }
        }
        // Walk up to the boss and it taunts you before the fight.
        if (step == StoryStep.CH5_BOSS && !active && host?.nearBoss(4, 45f) == true) {
            play(sceneDeepTaunt()) {
                setStep(StoryStep.CH5_FIGHT)
            }
        }
        // Deep in the cave where the boss hid: the key.
        if (step == StoryStep.CH5_KEY && !active && host?.atKeySpot() == true) {
            play(sceneKey()) {
                setStep(StoryStep.CH5_KING)
                toast("Found: the GR key. Return to the king in Duskhold.")
            }
        }
        // First step into the Sand Dunes: the region under attack.
        if (step == StoryStep.CH3_DONE && inDesert && !active) {
            play(sceneDuneEnter()) {
                setStep(StoryStep.CH4_VILLAGE)
                toast("Find the nearest village and learn what's happening.")
            }
        }
        // Walk up to Khepri and he gloats before the fight.
        if (step == StoryStep.CH4_BOSS && !active && host?.nearBoss(3, 45f) == true) {
            play(sceneDuneTaunt()) {
                setStep(StoryStep.CH4_FIGHT)
            }
        }
        // Walk up to Grimtusk and he gloats before the fight.
        if (step == StoryStep.CH3_BOSS && !active && host?.nearBoss(2, 45f) == true) {
            play(sceneFrostTaunt()) {
                setStep(StoryStep.CH3_FIGHT)
            }
        }
        // The rescue fight.
        if (step == StoryStep.CH2_RESCUE && !active) {
            val h = host
            if (h != null) {
                if (pendingRescue) {
                    val need = AMBUSH_TOTAL - kills
                    if (need > 0 && h.startRescue(need)) pendingRescue = false
                } else if (kills >= AMBUSH_TOTAL) {
                    setStep(StoryStep.CH2_THANKS)
                    toast("The way is clear. Talk to the villager.")
                } else if (h.ambushLeft() == 0) {
                    // They scattered or were lost: bring back the rest.
                    pendingRescue = true
                }
            }
        }
        // A boss has fallen: the memory returns.
        if (flashDelay >= 0f && !active) {
            flashDelay -= dt
            if (flashDelay < 0f) {
                flashDelay = -1f
                if (flashBoss == 0) {
                    play(sceneFlashback()) {
                        setStep(StoryStep.RETURN_WIZARD)
                        toast("A memory returns. Tell the wizard what you saw.")
                    }
                } else if (flashBoss == 1) {
                    play(sceneBossFlashback2()) {
                        setStep(StoryStep.CH2_DONE)
                        toast("Frost Peak is in danger. Head east.")
                    }
                } else if (flashBoss == 2) {
                    play(sceneBossFlashback3()) {
                        setStep(StoryStep.CH3_DONE)
                        toast("Your parents are somewhere in the Sand Dunes' direction. Head east.")
                    }
                } else if (flashBoss == 3) {
                    play(sceneBossFlashback4()) {
                        setStep(StoryStep.CH4_NEWS)
                        toast("Head south. Someone at the Oasis Camp is looking for you.")
                    }
                } else if (flashBoss == 11) {
                    play(sceneServant1Down()) {
                        setStep(StoryStep.SE_SERVANT2)
                        toast("Press on toward the second servant.")
                    }
                } else if (flashBoss == 12) {
                    play(sceneServant2Down()) {
                        setStep(StoryStep.SE_CASTLE)
                        toast("Climb to Vely's castle, in the deepest chamber.")
                    }
                } else if (flashBoss == 13) {
                    play(sceneVelyReveal()) {
                        host?.returnToGreenhollow()
                        setStep(StoryStep.SE_HOME)
                        toast("You're home in Greenhollow. Talk to Roger.")
                    }
                } else if (flashBoss == 4) {
                    play(sceneBossFlashback5()) {
                        host?.sendRogerHome()
                        setStep(StoryStep.CH5_KEY)
                        toast("Search the Hollow Deep's caves where the boss hid.")
                    }
                }
                flashBoss = -1
            }
        }
    }

    /**
     * You pressed TALK on [n]. True if a story scene took over; false means they talk the ordinary way
     * (a villager chatting, the Elder's quest, and so on).
     */
    fun talk(n: Npc): Boolean {
        if (active) return true
        return when {
            n.storyRole == StoryRole.WIZARD -> {
                wizardTalk()
                true
            }
            n.storyRole == StoryRole.ELDER -> elderTalk()
            n.storyRole == StoryRole.VILLAGER -> {
                savedVillagerTalk()
                true
            }
            n.storyRole == StoryRole.RECLUSE -> {
                recluseTalk()
                true
            }
            n.storyRole == StoryRole.ROGER -> {
                rogerTalk()
                true
            }
            n.storyRole == StoryRole.DUNE_VILLAGER -> {
                duneVillagerTalk()
                true
            }
            n.storyRole == StoryRole.GRANDMA || n.storyRole == StoryRole.GRANDPA -> {
                grandTalk()
                true
            }
            n.storyRole == StoryRole.DUNE_NEWS -> {
                duneNewsTalk()
                true
            }
            n.storyRole == StoryRole.KING -> kingTalk()
            n.storyRole == StoryRole.REALM_VILLAGER -> {
                realmVillagerTalk()
                true
            }
            n.storyRole == StoryRole.MOTHER || n.storyRole == StoryRole.FATHER -> {
                familyTalk(n.storyRole)
                true
            }
            n.role == NpcRole.VILLAGER && n.place == 30 && n.storyRole == StoryRole.NONE && step == StoryStep.CH5_VILLAGE -> {
                gloomhavenTalk()
                true
            }
            n.role == NpcRole.VILLAGER && n.place == 0 && step == StoryStep.ASK_AROUND -> {
                villagerTalk(n)
                true
            }
            n.role == NpcRole.VILLAGER && n.zone == Zone.FOREST && n.storyRole == StoryRole.NONE && step == StoryStep.CH2_ASK -> {
                woodsVillagerTalk(n)
                true
            }
            else -> false
        }
    }

    private fun wizardTalk() {
        when (step) {
            StoryStep.ARRIVED -> play(sceneWake()) {
                setStep(StoryStep.ASK_AROUND)
                toast("Ask around Greenhollow, then find the Elder.")
            }
            StoryStep.ASK_AROUND -> play(
                listOf(
                    StoryLine(WIZ, "Go on, ask around the village. Somebody may remember you. And somewhere in Greenhollow lives someone who knows more than he lets on: the Elder."),
                ),
            ) {}
            StoryStep.FOUND_ELDER -> play(sceneReport()) {
                setStep(StoryStep.HUNT_GORVAK)
                startMainQuest(0)
                // Already felled Gorvak before being asked? The memory comes back right away.
                if (bossBeaten(0)) {
                    flashBoss = 0
                    flashDelay = 1.5f
                }
            }
            StoryStep.HUNT_GORVAK -> play(
                listOf(
                    StoryLine(WIZ, "Gorvak the Moss King sleeps in a ring of standing stones, east of here. Be careful, and come back alive."),
                ),
            ) {}
            StoryStep.RETURN_WIZARD -> play(sceneKeystone()) {
                setStep(StoryStep.CH1_DONE)
                giveNecklace()
                toast("Received: Necklace of Courage")
            }
            StoryStep.CH5_RETURN -> returnHome()
            StoryStep.SE_HOME -> endingTalk()
            in StoryStep.CH5_DONE..StoryStep.SE_VELY -> play(
                listOf(StoryLine(WIZ, "The Grain Rot portal is waiting, Josh. Your father is resting. Go, and bring your mother home.")),
            ) {}
            in StoryStep.SE_DONE..99 -> play(
                listOf(StoryLine(WIZ, "Our family is whole again, thanks to you. Come and go through the portal whenever you like.")),
            ) {}
            else -> play(
                listOf(
                    StoryLine(WIZ, "The Whisperwoods await beyond the wall. Go gently, Josh. And remember, you're a very special boy."),
                ),
            ) {}
        }
    }

    /** The Elder: while you're asking around he has a story for you. Otherwise he's an ordinary quest-giver. */
    private fun elderTalk(): Boolean {
        if (step != StoryStep.ASK_AROUND) return false
        if (asked < NEED_ASKED) {
            play(
                listOf(
                    StoryLine(ELD, "A stranger, and not a soul who knows his face. Ask around the village first, friend. Then come and find me again."),
                ),
            ) {}
        } else {
            play(sceneElder()) {
                setStep(StoryStep.FOUND_ELDER)
                toast("Take what the Elder told you back to the wizard.")
            }
        }
        return true
    }

    private fun villagerTalk(n: Npc) {
        val first = askedIds.add(n.id)
        val reply = VILLAGER_REPLIES[n.id % VILLAGER_REPLIES.size]
        play(listOf(StoryLine(me, "Excuse me. Do you know me? I woke up here with no memory at all."), StoryLine(n.name, reply))) {
            if (first) {
                asked = askedIds.size
                save()
                version++
                if (asked == NEED_ASKED) toast("Several people have pointed you to the Elder by the notice board.")
            }
        }
    }

    // ---------- Chapter Two people ----------

    /** The villager you saved. */
    private fun savedVillagerTalk() {
        when (step) {
            StoryStep.CH2_RESCUE -> play(
                listOf(StoryLine(VIL, "Behind you! Please, drive them off!")),
            ) {}
            StoryStep.CH2_THANKS -> play(sceneThanks()) {
                host?.goHome()
                setStep(StoryStep.CH2_HOME)
                toast("He's brought you to his home in Thornwick. Talk to him.")
            }
            StoryStep.CH2_HOME -> play(sceneHome()) {
                host?.reward(150)
                setStep(StoryStep.CH2_RECLUSE)
                toast("Rested and fed. Find the man who sits alone, in Fernhollow.")
            }
            in 0 until StoryStep.CH2_RESCUE -> play(
                listOf(StoryLine(VIL, "Be careful if you're headed into the woods. Something's gone wrong with the creatures lately.")),
            ) {}
            StoryStep.CH2_DONE -> play(
                listOf(StoryLine(VIL, "Frost Peak needs you, Josh. Go, and don't give up on your parents.")),
            ) {}
            else -> play(
                listOf(StoryLine(VIL, "You've done so much for me already. Come back whenever you need a warm bed.")),
            ) {}
        }
    }

    /** The man who sits alone. */
    private fun recluseTalk() {
        when (step) {
            StoryStep.CH2_RECLUSE -> play(sceneRecluseMeet()) {
                setStep(StoryStep.CH2_ASK)
                toast("Ask around the Whisperwoods, then come back to him.")
            }
            StoryStep.CH2_ASK ->
                if (asked2 < NEED_ASKED) {
                    play(listOf(StoryLine(REC, "Go and ask the villagers whether anyone remembers you. Then come back and tell me what you learn."))) {}
                } else {
                    play(sceneRecluseReport()) {
                        setStep(StoryStep.CH2_BOSS)
                        startMainQuest(1)
                        // Already put the Hollow Elder down? The memory comes back right away.
                        if (bossBeaten(1)) {
                            flashBoss = 1
                            flashDelay = 1.5f
                        }
                        toast("Defeat The Hollow Elder to free the Whisperwoods.")
                    }
                }
            StoryStep.CH2_BOSS -> play(
                listOf(StoryLine(REC, "The Hollow Elder lurks deep in the woods, to the north-east. Be careful, Josh.")),
            ) {}
            in StoryStep.CH2_DONE..99 -> play(
                listOf(StoryLine(REC, "You know where I am, Josh. If you need my help, holler.")),
            ) {}
            else -> play(
                listOf(StoryLine(REC, "...Hm? Not now. I'm thinking.")),
            ) {}
        }
    }

    /** Roger, the Elder of Frost Peak. */
    private fun rogerTalk() {
        when (step) {
            StoryStep.CH3_EXPLORE -> play(sceneRoger()) {
                setStep(StoryStep.CH3_BOSS)
                startMainQuest(2)
                // Already felled Grimtusk? The memory comes back right away.
                if (bossBeaten(2)) {
                    flashBoss = 2
                    flashDelay = 1.5f
                }
                toast("Defeat Grimtusk the Frost Tyrant. He may know what happened to your parents.")
            }
            StoryStep.CH3_BOSS, StoryStep.CH3_FIGHT -> play(
                listOf(StoryLine(ROG, "Grimtusk waits in the highlands south of here. Stop the monsters he controls, Josh, and save this region.")),
            ) {}
            StoryStep.CH5_RETURN -> returnHome()
            StoryStep.SE_HOME -> endingTalk()
            StoryStep.CH5_BOSS, StoryStep.CH5_FIGHT -> play(
                listOf(StoryLine(ROG, "Be gentle with him, Josh. Stop him. Don't kill him.")),
            ) {}
            in StoryStep.CH5_DONE..99 -> play(
                listOf(StoryLine(ROG, "The portal is yours to open, Josh. Bring your mother home.")),
            ) {}
            in StoryStep.CH3_DONE..99 -> play(
                listOf(StoryLine(ROG, "Your parents are alive, Josh. Hold on to that. Go, and find them.")),
            ) {}
            else -> play(
                listOf(StoryLine(ELD, "Stranger... the old and the weary should be left to their rest.")),
            ) {}
        }
    }

    /** Sandholm's villager, whose grandparents are lost. */
    private fun duneVillagerTalk() {
        when (step) {
            StoryStep.CH4_VILLAGE -> play(sceneDuneVillager()) {
                setStep(StoryStep.CH4_CAVE)
                host?.placeGrandparents(true)
                toast("Search the Sand Dunes' caves. Listen for voices.")
            }
            StoryStep.CH4_CAVE -> play(
                listOf(StoryLine(VIL, "They went into one of the caves nearby, but I don't know which. Please, find them.")),
            ) {}
            StoryStep.CH4_RETURN -> play(sceneDuneReward()) {
                host?.reward(300)
                setStep(StoryStep.CH4_BOSS)
                startMainQuest(3)
                if (bossBeaten(3)) {
                    flashBoss = 3
                    flashDelay = 1.5f
                }
                toast("Defeat Khepri the Sun Devourer to free the Sand Dunes.")
            }
            in 0 until StoryStep.CH4_VILLAGE -> play(
                listOf(StoryLine(VIL, "Stay out of the dunes if you can. The storms have been awful lately.")),
            ) {}
            else -> play(
                listOf(StoryLine(VIL, "You brought my family home. I'll never forget it. Be careful out there.")),
            ) {}
        }
    }

    /** The grandparents. */
    private fun grandTalk() {
        if (step == StoryStep.CH4_CAVE) {
            play(sceneGrand()) {
                host?.placeGrandparents(false)
                setStep(StoryStep.CH4_RETURN)
                toast("They hurry home. Go back to the villager in Sandholm.")
            }
        } else {
            play(listOf(StoryLine("The Grandparents", "Thank you again, dear. You're a good boy."))) {}
        }
    }

    /** The Hollow Deep's king. Anything but the story's two moments: the lord's ordinary chat. */
    private fun kingTalk(): Boolean {
        return when (step) {
            StoryStep.CH5_EXPLORE -> {
                play(sceneKing()) {
                    setStep(StoryStep.CH5_VILLAGE)
                    toast("Head to the next village: Gloomhaven, north of the castle.")
                }
                true
            }
            StoryStep.CH5_KING -> {
                play(sceneKingReward()) {
                    host?.giveArmor()
                    setStep(StoryStep.CH5_RETURN)
                    toast("Received: the Grain Rot armor. Return to Greenhollow.")
                }
                true
            }
            else -> false
        }
    }

    /** One of Gloomhaven's villagers. */
    private fun gloomhavenTalk() {
        play(sceneGloomhaven()) {
            setStep(StoryStep.CH5_LEAVE)
            toast("Head out toward the caves.")
        }
    }

    /** Back in Greenhollow, with Roger and the wizard. */
    private fun returnHome() {
        play(sceneReturn()) {
            setStep(StoryStep.CH5_DONE)
            toast("Walk to the Grain Rot portal outside Greenhollow.")
        }
    }

    /** A villager hidden in the Grain Rot. */
    private fun realmVillagerTalk() {
        when (step) {
            StoryStep.SE_VILLAGE -> play(sceneRealmVillage()) {
                setStep(StoryStep.SE_SERVANT1)
                toast("Find and defeat Vely's first servant.")
            }
            StoryStep.SE_ENTER -> play(
                listOf(StoryLine(RVIL, "Quick, keep your head down! Don't let the servants see you.")),
            ) {}
            else -> play(
                listOf(StoryLine(RVIL, "Please, stop Vely. Bring our city back.")),
            ) {}
        }
    }

    /** Your mother or father, in the wizard's house. */
    private fun familyTalk(role: Int) {
        if (step == StoryStep.SE_HOME) {
            endingTalk()
        } else {
            val who = if (role == StoryRole.MOTHER) "Mother" else "Father"
            play(listOf(StoryLine(who, "Thank you, Josh. We're home, and we're together. That's all that matters."))) {}
        }
    }

    /** The last scene: the family together, the Keystone, Roger's truth. */
    private fun endingTalk() {
        play(sceneEnding()) {
            setStep(StoryStep.SE_DONE)
            ending = true
        }
    }

    /** The villager at the Oasis Camp. */
    private fun duneNewsTalk() {
        when (step) {
            StoryStep.CH4_NEWS -> play(sceneDuneNews()) {
                setStep(StoryStep.CH4_DONE)
                toast("Your parents are somewhere in the Hollow Deep. Head south.")
            }
            in StoryStep.CH4_DONE..99 -> play(
                listOf(StoryLine(VIL, "Hollow Deep lies south of here. Go find your family, Josh.")),
            ) {}
            else -> play(
                listOf(StoryLine(VIL, "Rest a moment if you need to. The desert is no place to rush through.")),
            ) {}
        }
    }

    private fun woodsVillagerTalk(n: Npc) {
        val first = askedIds2.add(n.id)
        val reply = WOODS_REPLIES[n.id % WOODS_REPLIES.size]
        play(listOf(StoryLine(me, "Excuse me. Do you know me? Did you ever see me before I came here?"), StoryLine(n.name, reply))) {
            if (first) {
                asked2 = askedIds2.size
                save()
                version++
                if (asked2 == NEED_ASKED) toast("Time to go back to the man in Fernhollow.")
            }
        }
    }

    // ---------- Playing a scene ----------

    private fun play(lines: List<StoryLine>, end: () -> Unit) {
        if (lines.isEmpty()) return
        sceneIdx = 0
        scene = lines
        onEnd = end
        version++
    }

    /** NEXT was pressed. Moves on one line; after the last, the scene ends and you're back in control. */
    fun next() {
        val s = scene ?: return
        if (sceneIdx < s.size - 1) {
            sceneIdx += 1
            version++
            return
        }
        val e = onEnd
        scene = null
        onEnd = null
        sceneIdx = 0
        version++
        e?.invoke()
    }

    // ---------- The scenes (Chapter One) ----------

    private fun sceneWake() = listOf(
        StoryLine("", "You wake in a strange bed. Your wounds are gone, but your mind is empty."),
        StoryLine(WIZ, "Easy now. The villagers carried you to my house. You were hurt badly when you came through that portal. I've mended your body."),
        StoryLine(WIZ, "Now tell me: who are you? Where did you come from? What brought you here?"),
        StoryLine(me, "I don't know. I don't remember anything."),
        StoryLine(WIZ, "Nothing at all? Hm. I was afraid of that. There is no spell that simply gives a memory back."),
        StoryLine(WIZ, "The only way I know is to go out into the world, face the bosses who rule each region, and recover your memory fragments one by one."),
        StoryLine(WIZ, "But first, two leads. Ask around the village, someone may remember you. And somewhere in Greenhollow lives a person who may know more: the Elder."),
    )

    private fun sceneElder() = listOf(
        StoryLine(ELD, "So the portal gave us a stranger with no past. I've lived over two hundred years, and I've seen this sickness spread. First the villagers, now you."),
        StoryLine(me, "Do you know why it's happening? Do you know who I am?"),
        StoryLine(ELD, "Who you are, I can't tell you. But I've heard this much: every missing memory is tied to one of the bosses who rule the regions. Defeat a boss, and a piece comes back."),
        StoryLine(ELD, "Who took the memories in the first place, nobody knows. Go and tell the wizard what I've told you."),
    )

    private fun sceneReport() = listOf(
        StoryLine(me, "The Elder says each memory is tied to a boss. Beat the boss, and a piece comes back."),
        StoryLine(WIZ, "That fits what I fear. Ever since whoever is behind this took hold, the regions have been cut off from one another by some kind of invisible wall: the Whisperwoods, the snow country, the desert, the dark deep. No one understands how it works."),
        StoryLine(WIZ, "I need you to go on this journey. Defeat the bosses, reopen the regions, and help bring the world back together like a family."),
        StoryLine(me, "If getting my memory back means bringing peace to everyone, then I'll do it."),
        StoryLine(WIZ, "Then start close to home. Gorvak the Moss King holds Greenhollow's own fragment, in a ring of standing stones east of here. Be careful."),
    )

    private fun sceneFlashback() = listOf(
        StoryLine("", "The Moss King falls. A memory rushes up, bright and sudden."),
        StoryLine("", "A name, spoken aloud: Josh. A small village, far from Greenhollow. That was home."),
        StoryLine("", "You were sent into the Grain Rot portal on purpose, to stop Nullfang. But Nullfang threw you back through, and the throw took your memory."),
        StoryLine("", "You still don't know why you were the one sent, or who sent you."),
        StoryLine("", "Back in Greenhollow, the villagers are remembering too. The whole village had been losing its memories."),
    )

    private fun sceneKeystone() = listOf(
        StoryLine(me, "Wizard, I remember. My name is Josh. I was sent into the Grain Rot to stop Nullfang, and he threw me back."),
        StoryLine(WIZ, "So the village's memories were stolen too. Now I understand. Josh, you are the Keystone: the last emperor, the one meant to knit this world back together."),
        StoryLine(WIZ, "Take this. A necklace that holds the power of courage. Where you're going, you may not come back alive."),
        StoryLine(WIZ, "Now it's time to go bring back our memories, and yours too. And remember, you're a very special boy."),
    )

    // ---------- The scenes (Chapter Two) ----------

    private fun sceneScream() = listOf(
        StoryLine("", "The Whisperwoods close in around you, dark and still. Then, somewhere ahead, a voice tears through the trees."),
        StoryLine("???", "Help! Somebody, please! Help me!"),
        StoryLine(me, "Someone's in trouble! I have to get to them!"),
    )

    private fun sceneThanks() = listOf(
        StoryLine(VIL, "You came! I thought I was finished. Thank you, stranger. Thank you."),
        StoryLine(me, "Are you hurt? Can you walk?"),
        StoryLine(VIL, "I'll live, thanks to you. Please, come to my home in Thornwick. You've earned a warm bed, a hot meal, and more than that. Follow me."),
        StoryLine("", "He leads you through the trees, to a small house on the edge of Thornwick."),
    )

    private fun sceneHome() = listOf(
        StoryLine("", "A fire crackles in the hearth. There is bread on the table, and a bed with clean sheets."),
        StoryLine(VIL, "Sit, eat, rest. It's the least I can do. And here, take this gold for your trouble."),
        StoryLine(me, "Thank you. Can I ask you something? Do you remember anything about what's going on in this region?"),
        StoryLine(VIL, "No. I don't even know why I was out there. All I know is that we were all told to work as a team, to make life in our city better. But nobody understands what's really happening, no matter who I ask."),
        StoryLine(VIL, "There's one man who might know. He sits alone in his house in Fernhollow, deep in his own thoughts, always. Go and see him."),
    )

    private fun sceneRecluseMeet() = listOf(
        StoryLine("", "In a quiet house in Fernhollow, a man sits alone by the fire, staring into it."),
        StoryLine(REC, "...A visitor. It's been a long time. Sit down, if you like."),
        StoryLine("", "You sit with him and tell him everything: who you are, what happened in Greenhollow, the portal, the lost memories, all of it."),
        StoryLine(REC, "I understand. All of it. You've been through a great deal, Josh."),
        StoryLine(REC, "If you need my help, you can holler at me."),
        StoryLine(REC, "For now, do this. Go around the Whisperwoods and ask people whether they remember you, from before you knew your own name. Every answer is a piece of your fragment. Then come back to me."),
    )

    private fun sceneRecluseReport() = listOf(
        StoryLine(me, "I asked around. Nobody here seems to remember me, but they all feel the same unease."),
        StoryLine(REC, "Then it's time you heard it plainly. Witches have crept into these woods. Swarms of spiders pour out of the dark. And a great creature, the Hollow Elder, has been terrorizing the whole region."),
        StoryLine(me, "I've told you what I remember about Nullfang, about the portal. But there's more, something I can almost..."),
        StoryLine("", "Exhaustion crashes over you. The room tilts, and everything goes dark."),
        StoryLine("", "Fire. Your house is burning, and you run inside, shouting for your mother and father."),
        StoryLine("", "Through the smoke, a towering figure: Nullfang. He seizes your family, and vanishes with them."),
        StoryLine("", "That is all you see. You wake, your heart pounding."),
        StoryLine(me, "Something happened to my mom and dad. Nullfang did something to them, but I don't know what."),
        StoryLine(me, "I understand now that I was going after Nullfang. But I still don't understand why it was me who was sent to stop him."),
        StoryLine(REC, "Rest a moment. When you're ready, the Hollow Elder is waiting in the north-east of the woods. Fight through the witches and the spiders to reach it. And remember, holler if you need me."),
    )

    private fun sceneBossFlashback2() = listOf(
        StoryLine("", "The Hollow Elder falls. Another memory rises, and this one is clear."),
        StoryLine("", "The night of the fire. Your father throws himself at Nullfang, trying to stop him from taking your family."),
        StoryLine("", "Nullfang flings a sleeping potion over both your parents. They fall. He scoops them up, and steps into the portal."),
        StoryLine("", "That is where the memory ends."),
        StoryLine("", "Footsteps crash through the trees behind you. It's the villager you saved, out of breath."),
        StoryLine(VIL, "Josh! Something is happening in Frost Peak. I don't know what, but the people there are in danger. They need you."),
        StoryLine(VIL, "I'm so sorry about your mother and father. But think positive, Josh. They might still be alive, and you have to find them."),
        StoryLine(VIL, "Don't give up on them. They won't give up on you. Gather every fragment of your memory. Once you do, you'll understand enough to find them."),
        StoryLine(me, "I won't stop. Not until I bring them home."),
    )

    // ---------- The scenes (Chapter Three) ----------

    private fun sceneFrostEnter() = listOf(
        StoryLine("", "The Frost Peak Highlands stretch out below you, white and howling. From the ridge you take it all in."),
        StoryLine("", "Monsters roam the slopes, hurting the animals and the people alike. And far off, seated like a king, the region's boss directs his creatures, taking the land for his own."),
        StoryLine(me, "I have to stop this. Now."),
    )

    private fun sceneRoger() = listOf(
        StoryLine("", "In a quiet house in Highcrest, an old man looks up from the fire. There is something familiar in his face, and fragments stir in your mind."),
        StoryLine(ELD, "I see that you survived."),
        StoryLine(me, "I did. I'm starting to remember things about my mom and dad. Something about Nullfang putting them to sleep. That's all I know."),
        StoryLine(ELD, "It's true. I saw Nullfang take your mother and father and go through the portal. That is as much as I saw."),
        StoryLine("", "Your head swims. A flash: this same old man, standing against Nullfang, trying to stop him from taking your parents."),
        StoryLine("", "Nullfang turns on him. \"Roger the Great, you will not stop me. These are the two most important people to someone, and he will never find out who it is.\""),
        StoryLine("", "The memory goes black. You collapse."),
        StoryLine("", "When you open your eyes, you are lying on a bed in the old man's house."),
        StoryLine(me, "Is your name Roger?"),
        StoryLine(ROG, "It is. Tell me, what did you see?"),
        StoryLine(me, "Nullfang called you Roger. He said the two people he was taking were important to someone, and that this someone would never find out who. Then it all went blank."),
        StoryLine(ROG, "Yes. All true. I tried to save your parents, though at the time I didn't know who you were, or who those two people truly were."),
        StoryLine(ROG, "But if that is what you saw... then you are him. You are the one who was prophesied to come and save our city."),
        StoryLine(ROG, "I was too late. Nullfang was already through the portal with them. I ran after him, but the portal sealed shut before I could follow."),
        StoryLine(ROG, "Now listen. Go and defeat the boss of Frost Peak, and recover your memory. I believe he may know what became of your parents. Stop the monsters he controls, and save this region."),
        StoryLine(me, "I will."),
    )

    private fun sceneFrostTaunt() = listOf(
        StoryLine("", "Grimtusk the Frost Tyrant sits among the ice, his creatures gathered at his feet."),
        StoryLine(me, "Where are my mom and dad? Tell me what you know!"),
        StoryLine(GRIM, "Ha ha ha! You think I'd tell you? There is nothing you can do, little one. You will never find your parents. You will never learn the truth."),
        StoryLine(me, "Then I'll take the truth from you."),
    )

    private fun sceneBossFlashback3() = listOf(
        StoryLine("", "Grimtusk crashes down, and the fragment rises."),
        StoryLine("", "A cave, dark and cold. Behind thick iron bars, two figures: your mother and your father, crying out for you, calling for help."),
        StoryLine("", "The memory cuts out there."),
        StoryLine(me, "They're alive. I know where they're being held now, or near enough. Hold on, Mom, Dad. I'm coming."),
    )

    // ---------- The scenes (Chapter Four) ----------

    private fun sceneDuneEnter() = listOf(
        StoryLine("", "The Sand Dunes burn beneath a hard sun, but the old peace is gone. Creatures prowl the valleys, and sandstorm tornadoes tear across the sand, ripping up everything in their path."),
        StoryLine(me, "It's the same as Frost Peak. I need to reach the nearest village and find out what's happening."),
    )

    private fun sceneDuneVillager() = listOf(
        StoryLine(VIL, "Stranger! Please, you have to help us. We woke up to all this, and none of us knows what's going on."),
        StoryLine(VIL, "I need to ask a personal favor too. My grandparents have disappeared. They went into the caves nearby to gather materials, just as the sand tornadoes and the creatures began to appear."),
        StoryLine(VIL, "That's when the boss of the Sand Dunes showed up and began terrorizing everyone. I don't know which cave they went into. Please, find them and bring them home."),
        StoryLine(me, "I'll find them. Don't worry."),
    )

    private fun sceneCaveHear() = listOf(
        StoryLine("", "Deep in the dark, voices echo off the stone: an old man and an old woman, shouting for help."),
        StoryLine(me, "That must be them!"),
    )

    private fun sceneGrand() = listOf(
        StoryLine("", "Two elderly people stand back to back in the gloom, fending off the creatures as best they can. You rush in and clear the last of the monsters away."),
        StoryLine("The Grandfather", "Thank heavens! Who are you, young man?"),
        StoryLine(me, "Your grandson sent me. I'm here to bring you home."),
        StoryLine("The Grandmother", "Our grandson? Bless him. Lead the way, dear, and we'll follow."),
        StoryLine("", "You lead them out through the tunnels and into the sunlight. They hurry ahead toward the village."),
    )

    private fun sceneDuneReward() = listOf(
        StoryLine(VIL, "You found them! They're home, and they're safe. I can't tell you what this means to me."),
        StoryLine(VIL, "Please, take this food and this gold. It's the least I can do."),
        StoryLine(me, "Thank you. Now I'm going to put an end to whatever is terrorizing your home."),
    )

    private fun sceneDuneTaunt() = listOf(
        StoryLine("", "Khepri the Sun Devourer rises from the dunes: a colossal scarab, sand streaming from his shell."),
        StoryLine(me, "Stop terrorizing these people! Leave this place!"),
        StoryLine(KHEP, "Hah! Hahaha! I was sent here by someone you do not know. And I am the one who caused all of this chaos."),
        StoryLine(KHEP, "I am the greatest monster of the dunes you will ever face. I am dangerous, little boy, and you will die here. Come, and try."),
        StoryLine(me, "Then I will."),
    )

    private fun sceneBossFlashback4() = listOf(
        StoryLine("", "Khepri collapses into the sand, and a fragment surfaces. This one is not a picture of your parents. It is a conversation you overhear."),
        StoryLine("", "Khepri's voice, and another, cold and familiar: Nullfang. They are planning to do something to your parents, something you are never meant to find out. They agree to keep it secret."),
        StoryLine("", "The memory cuts off."),
        StoryLine(me, "Nullfang... what are you doing to them? WHAT ARE YOU DOING TO MY PARENTS?"),
        StoryLine("", "Fury burns through you. You turn away from the fallen scarab and start walking toward the next region."),
    )

    private fun sceneDuneNews() = listOf(
        StoryLine(VIL, "Wait! Is your name Josh?"),
        StoryLine(me, "It is. How do you know?"),
        StoryLine(VIL, "I heard something about your parents. When the boss of the Sand Dunes came through a portal, I heard a man and a woman screaming from the other side. \"Please don't do this to us,\" they begged. Then the portal closed."),
        StoryLine(VIL, "That's all I heard. But I know your parents are somewhere inside the Hollow Deep. You have to go there and save them."),
        StoryLine(me, "Thank you. I will."),
    )

    // ---------- The scenes (Chapter Five) ----------

    private fun sceneDeepEnter() = listOf(
        StoryLine("", "The Hollow Deep: the light is fading and crystals glow faintly in the dark. But unlike every other region, there is nothing. No screaming. No creatures. No danger in sight. Only a deep, uneasy quiet."),
        StoryLine(me, "Why is it so quiet? Something is wrong. I'll explore on foot."),
    )

    private fun sceneKing() = listOf(
        StoryLine("", "In the great hall of the castle, a king sits alone in his chair, peacefully, as if waiting."),
        StoryLine(me, "Your Majesty? What's happened here?"),
        StoryLine("The King", "I... I don't know. All my people have disappeared. I'm the only one left. Creatures roam the Hollow Deep, and I've been too afraid to leave the castle, for fear I'll be taken too."),
        StoryLine("The King", "Please, I beg you. Find my missing people."),
        StoryLine(me, "I'll find them. I'll start with the next village."),
    )

    private fun sceneGloomhaven() = listOf(
        StoryLine("", "In Gloomhaven, a small group of villagers huddle together, the last ones left."),
        StoryLine(VIL, "A traveler! Thank the stars. Something creepy is going on here. People keep disappearing."),
        StoryLine(VIL, "There's a boss somewhere in the Hollow Deep, maybe near the caves. We don't know exactly where."),
        StoryLine(VIL, "Please, defeat it, and bring our people back."),
        StoryLine(me, "I will."),
    )

    private fun sceneRogerWarns() = listOf(
        StoryLine("", "As you leave the village, a familiar voice calls your name. Roger, the Elder, stands on the path behind you."),
        StoryLine(me, "Roger? What are you doing here?"),
        StoryLine(ROG, "I've come to warn you. The boss you're about to face in the Hollow Deep is not like the others."),
        StoryLine(ROG, "There is something I have to tell you. I've known it the whole time, but I waited until your memories had returned, so as not to disrupt them. Now that you are about to face this last boss, I can't hold it back any longer."),
        StoryLine(me, "What are you talking about?"),
        StoryLine(ROG, "The boss you are about to fight is your father."),
        StoryLine("", "Rage floods through you."),
        StoryLine(me, "You knew?! You were supposed to be helping me, and now you tell me the boss I'm about to fight is my own father? That's messed up. I don't believe you."),
        StoryLine(ROG, "Trust me."),
        StoryLine(ROG, "Josh, I am an ultimate wizard. I'm immortal. I've lived some two hundred years, mastering abilities and knowledge in all that time."),
        StoryLine(ROG, "After you left Frost Peak, I accidentally created a portal and went through it. I saw Nullfang turn your father into the boss of the Hollow Deep. And I learned that your mother is safe, still held prisoner in the Grain Rot. Nullfang did all this on purpose, to torment you through your memory fragments."),
        StoryLine(ROG, "The only way to bring your father back is to defeat the boss. The curse will break and he will reform. But the change has hurt him badly, and once it breaks, he won't remember anything."),
        StoryLine(ROG, "Here is the plan. When you win, I'll run in, take your father, and bring him to the wizard in Greenhollow so we can heal him and restore his memory."),
        StoryLine(ROG, "But for all three of you to be fully restored, you must be together. That means you still have to go into the Grain Rot, and rescue your mother."),
        StoryLine(me, "I understand."),
        StoryLine(ROG, "One more thing. Don't go too hard on him, or you could end up killing him for real. Go in there and stop him, carefully."),
    )

    private fun sceneDeepTaunt() = listOf(
        StoryLine("", "The boss of the Hollow Deep looms before you, a towering shape of stone and shadow."),
        StoryLine(me, "Dad? Dad, it's me, Josh!"),
        StoryLine(BOSS, "That ain't your dad."),
        StoryLine("", "Its face melts and reshapes, mockingly, into your father's face."),
        StoryLine(BOSS, "I'm right here, son. Come save your father."),
        StoryLine("", "Then the face twists back into the monster. Rage rises in you, and you catch yourself. Roger's warning rings in your ears: not too hard. Carefully."),
    )

    private fun sceneBossFlashback5() = listOf(
        StoryLine("", "The monster staggers, shrinks, and the curse breaks. Your father collapses, unconscious, and does not stir."),
        StoryLine(ROG, "I've got him! I'm taking him to Greenhollow, just as planned."),
        StoryLine("", "Roger lifts your father in his arms, and is gone."),
        StoryLine("", "Another fragment surfaces: what Roger had been talking about. Nullfang, standing over your mother, about to do something to her. The memory cuts off before it shows what."),
        StoryLine(me, "Nullfang... I'm coming for you."),
        StoryLine("", "Furious, you set out for the caves where the boss was hiding."),
    )

    private fun sceneKey() = listOf(
        StoryLine("", "Deep in the cave, something glints against the stone: a heavy iron key, marked with two letters: GR."),
        StoryLine(me, "What is this? GR?"),
        StoryLine("", "You take it. Across the Hollow Deep, the missing villagers reappear, blinking and bewildered, as if waking from a long sleep."),
    )

    private fun sceneKingReward() = listOf(
        StoryLine(me, "Your Majesty, your people are back. They're all safe."),
        StoryLine("The King", "They're back? Truly? Thank you, brave traveler. Thank you!"),
        StoryLine("The King", "Take this as your reward: a set of Grain Rot armor. You'll need it for when you go inside the Grain Rot portal."),
        StoryLine(me, "The Grain Rot portal? What do you mean?"),
        StoryLine("The King", "Go back to Greenhollow and speak with Roger the Elder and the wizard there. They will explain everything."),
    )

    private fun sceneReturn() = listOf(
        StoryLine("", "In the wizard's house in Greenhollow, Roger and the wizard are waiting."),
        StoryLine(ROG, "Josh. Your father is in critical condition, but the wizard has been healing him, and he's stable now."),
        StoryLine(ROG, "That key you're carrying. Where did you find it?"),
        StoryLine(me, "In the caves in the Hollow Deep."),
        StoryLine(ROG, "I know it. That is the key to the original portal, the one you were thrown out of. The true, main key into the Grain Rot. The portals I made myself were never strong enough."),
        StoryLine(ROG, "My power couldn't hold me in the Grain Rot. I lasted two seconds before I was forced out. But with the GR key, you'll have full access."),
        StoryLine(ROG, "Inside, you'll find the two remaining servants, and Vely himself. You have to stop him."),
        StoryLine(me, "Vely? Who's Vely?"),
        StoryLine(ROG, "Vely is the one behind everything. He has controlled all the biomes, and sent the servants after the people, to take over the regions."),
        StoryLine(ROG, "Don't worry about me, or the wizard, or your father. Just stop the servants, and Vely."),
        StoryLine(me, "I'll do it."),
    )

    // ---------- The scenes (the Secret Ending) ----------

    private fun scenePortal() = listOf(
        StoryLine("", "Before you stands the Grain Rot portal, black stone ringed in dead green light."),
        StoryLine("", "You raise the GR key toward it. A beam shoots from the key into the stone, and a keyhole opens in the portal. It unlocks, swirling violet and green."),
        StoryLine("", "You walk through."),
        StoryLine("", "As you step out, the landscape starts to look familiar, as if you've been here before, from the very start. It is the Grain Rot, but deeper into chaos than ever: more of the corrupted grain, more Grain Rot monsters everywhere. An overcast sky hangs over the whole land."),
        StoryLine("", "Below you, the two remaining servants direct the monsters and the enslaved villages. And far off, on top of a hill, stands a castle. That must be where Vely waits."),
        StoryLine(me, "I can do this. I've got to go save my mom. I've got to bring her back, so we can be a family again."),
    )

    private fun sceneCityFlash() = listOf(
        StoryLine("", "You start walking deeper into the Grain Rot. Suddenly your legs give way. You fall back, and pass out."),
        StoryLine("", "A flash: a beautiful city. Your mother and father sit together, laughing, having a good time. Villagers all around enjoy themselves in the sun."),
        StoryLine("", "It becomes clear. The Grain Rot was your home, your home city, before Vely took it over and turned it into chaos."),
        StoryLine("", "You wake on your own, burning with rage."),
        StoryLine(me, "Why would anyone do this to my home? I've got to do this. I've got to understand. I've got to know what I need to do."),
    )

    private fun sceneRealmVillage() = listOf(
        StoryLine("", "In the ruins, a village still stands. Villagers rush up and hurry you inside, before the servants can spot you."),
        StoryLine(RVIL, "We're so glad you're here! And your mother is still trapped."),
        StoryLine(RVIL, "Vely turned your mother into one of his own servants. The first servant."),
        StoryLine(me, "What? Are you serious?!"),
        StoryLine(RVIL, "Ever since you disappeared, our village has been a dark green abyss. One of our own sons saw it with his own eyes: your mother being changed into a servant."),
        StoryLine(RVIL, "She's being held inside the castle, in Vely's own domain. You have to go in and save her."),
        StoryLine(RVIL, "You must kill Vely's two remaining servants before you can reach him. Then stop Vely, and bring peace back to our village."),
        StoryLine(me, "I understand."),
    )

    private fun sceneServant1Taunt() = listOf(
        StoryLine("The First Servant", "Oh, I see you're back."),
        StoryLine(me, "You've done enough. I'm here to stop you and bring my village back. What you're doing isn't right. It's terrible, and it has to stop."),
        StoryLine("The First Servant", "Hah! I'm not going to stop."),
    )

    private fun sceneServant1Down() = listOf(
        StoryLine("", "The first servant falls. No memory fragment stirs. Josh realizes there are none left to find here."),
        StoryLine(me, "Then I press on, to the second servant."),
    )

    private fun sceneServant2Taunt() = listOf(
        StoryLine("The Second Servant", "You just killed my brother! Why did you kill my brother?"),
        StoryLine(me, "Because you took over my city, my people. It isn't right."),
        StoryLine("The Second Servant", "You don't deserve this city! My brother and I are the reason it's the way it is now, and we were happy here."),
        StoryLine("", "In a full rage, you charge."),
    )

    private fun sceneServant2Down() = listOf(
        StoryLine("The Second Servant", "Good luck, by the way. You're not going to like it when you face our boss up there."),
        StoryLine("", "The second servant falls. Ahead, a castle looms on the hill, and you start walking up toward it."),
    )

    private fun sceneVelyTaunt() = listOf(
        StoryLine("", "As you climb toward the castle, a strange pain wells up inside you, as if you can sense your mother, but can't understand how."),
        StoryLine("", "The Grain Rot armor and weapons you carry seem to be trying to tell you something, but all you hear is gibberish. You nearly pass out. You push through, get back up, and open the castle door."),
        StoryLine("Vely", "Oh, I see you came back."),
        StoryLine(me, "Your terror is over, Vely. I'm taking my city back."),
        StoryLine("Vely", "There's nothing you can do about it. You'll never find your mother here. You'll never find her at all."),
        StoryLine(me, "Stop terrorizing my city and my people! They don't deserve this."),
        StoryLine("Vely", "I am the greatest overpower of the Grain Rot. You will never find your mother. You're a little boy who doesn't know anything. There's a secret you will never uncover: what is actually going on."),
        StoryLine(me, "I'm going to stop you."),
        StoryLine("Vely", "Bring it, boy."),
    )

    private fun sceneVelyReveal() = listOf(
        StoryLine("Vely", "So... you actually beat me. Then you've earned the biggest secret of all: what truly happened to your mother."),
        StoryLine(me, "What are you talking about?"),
        StoryLine("Vely", "I am your mother."),
        StoryLine("", "You stand frozen."),
        StoryLine("Vely", "She went out looking for food. She came upon a Grain Rot tree, and she didn't know what it was. She saw the fruit, and took a bite."),
        StoryLine("Vely", "The poison spread through her blood and her veins, and began turning her into Vely. She lost consciousness, and control of herself completely. The Grain Rot inside her became Vely, and Vely terrorized everyone."),
        StoryLine("Vely", "You killed my people across Greenhollow, the Whisperwoods, Frost Peak, the Sand Dunes, and the Hollow Deep. Tell me, how did you like meeting your own father as the Hollow Deep's boss?"),
        StoryLine(me, "My father is fine now. He's recovering, thanks to me."),
        StoryLine("Vely", "Hm. Then since you made it this far, you can have your mother back. You've lifted the curse."),
        StoryLine("", "The curse breaks. Your mother lies there as it lifts. Far away, your home city is freed: blue skies and green grass return, and the villagers celebrate."),
        StoryLine("", "In the castle, you run to her side."),
        StoryLine("Mother", "Son. You've saved me."),
        StoryLine(me, "Yes, Mother. I've saved you."),
        StoryLine("Mother", "I never meant for any of this to happen."),
        StoryLine(me, "It's okay. I understand."),
        StoryLine("Mother", "This castle was yours, Josh. You were the last Keystone king, meant to be the overseer and protector of our people. But once I became Vely, I ruled it instead."),
        StoryLine(me, "I couldn't control what happened. I'm sorry."),
        StoryLine("", "She hugs you, crying."),
        StoryLine(me, "Dad is safe. I'll explain everything once we're back in Greenhollow."),
        StoryLine("Mother", "Greenhollow? What is that?"),
        StoryLine(me, "I'll explain later."),
        StoryLine("", "The Grain Rot itself opens a portal for you. You pick up your mother and carry her through, full circle to where it all began."),
    )

    private fun sceneEnding() = listOf(
        StoryLine(ROG, "You got your mother! You saved her!"),
        StoryLine(me, "I did. There's a lot I need to tell you."),
        StoryLine(ROG, "There's no time to waste. We need to get everyone's memories back fully."),
        StoryLine(WIZ, "Roger, it's your time to act. I don't have the power for this. Only you do."),
        StoryLine(ROG, "Josh, you and your parents, hold hands in a circle. A Keystone will rise in the middle, and when you touch it together, all your memories will be restored."),
        StoryLine("", "The three of you join hands. A keystone rises from the ground between you. You let go, reach out, and grab it together. A beam of light shoots into your heads, restoring every missing fragment and fully healing you.", 1),
        StoryLine("", "Overwhelmed with gratitude, you embrace Roger."),
        StoryLine("Father", "Roger, I know you tried to save us. Thank you for finding our son, and sending him to bring us home."),
        StoryLine("Mother", "Thank you, Roger."),
        StoryLine(ROG, "It's no trouble. I didn't even know who Josh truly was at the time."),
        StoryLine(ROG, "There's one more thing I want to do."),
        StoryLine("", "Roger walks to the Grain Rot portal and reopens it."),
        StoryLine(ROG, "Now that Vely is defeated and the curse lifted, my powers have fully returned. I could teleport anywhere now. But I'm leaving this portal open for good, so your family can visit the Grain Rot and keep adventuring there whenever you want."),
        StoryLine(ROG, "Now tell me, Josh. Who was Vely, really?"),
        StoryLine(me, "My mother went out for food, found a Grain Rot tree, and ate the fruit without knowing what it was. The poison took over her blood and turned her into Vely, a vessel with no control of herself, used to dominate both worlds."),
        StoryLine(me, "Now that Vely is defeated and the curse lifted, everything is back to normal."),
        StoryLine("", "You all embrace."),
        StoryLine(me, "Roger, come back with us to our own village."),
        StoryLine(ROG, "I'd love to. But I have to stay. I have to make sure my people are safe."),
        StoryLine(ROG, "I'm not just a wizard, or the king of Greenhollow. I'm the king and ultimate high wizard of the whole world: Greenhollow, the Whisperwoods, Frost Peak, the Sand Dunes, and the Hollow Deep alike."),
        StoryLine(me, "If you're that powerful, why couldn't you stop Vely yourself?"),
        StoryLine(ROG, "When the Grain Rot curse took hold, it infected and suppressed my own powers too. I couldn't act. You were the chosen one, Josh, the only one who could. And I'm glad it was you."),
        StoryLine("", "As he speaks, Roger transforms into his true form: the king, with all of his power and authority fully restored.", 2),
        StoryLine(ROG, "If it weren't for you, none of us would still be here."),
    )

    private companion object {
        const val WIZ = "The Wizard"
        const val ELD = "The Elder"
        const val VIL = "The Villager"
        const val REC = "The Recluse"
        const val ROG = "Roger"
        const val GRIM = "Grimtusk"
        const val KHEP = "Khepri"
        const val BOSS = "The Boss"
        const val RVIL = "The Villager"
        /** How many villagers you have to ask before moving on. */
        const val NEED_ASKED = 2
        /** How many monsters attack the villager in the Whisperwoods. */
        const val AMBUSH_TOTAL = 3
        val VILLAGER_REPLIES = arrayOf(
            "I'm sorry, I've never seen you before. You're the one they carried in, aren't you? You should speak to the Elder by the notice board. He's lived here longer than anyone.",
            "No, stranger, I don't know you. Strange thing is, lately I can't remember half of what I did last week either. The Elder by the notice board might know why.",
            "I wish I could help. Everyone here has been forgetful lately. Ask the Elder, he's seen two hundred years of strange things.",
            "Never seen you before, I'm afraid. If anyone knows anything, it'll be the Elder near the notice board.",
        )
        val WOODS_REPLIES = arrayOf(
            "No, I don't know you, traveler. We were all told to work together to make this city better, but nobody can tell me what's really going on.",
            "Your face is new to me. Strange things lately: witches in the trees, spiders in the dark. The man in Fernhollow might know more.",
            "I wish I could help. My own memory has been foggy for ages. Maybe it's the witches' doing.",
            "Never seen you before. Whatever's happening here, I hope you can stop it.",
        )
    }
}
