package com.keystone.rpg

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/** Player state. Updated on the drawing thread, read by the screen overlay. */
class Game(val world: World) {
    // Position in metres. y is eye height.
    @Volatile var x = world.spawnX
        private set
    @Volatile var z = world.spawnZ
        private set
    @Volatile var eyeY = world.groundAt(world.spawnX, world.spawnZ) + EYE
        private set
    @Volatile var yaw = world.spawnYaw
        private set
    @Volatile var pitch = -0.05f
        private set
    var time = 0f
        private set

    /** Time of day and weather. */
    val weather = Weather()

    /** True when standing on a floor inside a house or castle (rain goes quiet). */
    @Volatile var indoors = false
        private set

    /** Zone for the drawing thread (the screen overlay uses [zone]). */
    @Volatile var currentZone = Zone.MEADOW
        private set

    // Left thumb: -1..1 each way. Set by the touch handler.
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f

    /** Run button: on or off. */
    @Volatile var runOn = false

    /** 0..1. Running and jumping use it up; it comes back when you rest. */
    @Volatile var stamina = 1f
        private set

    /** True after running out: you have to catch your breath before running again. */
    @Volatile var winded = false
        private set

    @Volatile private var jumpAsked = false
    private var feetY = world.groundAt(world.spawnX, world.spawnZ)
    private var vy = 0f
    private var airborne = false
    private var restTimer = 0f

    // Right thumb: turning, collected until the next frame.
    private val lookLock = Any()
    private var lookX = 0f
    private var lookY = 0f

    // For the screen overlay.
    var zone by mutableStateOf(Zone.MEADOW)
        private set
    var zoneVisit by mutableIntStateOf(0)
        private set
    var hudTick by mutableLongStateOf(0L)
        private set

    /** Named places you've found. Greenhollow, where you start, counts from the beginning. */
    val discovered = BooleanArray(PLACES.size).also { it[0] = true }
    var discoverVisit by mutableIntStateOf(0)
        private set
    var lastDiscovered by mutableStateOf("")
        private set

    /** Region colours and borders, laid over the big map. */
    val regionOverlay: ImageBitmap

    private val probe = Probe()
    private val placed = Placed()
    private var walk = 0f
    private var stepCount = 0
    private var landed = false
    private var hudTimer = 0f

    // Fog-of-war map: fills in as you explore.
    private val explored = BooleanArray(GRID * GRID)
    private val minimap: Bitmap = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
        // Places you haven't been yet show as a faded, grey map.
        val faded = IntArray(GRID * GRID) { fade(world.mapColors[it]) }
        setPixels(faded, 0, GRID, 0, 0, GRID, GRID)
    }
    val minimapImage: ImageBitmap = minimap.asImageBitmap()
    private var lastCi = -1
    private var lastCj = -1

    init {
        val over = IntArray(GRID * GRID)
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val idx = j * GRID + i
                val r = world.regionMap[idx]
                val border = (i > 0 && world.regionMap[idx - 1] != r) ||
                    (j > 0 && world.regionMap[idx - GRID] != r) ||
                    (i < GRID - 1 && world.regionMap[idx + 1] != r) ||
                    (j < GRID - 1 && world.regionMap[idx + GRID] != r)
                val rgb = Zone.entries[r.toInt()].mapColor
                over[idx] = (if (border) 0xD0 shl 24 else 0x2C shl 24) or rgb
            }
        }
        regionOverlay = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
            setPixels(over, 0, GRID, 0, 0, GRID, GRID)
        }.asImageBitmap()
        reveal()
    }

    /** Map grid square you're in, like "H-7": letters down the side, numbers along the top. */
    fun gridRef(): String {
        val col = (x / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        val row = (z / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        return "${'A' + row}-$col"
    }

    fun jump() {
        jumpAsked = true
    }

    fun addLook(dx: Float, dy: Float) {
        synchronized(lookLock) {
            lookX += dx
            lookY += dy
        }
    }

    fun update(dt: Float) {
        time += dt
        synchronized(lookLock) {
            yaw -= lookX
            pitch = (pitch - lookY).coerceIn(-1.2f, 1.2f)
            lookX = 0f
            lookY = 0f
        }

        val mx = moveX
        val my = moveY
        val len = hypot(mx, my)
        val moving = len > 0.05f
        val sprinting = moving && runOn && !winded
        if (moving) {
            val limit = if (len > 1f) 1f / len else 1f
            val sy = sin(yaw)
            val cy = cos(yaw)
            // Forward is where we look; right is 90 degrees clockwise from it.
            val wx = (sy * -my + -cy * mx) * limit
            val wz = (cy * -my + sy * mx) * limit
            val step = (if (sprinting) RUN_SPEED else WALK_SPEED) * dt
            tryMove(x + wx * step, z)
            tryMove(x, z + wz * step)
            walk += dt * len.coerceAtMost(1f) * (if (sprinting) 1.5f else 1f)
        }

        // Stamina.
        if (sprinting) {
            stamina -= dt / RUN_SECONDS
            restTimer = 0f
            if (stamina <= 0f) {
                stamina = 0f
                winded = true
            }
        } else {
            restTimer += dt
            if (restTimer > 0.8f) stamina = (stamina + dt / RECOVER_SECONDS).coerceAtMost(1f)
        }
        if (winded && stamina > 0.3f) winded = false

        // Jumping and falling.
        val ground = world.groundAt(x, z, feetY)
        val floor = if (ground < 0f && !world.onBridge(x, z)) ground.coerceAtLeast(-0.9f) else ground
        if (jumpAsked) {
            jumpAsked = false
            if (!airborne && stamina >= JUMP_COST) {
                vy = JUMP_SPEED
                airborne = true
                stamina -= JUMP_COST
                restTimer = 0f
            }
        }
        if (airborne) {
            vy -= GRAVITY * dt
            feetY += vy * dt
            if (feetY <= floor) {
                feetY = floor
                vy = 0f
                airborne = false
                landed = true
            }
        } else if (floor < feetY - 0.8f) {
            airborne = true
            vy = 0f
        } else {
            feetY += (floor - feetY) * (dt * 14f).coerceAtMost(1f)
        }
        val bob = if (moving && !airborne) abs(sin(walk * 9f)) * (if (sprinting) 0.1f else 0.07f) else 0f
        eyeY = feetY + EYE + bob

        world.probe(x, z, probe)
        val si = probe.siteIndex
        if (si >= 0 && !discovered[si] && probe.siteCenter < PLACES[si].radius + 35f) {
            discovered[si] = true
            lastDiscovered = PLACES[si].name
            discoverVisit = discoverVisit + 1
        }
        val zNow = probe.zone
        if (zNow != currentZone) {
            currentZone = zNow
            zone = zNow
            zoneVisit = zoneVisit + 1
        }

        weather.update(dt, currentZone)

        // Footsteps, matched to what's underfoot.
        val under = world.floorUnder(x, z, feetY)
        indoors = under == 1 || under == 2
        if (landed) {
            landed = false
            Sound.step(surface(under), 1.25f)
        } else if (moving && !airborne) {
            val sc = kotlin.math.floor(walk * 9f / 3.1415927f).toInt()
            if (sc != stepCount) {
                stepCount = sc
                Sound.step(surface(under), if (sprinting) 1f else 0.75f)
            }
        }
        Sound.wind = weather.windFor(currentZone)
        Sound.rain = weather.rainFor(currentZone)
        Sound.indoors = indoors

        reveal()
        hudTimer += dt
        if (hudTimer > 0.08f) {
            hudTimer = 0f
            hudTick = hudTick + 1
        }
    }

    /** Which footstep sound to play here. [under] comes from [World.floorUnder]. */
    private fun surface(under: Int): Int {
        if (under == 1 || under == 3) return Surface.WOOD
        if (under == 2) return Surface.STONE
        val t = world.terrainAt(x, z)
        if (t < -0.05f) return Surface.WATER
        val hx = world.terrainAt(x + 1f, z) - world.terrainAt(x - 1f, z)
        val hz = world.terrainAt(x, z + 1f) - world.terrainAt(x, z - 1f)
        val flat = 2f / sqrt(hx * hx + hz * hz + 4f)
        return when (groundFlag(probe, x, z, t, flat)) {
            FLAG_GRASS -> Surface.GRASS
            FLAG_DIRT -> Surface.DIRT
            FLAG_SAND -> Surface.SAND
            FLAG_SNOW -> Surface.SNOW
            FLAG_STONE -> Surface.STONE
            else -> Surface.ROCK
        }
    }

    private fun tryMove(nx: Float, nz: Float) {
        if (world.isBlocked(nx, nz, probe)) return
        if (world.hitsObstacle(nx, nz, RADIUS, placed, probe, feetY)) return
        x = nx
        z = nz
    }

    private fun reveal() {
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        if (ci == lastCi && cj == lastCj) return
        lastCi = ci
        lastCj = cj
        val r = REVEAL_CELLS
        for (dj in -r..r) {
            for (di in -r..r) {
                if (di * di + dj * dj > r * r) continue
                val i = ci + di
                val j = cj + dj
                if (i < 0 || j < 0 || i >= GRID || j >= GRID) continue
                val idx = j * GRID + i
                if (explored[idx]) continue
                explored[idx] = true
                minimap.setPixel(i, j, world.mapColors[idx])
            }
        }
    }

    companion object {
        const val EYE = 1.7f
        const val WALK_SPEED = 6.5f
        const val RUN_SPEED = 12.5f
        const val RUN_SECONDS = 7f
        const val RECOVER_SECONDS = 5f
        const val JUMP_SPEED = 7.2f
        const val JUMP_COST = 0.08f
        const val GRAVITY = 22f
        const val RADIUS = 0.4f
        const val REVEAL_CELLS = 24
        const val MAP_GRID = 17

        private fun fade(c: Int): Int {
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val grey = (r * 0.3f + g * 0.59f + b * 0.11f)
            val fr = ((r + (grey - r) * 0.75f) * 0.5f + 18f).toInt().coerceIn(0, 255)
            val fg = ((g + (grey - g) * 0.75f) * 0.5f + 16f).toInt().coerceIn(0, 255)
            val fb = ((b + (grey - b) * 0.75f) * 0.5f + 22f).toInt().coerceIn(0, 255)
            return (0xFF shl 24) or (fr shl 16) or (fg shl 8) or fb
        }
    }
}
