package com.keystone.rpg

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Player state. Updated on the drawing thread, read by the screen overlay. */
class Game(val world: World) {
    // Position in metres. y is eye height.
    @Volatile var x = world.spawnX
        private set
    @Volatile var z = world.spawnZ
        private set
    @Volatile var eyeY = world.groundAt(world.spawnX, world.spawnZ) + EYE
        private set
    @Volatile var yaw = world.spawnYaw
        private set
    @Volatile var pitch = -0.05f
        private set
    var time = 0f
        private set

    /** Time of day and weather. */
    val weather = Weather()

    /** The animals and birds living around you. */
    val fauna = Fauna(world)

    /** Camera behind the hero (true) or looking out through his eyes (false). */
    @Volatile var thirdPerson = true

    /** When on, the hero turns and punches anything that comes within reach by himself. */
    @Volatile var autoFight = false

    // ---------- Treasure ----------
    /** Chests and hidden caves, always in the same places. */
    val treasure = Treasure(world)
    /** Your bag, what you're wearing, your gold. */
    val loot = Loot()
    /** Everyone living in the towns, camps and castles. */
    val people = People(world)
    /** Main missions and side quests. */
    val quests = Quests(people, fauna, treasure, world)
    /** The brick wall dividing each region, and the one gateway through each. */
    val borders = Borders(world)
    /** Everything you build, and the wood, stone and iron you've gathered for it. */
    val base = Base(world)

    // ---------- Building and gathering ----------
    /** Build mode: aim at a spot and a glowing outline shows where the piece will snap into place. */
    var buildMode by mutableStateOf(false)
    /** Which piece you're placing: see [PieceType]. */
    var buildType by mutableIntStateOf(PieceType.FOUNDATION)
    @Volatile private var buildRot = 0
    @Volatile private var placeAsked = false
    @Volatile private var removeAsked = false
    /** Where the next piece would go, and whether it can: the renderer draws it. */
    val ghost = Ghost()
    /** One line about the piece you're aiming: what it costs, or why it won't go there. */
    @Volatile var buildHint = ""
        private set
    /** Bumps to open the crafting window, when you use a bench. */
    var craftVisit by mutableIntStateOf(0)
        private set
    /** Words for the context button when it's about building or gathering. */
    @Volatile var actionLabel = ""
        private set
    /** "+2 wood" and so on, each time a blow lands on a tree or rock. */
    @Volatile var resToast = ""
        private set
    var resVisit by mutableIntStateOf(0)
        private set
    // Where the camera looked last frame, for aiming the piece you're placing.
    private var rayOx = 0f
    private var rayOy = 0f
    private var rayOz = 0f
    private var rayDx = 0f
    private var rayDy = 0f
    private var rayDz = 1f
    private var rayBack = 0f
    private val aimAt = FloatArray(3)
    // Chopping and mining.
    private var harvesting = false
    private var harvestQueued = false
    private var harvestCell = -1
    private var harvestLeft = 0
    private var handCount = 0
    private var nearCut = -1
    private var nearCutWood = true
    private var nearCutX = 0f
    private var nearCutZ = 0f
    private var cutScan = 0f
    private var toolTimer = 0f
    private var toolKind = 0
    private val cutRnd = java.util.Random()
    /** What you're holding instead of your weapon: 0 = nothing, 1 = an axe, 2 = a pickaxe. */
    val heldTool: Int get() = if (toolTimer > 0f || harvesting) toolKind else 0
    /** Which swing the hero's arms follow: chopping and mining borrow the sword's. */
    val animClass: Int get() = if (harvesting || heldTool != 0) WeaponClass.SWORD else weaponClass

    // ---------- Talking and trading ----------
    /** Who you're talking to (the talk window is open), or null. */
    @Volatile var talkingTo: Npc? = null
        private set
    /** What they said. */
    @Volatile var talkLine = ""
        private set
    /** Who you're trading with (the trade window is open), or null. */
    @Volatile var trading: Npc? = null
        private set
    var talkVersion by mutableIntStateOf(0)
        private set
    private var nearNpc: Npc? = null
    private var chatCount = 0
    /** Things the screen asked for, done on the game's own thread. */
    private val jobs = java.util.concurrent.ConcurrentLinkedQueue<() -> Unit>()
    /** Short news about quests: "Quest complete!" and so on. */
    @Volatile var questToast = ""
        private set
    var questVisit by mutableIntStateOf(0)
        private set
    /** Map markers: x, z, kind (0 = where a quest sends you, 1 = hand it in here, 2 = new work here). */
    @Volatile var marks = FloatArray(0)
        private set
    private var markTimer = 0f
    /** Cave you're inside (index into treasure.caves), or -1 out in the world. */
    @Volatile var inCave = -1
        private set
    /** Mesh of the cave you're in, for the renderer to upload. [caveMeshId] changes with each new one. */
    @Volatile var caveData: java.nio.ByteBuffer? = null
        private set
    @Volatile var caveCount = 0
        private set
    @Volatile var caveMeshId = 0
        private set
    /** What the context button does right now: see [ACTION_NONE] etc. */
    @Volatile var action = ACTION_NONE
        private set
    @Volatile private var interactAsked = false
    @Volatile private var pendingHeal = 0f
    /** Black fade when going in and out of caves, from 1 to 0. */
    @Volatile var fade = 0f
        private set
    /** What came out of the last chest, for the pop-up. */
    @Volatile var lastLoot: List<Item> = emptyList()
        private set
    var lootVisit by mutableIntStateOf(0)
        private set

    /** Most health you can have: grows with your level and what you're wearing. */
    val maxHealth: Float get() = MAX_HEALTH + (loot.level - 1) * 12f + loot.vitality
    /** Your level and progress to the next, for the bars at the bottom of the screen. */
    val level: Int get() = loot.level
    val xpFrac: Float get() = if (loot.level >= MAX_LEVEL) 1f else loot.xp.toFloat() / loot.xpNeeded(loot.level)
    /** Bumps each time you level up, to show the banner. */
    var levelVisit by mutableIntStateOf(0)
        private set
    /** "+48 XP" after a kill, and [xpVisit] to show it. */
    @Volatile var xpToast = ""
        private set
    var xpVisit by mutableIntStateOf(0)
        private set
    /** Title for the pop-up: treasure from a chest, or something a monster dropped. */
    @Volatile var lootTitle = "TREASURE!"
        private set
    /** Items monsters have dropped, waiting to be picked up. */
    val drops = ArrayList<Drop>()

    // ---------- Your health ----------
    @Volatile var health = MAX_HEALTH
        private set
    /** Knocked out: you wake up back in Greenhollow a few seconds later. */
    @Volatile var dead = false
        private set
    private var deadTimer = 0f
    private var regenWait = 0f
    /** Red flash round the screen when you get hit, fading from 1. */
    @Volatile var hurtFlash = 0f
        private set

    // ---------- The monster you're fighting, for the panel at the top of the screen ----------
    private var target: Creature? = null
    private var targetSeen = 0f
    @Volatile var targetName = ""
        private set
    @Volatile var targetLevel = 0
        private set
    /** 0..1 health left, or -1 when there's nothing to show. */
    @Volatile var targetFrac = -1f
        private set

    /** The kind of weapon in your hands: see [WeaponClass]. Follows whatever you wield from your bag. */
    var weaponClass by mutableIntStateOf(WeaponClass.SWORD)

    // ---------- Bodies to search ----------
    private val bodyLock = Any()
    private val bodies = ArrayList<Body>()
    private var nearBody: Body? = null
    /** The body you're going through right now (the loot window is open), or null. */
    @Volatile var searching: Body? = null
        private set
    /** Changes whenever the body you're searching changes, so the window redraws. */
    var searchVersion by mutableIntStateOf(0)
        private set

    // ---------- Bosses and the seals between regions ----------
    /** Big news for the banner: a boss appears, or falls. */
    @Volatile var bossTitle = ""
        private set
    @Volatile var bossLine = ""
        private set
    var bossVisit by mutableIntStateOf(0)
        private set
    private val bossAnnounced = BooleanArray(BOSSES.size)

    // ---------- World bosses ----------
    /** What the world boss line on screen says: when the next one's due, or where it is now. */
    var wbText by mutableStateOf("")
        private set
    /** True while one is out (the line turns red and gold). */
    var wbOut by mutableStateOf(false)
        private set
    /** Where it is, for the map (NaN while none is out). */
    @Volatile var wbMapX = Float.NaN
        private set
    @Volatile var wbMapZ = Float.NaN
        private set
    @Volatile var wbMapName = ""
        private set
    private var wbTimer = 0f
    private var wbSpotSlot = Long.MIN_VALUE
    private var wbSpotBoss = -1
    private var wbSpot: FloatArray? = null
    private var wbAnnouncedKey = Long.MIN_VALUE
    private var wbWarnedSlot = Long.MIN_VALUE
    // One called up early for testing (tap the world boss line five times).
    private var wbForcedUntil = 0L
    private var wbForcedKey = 0L
    private var wbForcedBoss = 0
    private var wbForcedSpot: FloatArray? = null
    @Volatile private var wbSummonAsked = false
    private var wbTaps = 0
    private var wbTapAt = 0L
    /** Why you can't go on, when you walk into a sealed region. */
    @Volatile var sealText = ""
        private set
    var sealVisit by mutableIntStateOf(0)
        private set
    private var sealWait = 0f
    private var sealTimer = 0f
    /** The monster in the panel at the top is a boss. */
    @Volatile var targetBoss = false
        private set

    @Volatile private var attackAsked = false
    private var attackTimer = 0f
    private var attackLength = 1f
    private var nextHit = 0
    /** How far through the current attack we are, 0..1, or -1 when not attacking. */
    val attackPhase: Float get() = if (attackTimer > 0f) 1f - attackTimer / attackLength else -1f

    // ---------- Lock-on: keeps facing whatever you're fighting, even while you walk round it ----------
    /** The monster the camera/body locks onto. Cleared when it dies, flees too far, or you tap LOCK again. */
    private var lockTarget: Creature? = null
    @Volatile var locked = false
        private set
    private var lockHoldTimer = 0f

    // ---------- Dodge roll ----------
    @Volatile private var dodgeAsked = false
    private var dodgeTimer = 0f
    private var dodgeCooldown = 0f
    private var dodgeDirX = 0f
    private var dodgeDirZ = 0f
    /** 0..1 through the current roll, or -1 when not rolling. */
    val dodgePhase: Float get() = if (dodgeTimer > 0f) 1f - dodgeTimer / DODGE_TIME else -1f
    /** True for the invulnerable window in the middle of the roll. */
    val dodging: Boolean get() = dodgeTimer > 0f
    /** True while the roll button is on cooldown, for the HUD to grey it out. */
    val dodgeReady: Boolean get() = dodgeCooldown <= 0f
    /** False while the kunai is flying; a new one appears in your hand a moment later. */
    val weaponInHand: Boolean get() {
        if (weaponClass != WeaponClass.KUNAI || harvesting) return true
        val p = attackPhase
        return p < 0.45f || p > 0.85f
    }

    /** Thrown kunai: x, y, z, vx, vy, vz, age (-1 = not flying). */
    val kunai = FloatArray(KUNAI_MAX * 7).also { for (i in 0 until KUNAI_MAX) it[i * 7 + 6] = -1f }
    private var aimX = 0f
    private var aimY = 0f
    private var aimZ = 0f
    private var aimed = false

    // What the hero model needs to animate itself.
    /** Height of the soles of your feet. */
    val feet: Float get() = feetY
    /** Which way the body faces. In third person he turns to face where he's walking. */
    var bodyYaw = world.spawnYaw
        private set
    /** Walk cycle: one full turn is a left and a right step. */
    val stridePhase: Float get() = walk * 9f + 1.5707964f
    /** 0 standing, 1 moving at full speed. */
    var moveAmount = 0f
        private set
    /** 0 walking, 1 sprinting. */
    var runAmount = 0f
        private set
    /** 0 on the ground, 1 in the air. */
    var airAmount = 0f
        private set

    /**
     * Dust, sand, snow and splashes kicked up by your feet. Each puff: x, y, z,
     * age (0 new .. 1 gone), kind (see [PUFF_DIRT] etc.), size.
     */
    val puffs = FloatArray(PUFFS * 6).also { for (i in 0 until PUFFS) it[i * 6 + 3] = 1f }
    private var nextPuff = 0
    private var footSide = 1f
    private var camDist = 4f
    private var climbing = false

    /** True when standing on a floor inside a house or castle (rain goes quiet). */
    @Volatile var indoors = false
        private set

    /** Zone for the drawing thread (the screen overlay uses [zone]). */
    @Volatile var currentZone = Zone.MEADOW

    // Left thumb: -1..1 each way. Set by the touch handler.
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f

    /** Run button: on or off. */
    @Volatile var runOn = false

    /** 0..1. Running and jumping use it up; it comes back when you rest. */
    @Volatile var stamina = 1f
        private set

    /** True after running out: you have to catch your breath before running again. */
    @Volatile var winded = false
        private set

    @Volatile private var jumpAsked = false
    private var feetY = world.groundAt(world.spawnX, world.spawnZ)
    private var vy = 0f
    private var airborne = false
    private var restTimer = 0f

    // Right thumb: turning, collected until the next frame.
    private val lookLock = Any()
    private var lookX = 0f
    private var lookY = 0f

    // For the screen overlay.
    var zone by mutableStateOf(Zone.MEADOW)
        private set
    var zoneVisit by mutableIntStateOf(0)
        private set
    var hudTick by mutableLongStateOf(0L)
        private set

    /** Named places you've found. Greenhollow, where you start, counts from the beginning. */
    val discovered = BooleanArray(PLACES.size).also { it[0] = true }
    var discoverVisit by mutableIntStateOf(0)
        private set
    var lastDiscovered by mutableStateOf("")
        private set

    /** Region colours and borders, laid over the big map. */
    val regionOverlay: ImageBitmap

    private val probe = Probe()
    private val placed = Placed()
    private var walk = 0f
    private var stepCount = 0
    private var landed = false
    private var posSaveTimer = 0f
    private var hudTimer = 0f

    // Fog-of-war map: fills in as you explore.
    private val explored = BooleanArray(GRID * GRID)
    private val minimap: Bitmap = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
        // Places you haven't been yet show as a faded, grey map.
        val faded = IntArray(GRID * GRID) { fade(world.mapColors[it]) }
        setPixels(faded, 0, GRID, 0, 0, GRID, GRID)
    }
    val minimapImage: ImageBitmap = minimap.asImageBitmap()
    private var lastCi = -1
    private var lastCj = -1

    init {
        world.base = base
        // Now that the treasure is laid out, let the thick woods and rock fields grow round it.
        for (c in treasure.chests) if (c.cave < 0) world.keepClear(c.x, c.z, 4f)
        for (cv in treasure.caves) world.keepClear(cv.x, cv.z, 8f)
        for (i in treasure.lairX.indices) world.keepClear(treasure.lairX[i], treasure.lairZ[i], 30f)
        world.denseReady = true
        val over = IntArray(GRID * GRID)
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val idx = j * GRID + i
                val r = world.regionMap[idx]
                val border = (i > 0 && world.regionMap[idx - 1] != r) ||
                    (j > 0 && world.regionMap[idx - GRID] != r) ||
                    (i < GRID - 1 && world.regionMap[idx + 1] != r) ||
                    (j < GRID - 1 && world.regionMap[idx + GRID] != r)
                val rgb = Zone.entries[r.toInt()].mapColor
                over[idx] = (if (border) 0xD0 shl 24 else 0x2C shl 24) or rgb
            }
        }
        regionOverlay = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
            setPixels(over, 0, GRID, 0, 0, GRID, GRID)
        }.asImageBitmap()
        fauna.lairX = treasure.lairX
        fauna.lairZ = treasure.lairZ
        reveal()
    }

    /** Map grid square you're in, like "H-7": letters down the side, numbers along the top. */
    fun gridRef(): String {
        val col = (x / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        val row = (z / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        return "${'A' + row}-$col"
    }

    fun jump() {
        jumpAsked = true
    }

    fun attack() {
        attackAsked = true
    }

    /** Tap to lock onto whatever's nearest in front of you; tap again (or walk far from it) to let go. */
    fun toggleLock() {
        if (lockTarget != null) {
            lockTarget = null
            locked = false
            return
        }
        val found = nearestAnimal(LOCK_RANGE, true) ?: nearestAnimal(LOCK_RANGE, false)
        if (found != null) {
            lockTarget = found
            locked = true
            lockHoldTimer = 0f
        }
    }

    /** Dodge roll: a quick burst out of harm's way, with a moment of invulnerability partway through. */
    fun dodge() {
        dodgeAsked = true
    }

    /** The context button: open a chest, go into a cave, or come back out. */
    fun interact() {
        interactAsked = true
    }

    // ---------- Talking, quests and trading (called from the screen) ----------

    /** The quest the person you're talking to wants to discuss, if any. */
    fun talkQuest(): Quest? {
        val n = talkingTo ?: return null
        if (n.role != NpcRole.QUEST && n.role != NpcRole.LORD) return null
        return quests.forGiver(n.id)
    }

    fun acceptQuest(q: Quest) {
        jobs.add {
            quests.accept(q, loot)
            questToast = "New quest: ${q.title}. It's marked on your map."
            questVisit = questVisit + 1
            talkingTo = null
            talkVersion = talkVersion + 1
        }
    }

    /** Hands in a finished quest: gold, experience and something good. */
    fun handInQuest(q: Quest) {
        jobs.add {
            if (quests.complete(q)) {
                val item = loot.rewardItem(q.tier, q.main)
                loot.addItem(item)
                loot.addGold(q.gold)
                gainXp(q.xp, q.gold)
                lootTitle = "QUEST COMPLETE"
                lastLoot = listOf(Item(Slot.POTION, 0, 4, "${q.gold} gold", 0, 0, -1, 0), item)
                lootVisit = lootVisit + 1
                Sound.call(0, 1f)
            }
            talkVersion = talkVersion + 1
        }
    }

    fun closeTalk() {
        talkingTo = null
        talkVersion = talkVersion + 1
    }

    /** From talking to a trader to looking at their goods. */
    fun openTrade() {
        val n = talkingTo ?: return
        synchronized(n) {
            if (n.stock == null) {
                n.stock = ArrayList(loot.traderStock(tierOf(n.zone), n.id * 7919L + 13L, PLACES[n.place].kind == Site.CASTLE))
            }
        }
        trading = n
        talkingTo = null
        talkVersion = talkVersion + 1
    }

    fun closeTrade() {
        trading = null
        talkVersion = talkVersion + 1
    }

    /** The trader's goods, for the screen. */
    fun tradeStock(): List<Item> {
        val n = trading ?: return emptyList()
        return synchronized(n) { n.stock?.let { ArrayList(it) } ?: emptyList() }
    }

    /** Buys the trader's item at [index]. False if you can't afford it. */
    fun buy(index: Int): Boolean {
        val n = trading ?: return false
        var ok = false
        synchronized(n) {
            val st = n.stock ?: return false
            if (index !in st.indices) return false
            val item = st[index]
            if (loot.buy(item, loot.buyPrice(item))) {
                st.removeAt(index)
                ok = true
            }
        }
        if (ok) Sound.step(Surface.WOOD, 1f)
        talkVersion = talkVersion + 1
        return ok
    }

    /** Sells your bag item at [index] to the trader. */
    fun sell(index: Int) {
        if (trading == null) return
        if (loot.sell(index) > 0) Sound.step(Surface.WOOD, 1f)
        talkVersion = talkVersion + 1
    }

    // ---------- The loot window ----------

    /** What's left on the body you're searching. */
    fun searchItems(): List<Item> = synchronized(bodyLock) { searching?.items?.let { ArrayList(it) } ?: emptyList() }
    fun searchGold(): Int = synchronized(bodyLock) { searching?.gold ?: 0 }
    fun searchName(): String = searching?.name ?: ""

    /** Takes item [index] off the body and puts it in your bag. */
    fun takeItem(index: Int) {
        var got: Item? = null
        synchronized(bodyLock) {
            val b = searching ?: return
            if (index in b.items.indices) got = b.items.removeAt(index)
        }
        got?.let { loot.addItem(it) }
        searchVersion = searchVersion + 1
    }

    fun takeGold() {
        var coins = 0
        synchronized(bodyLock) {
            val b = searching ?: return
            coins = b.gold
            b.gold = 0
        }
        if (coins > 0) loot.addGold(coins)
        searchVersion = searchVersion + 1
    }

    /** Takes everything and closes the window. */
    fun takeAll() {
        val got = ArrayList<Item>()
        var coins = 0
        synchronized(bodyLock) {
            val b = searching ?: return
            got.addAll(b.items)
            b.items.clear()
            coins = b.gold
            b.gold = 0
        }
        loot.addItems(got)
        if (coins > 0) loot.addGold(coins)
        closeSearch()
    }

    fun closeSearch() {
        synchronized(bodyLock) { searching = null }
        searchVersion = searchVersion + 1
    }

    /** Drinks the potion at [index] in your bag. */
    fun drinkPotion(index: Int) {
        val heal = loot.drink(index)
        if (heal > 0) pendingHeal += heal.toFloat()
    }

    /** Uses quick slot [i] along the bottom of the screen: drinks the potion in it, or wears / wields what's in it. */
    fun useQuick(i: Int) {
        if (dead) return
        val heal = loot.useQuick(i)
        if (heal > 0) pendingHeal += heal.toFloat()
    }

    /** Loads your bag and which chests you've opened. Call before playing. */
    fun loadSave(ctx: Context) {
        loot.load(ctx)
        // What you've built first, so you're put back standing on your floor, not inside it.
        base.load(ctx)
        // Your first time: the weapon you just picked. After that, whatever you last had in your hands.
        val wk = loot.weaponKind
        if (wk < 0) loot.giveStarter(weaponClass) else weaponClass = wk
        fauna.bossMask = loot.bossMask
        quests.load(ctx)
        health = maxHealth
        // Put you back where you last were, if that spot is inside the world.
        if (loot.hasSavedPosition) {
            val sx = loot.savedX
            val sz = loot.savedZ
            if (sx > 5f && sz > 5f && sx < WORLD_SIZE - 5f && sz < WORLD_SIZE - 5f) {
                x = sx
                z = sz
                yaw = loot.savedYaw
                bodyYaw = yaw
                feetY = world.groundAt(sx, sz, loot.savedFeet + 0.3f)
                // A tree may have grown where you last stood: step out to the nearest clear spot.
                if (world.hitsObstacle(x, z, RADIUS, placed, probe, feetY)) {
                    var done = false
                    var r = 1f
                    while (!done && r <= 12f) {
                        for (k in 0 until 16) {
                            val a = k * 0.3926991f
                            val nx = sx + sin(a) * r
                            val nz = sz + cos(a) * r
                            if (!world.isBlocked(nx, nz, probe) && !world.hitsObstacle(nx, nz, RADIUS, placed, probe, feetY)) {
                                x = nx
                                z = nz
                                feetY = world.groundAt(nx, nz, feetY + 0.3f)
                                done = true
                                break
                            }
                        }
                        r += 1f
                    }
                }
                vy = 0f
                airborne = false
                eyeY = feetY + EYE
            }
        }
        for (c in treasure.chests) {
            if (loot.isOpened(c.id)) {
                c.opened = true
                c.openT = 1f
            }
        }
        buildMode = false
        ghost.show = false
    }

    /** How much harder your hits are, from what you're wearing. */
    private fun powerMul(): Float = 1f + loot.power / 40f

    fun addLook(dx: Float, dy: Float) {
        synchronized(lookLock) {
            lookX += dx
            lookY += dy
        }
    }

    fun update(dt: Float) {
        time += dt
        synchronized(lookLock) {
            yaw -= lookX
            pitch = (pitch - lookY).coerceIn(-1.2f, 1.2f)
            lookX = 0f
            lookY = 0f
        }

        // The lock lets go the moment its target dies, vanishes or gets too far away.
        lockTarget?.let { lt0 ->
            if (!lt0.active || lt0.dying >= 0f || hypot(lt0.x - x, lt0.z - z) > LOCK_RANGE * 1.6f) {
                lockTarget = null
                locked = false
            }
        }
        // While locked on (third person), the stick rolls you instead of walking you.
        val lockMode = lockTarget != null && thirdPerson
        val rawX = if (dead) 0f else moveX
        val rawY = if (dead) 0f else moveY
        val rawLen = hypot(rawX, rawY)

        // Mid-swing you're committed: no walking or spinning away, so the blow you started still lands.
        val committed = attackTimer > 0f && attackPhase < 0.85f
        val mx = if (dead || committed || lockMode) 0f else moveX
        val my = if (dead || committed || lockMode) 0f else moveY
        val len = hypot(mx, my)
        val moving = len > 0.05f
        val sprinting = moving && runOn && !winded

        // Dodge roll: a quick burst in the direction you push the stick (or facing, if it's centred),
        // with the middle portion invulnerable. Overrides normal walking for its duration.
        // Locked on, just pushing the stick rolls you, once your first blow of a swing has landed.
        if (dodgeCooldown > 0f) dodgeCooldown -= dt
        val stickRoll = lockMode && rawLen > 0.55f && (attackTimer <= 0f || nextHit > 0)
        if ((dodgeAsked || stickRoll) && dodgeTimer <= 0f && dodgeCooldown <= 0f && !dead && !airborne && stamina >= DODGE_COST) {
            val sy0 = sin(yaw)
            val cy0 = cos(yaw)
            if (rawLen > 0.05f) {
                val l0 = 1f / rawLen
                dodgeDirX = (sy0 * -rawY + -cy0 * rawX) * l0
                dodgeDirZ = (cy0 * -rawY + sy0 * rawX) * l0
            } else {
                dodgeDirX = sin(bodyYaw)
                dodgeDirZ = cos(bodyYaw)
            }
            dodgeTimer = DODGE_TIME
            dodgeCooldown = DODGE_COOLDOWN
            stamina = (stamina - DODGE_COST).coerceAtLeast(0f)
            restTimer = 0f
            attackTimer = 0f
            Sound.step(Surface.DIRT, 1.2f)
        }
        dodgeAsked = false
        if (dodgeTimer > 0f) {
            dodgeTimer = (dodgeTimer - dt).coerceAtLeast(0f)
            val roll = 1f - dodgeTimer / DODGE_TIME
            // Fast out, easing off toward the end.
            val speed = DODGE_SPEED * (1f - roll * roll * 0.6f)
            tryMove(x + dodgeDirX * speed * dt, z)
            tryMove(x, z + dodgeDirZ * speed * dt)
            bodyYaw = atan2(dodgeDirX, dodgeDirZ)
        } else if (moving) {
            val limit = if (len > 1f) 1f / len else 1f
            val sy = sin(yaw)
            val cy = cos(yaw)
            // Forward is where we look; right is 90 degrees clockwise from it.
            val wx = (sy * -my + -cy * mx) * limit
            val wz = (cy * -my + sy * mx) * limit
            var step = (if (sprinting) RUN_SPEED else WALK_SPEED) * dt * (1f + loot.speed / 100f)
            // Steep ground: you slow to a climb, and it tires you out.
            climbing = false
            var tooTired = false
            val stepLen = hypot(wx, wz) * step
            if (inCave < 0 && stepLen > 1e-4f && world.floorUnder(x, z, feetY) == 0) {
                val rise = world.terrainAt(x + wx * step, z + wz * step) - world.terrainAt(x, z)
                val grade = rise / stepLen
                if (grade > 0.45f) step *= (1.25f - grade * 0.55f).coerceIn(0.35f, 1f)
                // Picking your way down a steep face is slower too.
                if (grade < -0.8f) step *= (1.2f + grade * 0.3f).coerceIn(0.45f, 1f)
                if (grade > 0.9f) {
                    climbing = true
                    if (winded) tooTired = true
                }
            }
            if (!tooTired) {
                tryMove(x + wx * step, z)
                tryMove(x, z + wz * step)
            }
            walk += dt * len.coerceAtMost(1f) * (if (sprinting) 1.5f else 1f) * (if (climbing) 0.7f else 1f)
            // Turn the body to face the way we're walking, unless we're locked onto something.
            if (lockTarget == null) {
                val want = atan2(wx, wz)
                var d = want - bodyYaw
                while (d > 3.1415927f) d -= 6.2831855f
                while (d < -3.1415927f) d += 6.2831855f
                bodyYaw += d * min(1f, dt * 10f)
            }
        } else {
            climbing = false
        }
        if (!thirdPerson) bodyYaw = yaw

        // Lock-on: keep facing whatever we've locked, third person only, as long as it's alive and close.
        run {
            val lt = lockTarget
            if (lt != null) {
                if (!lt.active || lt.dying >= 0f || hypot(lt.x - x, lt.z - z) > LOCK_RANGE * 1.6f) {
                    lockTarget = null
                    locked = false
                } else if (thirdPerson && dodgeTimer <= 0f) {
                    val want = atan2(lt.x - x, lt.z - z)
                    var d = want - bodyYaw
                    while (d > 3.1415927f) d -= 6.2831855f
                    while (d < -3.1415927f) d += 6.2831855f
                    bodyYaw += d * min(1f, dt * 12f)
                }
            }
        }
        moveAmount += ((if (moving) len.coerceAtMost(1f) else 0f) - moveAmount) * min(1f, dt * 8f)
        runAmount += ((if (sprinting) 1f else 0f) - runAmount) * min(1f, dt * 5f)

        // Stamina.
        if (sprinting || (climbing && moving)) {
            stamina -= (if (sprinting) dt / RUN_SECONDS else 0f) + (if (climbing) dt / CLIMB_SECONDS else 0f)
            restTimer = 0f
            if (stamina <= 0f) {
                stamina = 0f
                winded = true
            }
        } else {
            restTimer += dt
            if (restTimer > 0.8f) stamina = (stamina + dt / RECOVER_SECONDS).coerceAtMost(1f)
        }
        if (winded && stamina > 0.3f) winded = false

        // Jumping and falling.
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        val ground = if (cv != null) cv.floorAt(x - cv.x, z - cv.z) else world.groundAt(x, z, feetY)
        val floor = if (cv == null && ground < 0f && !world.onBridge(x, z)) ground.coerceAtLeast(-0.9f) else ground
        if (jumpAsked) {
            jumpAsked = false
            if (!airborne && stamina >= JUMP_COST) {
                vy = JUMP_SPEED
                airborne = true
                stamina -= JUMP_COST
                restTimer = 0f
            }
        }
        if (airborne) {
            vy -= GRAVITY * dt
            feetY += vy * dt
            if (feetY <= floor) {
                feetY = floor
                vy = 0f
                airborne = false
                landed = true
            }
        } else if (floor < feetY - 0.8f) {
            airborne = true
            vy = 0f
        } else {
            feetY += (floor - feetY) * (dt * 14f).coerceAtMost(1f)
            // Climbing a steep slope: don't let the feet sink into the hillside.
            if (feetY < floor - 0.12f) feetY = floor - 0.12f
        }
        airAmount += ((if (airborne) 1f else 0f) - airAmount) * min(1f, dt * 10f)
        val bob = if (moving && !airborne) abs(sin(walk * 9f)) * (if (sprinting) 0.1f else 0.07f) else 0f
        eyeY = feetY + EYE + bob

        world.probe(x, z, probe)
        val si = probe.siteIndex
        if (si >= 0 && !discovered[si] && probe.siteCenter < PLACES[si].radius + 35f) {
            discovered[si] = true
            lastDiscovered = PLACES[si].name
            discoverVisit = discoverVisit + 1
        }
        val zNow = probe.zone
        if (zNow != currentZone) {
            currentZone = zNow
            zone = zNow
            zoneVisit = zoneVisit + 1
        }

        weather.update(dt, currentZone)
        // Remember where you are every few seconds (outdoors, alive and on the ground).
        posSaveTimer += dt
        if (posSaveTimer > 3f && !dead && inCave < 0 && !airborne) {
            posSaveTimer = 0f
            loot.savePosition(x, z, if (thirdPerson) bodyYaw else yaw, feetY)
        }
        fauna.playerDown = dead || inCave >= 0
        fauna.caveDown = dead
        fauna.playerLevel = loot.level
        fauna.bossMask = loot.bossMask
        fauna.update(dt, x, z, time, if (inCave >= 0) treasure.caves.getOrNull(inCave) else null)
        // Swapped weapons in the bag: take up the new one once the current swing is done.
        val wk = loot.weaponKind
        if (wk >= 0 && wk != weaponClass && attackTimer <= 0f) weaponClass = wk
        updateBosses()
        updateWorldBoss(dt)
        updateSeals(dt)
        while (true) {
            val job = jobs.poll() ?: break
            job()
        }
        people.update(dt, x, z)
        updateMarks(dt)
        updateHealth(dt)
        updateBodies(dt)
        updateTreasure(dt)
        updateBuild(dt)
        updateDrops(dt)
        updateAttack(dt)
        updateKunai(dt)
        for (i in 0 until PUFFS) {
            val a = i * 6 + 3
            if (puffs[a] < 1f) puffs[a] = min(1f, puffs[a] + dt / 1.1f)
        }

        // Footsteps, matched to what's underfoot.
        val under = if (inCave >= 0) 2 else world.floorUnder(x, z, feetY)
        indoors = under == 1 || under == 2
        if (landed) {
            landed = false
            val sf = surface(under)
            Sound.step(sf, 1.25f)
            kickUp(sf, 0f, 1.6f)
            kickUp(sf, 0f, 1.2f)
        } else if (moving && !airborne) {
            val sc = kotlin.math.floor(walk * 9f / 3.1415927f).toInt()
            if (sc != stepCount) {
                stepCount = sc
                val sf = surface(under)
                Sound.step(sf, if (sprinting) 1f else 0.75f)
                footSide = -footSide
                kickUp(sf, footSide, if (sprinting) 1.3f else 0.85f)
            }
        }
        Sound.wind = weather.windFor(currentZone)
        Sound.rain = weather.rainFor(currentZone)
        Sound.indoors = indoors

        reveal()
        hudTimer += dt
        if (hudTimer > 0.08f) {
            hudTimer = 0f
            hudTick = hudTick + 1
        }
    }

    /** Attacks with your weapon: when you tap the button, or by itself when auto fight is on. */
    private fun updateAttack(dt: Float) {
        // A roll, a cave or a knockout can cut a swing short: it's no longer a chop.
        if (attackTimer <= 0f) harvesting = false
        if (attackTimer > 0f) {
            attackTimer -= dt
            val p = attackPhase
            val hits = hitTimes()
            while (nextHit < hits.size && (p >= hits[nextHit] || attackTimer <= 0f)) {
                strike(nextHit)
                nextHit++
            }
            if (attackTimer <= 0f) {
                attackTimer = 0f
                harvesting = false
            }
        }
        val range = autoRange()
        var target: Creature? = null
        if (dead) attackAsked = false
        if (dodgeTimer > 0f) attackAsked = false
        // Locked on: always swing at the lock, if it's close enough to hit.
        val lt = lockTarget
        if (lt != null && lt.active && lt.dying < 0f && hypot(lt.x - x, lt.z - z) <= range + 3f) target = lt
        // Auto fight goes for monsters first, and only swings at animals if there are none.
        if (target == null && autoFight && attackTimer <= 0f && !dead) target = nearestAnimal(range, true) ?: nearestAnimal(min(range, 18f), false)
        // No swinging in the middle of a roll.
        if (dodgeTimer > 0f) target = null
        if ((attackAsked || target != null) && attackTimer <= 0f) {
            if (target == null) target = nearestAnimal(range, true) ?: nearestAnimal(range, false)
            // Turn to face whatever you're attacking (third person only; in first person you aim).
            if (target != null && thirdPerson) bodyYaw = atan2(target.x - x, target.z - z)
            aimed = target != null
            aimTarget = target
            if (target != null) {
                val sp = fauna.species[target.sp]
                aimX = target.x + sin(target.yaw) * sp.colZ * target.scale
                aimY = target.y + 0.9f * target.scale
                aimZ = target.z + cos(target.yaw) * sp.colZ * target.scale
            }
            attackLength = when (weaponClass) {
                WeaponClass.KUNAI -> 0.6f
                WeaponClass.HALBERD -> 1.15f
                else -> 1.25f
            }
            attackTimer = attackLength
            nextHit = 0
        }
        attackAsked = false
    }

    /** When, through the current attack, each blow lands: the animation leans into these. */
    val attackHits: FloatArray get() = hitTimes()

    /** When, through the attack, each blow lands (or the kunai leaves your hand). */
    private fun hitTimes(): FloatArray = if (harvesting) SWORD_HITS else when (weaponClass) {
        WeaponClass.KUNAI -> KUNAI_HITS
        WeaponClass.HALBERD -> HALBERD_HITS
        else -> SWORD_HITS
    }

    /** How close something must be for auto fight to go for it. */
    private fun autoRange(): Float = when (weaponClass) {
        WeaponClass.KUNAI -> KUNAI_RANGE
        WeaponClass.HALBERD -> 2.6f
        else -> 2.2f
    }

    /** Blow number [n] of the current attack lands. */
    private fun strike(n: Int) {
        if (harvesting) {
            harvestHit()
            return
        }
        when (weaponClass) {
            WeaponClass.KUNAI -> throwKunai()
            // Halberd: a full spinning sweep that hits all round you, then a slam straight ahead.
            WeaponClass.HALBERD -> if (n == 0) melee(2.9f, -1.1f, 1) else melee(3.3f, 0.5f, 2)
            // Sword: two slashes, then an overhead chop.
            else -> if (n < 2) melee(2.5f, 0.15f, 1) else melee(2.7f, 0.55f, 2)
        }
    }

    /**
     * Hits every animal within [reach] metres (plus its size) and inside the cone in front of
     * you where the cosine of the angle is at least [cone] (-1 hits all the way round).
     */
    private fun melee(reach: Float, cone: Float, damage: Int) {
        val face = if (thirdPerson) bodyYaw else yaw
        val fx = sin(face)
        val fz = cos(face)
        var any = false
        for (c in fauna.creatures) {
            if (!c.active || c.dying >= 0f || !fightable(c)) continue
            val sp = fauna.species[c.sp]
            val dx = c.x - x
            val dz = c.z - z
            val d = hypot(dx, dz)
            if (d > reach + (sp.colR + sp.colHalf * 0.6f) * c.scale) continue
            if (d > 0.8f && (dx * fx + dz * fz) / d < cone) continue
            val px = if (d > 1e-3f) dx / d else fx
            val pz = if (d > 1e-3f) dz / d else fz
            strikeCreature(c, px, pz, damage.toFloat())
            spawnPuff(c.x - px * sp.colR * c.scale, c.y + 0.8f * c.scale, c.z - pz * sp.colR * c.scale, PUFF_HIT, 1.1f)
            any = true
        }
        if (any) Sound.step(Surface.DIRT, 1.4f)
    }

    /** What the attack in progress is aimed at, so a thrown kunai can follow it. */
    private var aimTarget: Creature? = null
    /** The monster each flying kunai is locked on to, if any. */
    private val kunaiTarget = arrayOfNulls<Creature>(KUNAI_MAX)

    /** Lets a kunai fly from your hand: at your target if you have one, otherwise where you're looking. */
    private fun throwKunai() {
        var slot = -1
        for (i in 0 until KUNAI_MAX) if (kunai[i * 7 + 6] < 0f) { slot = i; break }
        if (slot < 0) slot = 0
        val face = if (thirdPerson) bodyYaw else yaw
        val sx = x + sin(face) * 0.5f
        val sy = feetY + 1.75f
        val sz = z + cos(face) * 0.5f
        var dx: Float
        var dy: Float
        var dz: Float
        val tgt = aimTarget?.takeIf { aimed && it.active && it.dying < 0f && fightable(it) }
        if (tgt != null) {
            // Like a crossbow bolt: aim where the target will be when the kunai gets there,
            // and a touch high to allow for the drop over that distance.
            val sp = fauna.species[tgt.sp]
            val cx = tgt.x + sin(tgt.yaw) * sp.colZ * tgt.scale
            val cy = tgt.y + 0.9f * tgt.scale
            val cz = tgt.z + cos(tgt.yaw) * sp.colZ * tgt.scale
            val t = sqrt((cx - sx) * (cx - sx) + (cz - sz) * (cz - sz)) / KUNAI_SPEED
            dx = cx + sin(tgt.yaw) * tgt.speed * t - sx
            dy = cy + 0.5f * KUNAI_DROP * t * t - sy
            dz = cz + cos(tgt.yaw) * tgt.speed * t - sz
        } else if (aimed) {
            dx = aimX - sx
            dy = aimY - sy
            dz = aimZ - sz
        } else {
            val cp = cos(pitch)
            dx = cp * sin(yaw)
            dy = sin(pitch) + 0.05f
            dz = cp * cos(yaw)
        }
        val l = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1e-4f)
        val o = slot * 7
        kunai[o] = sx
        kunai[o + 1] = sy
        kunai[o + 2] = sz
        kunai[o + 3] = dx / l * KUNAI_SPEED
        kunai[o + 4] = dy / l * KUNAI_SPEED
        kunai[o + 5] = dz / l * KUNAI_SPEED
        kunai[o + 6] = 0f
        kunaiTarget[slot] = tgt
        Sound.step(Surface.SAND, 0.6f)
    }

    /** Moves thrown kunai along, and stops them when they hit an animal, the ground or a wall. */
    private fun updateKunai(dt: Float) {
        for (i in 0 until KUNAI_MAX) {
            val o = i * 7
            if (kunai[o + 6] < 0f) continue
            kunai[o + 6] += dt
            kunai[o + 4] -= KUNAI_DROP * dt
            // Locked on: it bends gently onto its target so a dodging monster can't simply sidestep it.
            val kt = kunaiTarget[i]
            if (kt != null && kt.active && kt.dying < 0f) {
                val ksp = fauna.species[kt.sp]
                val ex = kt.x + sin(kt.yaw) * ksp.colZ * kt.scale - kunai[o]
                val ey = kt.y + 0.9f * kt.scale - kunai[o + 1]
                val ez = kt.z + cos(kt.yaw) * ksp.colZ * kt.scale - kunai[o + 2]
                val el = sqrt(ex * ex + ey * ey + ez * ez).coerceAtLeast(1e-3f)
                val vl = sqrt(kunai[o + 3] * kunai[o + 3] + kunai[o + 4] * kunai[o + 4] + kunai[o + 5] * kunai[o + 5]).coerceAtLeast(1e-3f)
                val turn = min(1f, dt * KUNAI_HOMING)
                var nvx = kunai[o + 3] / vl + (ex / el - kunai[o + 3] / vl) * turn
                var nvy = kunai[o + 4] / vl + (ey / el - kunai[o + 4] / vl) * turn
                var nvz = kunai[o + 5] / vl + (ez / el - kunai[o + 5] / vl) * turn
                val nl = sqrt(nvx * nvx + nvy * nvy + nvz * nvz).coerceAtLeast(1e-3f)
                nvx /= nl
                nvy /= nl
                nvz /= nl
                kunai[o + 3] = nvx * vl
                kunai[o + 4] = nvy * vl
                kunai[o + 5] = nvz * vl
            }
            // Small steps, so a fast kunai can't jump straight past a small animal.
            var gone = false
            for (step in 0 until 4) {
                val h = dt / 4f
                kunai[o] += kunai[o + 3] * h
                kunai[o + 1] += kunai[o + 4] * h
                kunai[o + 2] += kunai[o + 5] * h
                val kx = kunai[o]
                val ky = kunai[o + 1]
                val kz = kunai[o + 2]
                for (c in fauna.creatures) {
                    if (!c.active || c.dying >= 0f || !fightable(c)) continue
                    val sp = fauna.species[c.sp]
                    if (ky < c.y - 0.2f || ky > c.y + 2.2f * c.scale) continue
                    val dx = kx - c.x
                    val dz = kz - c.z
                    val hx = sin(c.yaw)
                    val hz = cos(c.yaw)
                    val mid = sp.colZ * c.scale
                    val along = (dx * hx + dz * hz - mid).coerceIn(-sp.colHalf * c.scale, sp.colHalf * c.scale) + mid
                    val qx = dx - hx * along
                    val qz = dz - hz * along
                    val rr = sp.colR * c.scale + 0.35f
                    if (qx * qx + qz * qz < rr * rr) {
                        val v = hypot(kunai[o + 3], kunai[o + 5]).coerceAtLeast(1e-3f)
                        strikeCreature(c, kunai[o + 3] / v, kunai[o + 5] / v, 2f)
                        spawnPuff(kx, ky, kz, PUFF_HIT, 1.2f)
                        Sound.step(Surface.DIRT, 1.3f)
                        gone = true
                        break
                    }
                }
                if (gone) break
                val kcv = if (inCave >= 0) treasure.caves[inCave] else null
                val blocked = if (kcv != null) {
                    val dd = kcv.inside(kx - kcv.x, kz - kcv.z)
                    dd < 0.3f || ky < kcv.floorFrom(kx - kcv.x, kz - kcv.z, dd) || ky > kcv.ceilFrom(kx - kcv.x, kz - kcv.z, dd)
                } else {
                    ky < world.groundAt(kx, kz, ky) || hitsWall(kx, ky, kz, 0.1f)
                }
                if (blocked) {
                    spawnPuff(kx, ky, kz, PUFF_STONE, 0.8f)
                    gone = true
                    break
                }
            }
            if (gone || kunai[o + 6] > 1.6f) {
                kunai[o + 6] = -1f
                kunaiTarget[i] = null
            }
        }
    }

    /**
     * Lands a blow of [base] damage on [c]. Your gear adds Power, and your level against
     * the monster's matters a lot: well below it, you barely scratch it.
     */
    private fun strikeCreature(c: Creature, dx: Float, dz: Float, base: Float) {
        val sp = fauna.species[c.sp]
        // Under-leveled hits do a lot less: fighting something well above you should be a real grind.
        val gap = if (sp.monster) (1f + (loot.level - c.level) * 0.08f).coerceIn(0.15f, 1.8f) else 1f
        val alive = c.dying < 0f
        if (sp.monster) loot.discover(c.sp)
        // Deadly Aim nodes on the Sphere Grid give a chance for double damage.
        val crit = if (loot.gridCrit > 0 && kotlin.random.Random.nextInt(100) < loot.gridCrit) 2f else 1f
        fauna.hit(c, dx, dz, base * powerMul() * gap * crit)
        noteTarget(c)
        if (alive && c.dying >= 0f) onKill(c)
    }

    /** Experience, gold and maybe an item for bringing something down. */
    private fun onKill(c: Creature) {
        val sp = fauna.species[c.sp]
        if (!sp.monster) {
            gainXp(3, 0)
            return
        }
        val boss = c.boss
        val wb = c.wb
        val big = boss >= 0 || wb >= 0
        // An ordinary monster's spot stays empty for a while before anything new spawns there.
        if (!big) fauna.startCooldown(c)
        val tier = tierOf(sp.zones[0])
        // Monster XP Yield = Base Monster XP * (Monster Level ^ 1.2).
        var xpGain = monsterXpYield(c.level)
        if (boss >= 0) xpGain *= 12
        if (wb >= 0) xpGain *= 15
        // Monsters far below you are hardly worth it.
        if (!big && loot.level - c.level > 10) xpGain = max(1, xpGain / 5)
        gainXp(xpGain, 0)
        val finished = if (boss >= 0) quests.onBoss(boss) else quests.onKill(c.sp)
        if (finished != null) {
            questToast = "${finished.title}: done! Return to ${people.npcs[finished.giver].title}."
            questVisit = questVisit + 1
        }
        // Its body stays where it fell, with whatever it was carrying, for you to search.
        val coins = (2 + kotlin.random.Random.nextInt(5)) * tier * (if (wb >= 0) 30 else if (boss >= 0) 25 else 1)
        val items = ArrayList(loot.rollBody(tier, big))
        val name = if (boss >= 0) BOSSES[boss].name else if (wb >= 0) WORLD_BOSSES[wb].name else sp.name
        synchronized(bodyLock) {
            if (bodies.size >= 8) {
                val old = bodies.firstOrNull { it !== searching }
                if (old != null) {
                    old.c.keep = false
                    bodies.remove(old)
                }
            }
            c.keep = true
            bodies.add(Body(c, name, items, coins))
        }
        if (boss >= 0) {
            loot.beatBoss(boss)
            fauna.bossMask = loot.bossMask
            val next = ZONE_ORDER.getOrNull(zoneRank(BOSSES[boss].zone) + 1)
            bossTitle = "BOSS DEFEATED"
            bossLine = if (next != null) "The seal is broken: ${next.title} is open!" else "Every region is free. The Keystone is yours!"
            bossVisit = bossVisit + 1
            Sound.call(0, 1f)
        }
        if (wb >= 0) {
            // Its own gear goes straight in your bag, so it can't be lost with the body.
            val piece = loot.rollWorldPiece(wb, fauna.wbKey)
            fauna.wbIndex = -1
            bossTitle = "WORLD BOSS DEFEATED"
            bossLine = if (piece != null) {
                "Mythic drop: ${piece.name}!"
            } else {
                "No set piece this time. One's certain within ${loot.wbPityLeft} more."
            }
            bossVisit = bossVisit + 1
            Sound.call(0, 1f)
            if (piece != null) {
                questToast = "${piece.name} is in your bag:  ${piece.stats()}"
                questVisit = questVisit + 1
            }
        }
    }

    /** Bodies age, sink away once searched (or left too long), and the nearest one can be searched. */
    private fun updateBodies(dt: Float) {
        synchronized(bodyLock) {
            nearBody = null
            var best = 1e9f
            val it = bodies.iterator()
            while (it.hasNext()) {
                val b = it.next()
                b.age += dt
                val d = hypot(b.c.x - x, b.c.z - z)
                val empty = b.items.isEmpty() && b.gold == 0
                if (!b.c.active || b.age > 240f || d > 190f || (empty && b !== searching)) {
                    b.c.keep = false
                    it.remove()
                    continue
                }
                val sp = fauna.species[b.c.sp]
                val reach = 2.2f + (sp.colR + sp.colHalf * 0.5f) * b.c.scale
                if (fightable(b.c) && !dead && d < reach && d < best && abs(b.c.y - feetY) < 3f * b.c.scale) {
                    best = d
                    nearBody = b
                }
            }
            // Walked away, or knocked out: the loot window closes.
            val open = searching
            if (open != null && (dead || !fightable(open.c) || hypot(open.c.x - x, open.c.z - z) > 6f + open.c.scale * 2f)) {
                searching = null
                searchVersion = searchVersion + 1
            }
        }
    }

    /** Quest markers for the maps and over people's heads, and the hunt that draws monsters in. */
    private fun updateMarks(dt: Float) {
        // Walked away from whoever you were talking or trading with.
        val t = talkingTo ?: trading
        if (t != null && (dead || hypot(t.x - x, t.z - z) > 5f)) {
            talkingTo = null
            trading = null
            talkVersion = talkVersion + 1
        }
        markTimer -= dt
        if (markTimer > 0f) return
        markTimer = 0.4f
        fauna.favorSpecies = quests.huntNear(x, z)
        val out = ArrayList<Float>()
        for (q in quests.current()) {
            if (q.state == QState.READY) {
                val g = people.npcs[q.giver]
                out.add(g.x); out.add(g.z); out.add(1f)
            } else {
                out.add(q.markX); out.add(q.markZ); out.add(0f)
            }
        }
        val open = loot.unlockedRank
        for (n in people.npcs) {
            if (n.role != NpcRole.QUEST && n.role != NpcRole.LORD) {
                n.mark = 0
                continue
            }
            n.mark = when {
                quests.hasReady(n.id) -> 2
                quests.hasNew(n.id) && zoneRank(n.zone) <= open -> 1
                else -> 0
            }
            if (n.mark == 1) {
                out.add(n.x); out.add(n.z); out.add(2f)
            }
        }
        marks = out.toFloatArray()
    }

    /** A boss that notices you gets its name up on the screen. */
    private fun updateBosses() {
        for (i in fauna.bosses.indices) {
            val c = fauna.bosses[i]
            if (!c.active) {
                bossAnnounced[i] = false
                continue
            }
            if (c.aggro && c.dying < 0f && !bossAnnounced[i]) {
                bossAnnounced[i] = true
                bossTitle = BOSSES[i].name
                bossLine = "Boss of ${BOSSES[i].zone.title}  \u00B7  Level ${BOSSES[i].level}"
                bossVisit = bossVisit + 1
            }
        }
    }

    /** Tapped the world boss line: five quick taps call one up nearby right now, for testing. */
    fun tapWorldBoss() {
        val now = System.currentTimeMillis()
        wbTaps = if (now - wbTapAt < 2500L) wbTaps + 1 else 1
        wbTapAt = now
        if (wbTaps >= 5) {
            wbTaps = 0
            wbSummonAsked = true
        }
    }

    private fun compass(dx: Float, dz: Float): String {
        // North is -z on the map.
        var deg = Math.toDegrees(atan2(dx.toDouble(), (-dz).toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        return arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")[((deg + 22.5f) / 45f).toInt() % 8]
    }

    /** Keeps the world boss to its schedule: out for 30 minutes every 6 hours, in a region you've opened. */
    private fun updateWorldBoss(dt: Float) {
        wbTimer -= dt
        if (wbTimer > 0f) return
        wbTimer = 0.5f
        val now = System.currentTimeMillis()
        if (wbSummonAsked) {
            wbSummonAsked = false
            val spot = WorldSchedule.spotNear(world, x, z)
            if (spot != null && inCave < 0) {
                world.probe(x, z, probe)
                wbForcedBoss = zoneRank(probe.zone).coerceIn(0, WORLD_BOSSES.size - 1)
                wbForcedSpot = spot
                wbForcedKey = -(now / 1000L)
                wbForcedUntil = now + WorldSchedule.STAYS_MS
                fauna.worldBosses[0].active = false
            } else {
                questToast = "Nowhere clear for a world boss here. Try open ground outside."
                questVisit = questVisit + 1
            }
        }
        val slot = WorldSchedule.slot(now)
        val forced = now < wbForcedUntil
        val left: Long
        val key: Long
        val idx: Int
        val spot: FloatArray?
        if (forced) {
            left = wbForcedUntil - now
            key = wbForcedKey
            idx = wbForcedBoss
            spot = wbForcedSpot
        } else {
            left = WorldSchedule.timeLeft(now)
            key = slot
            idx = WorldSchedule.bossFor(slot, loot.unlockedRank)
            if (wbSpotSlot != slot || wbSpotBoss != idx) {
                wbSpotSlot = slot
                wbSpotBoss = idx
                wbSpot = WorldSchedule.findSpot(world, WORLD_BOSSES[idx].zone, slot, treasure.lairX, treasure.lairZ)
            }
            spot = wbSpot
        }
        val beaten = loot.wbBeatSlot == key
        val until = WorldSchedule.untilNext(now)
        if (left > 0L && spot != null && !beaten) {
            val def = WORLD_BOSSES[idx]
            fauna.wbIndex = idx
            fauna.wbX = spot[0]
            fauna.wbZ = spot[1]
            fauna.wbKey = key
            fauna.wbLevel = (loot.level + 3).coerceAtMost(MAX_LEVEL)
            wbMapX = spot[0]
            wbMapZ = spot[1]
            wbMapName = def.name
            if (wbAnnouncedKey != key) {
                wbAnnouncedKey = key
                bossTitle = def.name
                bossLine = "A world boss is loose in ${def.zone.title}! It's on your map."
                bossVisit = bossVisit + 1
            }
            val dx = spot[0] - x
            val dz = spot[1] - z
            val d = hypot(dx, dz)
            val where = if (d < 40f) "here!" else "${d.toInt()} m ${compass(dx, dz)}"
            wbText = "\uD83D\uDC51 ${def.name}  \u00B7  ${WorldSchedule.clock(left)} left  \u00B7  $where"
            wbOut = true
        } else {
            fauna.wbIndex = -1
            wbMapX = Float.NaN
            wbMapZ = Float.NaN
            if (until <= WorldSchedule.WARN_MS && wbWarnedSlot != slot + 1) {
                wbWarnedSlot = slot + 1
                questToast = "A world boss appears in ${WorldSchedule.clock(until)}!"
                questVisit = questVisit + 1
            }
            wbText = if (beaten && left > 0L) {
                "\uD83D\uDC51 World boss beaten!  Next in ${WorldSchedule.clock(until)}"
            } else {
                "\uD83D\uDC51 Next world boss in ${WorldSchedule.clock(until)}"
            }
            wbOut = false
        }
    }

    /** Glittering sparks at the one gateway through the wall you still need to earn. */
    private fun updateSeals(dt: Float) {
        sealWait = max(0f, sealWait - dt)
        sealTimer -= dt
        if (sealTimer > 0f || inCave >= 0) return
        sealTimer = 0.06f
        val bi = loot.unlockedRank
        if (bi >= BOSSES.size - 1 || !borders.hasGate(bi)) return
        val gx = borders.gateX[bi]
        val gz = borders.gateZ[bi]
        if (hypot(x - gx, z - gz) > 30f) return
        val rnd = kotlin.random.Random
        val a = rnd.nextFloat() * 6.2831855f
        val r = rnd.nextFloat() * 6f
        val sx = gx + cos(a) * r
        val sz = gz + sin(a) * r
        spawnPuff(sx, world.terrainAt(sx, sz) + 0.3f + rnd.nextFloat() * 3.2f, sz, PUFF_SEAL, 0.8f + rnd.nextFloat() * 0.8f)
    }

    /** You walked into a sealed region: say which boss you need to beat. */
    private fun hitSeal(zone: Zone) {
        if (sealWait > 0f) return
        sealWait = 4f
        val need = BOSSES[loot.unlockedRank.coerceIn(0, BOSSES.size - 1)]
        // The very next boss in line, not necessarily the last one standing between you and
        // this particular zone — regions must fall in order, one at a time.
        sealText = if (zoneRank(zone) > loot.unlockedRank + 1) {
            "${zone.title} is sealed. Clear each region in order, starting with ${need.name} in ${need.zone.title}."
        } else {
            "Defeat ${need.name} in ${need.zone.title} to break the seal on ${zone.title}."
        }
        sealVisit = sealVisit + 1
        Sound.step(Surface.STONE, 0.9f)
        val face = if (thirdPerson) bodyYaw else yaw
        for (k in 0 until 8) {
            val rnd = kotlin.random.Random
            spawnPuff(
                x + sin(face) * 1.4f + (rnd.nextFloat() - 0.5f) * 2.5f,
                feetY + 0.3f + rnd.nextFloat() * 2.2f,
                z + cos(face) * 1.4f + (rnd.nextFloat() - 0.5f) * 2.5f,
                PUFF_SEAL, 1.2f,
            )
        }
    }

    private fun gainXp(baseAmount: Int, coins: Int) {
        // Scholar nodes on the Sphere Grid add a bonus to all experience.
        val amount = (baseAmount * (1f + loot.gridXp / 100f)).toInt().coerceAtLeast(baseAmount)
        val ups = loot.addXp(amount)
        xpToast = if (coins > 0) "+$amount XP   +$coins gold" else "+$amount XP"
        xpVisit = xpVisit + 1
        if (ups > 0) {
            health = maxHealth
            levelVisit = levelVisit + 1
            Sound.call(0, 1f)
        }
    }

    /** Dropped items bob on the ground; walk over one to pick it up. */
    private fun updateDrops(dt: Float) {
        val it = drops.iterator()
        while (it.hasNext()) {
            val d = it.next()
            d.age += dt
            if (d.age > 120f) {
                it.remove()
                continue
            }
            if (inCave < 0 && !dead && hypot(d.x - x, d.z - z) < 1.6f && abs(d.y - feetY) < 2.5f) {
                loot.addItem(d.item)
                lootTitle = "PICKED UP"
                lastLoot = listOf(d.item)
                lootVisit = lootVisit + 1
                Sound.step(Surface.WOOD, 1f)
                it.remove()
            }
        }
    }

    /** Chest lids, the context button, and going in and out of caves. */
    private fun updateTreasure(dt: Float) {
        fade = max(0f, fade - dt * 1.3f)
        for (c in treasure.chests) if (c.opened && c.openT < 1f) c.openT = min(1f, c.openT + dt * 1.8f)
        // What's within reach?
        var chest: Chest? = null
        var best = 2.4f
        for (c in treasure.chests) {
            if (c.opened || c.cave != inCave) continue
            val d = hypot(c.x - x, c.z - z)
            if (d < best && abs(c.y - feetY) < 2f) {
                best = d
                chest = c
            }
        }
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        val mouth = if (cv == null) treasure.caveMouthNear(x, z, 3.2f) else null
        val exit = cv != null && hypot(x - cv.x, z - cv.z) < 2.2f
        val body = nearBody
        nearNpc = if (cv == null && !dead) people.nearest(x, z, feetY, 2.6f) else null
        val npc = nearNpc
        val relic = cv != null && quests.relicWanted(cv.id) && hypot(x - cv.relicX, z - cv.relicZ) < 2.4f
        // Out in the world: a crafting bench, an unfinished frame, or a tree or rock to work on.
        val outside = cv == null && !dead
        val bench = if (outside) base.benchNear(x, feetY, z, 2.6f) else null
        // A frame only takes over the button if you're carrying something it still needs.
        val frame = if (outside) base.unfinishedNear(x, feetY, z, 3.4f)?.takeIf { base.canHelp(it) } else null
        cutScan -= dt
        if (outside && (cutScan <= 0f || harvesting)) {
            cutScan = 0.15f
            if (!harvesting) scanForHarvest()
        } else if (!outside) {
            nearCut = -1
        }
        action = when {
            dead || searching != null || talkingTo != null || trading != null -> ACTION_NONE
            chest != null -> ACTION_OPEN
            body != null -> ACTION_SEARCH
            relic -> ACTION_RELIC
            npc != null -> ACTION_TALK
            mouth != null -> ACTION_ENTER
            exit -> ACTION_EXIT
            bench != null -> ACTION_CRAFT
            frame != null -> ACTION_FINISH
            nearCut >= 0 -> if (nearCutWood) ACTION_CHOP else ACTION_MINE
            else -> ACTION_NONE
        }
        actionLabel = when (action) {
            ACTION_CRAFT -> "\uD83D\uDEE0\uFE0F  CRAFTING BENCH"
            ACTION_FINISH -> if (frame != null) "\uD83D\uDD28  FINISH ${PieceType.NAMES[frame.type].uppercase()}  (${frame.missingText()})" else ""
            ACTION_CHOP -> if (base.axeTier > 0) "\uD83E\uDE93  CHOP TREE" else "\uD83C\uDF3F  GATHER WOOD"
            ACTION_MINE -> if (base.pickTier > 0) "\u26CF\uFE0F  MINE ROCK" else "\uD83E\uDEA8  GATHER STONE"
            else -> ""
        }
        // Tapped again mid-swing: go straight into the next one.
        if (harvestQueued && attackTimer <= 0f) {
            harvestQueued = false
            if (action == ACTION_CHOP || action == ACTION_MINE) startHarvest()
        }
        if (!interactAsked) return
        interactAsked = false
        when (action) {
            ACTION_OPEN -> if (chest != null) openChest(chest)
            ACTION_SEARCH -> if (body != null) {
                synchronized(bodyLock) { searching = body }
                searchVersion = searchVersion + 1
                Sound.step(Surface.WOOD, 0.8f)
            }
            ACTION_TALK -> if (npc != null) {
                talkLine = npcLine(npc, chatCount++)
                talkingTo = npc
                talkVersion = talkVersion + 1
                moveX = 0f
                moveY = 0f
            }
            ACTION_RELIC -> if (cv != null) {
                val q = quests.onRelic(cv.id)
                if (q != null) {
                    questToast = "Found ${q.thing}! Take it back to ${people.npcs[q.giver].title}."
                    questVisit = questVisit + 1
                }
                Sound.call(0, 1f)
            }
            ACTION_ENTER -> if (mouth != null) enterCave(mouth)
            ACTION_EXIT -> if (cv != null) leaveCave(cv)
            ACTION_CRAFT -> {
                moveX = 0f
                moveY = 0f
                craftVisit = craftVisit + 1
            }
            ACTION_FINISH -> if (frame != null) finishFrame(frame)
            ACTION_CHOP, ACTION_MINE -> startHarvest()
            else -> {}
        }
    }

    // ---------- Gathering: chopping trees and breaking rocks ----------

    /** Finds the nearest tree or rock you could work on from where you're standing. */
    private fun scanForHarvest() {
        nearCut = -1
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        var best = 1e9f
        for (j in cj - 1..cj + 1) {
            for (i in ci - 1..ci + 1) {
                if (!world.objectAt(i, j, placed, probe)) continue
                val k = placed.kind
                val wood = k == Kind.TREE || k == Kind.PINE || k == Kind.PALM || k == Kind.DEAD
                if (!wood && k != Kind.ROCK) continue
                if (abs(placed.y - feetY) > 2.5f) continue
                val d = hypot(placed.x - x, placed.z - z) - placed.radius
                if (d > 1.6f || d >= best) continue
                best = d
                nearCut = j * GRID + i
                nearCutWood = wood
                nearCutX = placed.x
                nearCutZ = placed.z
            }
        }
    }

    /** One swing at the tree or rock in front of you: three blows, each worth some wood or stone. */
    private fun startHarvest() {
        if (nearCut < 0 || dead || dodgeTimer > 0f) return
        if (attackTimer > 0f) {
            if (harvesting) harvestQueued = true
            return
        }
        if (nearCut != harvestCell) {
            harvestCell = nearCut
            val tier = if (nearCutWood) base.axeTier else base.pickTier
            harvestLeft = if (tier >= 2) 3 else 6
        }
        harvesting = true
        toolKind = if (nearCutWood) (if (base.axeTier > 0) 1 else 0) else (if (base.pickTier > 0) 2 else 0)
        toolTimer = 2.5f
        bodyYaw = atan2(nearCutX - x, nearCutZ - z)
        attackLength = 1.25f
        attackTimer = attackLength
        nextHit = 0
        restTimer = 0f
    }

    /** A blow lands on the tree or rock. */
    private fun harvestHit() {
        val k = harvestCell
        if (k < 0) return
        val i = k % GRID
        val j = k / GRID
        if (!world.objectAt(i, j, placed, probe)) return
        val wood = placed.kind != Kind.ROCK
        val tier = if (wood) base.axeTier else base.pickTier
        val r = if (wood) Res.WOOD else Res.STONE
        val dx = placed.x - x
        val dz = placed.z - z
        val d = max(0.01f, hypot(dx, dz))
        val px = placed.x - dx / d * placed.radius
        val pz = placed.z - dz / d * placed.radius
        val py = feetY + (if (wood) 1.1f else 0.5f)
        spawnPuff(px, py, pz, if (wood) PUFF_DIRT else PUFF_STONE, 0.9f)
        Sound.step(if (wood) Surface.WOOD else Surface.STONE, 1.5f)
        if (tier == 0) {
            // Bare hands: snap off branches, prise loose stones. Slow, but it gets you started.
            handCount++
            if (handCount % 2 == 0) {
                base.add(r, 1)
                resToast = "+1 ${Res.ICONS[r]}  ${Res.NAMES[r]}"
                resVisit = resVisit + 1
            }
            return
        }
        val gain = if (tier >= 2) 2 else 1
        base.add(r, gain)
        harvestLeft--
        var msg = "+$gain ${Res.ICONS[r]}  ${Res.NAMES[r]}"
        if (harvestLeft <= 0) {
            val zone = probe.zone
            base.cut(i, j, Base.REGROW_MS)
            var iron = 0
            if (!wood) {
                val rich = zone == Zone.SNOW || zone == Zone.CAVES || zone == Zone.DESERT
                iron = if (rich) 1 + cutRnd.nextInt(2) else if (cutRnd.nextFloat() < 0.4f) 1 else 0
                if (iron > 0 && tier >= 2) iron++
                if (iron > 0) {
                    base.add(Res.IRON, iron)
                    msg += "   +$iron ${Res.ICONS[Res.IRON]}  Iron"
                }
            }
            for (n in 0 until 3) spawnPuff(placed.x, placed.y + 0.6f + n * 0.9f, placed.z, if (wood) PUFF_DIRT else PUFF_STONE, 1.6f)
            Sound.step(if (wood) Surface.WOOD else Surface.STONE, 2.2f)
            questToast = if (wood) "Timber! The tree comes down." else if (iron > 0) "The rock splits open: you found iron!" else "The rock breaks apart."
            questVisit = questVisit + 1
            harvestCell = -1
            nearCut = -1
        }
        resToast = msg
        resVisit = resVisit + 1
    }

    // ---------- Building ----------

    fun selectPiece(t: Int) {
        buildType = t.coerceIn(0, PieceType.COUNT - 1)
        buildRot = 0
    }

    fun rotatePiece() {
        buildRot = (buildRot + 1) % 4
    }

    fun placePiece() {
        placeAsked = true
    }

    fun removePiece() {
        removeAsked = true
    }

    /** Makes a tool at the bench you're standing by. */
    fun craft(recipe: Int) {
        jobs.add {
            val msg = when {
                base.benchNear(x, feetY, z, 3.5f) == null -> "Stand at a crafting bench to make that."
                base.owns(recipe) -> "You already have one."
                !base.canAfford(Recipe.COST[recipe]) -> "You need ${Recipe.costText(recipe)} for a ${Recipe.NAMES[recipe]}."
                base.craft(recipe) -> "Made a ${Recipe.NAMES[recipe]}!"
                else -> "Can't make that yet."
            }
            questToast = msg
            questVisit = questVisit + 1
            Sound.step(Surface.WOOD, 1.2f)
        }
    }

    /** Puts whatever you're carrying into an unfinished frame. */
    private fun finishFrame(p: Piece) {
        val name = PieceType.NAMES[p.type]
        questToast = if (base.payInto(p)) {
            Sound.step(Surface.WOOD, 1.4f)
            if (p.paidInFull) "$name finished!" else "$name still needs ${p.missingText()}."
        } else {
            "You need ${p.missingText()} to finish the $name. Chop trees and break rocks for more."
        }
        questVisit = questVisit + 1
    }

    /** Where the middle of the screen points: the spot the next piece is aimed at. */
    private fun aimPoint(out: FloatArray) {
        val start = rayBack + 0.4f
        var t = start
        while (t < start + 8f) {
            val px = rayOx + rayDx * t
            val py = rayOy + rayDy * t
            val pz = rayOz + rayDz * t
            val g = world.groundAt(px, pz, py)
            if (py <= g || base.hitsPoint(px, py, pz, 0.05f)) {
                out[0] = px
                out[1] = max(py, g)
                out[2] = pz
                return
            }
            t += 0.1f
        }
        // Looking up into open air: a spot a few steps ahead, at that height.
        t = start + 3.5f
        out[0] = rayOx + rayDx * t
        out[1] = rayOy + rayDy * t
        out[2] = rayOz + rayDz * t
    }

    private fun updateBuild(dt: Float) {
        base.update(dt, x, z, feetY)
        if (toolTimer > 0f && !harvesting) toolTimer -= dt
        if (!buildMode || inCave >= 0 || dead) {
            ghost.show = false
            placeAsked = false
            removeAsked = false
            return
        }
        aimPoint(aimAt)
        val t = buildType
        base.plan(ghost, t, aimAt[0], aimAt[1], aimAt[2], x, z, feetY, yaw, buildRot)
        buildHint = if (ghost.ok) {
            val cost = PieceType.costText(t)
            if (base.has(t)) "${PieceType.NAMES[t]}  \u00B7  $cost" else "${PieceType.NAMES[t]}  \u00B7  $cost  (it'll wait as a frame till you have it all)"
        } else {
            ghost.reason
        }
        if (placeAsked) {
            placeAsked = false
            if (ghost.ok) {
                val p = base.place(ghost)
                Sound.step(if (t == PieceType.FOUNDATION || t == PieceType.STONE_WALL || t == PieceType.STONE_GABLE) Surface.STONE else Surface.WOOD, 1.6f)
                if (!p.paidInFull) {
                    questToast = "Frame up! Bring ${p.missingText()} to finish it."
                    questVisit = questVisit + 1
                }
            } else {
                questToast = ghost.reason
                questVisit = questVisit + 1
            }
        }
        if (removeAsked) {
            removeAsked = false
            val p = base.pieceNear(aimAt[0], aimAt[1], aimAt[2], 2.8f)
            if (p != null) {
                base.remove(p)
                Sound.step(Surface.WOOD, 1.2f)
                questToast = "Took down the ${PieceType.NAMES[p.type]}. Materials back in your pack."
            } else {
                questToast = "Aim at something you've built to take it down."
            }
            questVisit = questVisit + 1
        }
    }

    private fun openChest(c: Chest) {
        c.opened = true
        val fragId = LoreBook.chestFragment[c.id]
        if (fragId != null && loot.collectLore(fragId)) {
            lootTitle = "MEMORY FRAGMENT"
            lastLoot = loot.openChest(c.id, c.tier, c.rich)
            questToast = "Found a memory: \"${LoreBook.byId(fragId)?.title}\". Read it in your book."
            questVisit = questVisit + 1
        } else {
            lootTitle = "TREASURE!"
            lastLoot = loot.openChest(c.id, c.tier, c.rich)
        }
        lootVisit = lootVisit + 1
        Sound.call(0, 1f)
        Sound.step(Surface.WOOD, 1.2f)
    }

    private fun enterCave(cv: Cave) {
        val mb = cv.buildMesh()
        caveCount = mb.vertexCount
        caveData = mb.finish()
        caveMeshId = caveMeshId + 1
        inCave = cv.id
        // Arrive by the shaft of light, facing into the cave.
        val next = cv.chambers.getOrNull(1)
        val face = if (next != null) atan2(next[0], next[1]) else 0f
        x = cv.x + sin(face) * 2.5f
        z = cv.z + cos(face) * 2.5f
        yaw = face
        bodyYaw = face
        feetY = cv.floorAt(x - cv.x, z - cv.z)
        vy = 0f
        airborne = false
        fade = 1f
        attackTimer = 0f
        for (i in 0 until KUNAI_MAX) kunai[i * 7 + 6] = -1f
        lastDiscovered = cv.name
        discoverVisit = discoverVisit + 1
    }

    private fun leaveCave(cv: Cave) {
        inCave = -1
        x = cv.x + sin(cv.yaw) * 2.2f
        z = cv.z + cos(cv.yaw) * 2.2f
        yaw = cv.yaw
        bodyYaw = cv.yaw
        feetY = world.groundAt(x, z)
        vy = 0f
        airborne = false
        fade = 1f
        attackTimer = 0f
        for (i in 0 until KUNAI_MAX) kunai[i * 7 + 6] = -1f
    }

    /** Takes damage from monsters, heals slowly out of a fight, and handles being knocked out. */
    private fun updateHealth(dt: Float) {
        hurtFlash = max(0f, hurtFlash - dt * 1.6f)
        // The invulnerable heart of a dodge roll: incoming hits simply don't count.
        val invuln = dodgeTimer > DODGE_TIME * 0.15f && dodgeTimer < DODGE_TIME * 0.85f
        val dmg = if (invuln) 0f else fauna.pendingDamage
        fauna.pendingDamage = 0f
        if (dead) {
            deadTimer += dt
            if (deadTimer > 3.5f) respawn()
            return
        }
        if (pendingHeal > 0f) {
            health = min(maxHealth, health + pendingHeal)
            pendingHeal = 0f
        }
        if (dmg > 0f) {
            health = max(0f, health - dmg * 100f / (100f + loot.defense))
            hurtFlash = 1f
            regenWait = 5f
            Sound.step(Surface.DIRT, 1.5f)
            fauna.lastAttacker?.let { noteTarget(it) }
            if (health <= 0f) {
                dead = true
                deadTimer = 0f
                attackTimer = 0f
                fauna.calmAll()
                return
            }
        }
        if (!dead && fauna.poisonTime > 0f) {
            health = max(0f, health - fauna.poisonDps * dt)
            if (health <= 0f) {
                dead = true
                deadTimer = 0f
                attackTimer = 0f
                fauna.calmAll()
                return
            }
        }
        regenWait -= dt
        if (health > maxHealth) health = maxHealth
        if (regenWait <= 0f && health < maxHealth) health = min(maxHealth, health + (8f + loot.gridRegen) * dt)
        // The panel at the top: the monster you're fighting, while it's close.
        val t = target
        if (t != null) {
            val gone = !t.active || (t.dying >= 0f && t.dying > 2f) || hypot(t.x - x, t.z - z) > 45f
            if (gone) {
                target = null
                targetFrac = -1f
            } else {
                targetFrac = if (t.dying >= 0f) 0f else t.health / max(1f, t.maxHealth)
            }
        }
    }

    /** Shows [c] in the panel at the top of the screen, if it's a monster. */
    private fun noteTarget(c: Creature) {
        val sp = fauna.species[c.sp]
        if (!sp.monster) return
        target = c
        targetName = if (c.boss >= 0) BOSSES[c.boss].name else if (c.wb >= 0) WORLD_BOSSES[c.wb].name else sp.name
        targetBoss = c.boss >= 0 || c.wb >= 0
        targetLevel = c.level
        targetFrac = if (c.dying >= 0f) 0f else c.health / max(1f, c.maxHealth)
    }

    /** Wake up back at the start, fully healed. */
    private fun respawn() {
        closeSearch()
        talkingTo = null
        trading = null
        dead = false
        inCave = -1
        health = maxHealth
        hurtFlash = 0f
        x = world.spawnX
        z = world.spawnZ
        yaw = world.spawnYaw
        bodyYaw = yaw
        feetY = world.groundAt(x, z)
        vy = 0f
        airborne = false
        eyeY = feetY + EYE
        target = null
        targetFrac = -1f
    }

    /** The closest living animal within [range] metres of your body, or null. */
    private fun nearestAnimal(range: Float, monsters: Boolean): Creature? {
        var best: Creature? = null
        var bestD = 1e9f
        for (c in fauna.creatures) {
            if (!c.active || c.dying >= 0f || !fightable(c)) continue
            val sp = fauna.species[c.sp]
            if (sp.monster != monsters) continue
            val d = hypot(c.x - x, c.z - z) - (sp.colR + sp.colHalf * 0.5f) * c.scale
            if (d < range && d < bestD) {
                bestD = d
                best = c
            }
        }
        return best
    }

    /**
     * Whether you can hit [c] from where you are: inside a cave only the monsters in that cave,
     * and outside only the creatures out in the world (never anything in a cave you've left).
     */
    private fun fightable(c: Creature): Boolean {
        var inCaveList = false
        for (o in fauna.caveFoes) if (o === c) { inCaveList = true; break }
        return inCaveList == (inCave >= 0)
    }

    private fun spawnPuff(px: Float, py: Float, pz: Float, kind: Int, size: Float) {
        val o = nextPuff * 6
        nextPuff = (nextPuff + 1) % PUFFS
        puffs[o] = px
        puffs[o + 1] = py
        puffs[o + 2] = pz
        puffs[o + 3] = 0f
        puffs[o + 4] = kind.toFloat()
        puffs[o + 5] = size
    }

    /** A little cloud of whatever you're walking on, thrown up behind the foot that just landed. */
    private fun kickUp(surface: Int, side: Float, size: Float) {
        val kind = when (surface) {
            Surface.DIRT -> PUFF_DIRT
            Surface.SAND -> PUFF_SAND
            Surface.SNOW -> PUFF_SNOW
            Surface.STONE, Surface.ROCK -> PUFF_STONE
            Surface.WATER -> PUFF_WATER
            Surface.GRASS -> PUFF_GRASS
            else -> return
        }
        val fx = sin(bodyYaw)
        val fz = cos(bodyYaw)
        val i = nextPuff
        nextPuff = (nextPuff + 1) % PUFFS
        val o = i * 6
        puffs[o] = x - fx * 0.25f - fz * side * 0.12f
        puffs[o + 1] = feetY
        puffs[o + 2] = z - fz * 0.25f + fx * side * 0.12f
        puffs[o + 3] = 0f
        puffs[o + 4] = kind.toFloat()
        puffs[o + 5] = size * (if (kind == PUFF_GRASS) 0.55f else if (kind == PUFF_STONE) 0.7f else 1f)
    }

    /**
     * Where the camera goes this frame. Writes camera x, y, z, then the point it looks
     * at, then 1 if the hero should be drawn (0 when the camera is too close to him).
     */
    fun camera(dt: Float, out: FloatArray) {
        val cp = cos(pitch)
        val fx = cp * sin(yaw)
        val fy = sin(pitch)
        val fz = cp * cos(yaw)
        rayDx = fx
        rayDy = fy
        rayDz = fz
        if (!thirdPerson) {
            out[0] = x
            out[1] = eyeY
            out[2] = z
            out[3] = x + fx
            out[4] = eyeY + fy
            out[5] = z + fz
            out[6] = 0f
            camDist = 0.5f
            rayOx = x
            rayOy = eyeY
            rayOz = z
            rayBack = 0f
            return
        }
        // Over the right shoulder, a few metres back. Walls and hills pull the camera in.
        val headY = feetY + 1.7f
        val rx = -cos(yaw)
        val rz = sin(yaw)
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        val shoulder = if (indoors && cv == null) 0.25f else 0.45f
        val want = if (cv != null) 3.4f else if (indoors) 2.3f else 4.2f + runAmount * 0.5f
        var free = want
        val steps = 12
        for (i in 1..steps) {
            val t = want * i / steps
            val k = t / want
            val sx = x + rx * shoulder * k - fx * t
            val sy = headY - fy * t
            val sz = z + rz * shoulder * k - fz * t
            var hit = if (cv != null) {
                val dd = cv.inside(sx - cv.x, sz - cv.z)
                dd < 0.5f || sy < cv.floorFrom(sx - cv.x, sz - cv.z, dd) + 0.3f || sy > cv.ceilFrom(sx - cv.x, sz - cv.z, dd) - 0.3f
            } else {
                world.terrainAt(sx, sz) + 0.3f > sy && world.floorUnder(x, z, feetY) == 0
            }
            if (!hit) hit = hitsWall(sx, sy, sz, 0.3f)
            if (hit) {
                free = max(0.4f, t - want / steps)
                break
            }
        }
        camDist = if (free < camDist) free else camDist + (free - camDist) * min(1f, dt * 2.5f)
        val k = camDist / want
        var cx = x + rx * shoulder * k - fx * camDist
        var cy = headY - fy * camDist
        var cz = z + rz * shoulder * k - fz * camDist
        if (cv != null) {
            val dd = cv.inside(cx - cv.x, cz - cv.z)
            val g = cv.floorFrom(cx - cv.x, cz - cv.z, dd)
            if (cy < g + 0.35f) cy = g + 0.35f
            cy = min(cy, max(g + 0.5f, cv.ceilFrom(cx - cv.x, cz - cv.z, dd) - 0.35f))
        } else {
            val g = world.groundAt(cx, cz, cy)
            if (cy < g + 0.35f) cy = g + 0.35f
            if (indoors) cy = min(cy, feetY + 2.1f)
        }
        if (cx < 1f) cx = 1f
        if (cz < 1f) cz = 1f
        out[0] = cx
        out[1] = cy
        out[2] = cz
        out[3] = cx + fx
        out[4] = cy + fy
        out[5] = cz + fz
        out[6] = if (camDist > 0.9f) 1f else 0f
        rayOx = cx
        rayOy = cy
        rayOz = cz
        rayBack = camDist
    }

    /** Whether a point would be inside a wall, floor or roof beam of a building. */
    private fun hitsWall(px: Float, py: Float, pz: Float, r: Float): Boolean {
        for (st in world.structures) {
            val dx = px - st.cx
            val dz = pz - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (so in st.solids) if (so.hitsPoint(px, py, pz, r)) return true
        }
        return base.hitsPoint(px, py, pz, r)
    }

    /** How deep a body at (px, pz) would be inside the nearest animal (0 = not touching). */
    private fun animalOverlap(px: Float, pz: Float): Float {
        var worst = 0f
        if (inCave >= 0) return 0f
        for (c in fauna.creatures) {
            if (!c.active || c.dying >= 0f) continue
            val sp = fauna.species[c.sp]
            if (abs(feetY - c.y) > 2.5f * c.scale) continue
            val dx = px - c.x
            val dz = pz - c.z
            val reach = (sp.colHalf + sp.colR + abs(sp.colZ)) * c.scale + RADIUS
            if (dx * dx + dz * dz > reach * reach) continue
            val hx = sin(c.yaw)
            val hz = cos(c.yaw)
            val mid = sp.colZ * c.scale
            val along = (dx * hx + dz * hz - mid).coerceIn(-sp.colHalf * c.scale, sp.colHalf * c.scale) + mid
            val qx = dx - hx * along
            val qz = dz - hz * along
            val rr = sp.colR * c.scale + RADIUS
            val over = rr - sqrt(qx * qx + qz * qz)
            if (over > worst) worst = over
        }
        return worst
    }

    /** Which footstep sound to play here. [under] comes from [World.floorUnder]. */
    private fun surface(under: Int): Int {
        if (inCave >= 0) return Surface.STONE
        if (under == 1 || under == 3 || under == 5) return Surface.WOOD
        if (under == 6) return Surface.STONE
        if (under == 2) return Surface.STONE
        val t = world.terrainAt(x, z)
        if (t < -0.05f) return Surface.WATER
        val hx = world.terrainAt(x + 1f, z) - world.terrainAt(x - 1f, z)
        val hz = world.terrainAt(x, z + 1f) - world.terrainAt(x, z - 1f)
        val flat = 2f / sqrt(hx * hx + hz * hz + 4f)
        return when (groundFlag(probe, x, z, t, flat)) {
            FLAG_GRASS -> Surface.GRASS
            FLAG_DIRT -> Surface.DIRT
            FLAG_SAND -> Surface.SAND
            FLAG_SNOW -> Surface.SNOW
            FLAG_STONE -> Surface.STONE
            else -> Surface.ROCK
        }
    }

    private fun tryMove(nx: Float, nz: Float) {
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        if (cv != null) {
            if (!cv.walkable(nx - cv.x, nz - cv.z, RADIUS)) return
            for (c in treasure.chests) {
                if (c.cave != cv.id) continue
                val rr = 0.55f + RADIUS
                if ((nx - c.x) * (nx - c.x) + (nz - c.z) * (nz - c.z) < rr * rr) return
            }
            x = nx
            z = nz
            return
        }
        if (world.isBlocked(nx, nz, probe)) return
        // The seal round a region you haven't earned yet: no exceptions, no skipping ahead.
        val zr = zoneRank(probe.zone)
        if (zr > loot.unlockedRank) {
            hitSeal(probe.zone)
            return
        }
        if (world.hitsObstacle(nx, nz, RADIUS, placed, probe, feetY)) return
        if (borders.blocksWall(nx, nz, RADIUS)) return
        if (treasure.blocksOutside(nx, nz, RADIUS)) return
        if (people.blocks(nx, nz, RADIUS) && !people.blocks(x, z, RADIUS)) return
        // Animals are solid. If one has walked into you, you can still step away from it.
        val over = animalOverlap(nx, nz)
        if (over > 0f && over >= animalOverlap(x, z) - 1e-4f) return
        x = nx
        z = nz
    }

    private fun reveal() {
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        if (ci == lastCi && cj == lastCj) return
        lastCi = ci
        lastCj = cj
        val r = REVEAL_CELLS
        for (dj in -r..r) {
            for (di in -r..r) {
                if (di * di + dj * dj > r * r) continue
                val i = ci + di
                val j = cj + dj
                if (i < 0 || j < 0 || i >= GRID || j >= GRID) continue
                val idx = j * GRID + i
                if (explored[idx]) continue
                explored[idx] = true
                minimap.setPixel(i, j, world.mapColors[idx])
            }
        }
    }

    companion object {
        const val EYE = 1.7f
        const val WALK_SPEED = 6.5f
        const val RUN_SPEED = 12.5f
        const val RUN_SECONDS = 7f
        const val RECOVER_SECONDS = 5f
        const val CLIMB_SECONDS = 14f
        const val PUFFS = 64
        const val PUFF_DIRT = 0
        const val PUFF_SAND = 1
        const val PUFF_SNOW = 2
        const val PUFF_STONE = 3
        const val PUFF_WATER = 4
        const val PUFF_GRASS = 5
        const val PUFF_HIT = 6
        const val PUFF_SEAL = 7
        const val MAX_HEALTH = 100f
        const val ACTION_NONE = 0
        const val ACTION_OPEN = 1
        const val ACTION_ENTER = 2
        const val ACTION_EXIT = 3
        const val ACTION_SEARCH = 4
        const val ACTION_TALK = 5
        const val ACTION_RELIC = 6
        const val ACTION_CRAFT = 7
        const val ACTION_FINISH = 8
        const val ACTION_CHOP = 9
        const val ACTION_MINE = 10
        const val KUNAI_MAX = 8
        const val KUNAI_SPEED = 42f
        /** How far the kunai auto-locks on to a monster, like a crossbow. */
        const val KUNAI_RANGE = 34f
        /** How fast a flying kunai drops. */
        const val KUNAI_DROP = 3f
        /** How hard a locked-on kunai turns towards its target (per second). */
        const val KUNAI_HOMING = 3.5f
        private val KUNAI_HITS = floatArrayOf(0.45f)
        private val HALBERD_HITS = floatArrayOf(0.3f, 0.8f)
        private val SWORD_HITS = floatArrayOf(0.22f, 0.52f, 0.84f)
        const val JUMP_SPEED = 7.2f
        const val JUMP_COST = 0.08f

        // ---------- Lock-on and dodge roll ----------
        const val LOCK_RANGE = 16f
        const val DODGE_TIME = 0.38f
        const val DODGE_SPEED = 15f
        const val DODGE_COST = 0.16f
        const val DODGE_COOLDOWN = 0.55f
        const val GRAVITY = 22f
        const val RADIUS = 0.4f
        const val REVEAL_CELLS = 24
        const val MAP_GRID = 17

        private fun fade(c: Int): Int {
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val grey = (r * 0.3f + g * 0.59f + b * 0.11f)
            val fr = ((r + (grey - r) * 0.75f) * 0.5f + 18f).toInt().coerceIn(0, 255)
            val fg = ((g + (grey - g) * 0.75f) * 0.5f + 16f).toInt().coerceIn(0, 255)
            val fb = ((b + (grey - b) * 0.75f) * 0.5f + 22f).toInt().coerceIn(0, 255)
            return (0xFF shl 24) or (fr shl 16) or (fg shl 8) or fb
        }
    }
}

/** A fallen monster, lying where it fell with whatever it was carrying, until you search it. */
class Body(val c: Creature, val name: String, val items: ArrayList<Item>, var gold: Int) {
    var age = 0f
}
