package com.keystone.rpg

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Player state. Updated on the drawing thread, read by the screen overlay. */
class Game(val world: World) {
    // Position in metres. y is eye height.
    @Volatile var x = world.spawnX
        private set
    @Volatile var z = world.spawnZ
        private set
    @Volatile var eyeY = world.groundAt(world.spawnX, world.spawnZ) + EYE
        private set
    @Volatile var yaw = world.spawnYaw
        private set
    @Volatile var pitch = -0.05f
        private set
    var time = 0f
        private set

    /** Zone for the drawing thread (the screen overlay uses [zone]). */
    @Volatile var currentZone = Zone.MEADOW
        private set

    // Left thumb: -1..1 each way. Set by the touch handler.
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f

    // Right thumb: turning, collected until the next frame.
    private val lookLock = Any()
    private var lookX = 0f
    private var lookY = 0f

    // For the screen overlay.
    var zone by mutableStateOf(Zone.MEADOW)
        private set
    var zoneVisit by mutableIntStateOf(0)
        private set
    var hudTick by mutableLongStateOf(0L)
        private set

    private val probe = Probe()
    private val placed = Placed()
    private var walk = 0f
    private var hudTimer = 0f

    // Fog-of-war map: fills in as you explore.
    private val explored = BooleanArray(GRID * GRID)
    private val minimap: Bitmap = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
        eraseColor(0xFF15131C.toInt())
    }
    val minimapImage: ImageBitmap = minimap.asImageBitmap()
    private var lastCi = -1
    private var lastCj = -1

    init {
        reveal()
    }

    fun addLook(dx: Float, dy: Float) {
        synchronized(lookLock) {
            lookX += dx
            lookY += dy
        }
    }

    fun update(dt: Float) {
        time += dt
        synchronized(lookLock) {
            yaw -= lookX
            pitch = (pitch - lookY).coerceIn(-1.2f, 1.2f)
            lookX = 0f
            lookY = 0f
        }

        val mx = moveX
        val my = moveY
        val len = hypot(mx, my)
        var moving = false
        if (len > 0.05f) {
            val limit = if (len > 1f) 1f / len else 1f
            val sy = sin(yaw)
            val cy = cos(yaw)
            // Forward is where we look; right is 90 degrees clockwise from it.
            val wx = (sy * -my + -cy * mx) * limit
            val wz = (cy * -my + sy * mx) * limit
            val step = SPEED * dt
            tryMove(x + wx * step, z)
            tryMove(x, z + wz * step)
            moving = true
            walk += dt * len.coerceAtMost(1f)
        }

        val ground = world.groundAt(x, z)
        val feet = if (ground < 0f && !world.onBridge(x, z)) ground.coerceAtLeast(-0.9f) else ground
        val bob = if (moving) abs(sin(walk * 9f)) * 0.07f else 0f
        val target = feet + EYE + bob
        eyeY += (target - eyeY) * (dt * 12f).coerceAtMost(1f)

        world.probe(x, z, probe)
        val zNow = probe.zone
        if (zNow != currentZone) {
            currentZone = zNow
            zone = zNow
            zoneVisit = zoneVisit + 1
        }

        reveal()
        hudTimer += dt
        if (hudTimer > 0.08f) {
            hudTimer = 0f
            hudTick = hudTick + 1
        }
    }

    private fun tryMove(nx: Float, nz: Float) {
        if (world.isBlocked(nx, nz, probe)) return
        if (world.hitsObstacle(nx, nz, RADIUS, placed, probe)) return
        x = nx
        z = nz
    }

    private fun reveal() {
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        if (ci == lastCi && cj == lastCj) return
        lastCi = ci
        lastCj = cj
        val r = REVEAL_CELLS
        for (dj in -r..r) {
            for (di in -r..r) {
                if (di * di + dj * dj > r * r) continue
                val i = ci + di
                val j = cj + dj
                if (i < 0 || j < 0 || i >= GRID || j >= GRID) continue
                val idx = j * GRID + i
                if (explored[idx]) continue
                explored[idx] = true
                minimap.setPixel(i, j, world.mapColors[idx])
            }
        }
    }

    companion object {
        const val EYE = 1.7f
        const val SPEED = 7f
        const val RADIUS = 0.4f
        const val REVEAL_CELLS = 24
    }
}
