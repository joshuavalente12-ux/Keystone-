package com.keystone.rpg

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.floor
import kotlin.math.hypot

class Game(val world: World) {
    // Player position in tiles (1.0 = one tile).
    var x = world.spawnX
        private set
    var y = world.spawnY
        private set
    var faceX = 0f
        private set
    var faceY = 1f
        private set
    var moving = false
        private set
    var walkTime = 0f
        private set
    var time = 0f
        private set

    // Joystick input, each -1..1. Set by the touch handler.
    var inputX = 0f
    var inputY = 0f

    // Bumped every frame so the screen redraws.
    var tick by mutableLongStateOf(0L)
        private set
    var zone by mutableStateOf(Zone.MEADOW)
        private set
    var zoneVisit by mutableIntStateOf(0)
        private set

    private val radius = 0.3f
    private val speed = 4.2f
    private val revealRadius = 7

    private val explored = BooleanArray(world.size * world.size)
    private val minimap: Bitmap =
        Bitmap.createBitmap(world.size, world.size, Bitmap.Config.ARGB_8888).apply {
            eraseColor(0xFF15131C.toInt())
        }
    val minimapImage: ImageBitmap = minimap.asImageBitmap()

    private var lastTx = Int.MIN_VALUE
    private var lastTy = Int.MIN_VALUE

    init {
        checkTile()
    }

    fun update(dt: Float) {
        time += dt
        val len = hypot(inputX, inputY)
        moving = len > 0.01f
        if (moving) {
            val limit = if (len > 1f) 1f / len else 1f
            faceX = inputX / len
            faceY = inputY / len
            val step = speed * dt
            tryMove(inputX * limit * step, 0f)
            tryMove(0f, inputY * limit * step)
            walkTime += dt
        }
        checkTile()
        tick = tick + 1
    }

    private fun tryMove(mx: Float, my: Float) {
        val nx = x + mx
        val ny = y + my
        if (!blocked(nx, ny)) {
            x = nx
            y = ny
        }
    }

    /** Circle-vs-tile check against every solid tile the player could touch. */
    private fun blocked(px: Float, py: Float): Boolean {
        val minX = floor(px - radius).toInt()
        val maxX = floor(px + radius).toInt()
        val minY = floor(py - radius).toInt()
        val maxY = floor(py + radius).toInt()
        for (ty in minY..maxY) {
            for (tx in minX..maxX) {
                if (!world.isSolid(tx, ty)) continue
                val cx = px.coerceIn(tx.toFloat(), tx + 1f)
                val cy = py.coerceIn(ty.toFloat(), ty + 1f)
                val ddx = px - cx
                val ddy = py - cy
                if (ddx * ddx + ddy * ddy < radius * radius) return true
            }
        }
        return false
    }

    private fun checkTile() {
        val tx = floor(x).toInt()
        val ty = floor(y).toInt()
        if (tx == lastTx && ty == lastTy) return
        lastTx = tx
        lastTy = ty
        reveal(tx, ty)
        val z = world.zoneAt(tx, ty)
        if (z != zone) {
            zone = z
            zoneVisit = zoneVisit + 1
        }
    }

    private fun reveal(cx: Int, cy: Int) {
        val n = world.size
        for (dy in -revealRadius..revealRadius) {
            for (dx in -revealRadius..revealRadius) {
                if (dx * dx + dy * dy > revealRadius * revealRadius) continue
                val tx = cx + dx
                val ty = cy + dy
                if (tx < 0 || ty < 0 || tx >= n || ty >= n) continue
                val i = ty * n + tx
                if (explored[i]) continue
                explored[i] = true
                minimap.setPixel(tx, ty, Palette.mapColor(world.tiles[i], world.zoneIndex(tx, ty)))
            }
        }
    }
}
