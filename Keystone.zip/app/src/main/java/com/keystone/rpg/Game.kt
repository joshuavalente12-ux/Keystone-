package com.keystone.rpg

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Player state. Updated on the drawing thread, read by the screen overlay. */
class Game(val world: World) {
    // Position in metres. y is eye height.
    @Volatile var x = world.spawnX
        private set
    @Volatile var z = world.spawnZ
        private set
    @Volatile var eyeY = world.groundAt(world.spawnX, world.spawnZ) + EYE
        private set
    @Volatile var yaw = world.spawnYaw
        private set
    @Volatile var pitch = -0.05f
        private set
    var time = 0f
        private set

    /** Time of day and weather. */
    val weather = Weather()

    /** The animals and birds living around you. */
    val fauna = Fauna(world)

    /** Camera behind the hero (true) or looking out through his eyes (false). */
    @Volatile var thirdPerson = true

    /** When on, the hero turns and punches anything that comes within reach by himself. */
    @Volatile var autoFight = false

    // ---------- Treasure ----------
    /** Chests and hidden caves, always in the same places. */
    val treasure = Treasure(world)
    /** Your bag, what you're wearing, your gold. */
    val loot = Loot()
    /** Cave you're inside (index into treasure.caves), or -1 out in the world. */
    @Volatile var inCave = -1
        private set
    /** Mesh of the cave you're in, for the renderer to upload. [caveMeshId] changes with each new one. */
    @Volatile var caveData: java.nio.ByteBuffer? = null
        private set
    @Volatile var caveCount = 0
        private set
    @Volatile var caveMeshId = 0
        private set
    /** What the context button does right now: see [ACTION_NONE] etc. */
    @Volatile var action = ACTION_NONE
        private set
    @Volatile private var interactAsked = false
    @Volatile private var pendingHeal = 0f
    /** Black fade when going in and out of caves, from 1 to 0. */
    @Volatile var fade = 0f
        private set
    /** What came out of the last chest, for the pop-up. */
    @Volatile var lastLoot: List<Item> = emptyList()
        private set
    var lootVisit by mutableIntStateOf(0)
        private set

    /** Most health you can have: grows with your level and what you're wearing. */
    val maxHealth: Float get() = MAX_HEALTH + (loot.level - 1) * 12f + loot.vitality
    /** Your level and progress to the next, for the bars at the bottom of the screen. */
    val level: Int get() = loot.level
    val xpFrac: Float get() = if (loot.level >= MAX_LEVEL) 1f else loot.xp.toFloat() / loot.xpNeeded(loot.level)
    /** Bumps each time you level up, to show the banner. */
    var levelVisit by mutableIntStateOf(0)
        private set
    /** "+48 XP" after a kill, and [xpVisit] to show it. */
    @Volatile var xpToast = ""
        private set
    var xpVisit by mutableIntStateOf(0)
        private set
    /** Title for the pop-up: treasure from a chest, or something a monster dropped. */
    @Volatile var lootTitle = "TREASURE!"
        private set
    /** Items monsters have dropped, waiting to be picked up. */
    val drops = ArrayList<Drop>()

    // ---------- Your health ----------
    @Volatile var health = MAX_HEALTH
        private set
    /** Knocked out: you wake up back in Greenhollow a few seconds later. */
    @Volatile var dead = false
        private set
    private var deadTimer = 0f
    private var regenWait = 0f
    /** Red flash round the screen when you get hit, fading from 1. */
    @Volatile var hurtFlash = 0f
        private set

    // ---------- The monster you're fighting, for the panel at the top of the screen ----------
    private var target: Creature? = null
    private var targetSeen = 0f
    @Volatile var targetName = ""
        private set
    @Volatile var targetLevel = 0
        private set
    /** 0..1 health left, or -1 when there's nothing to show. */
    @Volatile var targetFrac = -1f
        private set

    /** Which weapon you chose at the start: see [WeaponClass]. */
    @Volatile var weaponClass = WeaponClass.SWORD

    @Volatile private var attackAsked = false
    private var attackTimer = 0f
    private var attackLength = 1f
    private var nextHit = 0
    /** How far through the current attack we are, 0..1, or -1 when not attacking. */
    val attackPhase: Float get() = if (attackTimer > 0f) 1f - attackTimer / attackLength else -1f
    /** False while the kunai is flying; a new one appears in your hand a moment later. */
    val weaponInHand: Boolean get() {
        if (weaponClass != WeaponClass.KUNAI) return true
        val p = attackPhase
        return p < 0.45f || p > 0.85f
    }

    /** Thrown kunai: x, y, z, vx, vy, vz, age (-1 = not flying). */
    val kunai = FloatArray(KUNAI_MAX * 7).also { for (i in 0 until KUNAI_MAX) it[i * 7 + 6] = -1f }
    private var aimX = 0f
    private var aimY = 0f
    private var aimZ = 0f
    private var aimed = false

    // What the hero model needs to animate itself.
    /** Height of the soles of your feet. */
    val feet: Float get() = feetY
    /** Which way the body faces. In third person he turns to face where he's walking. */
    var bodyYaw = world.spawnYaw
        private set
    /** Walk cycle: one full turn is a left and a right step. */
    val stridePhase: Float get() = walk * 9f + 1.5707964f
    /** 0 standing, 1 moving at full speed. */
    var moveAmount = 0f
        private set
    /** 0 walking, 1 sprinting. */
    var runAmount = 0f
        private set
    /** 0 on the ground, 1 in the air. */
    var airAmount = 0f
        private set

    /**
     * Dust, sand, snow and splashes kicked up by your feet. Each puff: x, y, z,
     * age (0 new .. 1 gone), kind (see [PUFF_DIRT] etc.), size.
     */
    val puffs = FloatArray(PUFFS * 6).also { for (i in 0 until PUFFS) it[i * 6 + 3] = 1f }
    private var nextPuff = 0
    private var footSide = 1f
    private var camDist = 4f
    private var climbing = false

    /** True when standing on a floor inside a house or castle (rain goes quiet). */
    @Volatile var indoors = false
        private set

    /** Zone for the drawing thread (the screen overlay uses [zone]). */
    @Volatile var currentZone = Zone.MEADOW
        private set

    // Left thumb: -1..1 each way. Set by the touch handler.
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f

    /** Run button: on or off. */
    @Volatile var runOn = false

    /** 0..1. Running and jumping use it up; it comes back when you rest. */
    @Volatile var stamina = 1f
        private set

    /** True after running out: you have to catch your breath before running again. */
    @Volatile var winded = false
        private set

    @Volatile private var jumpAsked = false
    private var feetY = world.groundAt(world.spawnX, world.spawnZ)
    private var vy = 0f
    private var airborne = false
    private var restTimer = 0f

    // Right thumb: turning, collected until the next frame.
    private val lookLock = Any()
    private var lookX = 0f
    private var lookY = 0f

    // For the screen overlay.
    var zone by mutableStateOf(Zone.MEADOW)
        private set
    var zoneVisit by mutableIntStateOf(0)
        private set
    var hudTick by mutableLongStateOf(0L)
        private set

    /** Named places you've found. Greenhollow, where you start, counts from the beginning. */
    val discovered = BooleanArray(PLACES.size).also { it[0] = true }
    var discoverVisit by mutableIntStateOf(0)
        private set
    var lastDiscovered by mutableStateOf("")
        private set

    /** Region colours and borders, laid over the big map. */
    val regionOverlay: ImageBitmap

    private val probe = Probe()
    private val placed = Placed()
    private var walk = 0f
    private var stepCount = 0
    private var landed = false
    private var hudTimer = 0f

    // Fog-of-war map: fills in as you explore.
    private val explored = BooleanArray(GRID * GRID)
    private val minimap: Bitmap = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
        // Places you haven't been yet show as a faded, grey map.
        val faded = IntArray(GRID * GRID) { fade(world.mapColors[it]) }
        setPixels(faded, 0, GRID, 0, 0, GRID, GRID)
    }
    val minimapImage: ImageBitmap = minimap.asImageBitmap()
    private var lastCi = -1
    private var lastCj = -1

    init {
        val over = IntArray(GRID * GRID)
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val idx = j * GRID + i
                val r = world.regionMap[idx]
                val border = (i > 0 && world.regionMap[idx - 1] != r) ||
                    (j > 0 && world.regionMap[idx - GRID] != r) ||
                    (i < GRID - 1 && world.regionMap[idx + 1] != r) ||
                    (j < GRID - 1 && world.regionMap[idx + GRID] != r)
                val rgb = Zone.entries[r.toInt()].mapColor
                over[idx] = (if (border) 0xD0 shl 24 else 0x2C shl 24) or rgb
            }
        }
        regionOverlay = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
            setPixels(over, 0, GRID, 0, 0, GRID, GRID)
        }.asImageBitmap()
        reveal()
    }

    /** Map grid square you're in, like "H-7": letters down the side, numbers along the top. */
    fun gridRef(): String {
        val col = (x / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        val row = (z / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        return "${'A' + row}-$col"
    }

    fun jump() {
        jumpAsked = true
    }

    fun attack() {
        attackAsked = true
    }

    /** The context button: open a chest, go into a cave, or come back out. */
    fun interact() {
        interactAsked = true
    }

    /** Drinks the potion at [index] in your bag. */
    fun drinkPotion(index: Int) {
        val heal = loot.drink(index)
        if (heal > 0) pendingHeal += heal.toFloat()
    }

    /** Loads your bag and which chests you've opened. Call before playing. */
    fun loadSave(ctx: Context) {
        loot.load(ctx)
        health = maxHealth
        for (c in treasure.chests) {
            if (loot.isOpened(c.id)) {
                c.opened = true
                c.openT = 1f
            }
        }
    }

    /** How much harder your hits are, from what you're wearing. */
    private fun powerMul(): Float = 1f + loot.power / 40f

    fun addLook(dx: Float, dy: Float) {
        synchronized(lookLock) {
            lookX += dx
            lookY += dy
        }
    }

    fun update(dt: Float) {
        time += dt
        synchronized(lookLock) {
            yaw -= lookX
            pitch = (pitch - lookY).coerceIn(-1.2f, 1.2f)
            lookX = 0f
            lookY = 0f
        }

        val mx = if (dead) 0f else moveX
        val my = if (dead) 0f else moveY
        val len = hypot(mx, my)
        val moving = len > 0.05f
        val sprinting = moving && runOn && !winded
        if (moving) {
            val limit = if (len > 1f) 1f / len else 1f
            val sy = sin(yaw)
            val cy = cos(yaw)
            // Forward is where we look; right is 90 degrees clockwise from it.
            val wx = (sy * -my + -cy * mx) * limit
            val wz = (cy * -my + sy * mx) * limit
            var step = (if (sprinting) RUN_SPEED else WALK_SPEED) * dt * (1f + loot.speed / 100f)
            // Steep ground: you slow to a climb, and it tires you out.
            climbing = false
            var tooTired = false
            val stepLen = hypot(wx, wz) * step
            if (inCave < 0 && stepLen > 1e-4f && world.floorUnder(x, z, feetY) == 0) {
                val rise = world.terrainAt(x + wx * step, z + wz * step) - world.terrainAt(x, z)
                val grade = rise / stepLen
                if (grade > 0.45f) step *= (1.25f - grade * 0.55f).coerceIn(0.35f, 1f)
                // Picking your way down a steep face is slower too.
                if (grade < -0.8f) step *= (1.2f + grade * 0.3f).coerceIn(0.45f, 1f)
                if (grade > 0.9f) {
                    climbing = true
                    if (winded) tooTired = true
                }
            }
            if (!tooTired) {
                tryMove(x + wx * step, z)
                tryMove(x, z + wz * step)
            }
            walk += dt * len.coerceAtMost(1f) * (if (sprinting) 1.5f else 1f) * (if (climbing) 0.7f else 1f)
            // Turn the body to face the way we're walking.
            val want = atan2(wx, wz)
            var d = want - bodyYaw
            while (d > 3.1415927f) d -= 6.2831855f
            while (d < -3.1415927f) d += 6.2831855f
            bodyYaw += d * min(1f, dt * 10f)
        } else {
            climbing = false
        }
        if (!thirdPerson) bodyYaw = yaw
        moveAmount += ((if (moving) len.coerceAtMost(1f) else 0f) - moveAmount) * min(1f, dt * 8f)
        runAmount += ((if (sprinting) 1f else 0f) - runAmount) * min(1f, dt * 5f)

        // Stamina.
        if (sprinting || (climbing && moving)) {
            stamina -= (if (sprinting) dt / RUN_SECONDS else 0f) + (if (climbing) dt / CLIMB_SECONDS else 0f)
            restTimer = 0f
            if (stamina <= 0f) {
                stamina = 0f
                winded = true
            }
        } else {
            restTimer += dt
            if (restTimer > 0.8f) stamina = (stamina + dt / RECOVER_SECONDS).coerceAtMost(1f)
        }
        if (winded && stamina > 0.3f) winded = false

        // Jumping and falling.
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        val ground = if (cv != null) cv.floorAt(x - cv.x, z - cv.z) else world.groundAt(x, z, feetY)
        val floor = if (cv == null && ground < 0f && !world.onBridge(x, z)) ground.coerceAtLeast(-0.9f) else ground
        if (jumpAsked) {
            jumpAsked = false
            if (!airborne && stamina >= JUMP_COST) {
                vy = JUMP_SPEED
                airborne = true
                stamina -= JUMP_COST
                restTimer = 0f
            }
        }
        if (airborne) {
            vy -= GRAVITY * dt
            feetY += vy * dt
            if (feetY <= floor) {
                feetY = floor
                vy = 0f
                airborne = false
                landed = true
            }
        } else if (floor < feetY - 0.8f) {
            airborne = true
            vy = 0f
        } else {
            feetY += (floor - feetY) * (dt * 14f).coerceAtMost(1f)
            // Climbing a steep slope: don't let the feet sink into the hillside.
            if (feetY < floor - 0.12f) feetY = floor - 0.12f
        }
        airAmount += ((if (airborne) 1f else 0f) - airAmount) * min(1f, dt * 10f)
        val bob = if (moving && !airborne) abs(sin(walk * 9f)) * (if (sprinting) 0.1f else 0.07f) else 0f
        eyeY = feetY + EYE + bob

        world.probe(x, z, probe)
        val si = probe.siteIndex
        if (si >= 0 && !discovered[si] && probe.siteCenter < PLACES[si].radius + 35f) {
            discovered[si] = true
            lastDiscovered = PLACES[si].name
            discoverVisit = discoverVisit + 1
        }
        val zNow = probe.zone
        if (zNow != currentZone) {
            currentZone = zNow
            zone = zNow
            zoneVisit = zoneVisit + 1
        }

        weather.update(dt, currentZone)
        fauna.playerDown = dead || inCave >= 0
        fauna.playerLevel = loot.level
        fauna.update(dt, x, z, time)
        updateHealth(dt)
        updateTreasure(dt)
        updateDrops(dt)
        updateAttack(dt)
        updateKunai(dt)
        for (i in 0 until PUFFS) {
            val a = i * 6 + 3
            if (puffs[a] < 1f) puffs[a] = min(1f, puffs[a] + dt / 1.1f)
        }

        // Footsteps, matched to what's underfoot.
        val under = if (inCave >= 0) 2 else world.floorUnder(x, z, feetY)
        indoors = under == 1 || under == 2
        if (landed) {
            landed = false
            val sf = surface(under)
            Sound.step(sf, 1.25f)
            kickUp(sf, 0f, 1.6f)
            kickUp(sf, 0f, 1.2f)
        } else if (moving && !airborne) {
            val sc = kotlin.math.floor(walk * 9f / 3.1415927f).toInt()
            if (sc != stepCount) {
                stepCount = sc
                val sf = surface(under)
                Sound.step(sf, if (sprinting) 1f else 0.75f)
                footSide = -footSide
                kickUp(sf, footSide, if (sprinting) 1.3f else 0.85f)
            }
        }
        Sound.wind = weather.windFor(currentZone)
        Sound.rain = weather.rainFor(currentZone)
        Sound.indoors = indoors

        reveal()
        hudTimer += dt
        if (hudTimer > 0.08f) {
            hudTimer = 0f
            hudTick = hudTick + 1
        }
    }

    /** Attacks with your weapon: when you tap the button, or by itself when auto fight is on. */
    private fun updateAttack(dt: Float) {
        if (attackTimer > 0f) {
            attackTimer -= dt
            val p = attackPhase
            val hits = hitTimes()
            while (nextHit < hits.size && (p >= hits[nextHit] || attackTimer <= 0f)) {
                strike(nextHit)
                nextHit++
            }
            if (attackTimer <= 0f) attackTimer = 0f
        }
        val range = autoRange()
        var target: Creature? = null
        if (dead) attackAsked = false
        // Auto fight goes for monsters first, and only swings at animals if there are none.
        if (autoFight && attackTimer <= 0f && !dead) target = nearestAnimal(range, true) ?: nearestAnimal(range, false)
        if ((attackAsked || target != null) && attackTimer <= 0f) {
            if (target == null) target = nearestAnimal(range, true) ?: nearestAnimal(range, false)
            // Turn to face whatever you're attacking (third person only; in first person you aim).
            if (target != null && thirdPerson) bodyYaw = atan2(target.x - x, target.z - z)
            aimed = target != null
            if (target != null) {
                val sp = fauna.species[target.sp]
                aimX = target.x + sin(target.yaw) * sp.colZ * target.scale
                aimY = target.y + 0.9f * target.scale
                aimZ = target.z + cos(target.yaw) * sp.colZ * target.scale
            }
            attackLength = when (weaponClass) {
                WeaponClass.KUNAI -> 0.6f
                WeaponClass.HALBERD -> 1.15f
                else -> 1.25f
            }
            attackTimer = attackLength
            nextHit = 0
        }
        attackAsked = false
    }

    /** When, through the attack, each blow lands (or the kunai leaves your hand). */
    private fun hitTimes(): FloatArray = when (weaponClass) {
        WeaponClass.KUNAI -> KUNAI_HITS
        WeaponClass.HALBERD -> HALBERD_HITS
        else -> SWORD_HITS
    }

    /** How close something must be for auto fight to go for it. */
    private fun autoRange(): Float = when (weaponClass) {
        WeaponClass.KUNAI -> 18f
        WeaponClass.HALBERD -> 2.6f
        else -> 2.2f
    }

    /** Blow number [n] of the current attack lands. */
    private fun strike(n: Int) {
        when (weaponClass) {
            WeaponClass.KUNAI -> throwKunai()
            // Halberd: a full spinning sweep that hits all round you, then a slam straight ahead.
            WeaponClass.HALBERD -> if (n == 0) melee(2.9f, -1.1f, 1) else melee(3.3f, 0.5f, 2)
            // Sword: two slashes, then an overhead chop.
            else -> if (n < 2) melee(2.5f, 0.15f, 1) else melee(2.7f, 0.55f, 2)
        }
    }

    /**
     * Hits every animal within [reach] metres (plus its size) and inside the cone in front of
     * you where the cosine of the angle is at least [cone] (-1 hits all the way round).
     */
    private fun melee(reach: Float, cone: Float, damage: Int) {
        if (inCave >= 0) return
        val face = if (thirdPerson) bodyYaw else yaw
        val fx = sin(face)
        val fz = cos(face)
        var any = false
        for (c in fauna.creatures) {
            if (!c.active || c.dying >= 0f) continue
            val sp = fauna.species[c.sp]
            val dx = c.x - x
            val dz = c.z - z
            val d = hypot(dx, dz)
            if (d > reach + (sp.colR + sp.colHalf * 0.6f) * c.scale) continue
            if (d > 0.8f && (dx * fx + dz * fz) / d < cone) continue
            val px = if (d > 1e-3f) dx / d else fx
            val pz = if (d > 1e-3f) dz / d else fz
            strikeCreature(c, px, pz, damage.toFloat())
            spawnPuff(c.x - px * sp.colR * c.scale, c.y + 0.8f * c.scale, c.z - pz * sp.colR * c.scale, PUFF_HIT, 1.1f)
            any = true
        }
        if (any) Sound.step(Surface.DIRT, 1.4f)
    }

    /** Lets a kunai fly from your hand: at your target if you have one, otherwise where you're looking. */
    private fun throwKunai() {
        var slot = -1
        for (i in 0 until KUNAI_MAX) if (kunai[i * 7 + 6] < 0f) { slot = i; break }
        if (slot < 0) slot = 0
        val face = if (thirdPerson) bodyYaw else yaw
        val sx = x + sin(face) * 0.5f
        val sy = feetY + 1.75f
        val sz = z + cos(face) * 0.5f
        var dx: Float
        var dy: Float
        var dz: Float
        if (aimed) {
            dx = aimX - sx
            dy = aimY - sy
            dz = aimZ - sz
        } else {
            val cp = cos(pitch)
            dx = cp * sin(yaw)
            dy = sin(pitch) + 0.05f
            dz = cp * cos(yaw)
        }
        val l = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1e-4f)
        val o = slot * 7
        kunai[o] = sx
        kunai[o + 1] = sy
        kunai[o + 2] = sz
        kunai[o + 3] = dx / l * KUNAI_SPEED
        kunai[o + 4] = dy / l * KUNAI_SPEED
        kunai[o + 5] = dz / l * KUNAI_SPEED
        kunai[o + 6] = 0f
        Sound.step(Surface.SAND, 0.6f)
    }

    /** Moves thrown kunai along, and stops them when they hit an animal, the ground or a wall. */
    private fun updateKunai(dt: Float) {
        for (i in 0 until KUNAI_MAX) {
            val o = i * 7
            if (kunai[o + 6] < 0f) continue
            kunai[o + 6] += dt
            kunai[o + 4] -= 3f * dt
            // Small steps, so a fast kunai can't jump straight past a small animal.
            var gone = false
            for (step in 0 until 4) {
                val h = dt / 4f
                kunai[o] += kunai[o + 3] * h
                kunai[o + 1] += kunai[o + 4] * h
                kunai[o + 2] += kunai[o + 5] * h
                val kx = kunai[o]
                val ky = kunai[o + 1]
                val kz = kunai[o + 2]
                for (c in fauna.creatures) {
                    if (inCave >= 0) break
                    if (!c.active || c.dying >= 0f) continue
                    val sp = fauna.species[c.sp]
                    if (ky < c.y - 0.2f || ky > c.y + 2.2f * c.scale) continue
                    val dx = kx - c.x
                    val dz = kz - c.z
                    val hx = sin(c.yaw)
                    val hz = cos(c.yaw)
                    val mid = sp.colZ * c.scale
                    val along = (dx * hx + dz * hz - mid).coerceIn(-sp.colHalf * c.scale, sp.colHalf * c.scale) + mid
                    val qx = dx - hx * along
                    val qz = dz - hz * along
                    val rr = sp.colR * c.scale + 0.35f
                    if (qx * qx + qz * qz < rr * rr) {
                        val v = hypot(kunai[o + 3], kunai[o + 5]).coerceAtLeast(1e-3f)
                        strikeCreature(c, kunai[o + 3] / v, kunai[o + 5] / v, 2f)
                        spawnPuff(kx, ky, kz, PUFF_HIT, 1.2f)
                        Sound.step(Surface.DIRT, 1.3f)
                        gone = true
                        break
                    }
                }
                if (gone) break
                val kcv = if (inCave >= 0) treasure.caves[inCave] else null
                val blocked = if (kcv != null) {
                    val dd = kcv.inside(kx - kcv.x, kz - kcv.z)
                    dd < 0.3f || ky < kcv.floorFrom(kx - kcv.x, kz - kcv.z, dd) || ky > kcv.ceilFrom(kx - kcv.x, kz - kcv.z, dd)
                } else {
                    ky < world.groundAt(kx, kz, ky) || hitsWall(kx, ky, kz, 0.1f)
                }
                if (blocked) {
                    spawnPuff(kx, ky, kz, PUFF_STONE, 0.8f)
                    gone = true
                    break
                }
            }
            if (gone || kunai[o + 6] > 1.6f) kunai[o + 6] = -1f
        }
    }

    /**
     * Lands a blow of [base] damage on [c]. Your gear adds Power, and your level against
     * the monster's matters a lot: well below it, you barely scratch it.
     */
    private fun strikeCreature(c: Creature, dx: Float, dz: Float, base: Float) {
        val sp = fauna.species[c.sp]
        val gap = if (sp.monster) (1f + (loot.level - c.level) * 0.035f).coerceIn(0.08f, 1.8f) else 1f
        val alive = c.dying < 0f
        fauna.hit(c, dx, dz, base * powerMul() * gap)
        noteTarget(c)
        if (alive && c.dying >= 0f) onKill(c)
    }

    /** Experience, gold and maybe an item for bringing something down. */
    private fun onKill(c: Creature) {
        val sp = fauna.species[c.sp]
        if (!sp.monster) {
            gainXp(3, 0)
            return
        }
        val tier = tierOf(sp.zones[0])
        var xpGain = ((8 + c.level * 4) * (sp.hp / 4f)).toInt()
        // Monsters far below you are hardly worth it.
        if (loot.level - c.level > 10) xpGain = max(1, xpGain / 5)
        val coins = (2 + kotlin.random.Random.nextInt(5)) * tier
        loot.addGold(coins)
        gainXp(xpGain, coins)
        // Big ones always drop something; the rest, now and then.
        val chance = if (sp.hp >= 25) 1f else 0.35f
        if (kotlin.random.Random.nextFloat() < chance && drops.size < 24) {
            drops.add(Drop(c.x, world.groundAt(c.x, c.z), c.z, loot.rollDrop(tier)))
        }
    }

    private fun gainXp(amount: Int, coins: Int) {
        val ups = loot.addXp(amount)
        xpToast = if (coins > 0) "+$amount XP   +$coins gold" else "+$amount XP"
        xpVisit = xpVisit + 1
        if (ups > 0) {
            health = maxHealth
            levelVisit = levelVisit + 1
            Sound.call(0, 1f)
        }
    }

    /** Dropped items bob on the ground; walk over one to pick it up. */
    private fun updateDrops(dt: Float) {
        val it = drops.iterator()
        while (it.hasNext()) {
            val d = it.next()
            d.age += dt
            if (d.age > 120f) {
                it.remove()
                continue
            }
            if (inCave < 0 && !dead && hypot(d.x - x, d.z - z) < 1.6f && abs(d.y - feetY) < 2.5f) {
                loot.addItem(d.item)
                lootTitle = "PICKED UP"
                lastLoot = listOf(d.item)
                lootVisit = lootVisit + 1
                Sound.step(Surface.WOOD, 1f)
                it.remove()
            }
        }
    }

    /** Chest lids, the context button, and going in and out of caves. */
    private fun updateTreasure(dt: Float) {
        fade = max(0f, fade - dt * 1.3f)
        for (c in treasure.chests) if (c.opened && c.openT < 1f) c.openT = min(1f, c.openT + dt * 1.8f)
        // What's within reach?
        var chest: Chest? = null
        var best = 2.4f
        for (c in treasure.chests) {
            if (c.opened || c.cave != inCave) continue
            val d = hypot(c.x - x, c.z - z)
            if (d < best && abs(c.y - feetY) < 2f) {
                best = d
                chest = c
            }
        }
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        val mouth = if (cv == null) treasure.caveMouthNear(x, z, 3.2f) else null
        val exit = cv != null && hypot(x - cv.x, z - cv.z) < 2.2f
        action = when {
            dead -> ACTION_NONE
            chest != null -> ACTION_OPEN
            mouth != null -> ACTION_ENTER
            exit -> ACTION_EXIT
            else -> ACTION_NONE
        }
        if (!interactAsked) return
        interactAsked = false
        when (action) {
            ACTION_OPEN -> if (chest != null) openChest(chest)
            ACTION_ENTER -> if (mouth != null) enterCave(mouth)
            ACTION_EXIT -> if (cv != null) leaveCave(cv)
            else -> {}
        }
    }

    private fun openChest(c: Chest) {
        c.opened = true
        lootTitle = "TREASURE!"
        lastLoot = loot.openChest(c.id, c.tier, c.rich)
        lootVisit = lootVisit + 1
        Sound.call(0, 1f)
        Sound.step(Surface.WOOD, 1.2f)
    }

    private fun enterCave(cv: Cave) {
        val mb = cv.buildMesh()
        caveCount = mb.vertexCount
        caveData = mb.finish()
        caveMeshId = caveMeshId + 1
        inCave = cv.id
        // Arrive by the shaft of light, facing into the cave.
        val next = cv.chambers.getOrNull(1)
        val face = if (next != null) atan2(next[0], next[1]) else 0f
        x = cv.x + sin(face) * 2.5f
        z = cv.z + cos(face) * 2.5f
        yaw = face
        bodyYaw = face
        feetY = cv.floorAt(x - cv.x, z - cv.z)
        vy = 0f
        airborne = false
        fade = 1f
        attackTimer = 0f
        for (i in 0 until KUNAI_MAX) kunai[i * 7 + 6] = -1f
        lastDiscovered = cv.name
        discoverVisit = discoverVisit + 1
    }

    private fun leaveCave(cv: Cave) {
        inCave = -1
        x = cv.x + sin(cv.yaw) * 2.2f
        z = cv.z + cos(cv.yaw) * 2.2f
        yaw = cv.yaw
        bodyYaw = cv.yaw
        feetY = world.groundAt(x, z)
        vy = 0f
        airborne = false
        fade = 1f
        attackTimer = 0f
        for (i in 0 until KUNAI_MAX) kunai[i * 7 + 6] = -1f
    }

    /** Takes damage from monsters, heals slowly out of a fight, and handles being knocked out. */
    private fun updateHealth(dt: Float) {
        hurtFlash = max(0f, hurtFlash - dt * 1.6f)
        val dmg = fauna.pendingDamage
        fauna.pendingDamage = 0f
        if (dead) {
            deadTimer += dt
            if (deadTimer > 3.5f) respawn()
            return
        }
        if (pendingHeal > 0f) {
            health = min(maxHealth, health + pendingHeal)
            pendingHeal = 0f
        }
        if (dmg > 0f) {
            health = max(0f, health - dmg * 100f / (100f + loot.defense))
            hurtFlash = 1f
            regenWait = 5f
            Sound.step(Surface.DIRT, 1.5f)
            fauna.lastAttacker?.let { noteTarget(it) }
            if (health <= 0f) {
                dead = true
                deadTimer = 0f
                attackTimer = 0f
                fauna.calmAll()
                return
            }
        }
        regenWait -= dt
        if (health > maxHealth) health = maxHealth
        if (regenWait <= 0f && health < maxHealth) health = min(maxHealth, health + 8f * dt)
        // The panel at the top: the monster you're fighting, while it's close.
        val t = target
        if (t != null) {
            val gone = !t.active || (t.dying >= 0f && t.dying > 2f) || hypot(t.x - x, t.z - z) > 45f
            if (gone) {
                target = null
                targetFrac = -1f
            } else {
                targetFrac = if (t.dying >= 0f) 0f else t.health / max(1f, t.maxHealth)
            }
        }
    }

    /** Shows [c] in the panel at the top of the screen, if it's a monster. */
    private fun noteTarget(c: Creature) {
        val sp = fauna.species[c.sp]
        if (!sp.monster) return
        target = c
        targetName = sp.name
        targetLevel = c.level
        targetFrac = if (c.dying >= 0f) 0f else c.health / max(1f, c.maxHealth)
    }

    /** Wake up back at the start, fully healed. */
    private fun respawn() {
        dead = false
        inCave = -1
        health = maxHealth
        hurtFlash = 0f
        x = world.spawnX
        z = world.spawnZ
        yaw = world.spawnYaw
        bodyYaw = yaw
        feetY = world.groundAt(x, z)
        vy = 0f
        airborne = false
        eyeY = feetY + EYE
        target = null
        targetFrac = -1f
    }

    /** The closest living animal within [range] metres of your body, or null. */
    private fun nearestAnimal(range: Float, monsters: Boolean): Creature? {
        if (inCave >= 0) return null
        var best: Creature? = null
        var bestD = 1e9f
        for (c in fauna.creatures) {
            if (!c.active || c.dying >= 0f) continue
            val sp = fauna.species[c.sp]
            if (sp.monster != monsters) continue
            val d = hypot(c.x - x, c.z - z) - (sp.colR + sp.colHalf * 0.5f) * c.scale
            if (d < range && d < bestD) {
                bestD = d
                best = c
            }
        }
        return best
    }

    private fun spawnPuff(px: Float, py: Float, pz: Float, kind: Int, size: Float) {
        val o = nextPuff * 6
        nextPuff = (nextPuff + 1) % PUFFS
        puffs[o] = px
        puffs[o + 1] = py
        puffs[o + 2] = pz
        puffs[o + 3] = 0f
        puffs[o + 4] = kind.toFloat()
        puffs[o + 5] = size
    }

    /** A little cloud of whatever you're walking on, thrown up behind the foot that just landed. */
    private fun kickUp(surface: Int, side: Float, size: Float) {
        val kind = when (surface) {
            Surface.DIRT -> PUFF_DIRT
            Surface.SAND -> PUFF_SAND
            Surface.SNOW -> PUFF_SNOW
            Surface.STONE, Surface.ROCK -> PUFF_STONE
            Surface.WATER -> PUFF_WATER
            Surface.GRASS -> PUFF_GRASS
            else -> return
        }
        val fx = sin(bodyYaw)
        val fz = cos(bodyYaw)
        val i = nextPuff
        nextPuff = (nextPuff + 1) % PUFFS
        val o = i * 6
        puffs[o] = x - fx * 0.25f - fz * side * 0.12f
        puffs[o + 1] = feetY
        puffs[o + 2] = z - fz * 0.25f + fx * side * 0.12f
        puffs[o + 3] = 0f
        puffs[o + 4] = kind.toFloat()
        puffs[o + 5] = size * (if (kind == PUFF_GRASS) 0.55f else if (kind == PUFF_STONE) 0.7f else 1f)
    }

    /**
     * Where the camera goes this frame. Writes camera x, y, z, then the point it looks
     * at, then 1 if the hero should be drawn (0 when the camera is too close to him).
     */
    fun camera(dt: Float, out: FloatArray) {
        val cp = cos(pitch)
        val fx = cp * sin(yaw)
        val fy = sin(pitch)
        val fz = cp * cos(yaw)
        if (!thirdPerson) {
            out[0] = x
            out[1] = eyeY
            out[2] = z
            out[3] = x + fx
            out[4] = eyeY + fy
            out[5] = z + fz
            out[6] = 0f
            camDist = 0.5f
            return
        }
        // Over the right shoulder, a few metres back. Walls and hills pull the camera in.
        val headY = feetY + 1.7f
        val rx = -cos(yaw)
        val rz = sin(yaw)
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        val shoulder = if (indoors && cv == null) 0.25f else 0.45f
        val want = if (cv != null) 3.4f else if (indoors) 2.3f else 4.2f + runAmount * 0.5f
        var free = want
        val steps = 12
        for (i in 1..steps) {
            val t = want * i / steps
            val k = t / want
            val sx = x + rx * shoulder * k - fx * t
            val sy = headY - fy * t
            val sz = z + rz * shoulder * k - fz * t
            var hit = if (cv != null) {
                val dd = cv.inside(sx - cv.x, sz - cv.z)
                dd < 0.5f || sy < cv.floorFrom(sx - cv.x, sz - cv.z, dd) + 0.3f || sy > cv.ceilFrom(sx - cv.x, sz - cv.z, dd) - 0.3f
            } else {
                world.terrainAt(sx, sz) + 0.3f > sy && world.floorUnder(x, z, feetY) == 0
            }
            if (!hit) hit = hitsWall(sx, sy, sz, 0.3f)
            if (hit) {
                free = max(0.4f, t - want / steps)
                break
            }
        }
        camDist = if (free < camDist) free else camDist + (free - camDist) * min(1f, dt * 2.5f)
        val k = camDist / want
        var cx = x + rx * shoulder * k - fx * camDist
        var cy = headY - fy * camDist
        var cz = z + rz * shoulder * k - fz * camDist
        if (cv != null) {
            val dd = cv.inside(cx - cv.x, cz - cv.z)
            val g = cv.floorFrom(cx - cv.x, cz - cv.z, dd)
            if (cy < g + 0.35f) cy = g + 0.35f
            cy = min(cy, max(g + 0.5f, cv.ceilFrom(cx - cv.x, cz - cv.z, dd) - 0.35f))
        } else {
            val g = world.groundAt(cx, cz, cy)
            if (cy < g + 0.35f) cy = g + 0.35f
            if (indoors) cy = min(cy, feetY + 2.1f)
        }
        if (cx < 1f) cx = 1f
        if (cz < 1f) cz = 1f
        out[0] = cx
        out[1] = cy
        out[2] = cz
        out[3] = cx + fx
        out[4] = cy + fy
        out[5] = cz + fz
        out[6] = if (camDist > 0.9f) 1f else 0f
    }

    /** Whether a point would be inside a wall, floor or roof beam of a building. */
    private fun hitsWall(px: Float, py: Float, pz: Float, r: Float): Boolean {
        for (st in world.structures) {
            val dx = px - st.cx
            val dz = pz - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (so in st.solids) if (so.hitsPoint(px, py, pz, r)) return true
        }
        return false
    }

    /** How deep a body at (px, pz) would be inside the nearest animal (0 = not touching). */
    private fun animalOverlap(px: Float, pz: Float): Float {
        var worst = 0f
        if (inCave >= 0) return 0f
        for (c in fauna.creatures) {
            if (!c.active || c.dying >= 0f) continue
            val sp = fauna.species[c.sp]
            if (abs(feetY - c.y) > 2.5f * c.scale) continue
            val dx = px - c.x
            val dz = pz - c.z
            val reach = (sp.colHalf + sp.colR + abs(sp.colZ)) * c.scale + RADIUS
            if (dx * dx + dz * dz > reach * reach) continue
            val hx = sin(c.yaw)
            val hz = cos(c.yaw)
            val mid = sp.colZ * c.scale
            val along = (dx * hx + dz * hz - mid).coerceIn(-sp.colHalf * c.scale, sp.colHalf * c.scale) + mid
            val qx = dx - hx * along
            val qz = dz - hz * along
            val rr = sp.colR * c.scale + RADIUS
            val over = rr - sqrt(qx * qx + qz * qz)
            if (over > worst) worst = over
        }
        return worst
    }

    /** Which footstep sound to play here. [under] comes from [World.floorUnder]. */
    private fun surface(under: Int): Int {
        if (inCave >= 0) return Surface.STONE
        if (under == 1 || under == 3) return Surface.WOOD
        if (under == 2) return Surface.STONE
        val t = world.terrainAt(x, z)
        if (t < -0.05f) return Surface.WATER
        val hx = world.terrainAt(x + 1f, z) - world.terrainAt(x - 1f, z)
        val hz = world.terrainAt(x, z + 1f) - world.terrainAt(x, z - 1f)
        val flat = 2f / sqrt(hx * hx + hz * hz + 4f)
        return when (groundFlag(probe, x, z, t, flat)) {
            FLAG_GRASS -> Surface.GRASS
            FLAG_DIRT -> Surface.DIRT
            FLAG_SAND -> Surface.SAND
            FLAG_SNOW -> Surface.SNOW
            FLAG_STONE -> Surface.STONE
            else -> Surface.ROCK
        }
    }

    private fun tryMove(nx: Float, nz: Float) {
        val cv = if (inCave >= 0) treasure.caves[inCave] else null
        if (cv != null) {
            if (!cv.walkable(nx - cv.x, nz - cv.z, RADIUS)) return
            for (c in treasure.chests) {
                if (c.cave != cv.id) continue
                val rr = 0.55f + RADIUS
                if ((nx - c.x) * (nx - c.x) + (nz - c.z) * (nz - c.z) < rr * rr) return
            }
            x = nx
            z = nz
            return
        }
        if (world.isBlocked(nx, nz, probe)) return
        if (world.hitsObstacle(nx, nz, RADIUS, placed, probe, feetY)) return
        if (treasure.blocksOutside(nx, nz, RADIUS)) return
        // Animals are solid. If one has walked into you, you can still step away from it.
        val over = animalOverlap(nx, nz)
        if (over > 0f && over >= animalOverlap(x, z) - 1e-4f) return
        x = nx
        z = nz
    }

    private fun reveal() {
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        if (ci == lastCi && cj == lastCj) return
        lastCi = ci
        lastCj = cj
        val r = REVEAL_CELLS
        for (dj in -r..r) {
            for (di in -r..r) {
                if (di * di + dj * dj > r * r) continue
                val i = ci + di
                val j = cj + dj
                if (i < 0 || j < 0 || i >= GRID || j >= GRID) continue
                val idx = j * GRID + i
                if (explored[idx]) continue
                explored[idx] = true
                minimap.setPixel(i, j, world.mapColors[idx])
            }
        }
    }

    companion object {
        const val EYE = 1.7f
        const val WALK_SPEED = 6.5f
        const val RUN_SPEED = 12.5f
        const val RUN_SECONDS = 7f
        const val RECOVER_SECONDS = 5f
        const val CLIMB_SECONDS = 14f
        const val PUFFS = 24
        const val PUFF_DIRT = 0
        const val PUFF_SAND = 1
        const val PUFF_SNOW = 2
        const val PUFF_STONE = 3
        const val PUFF_WATER = 4
        const val PUFF_GRASS = 5
        const val PUFF_HIT = 6
        const val MAX_HEALTH = 100f
        const val ACTION_NONE = 0
        const val ACTION_OPEN = 1
        const val ACTION_ENTER = 2
        const val ACTION_EXIT = 3
        const val KUNAI_MAX = 8
        const val KUNAI_SPEED = 30f
        private val KUNAI_HITS = floatArrayOf(0.45f)
        private val HALBERD_HITS = floatArrayOf(0.3f, 0.8f)
        private val SWORD_HITS = floatArrayOf(0.22f, 0.52f, 0.84f)
        const val JUMP_SPEED = 7.2f
        const val JUMP_COST = 0.08f
        const val GRAVITY = 22f
        const val RADIUS = 0.4f
        const val REVEAL_CELLS = 24
        const val MAP_GRID = 17

        private fun fade(c: Int): Int {
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val grey = (r * 0.3f + g * 0.59f + b * 0.11f)
            val fr = ((r + (grey - r) * 0.75f) * 0.5f + 18f).toInt().coerceIn(0, 255)
            val fg = ((g + (grey - g) * 0.75f) * 0.5f + 16f).toInt().coerceIn(0, 255)
            val fb = ((b + (grey - b) * 0.75f) * 0.5f + 22f).toInt().coerceIn(0, 255)
            return (0xFF shl 24) or (fr shl 16) or (fg shl 8) or fb
        }
    }
}
