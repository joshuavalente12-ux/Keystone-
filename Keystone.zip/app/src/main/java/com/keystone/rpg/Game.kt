package com.keystone.rpg

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Player state. Updated on the drawing thread, read by the screen overlay. */
class Game(val world: World) {
    // Position in metres. y is eye height.
    @Volatile var x = world.spawnX
        private set
    @Volatile var z = world.spawnZ
        private set
    @Volatile var eyeY = world.groundAt(world.spawnX, world.spawnZ) + EYE
        private set
    @Volatile var yaw = world.spawnYaw
        private set
    @Volatile var pitch = -0.05f
        private set
    var time = 0f
        private set

    /** Time of day and weather. */
    val weather = Weather()

    /** The animals and birds living around you. */
    val fauna = Fauna(world)

    /** Camera behind the hero (true) or looking out through his eyes (false). */
    @Volatile var thirdPerson = true

    // What the hero model needs to animate itself.
    /** Height of the soles of your feet. */
    val feet: Float get() = feetY
    /** Which way the body faces. In third person he turns to face where he's walking. */
    var bodyYaw = world.spawnYaw
        private set
    /** Walk cycle: one full turn is a left and a right step. */
    val stridePhase: Float get() = walk * 9f + 1.5707964f
    /** 0 standing, 1 moving at full speed. */
    var moveAmount = 0f
        private set
    /** 0 walking, 1 sprinting. */
    var runAmount = 0f
        private set
    /** 0 on the ground, 1 in the air. */
    var airAmount = 0f
        private set

    /**
     * Dust, sand, snow and splashes kicked up by your feet. Each puff: x, y, z,
     * age (0 new .. 1 gone), kind (see [PUFF_DIRT] etc.), size.
     */
    val puffs = FloatArray(PUFFS * 6).also { for (i in 0 until PUFFS) it[i * 6 + 3] = 1f }
    private var nextPuff = 0
    private var footSide = 1f
    private var camDist = 4f
    private var climbing = false

    /** True when standing on a floor inside a house or castle (rain goes quiet). */
    @Volatile var indoors = false
        private set

    /** Zone for the drawing thread (the screen overlay uses [zone]). */
    @Volatile var currentZone = Zone.MEADOW
        private set

    // Left thumb: -1..1 each way. Set by the touch handler.
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f

    /** Run button: on or off. */
    @Volatile var runOn = false

    /** 0..1. Running and jumping use it up; it comes back when you rest. */
    @Volatile var stamina = 1f
        private set

    /** True after running out: you have to catch your breath before running again. */
    @Volatile var winded = false
        private set

    @Volatile private var jumpAsked = false
    private var feetY = world.groundAt(world.spawnX, world.spawnZ)
    private var vy = 0f
    private var airborne = false
    private var restTimer = 0f

    // Right thumb: turning, collected until the next frame.
    private val lookLock = Any()
    private var lookX = 0f
    private var lookY = 0f

    // For the screen overlay.
    var zone by mutableStateOf(Zone.MEADOW)
        private set
    var zoneVisit by mutableIntStateOf(0)
        private set
    var hudTick by mutableLongStateOf(0L)
        private set

    /** Named places you've found. Greenhollow, where you start, counts from the beginning. */
    val discovered = BooleanArray(PLACES.size).also { it[0] = true }
    var discoverVisit by mutableIntStateOf(0)
        private set
    var lastDiscovered by mutableStateOf("")
        private set

    /** Region colours and borders, laid over the big map. */
    val regionOverlay: ImageBitmap

    private val probe = Probe()
    private val placed = Placed()
    private var walk = 0f
    private var stepCount = 0
    private var landed = false
    private var hudTimer = 0f

    // Fog-of-war map: fills in as you explore.
    private val explored = BooleanArray(GRID * GRID)
    private val minimap: Bitmap = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
        // Places you haven't been yet show as a faded, grey map.
        val faded = IntArray(GRID * GRID) { fade(world.mapColors[it]) }
        setPixels(faded, 0, GRID, 0, 0, GRID, GRID)
    }
    val minimapImage: ImageBitmap = minimap.asImageBitmap()
    private var lastCi = -1
    private var lastCj = -1

    init {
        val over = IntArray(GRID * GRID)
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val idx = j * GRID + i
                val r = world.regionMap[idx]
                val border = (i > 0 && world.regionMap[idx - 1] != r) ||
                    (j > 0 && world.regionMap[idx - GRID] != r) ||
                    (i < GRID - 1 && world.regionMap[idx + 1] != r) ||
                    (j < GRID - 1 && world.regionMap[idx + GRID] != r)
                val rgb = Zone.entries[r.toInt()].mapColor
                over[idx] = (if (border) 0xD0 shl 24 else 0x2C shl 24) or rgb
            }
        }
        regionOverlay = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888).apply {
            setPixels(over, 0, GRID, 0, 0, GRID, GRID)
        }.asImageBitmap()
        reveal()
    }

    /** Map grid square you're in, like "H-7": letters down the side, numbers along the top. */
    fun gridRef(): String {
        val col = (x / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        val row = (z / WORLD_SIZE * MAP_GRID).toInt().coerceIn(0, MAP_GRID - 1)
        return "${'A' + row}-$col"
    }

    fun jump() {
        jumpAsked = true
    }

    fun addLook(dx: Float, dy: Float) {
        synchronized(lookLock) {
            lookX += dx
            lookY += dy
        }
    }

    fun update(dt: Float) {
        time += dt
        synchronized(lookLock) {
            yaw -= lookX
            pitch = (pitch - lookY).coerceIn(-1.2f, 1.2f)
            lookX = 0f
            lookY = 0f
        }

        val mx = moveX
        val my = moveY
        val len = hypot(mx, my)
        val moving = len > 0.05f
        val sprinting = moving && runOn && !winded
        if (moving) {
            val limit = if (len > 1f) 1f / len else 1f
            val sy = sin(yaw)
            val cy = cos(yaw)
            // Forward is where we look; right is 90 degrees clockwise from it.
            val wx = (sy * -my + -cy * mx) * limit
            val wz = (cy * -my + sy * mx) * limit
            var step = (if (sprinting) RUN_SPEED else WALK_SPEED) * dt
            // Steep ground: you slow to a climb, and it tires you out.
            climbing = false
            var tooTired = false
            val stepLen = hypot(wx, wz) * step
            if (stepLen > 1e-4f && world.floorUnder(x, z, feetY) == 0) {
                val rise = world.terrainAt(x + wx * step, z + wz * step) - world.terrainAt(x, z)
                val grade = rise / stepLen
                if (grade > 0.45f) step *= (1.25f - grade * 0.55f).coerceIn(0.35f, 1f)
                // Picking your way down a steep face is slower too.
                if (grade < -0.8f) step *= (1.2f + grade * 0.3f).coerceIn(0.45f, 1f)
                if (grade > 0.9f) {
                    climbing = true
                    if (winded) tooTired = true
                }
            }
            if (!tooTired) {
                tryMove(x + wx * step, z)
                tryMove(x, z + wz * step)
            }
            walk += dt * len.coerceAtMost(1f) * (if (sprinting) 1.5f else 1f) * (if (climbing) 0.7f else 1f)
            // Turn the body to face the way we're walking.
            val want = atan2(wx, wz)
            var d = want - bodyYaw
            while (d > 3.1415927f) d -= 6.2831855f
            while (d < -3.1415927f) d += 6.2831855f
            bodyYaw += d * min(1f, dt * 10f)
        } else {
            climbing = false
        }
        if (!thirdPerson) bodyYaw = yaw
        moveAmount += ((if (moving) len.coerceAtMost(1f) else 0f) - moveAmount) * min(1f, dt * 8f)
        runAmount += ((if (sprinting) 1f else 0f) - runAmount) * min(1f, dt * 5f)

        // Stamina.
        if (sprinting || (climbing && moving)) {
            stamina -= (if (sprinting) dt / RUN_SECONDS else 0f) + (if (climbing) dt / CLIMB_SECONDS else 0f)
            restTimer = 0f
            if (stamina <= 0f) {
                stamina = 0f
                winded = true
            }
        } else {
            restTimer += dt
            if (restTimer > 0.8f) stamina = (stamina + dt / RECOVER_SECONDS).coerceAtMost(1f)
        }
        if (winded && stamina > 0.3f) winded = false

        // Jumping and falling.
        val ground = world.groundAt(x, z, feetY)
        val floor = if (ground < 0f && !world.onBridge(x, z)) ground.coerceAtLeast(-0.9f) else ground
        if (jumpAsked) {
            jumpAsked = false
            if (!airborne && stamina >= JUMP_COST) {
                vy = JUMP_SPEED
                airborne = true
                stamina -= JUMP_COST
                restTimer = 0f
            }
        }
        if (airborne) {
            vy -= GRAVITY * dt
            feetY += vy * dt
            if (feetY <= floor) {
                feetY = floor
                vy = 0f
                airborne = false
                landed = true
            }
        } else if (floor < feetY - 0.8f) {
            airborne = true
            vy = 0f
        } else {
            feetY += (floor - feetY) * (dt * 14f).coerceAtMost(1f)
            // Climbing a steep slope: don't let the feet sink into the hillside.
            if (feetY < floor - 0.12f) feetY = floor - 0.12f
        }
        airAmount += ((if (airborne) 1f else 0f) - airAmount) * min(1f, dt * 10f)
        val bob = if (moving && !airborne) abs(sin(walk * 9f)) * (if (sprinting) 0.1f else 0.07f) else 0f
        eyeY = feetY + EYE + bob

        world.probe(x, z, probe)
        val si = probe.siteIndex
        if (si >= 0 && !discovered[si] && probe.siteCenter < PLACES[si].radius + 35f) {
            discovered[si] = true
            lastDiscovered = PLACES[si].name
            discoverVisit = discoverVisit + 1
        }
        val zNow = probe.zone
        if (zNow != currentZone) {
            currentZone = zNow
            zone = zNow
            zoneVisit = zoneVisit + 1
        }

        weather.update(dt, currentZone)
        fauna.update(dt, x, z, time)
        for (i in 0 until PUFFS) {
            val a = i * 6 + 3
            if (puffs[a] < 1f) puffs[a] = min(1f, puffs[a] + dt / 1.1f)
        }

        // Footsteps, matched to what's underfoot.
        val under = world.floorUnder(x, z, feetY)
        indoors = under == 1 || under == 2
        if (landed) {
            landed = false
            val sf = surface(under)
            Sound.step(sf, 1.25f)
            kickUp(sf, 0f, 1.6f)
            kickUp(sf, 0f, 1.2f)
        } else if (moving && !airborne) {
            val sc = kotlin.math.floor(walk * 9f / 3.1415927f).toInt()
            if (sc != stepCount) {
                stepCount = sc
                val sf = surface(under)
                Sound.step(sf, if (sprinting) 1f else 0.75f)
                footSide = -footSide
                kickUp(sf, footSide, if (sprinting) 1.3f else 0.85f)
            }
        }
        Sound.wind = weather.windFor(currentZone)
        Sound.rain = weather.rainFor(currentZone)
        Sound.indoors = indoors

        reveal()
        hudTimer += dt
        if (hudTimer > 0.08f) {
            hudTimer = 0f
            hudTick = hudTick + 1
        }
    }

    /** A little cloud of whatever you're walking on, thrown up behind the foot that just landed. */
    private fun kickUp(surface: Int, side: Float, size: Float) {
        val kind = when (surface) {
            Surface.DIRT -> PUFF_DIRT
            Surface.SAND -> PUFF_SAND
            Surface.SNOW -> PUFF_SNOW
            Surface.STONE, Surface.ROCK -> PUFF_STONE
            Surface.WATER -> PUFF_WATER
            Surface.GRASS -> PUFF_GRASS
            else -> return
        }
        val fx = sin(bodyYaw)
        val fz = cos(bodyYaw)
        val i = nextPuff
        nextPuff = (nextPuff + 1) % PUFFS
        val o = i * 6
        puffs[o] = x - fx * 0.25f - fz * side * 0.12f
        puffs[o + 1] = feetY
        puffs[o + 2] = z - fz * 0.25f + fx * side * 0.12f
        puffs[o + 3] = 0f
        puffs[o + 4] = kind.toFloat()
        puffs[o + 5] = size * (if (kind == PUFF_GRASS) 0.55f else if (kind == PUFF_STONE) 0.7f else 1f)
    }

    /**
     * Where the camera goes this frame. Writes camera x, y, z, then the point it looks
     * at, then 1 if the hero should be drawn (0 when the camera is too close to him).
     */
    fun camera(dt: Float, out: FloatArray) {
        val cp = cos(pitch)
        val fx = cp * sin(yaw)
        val fy = sin(pitch)
        val fz = cp * cos(yaw)
        if (!thirdPerson) {
            out[0] = x
            out[1] = eyeY
            out[2] = z
            out[3] = x + fx
            out[4] = eyeY + fy
            out[5] = z + fz
            out[6] = 0f
            camDist = 0.5f
            return
        }
        // Over the right shoulder, a few metres back. Walls and hills pull the camera in.
        val headY = feetY + 1.7f
        val rx = -cos(yaw)
        val rz = sin(yaw)
        val shoulder = if (indoors) 0.25f else 0.45f
        val want = if (indoors) 2.3f else 4.2f + runAmount * 0.5f
        var free = want
        val steps = 12
        for (i in 1..steps) {
            val t = want * i / steps
            val k = t / want
            val sx = x + rx * shoulder * k - fx * t
            val sy = headY - fy * t
            val sz = z + rz * shoulder * k - fz * t
            var hit = world.terrainAt(sx, sz) + 0.3f > sy && world.floorUnder(x, z, feetY) == 0
            if (!hit) hit = hitsWall(sx, sy, sz, 0.3f)
            if (hit) {
                free = max(0.4f, t - want / steps)
                break
            }
        }
        camDist = if (free < camDist) free else camDist + (free - camDist) * min(1f, dt * 2.5f)
        val k = camDist / want
        var cx = x + rx * shoulder * k - fx * camDist
        var cy = headY - fy * camDist
        var cz = z + rz * shoulder * k - fz * camDist
        val g = world.groundAt(cx, cz, cy)
        if (cy < g + 0.35f) cy = g + 0.35f
        if (indoors) cy = min(cy, feetY + 2.1f)
        if (cx < 1f) cx = 1f
        if (cz < 1f) cz = 1f
        out[0] = cx
        out[1] = cy
        out[2] = cz
        out[3] = cx + fx
        out[4] = cy + fy
        out[5] = cz + fz
        out[6] = if (camDist > 0.9f) 1f else 0f
    }

    /** Whether a point would be inside a wall, floor or roof beam of a building. */
    private fun hitsWall(px: Float, py: Float, pz: Float, r: Float): Boolean {
        for (st in world.structures) {
            val dx = px - st.cx
            val dz = pz - st.cz
            if (dx * dx + dz * dz > (st.radius + 10f) * (st.radius + 10f)) continue
            for (so in st.solids) if (so.hitsPoint(px, py, pz, r)) return true
        }
        return false
    }

    /** How deep a body at (px, pz) would be inside the nearest animal (0 = not touching). */
    private fun animalOverlap(px: Float, pz: Float): Float {
        var worst = 0f
        for (c in fauna.animals) {
            if (!c.active) continue
            val sp = fauna.species[c.sp]
            if (abs(feetY - c.y) > 2.5f * c.scale) continue
            val dx = px - c.x
            val dz = pz - c.z
            val reach = (sp.colHalf + sp.colR + abs(sp.colZ)) * c.scale + RADIUS
            if (dx * dx + dz * dz > reach * reach) continue
            val hx = sin(c.yaw)
            val hz = cos(c.yaw)
            val mid = sp.colZ * c.scale
            val along = (dx * hx + dz * hz - mid).coerceIn(-sp.colHalf * c.scale, sp.colHalf * c.scale) + mid
            val qx = dx - hx * along
            val qz = dz - hz * along
            val rr = sp.colR * c.scale + RADIUS
            val over = rr - sqrt(qx * qx + qz * qz)
            if (over > worst) worst = over
        }
        return worst
    }

    /** Which footstep sound to play here. [under] comes from [World.floorUnder]. */
    private fun surface(under: Int): Int {
        if (under == 1 || under == 3) return Surface.WOOD
        if (under == 2) return Surface.STONE
        val t = world.terrainAt(x, z)
        if (t < -0.05f) return Surface.WATER
        val hx = world.terrainAt(x + 1f, z) - world.terrainAt(x - 1f, z)
        val hz = world.terrainAt(x, z + 1f) - world.terrainAt(x, z - 1f)
        val flat = 2f / sqrt(hx * hx + hz * hz + 4f)
        return when (groundFlag(probe, x, z, t, flat)) {
            FLAG_GRASS -> Surface.GRASS
            FLAG_DIRT -> Surface.DIRT
            FLAG_SAND -> Surface.SAND
            FLAG_SNOW -> Surface.SNOW
            FLAG_STONE -> Surface.STONE
            else -> Surface.ROCK
        }
    }

    private fun tryMove(nx: Float, nz: Float) {
        if (world.isBlocked(nx, nz, probe)) return
        if (world.hitsObstacle(nx, nz, RADIUS, placed, probe, feetY)) return
        // Animals are solid. If one has walked into you, you can still step away from it.
        val over = animalOverlap(nx, nz)
        if (over > 0f && over >= animalOverlap(x, z) - 1e-4f) return
        x = nx
        z = nz
    }

    private fun reveal() {
        val ci = (x / CELL).toInt()
        val cj = (z / CELL).toInt()
        if (ci == lastCi && cj == lastCj) return
        lastCi = ci
        lastCj = cj
        val r = REVEAL_CELLS
        for (dj in -r..r) {
            for (di in -r..r) {
                if (di * di + dj * dj > r * r) continue
                val i = ci + di
                val j = cj + dj
                if (i < 0 || j < 0 || i >= GRID || j >= GRID) continue
                val idx = j * GRID + i
                if (explored[idx]) continue
                explored[idx] = true
                minimap.setPixel(i, j, world.mapColors[idx])
            }
        }
    }

    companion object {
        const val EYE = 1.7f
        const val WALK_SPEED = 6.5f
        const val RUN_SPEED = 12.5f
        const val RUN_SECONDS = 7f
        const val RECOVER_SECONDS = 5f
        const val CLIMB_SECONDS = 14f
        const val PUFFS = 24
        const val PUFF_DIRT = 0
        const val PUFF_SAND = 1
        const val PUFF_SNOW = 2
        const val PUFF_STONE = 3
        const val PUFF_WATER = 4
        const val PUFF_GRASS = 5
        const val JUMP_SPEED = 7.2f
        const val JUMP_COST = 0.08f
        const val GRAVITY = 22f
        const val RADIUS = 0.4f
        const val REVEAL_CELLS = 24
        const val MAP_GRID = 17

        private fun fade(c: Int): Int {
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val grey = (r * 0.3f + g * 0.59f + b * 0.11f)
            val fr = ((r + (grey - r) * 0.75f) * 0.5f + 18f).toInt().coerceIn(0, 255)
            val fg = ((g + (grey - g) * 0.75f) * 0.5f + 16f).toInt().coerceIn(0, 255)
            val fb = ((b + (grey - b) * 0.75f) * 0.5f + 22f).toInt().coerceIn(0, 255)
            return (0xFF shl 24) or (fr shl 16) or (fg shl 8) or fb
        }
    }
}
