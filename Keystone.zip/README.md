# Keystone

A first-person open-world adventure for Android, built entirely in the cloud with GitHub Actions.

## The world
- 2.9 km across (about 8.5 square km, 3.27 square miles), low-poly 3D with fog and sunlight.
- You start in the top-left corner in Greenhollow Meadow, ringed by mountains with four gates.
- Four zones fan out from the corner: Frostpeak (snow, top edge), Whisperwood (forest,
  with a river and a wooden bridge), The Hollow Deep (dark canyon lands with glowing
  crystals) and the Sunscar Dunes (desert with an oasis, left edge).
- Every zone has a trail ending at a stone circle with a keyhole shrine and a beam of
  light you can see from far away. Keys will go there later.

## Controls
- Left thumb: walk (floating joystick).
- Right thumb: drag to look around.

## Code
- `World.kt`: map layout, heights, zones, what stands where, collision.
- `Mesh.kt`: builds lit low-poly shapes.
- `Chunks.kt`: builds the world in 192 m chunks on a background thread.
- `Renderer.kt`: OpenGL ES 2.0 drawing, fog and chunk streaming.
- `Game.kt`: the player: moving, looking, zones, minimap.
- `MainActivity.kt`: title screen, touch controls, minimap and zone banners.
