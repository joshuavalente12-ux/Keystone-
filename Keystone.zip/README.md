# Keystone

A first-person open-world adventure for Android, built entirely in the cloud with GitHub Actions.

## The world
- 2.9 km across (about 8.5 square km, 3.27 square miles), low-poly 3D with fog and sunlight.
- You start in the top-left corner in Greenhollow Meadow, ringed by mountains with four gates.
- Four zones fan out from the corner: Frostpeak (snow, top edge), Whisperwood (forest,
  with a river and a wooden bridge), The Hollow Deep (dark canyon lands with glowing
  crystals) and the Sunscar Dunes (desert with an oasis, left edge).
- Every zone has a trail ending at a stone circle with a keyhole shrine and a beam of
  light you can see from far away. Keys will go there later.

## Controls (landscape)
- Left thumb: walk (floating joystick).
- Right thumb: drag to look around.
- RUN: tap to switch running on/off. Uses stamina; when it runs out you're winded until it recovers.
- JUMP: jump (uses a little stamina).
- MAP (or tap the minimap): the whole world. Explored places in colour, the rest faded.

## Look
- Smooth-shaded hills, ground detail up close, swaying grass, tree shadows.
- Sky that fades from horizon to deep blue, a sun, drifting clouds.
- Water that reflects the sky and sparkles in the sun.

## Code
- `World.kt`: map layout, heights, zones, what stands where, collision.
- `Mesh.kt`: builds lit low-poly shapes.
- `Chunks.kt`: builds the world in 192 m chunks on a background thread.
- `Renderer.kt`: OpenGL ES 2.0 drawing, fog and chunk streaming.
- `Game.kt`: the player: moving, looking, zones, minimap.
- `MainActivity.kt`: title screen, touch controls, minimap and zone banners.
