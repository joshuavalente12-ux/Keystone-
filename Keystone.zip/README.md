# Keystone

A first-person open-world adventure for Android, built entirely in the cloud with GitHub Actions.

## The world
- 2.9 km across (about 8.5 square km), laid out like a real map in the spirit of
  Enshrouded and Fallout 3.
- Five regions with rising danger: Greenhollow (level 1-5, start, bottom-left),
  Whisperwood (6-12, forest, top-left), Frostpeak Highlands (13-18, centre),
  Sunscar Dunes (19-25, desert, top-right), The Hollow Deep (26-30, dark canyon
  lands, bottom-right).
- 21 named places joined by winding roads: towns with houses and a well, ruins,
  watchtowers, vaults with round steel doors, camps with tents and fires, and four
  shrines with beams of light.
- Winding mountain ranges, a river with bridges wherever a road crosses, lakes,
  a pond and a desert oasis.
- Walk near a place to discover it. The map shows regions, level ranges, a grid
  (A-Q down, 0-16 across) and every place you've found.

## Controls (landscape)
- Left thumb: walk (floating joystick).
- Right thumb: drag to look around.
- RUN: tap to switch running on/off. Uses stamina; when it runs out you're winded until it recovers.
- JUMP: jump (uses a little stamina).
- MAP (or tap the minimap): the whole world. Explored places in colour, the rest faded.

## Look
- Smooth-shaded hills, ground detail up close, swaying grass, tree shadows.
- Sky that fades from horizon to deep blue, a sun, drifting clouds.
- Water that reflects the sky and sparkles in the sun.

## Code
- `World.kt`: map layout, heights, zones, what stands where, collision.
- `Mesh.kt`: builds lit low-poly shapes.
- `Chunks.kt`: builds the world in 192 m chunks on a background thread.
- `Renderer.kt`: OpenGL ES 2.0 drawing, fog and chunk streaming.
- `Game.kt`: the player: moving, looking, zones, minimap.
- `MainActivity.kt`: title screen, touch controls, minimap and zone banners.
