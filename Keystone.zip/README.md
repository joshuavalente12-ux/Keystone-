# Keystone

A top-down open-world RPG for Android (Kotlin + Jetpack Compose).

Stage 1 (this build): one seamless 128x128 world with a central meadow and four
zones (Whisperwood forest, Sunscar Dunes, Frostpeak, The Hollow Deep), floating
touch joystick, collision, zone banners and an explore-as-you-go minimap.

Coming next: resources, auto-attack combat and monsters, stats, keys that lock the gates.

Built by GitHub Actions (see .github/workflows/build.yml in the repo).
