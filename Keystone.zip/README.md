# Keystone

A first-person open-world adventure for Android, built entirely in the cloud with GitHub Actions.

## The world
- 2.9 km across (about 8.5 square km), laid out like a real map in the spirit of
  Enshrouded and Fallout 3.
- Five regions with rising danger: Greenhollow (level 1-20, start, bottom-left),
  Whisperwood (30-40, forest, top-left), Frostpeak Highlands (60-70, centre),
  Sunscar Dunes (90-100, desert, top-right), The Hollow Deep (110-150, dark canyon
  lands, bottom-right).
- 21 named places joined by winding roads: towns with houses and a well, ruins,
  watchtowers, vaults with round steel doors, camps with tents and fires, and four
  shrines with beams of light.
- Winding mountain ranges, a river with bridges wherever a road crosses, lakes,
  a pond and a desert oasis.
- Walk near a place to discover it. The map shows regions, level ranges, a grid
  (A-Q down, 0-16 across) and every place you've found.

## Controls (landscape)
- Left thumb: walk (floating joystick).
- Right thumb: drag to look around.
- RUN: tap to switch running on/off. Uses stamina; when it runs out you're winded until it recovers.
- JUMP: jump (uses a little stamina).
- MAP (or tap the minimap): the whole world. Explored places in colour, the rest faded.

## Look
- Every surface has its own shader texture: grass with dry patches, pebbly roads,
  rippled sand, sparkling snow, layered rock, bark, leaves, wood grain, stone,
  plaster and shingled roofs.
- Timber-framed cottages, fire pits with dancing flames and rising smoke.
- Ferns, bushes and wildflowers; grass and leaves sway in the wind; snow resting on
  the pines in Frostpeak and snow falling from the sky there.
- Sky with sun glow, haze and drifting high clouds, plus puffy low clouds.
- Rippling water that reflects the sky and glitters in the sun.
- Gentle colour grading and a lens vignette.

## Code
- `World.kt`: map layout, heights, zones, what stands where, collision.
- `Mesh.kt`: builds lit low-poly shapes.
- `Chunks.kt`: builds the world in 192 m chunks on a background thread.
- `Renderer.kt`: OpenGL ES 2.0 drawing, fog and chunk streaming.
- `Game.kt`: the player: moving, looking, zones, minimap.
- `MainActivity.kt`: title screen, touch controls, minimap and zone banners.
