# Google Play Games setup for Keystone

Sign-in is automatic at launch. If it fails, the player is a guest (saves stay on the phone).
Save / Load on the title screen use the Play Games cloud save ("Saved Games").

## In Android Studio (already done in this zip)
- `app/build.gradle.kts`: `com.google.android.gms:play-services-games-v2` (pin a fixed version once it builds).
- `AndroidManifest.xml`: `<meta-data com.google.android.gms.games.APP_ID>` and `android:name=".KeystoneApplication"`.
- `KeystoneApplication.kt`: `PlayGamesSdk.initialize(this)`.
- `PlayGamesManager.kt`: sign-in status, manual sign-in, cloud save/load.
- **You must edit** `res/values/strings.xml`: put your numeric Project ID in `game_services_project_id`.

## In Google Play Console
1. Create the app (or open it), then Grow > Play Games Services > Setup and management > Configuration.
2. Create a new Play Games Services project. Copy the numeric **Project ID** into strings.xml.
3. Configuration > Add credential > Android. Enter package name `com.keystone.rpg`
   (change `applicationId` in build.gradle.kts first if you want your own; it can't change after upload)
   and the SHA-1 of the key that signs the build:
   - Debug: run `./gradlew signingReport` and use the debug SHA-1.
   - Release: Play Console > Test and release > App integrity > App signing key certificate SHA-1.
   Create the OAuth client / consent screen when prompted.
4. Configuration: turn on **Saved games**.
5. Testers: add your Google account(s) so you can sign in before the game services are published.
6. When ready, publish the Play Games Services configuration alongside your app release.
