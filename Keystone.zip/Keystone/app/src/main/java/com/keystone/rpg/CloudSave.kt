package com.keystone.rpg

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.games.PlayGames
import com.google.android.gms.games.PlayGamesSdk
import com.google.android.gms.games.SnapshotsClient
import com.google.android.gms.games.snapshot.Snapshot
import com.google.android.gms.games.snapshot.SnapshotMetadataChange
import org.json.JSONArray
import org.json.JSONObject

/** Finds the Activity behind a Context (Compose hands out wrapped contexts). */
fun Context.keystoneActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Google Play Games sign-in and cloud saving.
 *
 * Signing in happens by itself when the game opens. If it doesn't work (no internet, no
 * Play Games account, or the game isn't set up in the Play Console yet) you simply play as
 * a guest and the save stays on the phone, exactly like before.
 *
 * While signed in, your save is copied to your Google account: when the game closes, every
 * few minutes while you play, and whenever you press Save. On a new phone, signing in
 * brings your adventure back.
 */
object CloudSave {
    const val NOT_SET_UP = 0
    const val CHECKING = 1
    const val SIGNED_IN = 2
    const val GUEST = 3

    private const val FILE = "keystone_cloud_v1"
    private const val PREFS = "keystone_save"

    var state by mutableIntStateOf(NOT_SET_UP)
        private set
    var playerName by mutableStateOf("")
        private set
    var working by mutableStateOf(false)
        private set
    var note by mutableStateOf("")
        private set

    /** Goes up every time the save on this phone was replaced by the cloud copy. */
    var restoredTick by mutableIntStateOf(0)
        private set

    /** Once you press Play or New Game, the cloud must not swap your save out from under you. */
    @Volatile var locked = false

    private var started = false

    private fun configured(ctx: Context): Boolean {
        val id = ctx.getString(R.string.game_services_project_id).trim()
        return id.length >= 6 && id.all { it.isDigit() }
    }

    /** Call once when the app opens. */
    fun start(activity: Activity) {
        if (started) return
        started = true
        if (!configured(activity)) {
            state = NOT_SET_UP
            return
        }
        try {
            PlayGamesSdk.initialize(activity.applicationContext)
            state = CHECKING
            PlayGames.getGamesSignInClient(activity).isAuthenticated().addOnCompleteListener { task ->
                if (task.isSuccessful && task.result.isAuthenticated) {
                    onSignedIn(activity)
                } else {
                    state = GUEST
                }
            }
        } catch (e: Throwable) {
            android.util.Log.e("Keystone", "Play Games start failed: $e")
            state = GUEST
        }
    }

    /** For a guest who changes their mind. */
    fun signIn(activity: Activity) {
        if (state != GUEST) return
        try {
            state = CHECKING
            PlayGames.getGamesSignInClient(activity).signIn().addOnCompleteListener { task ->
                if (task.isSuccessful && task.result.isAuthenticated) {
                    onSignedIn(activity)
                } else {
                    state = GUEST
                    note = "Couldn't sign in. You are playing as a guest."
                }
            }
        } catch (e: Throwable) {
            state = GUEST
            note = "Couldn't sign in. You are playing as a guest."
        }
    }

    private fun onSignedIn(activity: Activity) {
        state = SIGNED_IN
        try {
            PlayGames.getPlayersClient(activity).currentPlayer.addOnCompleteListener { task ->
                if (task.isSuccessful) playerName = task.result.displayName
            }
        } catch (e: Throwable) {
        }
        autoSync(activity)
    }

    // ---------- Turning the save into text and back ----------

    private fun localHasSave(ctx: Context): Boolean =
        !ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("weapon", "").isNullOrEmpty()

    private fun localTime(ctx: Context): Long =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("savedAt", 0L)

    /** Everything in the save, as text. Null if there is no adventure yet to save. */
    private fun exportLocal(ctx: Context): String? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.getString("weapon", "").isNullOrEmpty()) return null
        val data = JSONObject()
        for (entry in p.all.entries) {
            val v = entry.value
            val a = JSONArray()
            if (v is Int) {
                a.put("i")
                a.put(v)
            } else if (v is Long) {
                a.put("l")
                a.put(v)
            } else if (v is Float) {
                a.put("f")
                a.put(v.toDouble())
            } else if (v is Boolean) {
                a.put("b")
                a.put(v)
            } else if (v is String) {
                a.put("s")
                a.put(v)
            } else {
                continue
            }
            data.put(entry.key, a)
        }
        val root = JSONObject()
        root.put("v", 1)
        root.put("savedAt", p.getLong("savedAt", 0L))
        root.put("level", p.getInt("level", 1))
        root.put("data", data)
        return root.toString()
    }

    /** Replaces the save on this phone with [text]. */
    private fun importLocal(ctx: Context, text: String): Boolean {
        return try {
            val root = JSONObject(text)
            val data = root.getJSONObject("data")
            val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            e.clear()
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val a = data.getJSONArray(k)
                val kind = a.getString(0)
                if (kind == "i") e.putInt(k, a.getInt(1))
                else if (kind == "l") e.putLong(k, a.getLong(1))
                else if (kind == "f") e.putFloat(k, a.getDouble(1).toFloat())
                else if (kind == "b") e.putBoolean(k, a.getBoolean(1))
                else if (kind == "s") e.putString(k, a.getString(1))
            }
            e.commit()
        } catch (t: Throwable) {
            false
        }
    }

    private fun readCloud(snap: Snapshot): String? {
        return try {
            val bytes = snap.snapshotContents.readFully()
            if (bytes.isEmpty()) null else String(bytes, Charsets.UTF_8)
        } catch (t: Throwable) {
            null
        }
    }

    private fun cloudTime(text: String): Long = try {
        JSONObject(text).optLong("savedAt", 0L)
    } catch (t: Throwable) {
        0L
    }

    private fun openCloud(activity: Activity, onOpen: (Snapshot?) -> Unit) {
        try {
            PlayGames.getSnapshotsClient(activity)
                .open(FILE, true, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED)
                .addOnCompleteListener { task ->
                    val snap: Snapshot? = if (task.isSuccessful) task.result.data else null
                    onOpen(snap)
                }
        } catch (t: Throwable) {
            onOpen(null)
        }
    }

    private fun write(activity: Activity, snap: Snapshot, json: String, done: (Boolean) -> Unit) {
        try {
            snap.snapshotContents.writeBytes(json.toByteArray(Charsets.UTF_8))
            val change = SnapshotMetadataChange.Builder().setDescription("Keystone save").build()
            PlayGames.getSnapshotsClient(activity).commitAndClose(snap, change)
                .addOnCompleteListener { task -> done(task.isSuccessful) }
        } catch (t: Throwable) {
            done(false)
        }
    }

    private fun discard(activity: Activity, snap: Snapshot) {
        try {
            PlayGames.getSnapshotsClient(activity).discardAndClose(snap)
        } catch (t: Throwable) {
        }
    }

    // ---------- What the game and the buttons call ----------

    /** Right after signing in: keep whichever copy is newer. */
    private fun autoSync(activity: Activity) {
        if (working) return
        working = true
        openCloud(activity) { snap ->
            if (snap == null) {
                working = false
                return@openCloud
            }
            val cloud = readCloud(snap)
            val hasLocal = localHasSave(activity)
            val localAt = localTime(activity)
            val cloudAt = if (cloud == null) -1L else cloudTime(cloud)
            if (cloud != null && !locked && (!hasLocal || cloudAt > localAt)) {
                val ok = importLocal(activity, cloud)
                discard(activity, snap)
                working = false
                if (ok) {
                    restoredTick += 1
                    note = "Your cloud save was loaded."
                }
            } else if (hasLocal && localAt >= cloudAt) {
                val json = exportLocal(activity)
                if (json == null) {
                    discard(activity, snap)
                    working = false
                } else {
                    write(activity, snap, json) { ok ->
                        working = false
                        if (ok) note = "Saved to the cloud."
                    }
                }
            } else {
                discard(activity, snap)
                working = false
            }
        }
    }

    /**
     * Copies the save on this phone up to the cloud. The quiet version (used when the game
     * closes and every few minutes) never overwrites a newer cloud save; [force] does.
     */
    fun upload(activity: Activity, force: Boolean = false) {
        if (state != SIGNED_IN || working) return
        val json = exportLocal(activity)
        if (json == null) {
            if (force) note = "Nothing to save yet. Start a game first."
            return
        }
        working = true
        if (force) note = "Saving\u2026"
        openCloud(activity) { snap ->
            if (snap == null) {
                working = false
                if (force) note = "Couldn't reach the cloud. Try again in a moment."
                return@openCloud
            }
            val cloud = readCloud(snap)
            val newerInCloud = cloud != null && cloudTime(cloud) > localTime(activity)
            if (newerInCloud && !force) {
                discard(activity, snap)
                working = false
            } else {
                write(activity, snap, json) { ok ->
                    working = false
                    if (force) note = if (ok) "Saved to the cloud." else "Couldn't save. Try again in a moment."
                }
            }
        }
    }

    /** Replaces the save on this phone with the one in the cloud. */
    fun download(activity: Activity) {
        if (state != SIGNED_IN || working) return
        working = true
        note = "Loading\u2026"
        openCloud(activity) { snap ->
            if (snap == null) {
                working = false
                note = "Couldn't reach the cloud. Try again in a moment."
                return@openCloud
            }
            val cloud = readCloud(snap)
            discard(activity, snap)
            working = false
            if (cloud == null) {
                note = "No cloud save found yet."
            } else if (importLocal(activity, cloud)) {
                restoredTick += 1
                note = "Your cloud save was loaded."
            } else {
                note = "That save couldn't be read."
            }
        }
    }

    /** Human-readable line for the title screen. */
    fun statusText(): String = when (state) {
        SIGNED_IN -> if (playerName.isEmpty()) "Signed in to Google Play Games" else "Signed in as $playerName"
        CHECKING -> "Signing in to Google Play Games\u2026"
        GUEST -> "Guest. Progress is saved on this phone only. Tap to sign in."
        else -> "Cloud saving isn't set up yet."
    }
}
