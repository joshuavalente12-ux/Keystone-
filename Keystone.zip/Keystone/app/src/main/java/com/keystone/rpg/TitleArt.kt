package com.keystone.rpg

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope

/** A soft round glow. */
private fun DrawScope.titleGlow(c: Offset, r: Float, color: Color, a: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color.copy(alpha = a), Color.Transparent), center = c, radius = r),
        radius = r,
        center = c,
    )
}

/** A filled flat-sided shape. */
private fun DrawScope.titlePoly(color: Color, pts: List<Offset>) {
    if (pts.size < 3) return
    val p = Path()
    p.moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) p.lineTo(pts[i].x, pts[i].y)
    p.close()
    drawPath(p, color)
}

/** A thick straight line. */
private fun DrawScope.titleBeam(a: Offset, b: Offset, sw: Float, color: Color) {
    drawLine(color, a, b, strokeWidth = sw)
}

/** Tiny repeatable random numbers, so the stars and grass never shift between frames. */
private class TitleDice(seed: Int) {
    private var s = seed
    fun next(): Float {
        s = (s * 1103515245 + 12345) and 0x7fffffff
        return ((s shr 8) % 1000) / 1000f
    }
}

/**
 * The still picture behind the title screen: the hero, sword raised, with a rot monster
 * looming behind him against the moon. Everything is measured from the screen height so it
 * looks the same on any phone.
 */
fun DrawScope.drawTitleScene() {
    val w = size.width
    val h = size.height
    val dice = TitleDice(7)

    // ---- Sky ----
    drawRect(brush = Brush.verticalGradient(listOf(Color(0xFF03070B), Color(0xFF0A1C1A), Color(0xFF214B36))))
    for (i in 0 until 90) {
        val sx = dice.next() * w
        val sy = dice.next() * h * 0.55f
        val sr = (0.6f + dice.next() * 1.4f) * (h / 1080f)
        drawCircle(Color.White.copy(alpha = 0.25f + dice.next() * 0.5f), radius = sr, center = Offset(sx, sy))
    }

    // ---- Moon, right behind the monster's head ----
    val cx = 0.40f * w
    val headY = 0.42f * h
    val moonC = Offset(cx, headY - 0.06f * h)
    titleGlow(moonC, 0.55f * h, Color(0xFF9FE8B8), 0.22f)
    drawCircle(Color(0xFFDDEBD2), radius = 0.19f * h, center = moonC)
    drawCircle(Color(0xFFC3D6B8), radius = 0.045f * h, center = Offset(moonC.x - 0.07f * h, moonC.y - 0.03f * h))
    drawCircle(Color(0xFFC3D6B8), radius = 0.03f * h, center = Offset(moonC.x + 0.06f * h, moonC.y + 0.07f * h))

    // ---- Far treeline ----
    val treeCol = Color(0xFF07130E)
    var tx = -0.02f * w
    while (tx < w * 1.02f) {
        val th = (0.10f + dice.next() * 0.13f) * h
        val tw = (0.03f + dice.next() * 0.03f) * h
        titlePoly(treeCol, listOf(Offset(tx - tw, 0.72f * h), Offset(tx, 0.72f * h - th), Offset(tx + tw, 0.72f * h)))
        tx += tw * 1.1f
    }
    drawRect(treeCol, topLeft = Offset(0f, 0.72f * h), size = Size(w, 0.28f * h))

    // ---- The rot monster ----
    fun mx(d: Float): Float = cx + d * h
    fun my(f: Float): Float = f * h
    val body = Color(0xFF050A08)

    val torso = Path()
    torso.moveTo(mx(-0.66f), h)
    torso.lineTo(mx(-0.58f), my(0.80f))
    torso.cubicTo(mx(-0.56f), my(0.66f), mx(-0.30f), my(0.58f), mx(-0.10f), my(0.53f))
    torso.lineTo(mx(0.10f), my(0.53f))
    torso.cubicTo(mx(0.30f), my(0.58f), mx(0.56f), my(0.66f), mx(0.58f), my(0.80f))
    torso.lineTo(mx(0.66f), h)
    torso.close()
    drawPath(torso, body)

    // Neck and head.
    titlePoly(
        body,
        listOf(
            Offset(mx(-0.06f), my(0.46f)), Offset(mx(0.06f), my(0.46f)),
            Offset(mx(0.11f), my(0.56f)), Offset(mx(-0.11f), my(0.56f)),
        ),
    )
    drawOval(body, topLeft = Offset(cx - 0.085f * h, headY - 0.10f * h), size = Size(0.17f * h, 0.21f * h))

    // Long arms hanging down.
    for (side in listOf(-1f, 1f)) {
        titlePoly(
            body,
            listOf(
                Offset(mx(side * 0.50f), my(0.62f)), Offset(mx(side * 0.38f), my(0.62f)),
                Offset(mx(side * 0.44f), my(0.86f)), Offset(mx(side * 0.47f), my(0.99f)),
                Offset(mx(side * 0.57f), my(0.99f)), Offset(mx(side * 0.58f), my(0.84f)),
            ),
        )
    }

    // Rot glowing through its body, and root veins.
    titleGlow(Offset(mx(-0.18f), my(0.68f)), 0.10f * h, Color(0xFF6CFF7A), 0.16f)
    titleGlow(Offset(mx(0.22f), my(0.74f)), 0.13f * h, Color(0xFF6CFF7A), 0.12f)
    titleGlow(Offset(mx(0.0f), my(0.60f)), 0.08f * h, Color(0xFF9CFF6A), 0.14f)
    for (i in 0 until 7) {
        val vx = -0.5f + i * 0.17f
        titleBeam(
            Offset(mx(vx), my(0.62f + dice.next() * 0.05f)),
            Offset(mx(vx * 0.7f), my(0.86f + dice.next() * 0.1f)),
            0.006f * h,
            Color(0xFF6CFF7A).copy(alpha = 0.28f),
        )
    }

    // Glowing rotroot antlers.
    val antlerGreen = Color(0xFFB8FF6A)
    val k = 0.62f
    fun antlerPoint(side: Float, dx: Float, dy: Float): Offset = Offset(cx + side * dx * k * h, headY + dy * k * h)
    fun antler(a: Offset, b: Offset) {
        titleBeam(a, b, 0.030f * h, antlerGreen.copy(alpha = 0.16f))
        titleBeam(a, b, 0.011f * h, antlerGreen.copy(alpha = 0.95f))
    }
    for (side in listOf(-1f, 1f)) {
        val b0 = antlerPoint(side, 0.04f, -0.08f)
        val b1 = antlerPoint(side, 0.13f, -0.24f)
        val b2 = antlerPoint(side, 0.19f, -0.42f)
        val b3 = antlerPoint(side, 0.30f, -0.55f)
        antler(b0, b1)
        antler(b1, b2)
        antler(b2, b3)
        antler(b1, antlerPoint(side, 0.27f, -0.22f))
        antler(b2, antlerPoint(side, 0.06f, -0.50f))
        antler(b2, antlerPoint(side, 0.34f, -0.38f))
        antler(b3, antlerPoint(side, 0.24f, -0.66f))
        antler(b3, antlerPoint(side, 0.40f, -0.62f))
    }

    // Burning eyes.
    for (side in listOf(-1f, 1f)) {
        val ec = Offset(cx + side * 0.035f * h, headY - 0.005f * h)
        titleGlow(ec, 0.06f * h, Color(0xFF7CFF5A), 0.55f)
        drawCircle(Color(0xFFE6FFC0), radius = 0.012f * h, center = ec)
    }

    // ---- Mist between the monster and the hero ----
    drawRect(
        brush = Brush.verticalGradient(
            listOf(Color.Transparent, Color(0x552E7A55), Color.Transparent),
            startY = 0.72f * h,
            endY = h,
        ),
        topLeft = Offset(0f, 0.72f * h),
        size = Size(w, 0.28f * h),
    )

    // ---- The hero ----
    val hero = Color(0xFF0B1116)
    val rim = Color(0xFF7FD6C0).copy(alpha = 0.55f)
    val big = 0.42f * h
    val hx = cx - 0.32f * h
    val feetY = 0.95f * h
    fun hp(dx: Float, dy: Float): Offset = Offset(hx + dx * big, feetY + dy * big)

    // Shadow on the ground.
    drawOval(Color(0xFF020403), topLeft = hp(-0.30f, -0.03f), size = Size(0.60f * big, 0.06f * big))

    // Cape blowing behind him.
    titlePoly(
        Color(0xFF1B0B12),
        listOf(
            hp(-0.08f, -0.88f), hp(-0.16f, -0.80f), hp(-0.40f, -0.34f), hp(-0.62f, -0.10f),
            hp(-0.34f, -0.04f), hp(-0.16f, -0.26f), hp(-0.04f, -0.60f),
        ),
    )
    // Legs and body.
    titlePoly(hero, listOf(hp(-0.13f, 0f), hp(-0.03f, 0f), hp(-0.02f, -0.48f), hp(-0.14f, -0.48f)))
    titlePoly(hero, listOf(hp(0.05f, 0f), hp(0.16f, 0f), hp(0.12f, -0.48f), hp(0.01f, -0.48f)))
    titlePoly(
        hero,
        listOf(
            hp(-0.15f, -0.46f), hp(0.15f, -0.46f), hp(0.17f, -0.80f),
            hp(0.08f, -0.90f), hp(-0.08f, -0.90f), hp(-0.17f, -0.80f),
        ),
    )
    drawCircle(hero, radius = 0.075f * big, center = hp(0f, -0.98f))
    // Red scarf.
    titlePoly(Color(0xFF7A1F2A), listOf(hp(-0.05f, -0.91f), hp(-0.32f, -0.85f), hp(-0.24f, -0.80f), hp(0.05f, -0.87f)))
    // Moonlight on his edge.
    titleBeam(hp(0.15f, -0.46f), hp(0.17f, -0.80f), 0.010f * big, rim)
    titleBeam(hp(0.12f, -0.02f), hp(0.12f, -0.46f), 0.008f * big, rim)

    // The arm that hangs at his side.
    titleBeam(hp(-0.13f, -0.83f), hp(-0.22f, -0.58f), 0.075f * big, hero)

    // The raised arm and the sword.
    val hand = hp(0.24f, -1.00f)
    val tip = hp(0.54f, -1.55f)
    titleBeam(hp(0.12f, -0.83f), hp(0.22f, -0.93f), 0.075f * big, hero)
    titleBeam(hp(0.22f, -0.93f), hand, 0.065f * big, hero)
    titleBeam(hand, tip, 0.10f * big, Color(0xFFF08AB8).copy(alpha = 0.18f))
    titleBeam(hand, tip, 0.032f * big, Color(0xFFEAF2F8))
    titleBeam(hp(0.25f, -1.02f), hp(0.53f, -1.53f), 0.010f * big, Color.White)
    titleBeam(hand + Offset(-0.06f * big, -0.035f * big), hand + Offset(0.06f * big, 0.035f * big), 0.028f * big, Color(0xFFFFC940))
    drawCircle(hero, radius = 0.045f * big, center = hand)
    titleGlow(tip, 0.30f * big, Color(0xFFF7C6DC), 0.35f)

    // ---- Ground, grass and drifting spores ----
    drawRect(
        brush = Brush.verticalGradient(
            listOf(Color.Transparent, Color(0xFF040705)),
            startY = 0.88f * h,
            endY = h,
        ),
        topLeft = Offset(0f, 0.88f * h),
        size = Size(w, 0.12f * h),
    )
    for (i in 0 until 90) {
        val gx = dice.next() * w
        val gh = (0.03f + dice.next() * 0.06f) * h
        val gw = 0.012f * h
        titlePoly(Color(0xFF030604), listOf(Offset(gx - gw, h), Offset(gx, h - gh), Offset(gx + gw, h)))
    }
    for (i in 0 until 40) {
        val spx = dice.next() * w
        val spy = (0.15f + dice.next() * 0.8f) * h
        val spr = (1.0f + dice.next() * 2.0f) * (h / 1080f)
        drawCircle(Color(0xFF9CFF6A).copy(alpha = 0.15f + dice.next() * 0.35f), radius = spr, center = Offset(spx, spy))
    }

    // ---- Darken the right side so the title and buttons read clearly, then a lens vignette ----
    drawRect(
        brush = Brush.horizontalGradient(
            listOf(Color.Transparent, Color(0xD9040807)),
            startX = 0.58f * w,
            endX = w,
        ),
        topLeft = Offset(0.58f * w, 0f),
        size = Size(0.42f * w, h),
    )
    drawRect(
        brush = Brush.radialGradient(
            0.6f to Color.Transparent,
            1f to Color(0x66000000),
            center = center,
            radius = size.maxDimension * 0.62f,
        ),
    )
}
