package com.keystone.rpg

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.geometry.Offset

/**
 * Where the player has dragged each HUD button to, as an (x, y) offset in pixels from its
 * normal spot. Saved to disk so a custom layout survives closing the game.
 */
object HudLayout {
    private const val PREFS = "keystone_hud_layout"

    /** Loads every saved offset into a live map the UI can read and write directly. */
    fun load(context: Context): SnapshotStateMap<String, Offset> {
        val map = mutableStateMapOf<String, Offset>()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (key in prefs.all.keys) {
            if (!key.endsWith("_x")) continue
            val id = key.removeSuffix("_x")
            val x = prefs.getFloat(key, 0f)
            val y = prefs.getFloat(id + "_y", 0f)
            if (x != 0f || y != 0f) map[id] = Offset(x, y)
        }
        return map
    }

    fun save(context: Context, id: String, offset: Offset) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(id + "_x", offset.x)
            .putFloat(id + "_y", offset.y)
            .apply()
    }

    /** Puts every button back where it started. */
    fun reset(context: Context, map: SnapshotStateMap<String, Offset>) {
        map.clear()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
