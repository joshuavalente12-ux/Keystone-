package com.keystone.rpg

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Distance between two neighbouring nodes, in dp. */
private const val NODE_GAP = 84f

/**
 * The Sphere Grid screen. Drag to look around, tap a node to see what it does, and press
 * Unlock to take it. Unlocking is permanent: there is no way to undo it.
 */
@Composable
fun GridPanel(game: Game, onClose: () -> Unit) {
    val v = game.loot.version
    val unlocked = remember(v) { game.loot.gridSnapshot() }
    val points = remember(v) { game.loot.gridPoints }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var selected by remember { mutableIntStateOf(SphereGrid.HOME) }
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF2070B12))
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val gap = NODE_GAP * density
                        pan = Offset(
                            (pan.x + dragAmount.x).coerceIn(-9f * gap, 9f * gap),
                            (pan.y + dragAmount.y).coerceIn(-7f * gap, 7f * gap),
                        )
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { tap ->
                        val gap = NODE_GAP * density
                        val origin = Offset(size.width / 2f, size.height / 2f) + pan
                        var best = -1
                        var bestDist = gap * 0.5f
                        for (n in SphereGrid.nodes) {
                            val p = Offset(
                                origin.x + (n.col - SphereGrid.CENTER_COL) * gap,
                                origin.y + (n.row - SphereGrid.CENTER_ROW) * gap,
                            )
                            val d = (p - tap).getDistance()
                            if (d < bestDist) {
                                bestDist = d
                                best = n.id
                            }
                        }
                        if (best >= 0) selected = best
                    }
                },
        ) {
            val gap = NODE_GAP.dp.toPx()
            val origin = Offset(size.width / 2f, size.height / 2f) + pan
            val gold = Color(0xFFFFC940)

            fun posOf(n: GridNode): Offset = Offset(
                origin.x + (n.col - SphereGrid.CENTER_COL) * gap,
                origin.y + (n.row - SphereGrid.CENTER_ROW) * gap,
            )

            fun isOn(id: Int): Boolean = id == SphereGrid.HOME || id in unlocked

            fun edge(a: GridNode, b: GridNode) {
                val aOn = isOn(a.id)
                val bOn = isOn(b.id)
                val color = when {
                    aOn && bOn -> gold
                    aOn || bOn -> gold.copy(alpha = 0.45f)
                    else -> Color.White.copy(alpha = 0.14f)
                }
                val width = if (aOn && bOn) 4.dp.toPx() else 2.dp.toPx()
                drawLine(color, posOf(a), posOf(b), strokeWidth = width)
            }

            fun visible(p: Offset): Boolean =
                p.x > -gap && p.x < size.width + gap && p.y > -gap && p.y < size.height + gap

            // Paths first, so the nodes sit on top of them.
            for (n in SphereGrid.nodes) {
                if (!visible(posOf(n))) continue
                if (n.col < SphereGrid.COLS - 1) edge(n, SphereGrid.nodes[n.id + 1])
                if (n.row < SphereGrid.ROWS - 1) edge(n, SphereGrid.nodes[n.id + SphereGrid.COLS])
            }

            paint.textSize = 12.dp.toPx()
            for (n in SphereGrid.nodes) {
                val p = posOf(n)
                if (!visible(p)) continue
                val on = isOn(n.id)
                val reach = SphereGrid.reachable(n.id, unlocked)
                val radius = when {
                    n.kind == GridKind.START -> 30.dp.toPx()
                    n.kind.cost > 1 -> 27.dp.toPx()
                    else -> 21.dp.toPx()
                }
                val fill = when {
                    on -> n.kind.color
                    reach -> n.kind.color.copy(alpha = 0.6f)
                    else -> n.kind.color.copy(alpha = 0.2f)
                }
                drawCircle(color = fill, radius = radius, center = p)
                if (on) {
                    drawCircle(color = gold, radius = radius, center = p, style = Stroke(width = 3.dp.toPx()))
                } else if (reach) {
                    drawCircle(color = Color.White, radius = radius, center = p, style = Stroke(width = 2.dp.toPx()))
                }
                if (n.id == selected) {
                    drawCircle(
                        color = Color.White,
                        radius = radius + 6.dp.toPx(),
                        center = p,
                        style = Stroke(width = 3.dp.toPx()),
                    )
                }
                paint.color = if (on) 0xFF101418.toInt() else 0xCCFFFFFF.toInt()
                drawIntoCanvas { canvas ->
                    canvas.nativeCanvas.drawText(n.kind.tag, p.x, p.y + paint.textSize * 0.35f, paint)
                }
            }
        }

        // Top bar: title, points to spend, and Done.
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Sphere Grid", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(14.dp))
            Text(
                "Points: $points",
                color = if (points > 0) Color.White else Color(0xFF8FA99A),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        Button(
            onClick = onClose,
            colors = ButtonDefaults.buttonColors(containerColor = Palette.gold, contentColor = Color(0xFF1E2A22)),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .safeDrawingPadding()
                .padding(12.dp),
        ) {
            Text("Done", fontWeight = FontWeight.Bold)
        }

        // What the selected node does, and the button to take it.
        val node = SphereGrid.nodes[selected]
        val on = selected == SphereGrid.HOME || selected in unlocked
        val reach = SphereGrid.reachable(selected, unlocked)
        val cost = node.kind.cost
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .padding(12.dp)
                .widthIn(max = 420.dp)
                .background(Color(0xF2141A22), RoundedCornerShape(16.dp))
                .border(1.5.dp, node.kind.color.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(node.kind.title, color = node.kind.color, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(
                node.kind.info,
                color = Color(0xFFDCE6E0),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            when {
                selected == SphereGrid.HOME -> Text(
                    "Drag to look around. Tap a glowing-ringed node beside your path.",
                    color = Color(0xFF8FA99A),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                on -> Text("Unlocked", color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                !reach -> Text(
                    "Too far. Unlock a node right next to it first.",
                    color = Color(0xFF8FA99A),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                points < cost -> Text(
                    "Needs $cost points. You have $points.",
                    color = Color(0xFFE08A7A),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                )
                else -> {
                    Button(
                        onClick = { game.loot.gridUnlock(selected) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Palette.gold,
                            contentColor = Color(0xFF1E2A22),
                        ),
                        shape = RoundedCornerShape(24.dp),
                    ) {
                        Text(
                            if (cost == 1) "Unlock for 1 point" else "Unlock for $cost points",
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("Permanent. This can never be undone.", color = Color(0xFF8FA99A), fontSize = 12.sp)
                }
            }
        }
    }
}
