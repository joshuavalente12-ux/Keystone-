package com.keystone.rpg

import androidx.compose.ui.graphics.Color
import kotlin.math.abs

/** What a node on the grid gives you. Ordinary nodes cost 1 point, the big perks cost 3. */
enum class GridKind(val title: String, val tag: String, val info: String, val cost: Int, val color: Color) {
    START("Keystone", "KEY", "Where every path begins.", 0, Color(0xFFFFC940)),
    POWER("Strength", "STR", "+1 Power. Your hits do about 2.5% more damage.", 1, Color(0xFFE0574B)),
    DEFENSE("Defense", "DEF", "+2 Defense. Monsters hurt you less.", 1, Color(0xFF4B8FE0)),
    VITALITY("Vitality", "HP", "+10 maximum health.", 1, Color(0xFF58C46A)),
    SPEED("Swiftness", "SPD", "+1% movement and sprint speed.", 1, Color(0xFFE0C24B)),
    CRIT("Deadly Aim", "CRT", "+3% chance for a hit to land double damage.", 3, Color(0xFFFF7A3D)),
    BULWARK("Bulwark", "BLW", "+6 Defense.", 3, Color(0xFF7A6BE0)),
    REGEN("Second Wind", "RGN", "+2 health regained every second.", 3, Color(0xFF3DD6B0)),
    SCHOLAR("Scholar", "XP", "+4% experience from everything you defeat.", 3, Color(0xFFE05CC8)),
}

class GridNode(val id: Int, val col: Int, val row: Int, val kind: GridKind)

/** Everything the grid adds up to. */
class GridBonus(
    val power: Int,
    val defense: Int,
    val vitality: Int,
    val speed: Int,
    val crit: Int,
    val regen: Int,
    val xpPct: Int,
)

/**
 * The board. It is the same for everybody: the same nodes in the same places every time.
 * You start at the Keystone in the middle and can only unlock a node that touches one you
 * already have. Once a node is unlocked it is yours for good.
 *
 * The four corners lean towards Strength (top left), Swiftness (top right), Defense
 * (bottom left) and Vitality (bottom right), with the big perks scattered through them.
 */
object SphereGrid {
    const val COLS = 17
    const val ROWS = 13
    const val CENTER_COL = 8
    const val CENTER_ROW = 6
    const val HOME = CENTER_ROW * COLS + CENTER_COL

    val nodes: List<GridNode> = build()

    private fun build(): List<GridNode> {
        val out = ArrayList<GridNode>(COLS * ROWS)
        // Same order as the corner numbers below: 0 Strength, 1 Defense, 2 Vitality, 3 Swiftness.
        val basics = listOf(GridKind.POWER, GridKind.DEFENSE, GridKind.VITALITY, GridKind.SPEED)
        val specials = listOf(GridKind.CRIT, GridKind.BULWARK, GridKind.REGEN, GridKind.SCHOLAR)
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                val dx = c - CENTER_COL
                val dy = r - CENTER_ROW
                val corner = when {
                    dx < 0 && dy < 0 -> 0
                    dx >= 0 && dy < 0 -> 3
                    dx < 0 -> 1
                    else -> 2
                }
                val h = ((c * 73856093) xor (r * 19349663)) and 0x7fffffff
                val kind = when {
                    dx == 0 && dy == 0 -> GridKind.START
                    // The four nodes touching the Keystone: your first choice.
                    dx == 0 && dy == -1 -> GridKind.POWER
                    dx == 1 && dy == 0 -> GridKind.SPEED
                    dx == 0 && dy == 1 -> GridKind.VITALITY
                    dx == -1 && dy == 0 -> GridKind.DEFENSE
                    abs(dx) + abs(dy) >= 3 && h % 11 == 0 -> specials[corner]
                    (h / 7) % 100 < 18 -> basics[(h / 13) % 4]
                    else -> basics[corner]
                }
                out.add(GridNode(r * COLS + c, c, r, kind))
            }
        }
        return out
    }

    /** The nodes touching this one: left, right, above and below. */
    fun neighbors(id: Int): List<Int> {
        val c = id % COLS
        val r = id / COLS
        val out = ArrayList<Int>(4)
        if (c > 0) out.add(id - 1)
        if (c < COLS - 1) out.add(id + 1)
        if (r > 0) out.add(id - COLS)
        if (r < ROWS - 1) out.add(id + COLS)
        return out
    }

    /** True if [id] is not yet yours but touches the Keystone or a node that is. */
    fun reachable(id: Int, unlocked: Set<Int>): Boolean {
        if (id == HOME || id in unlocked) return false
        if (id < 0 || id >= COLS * ROWS) return false
        for (n in neighbors(id)) {
            if (n == HOME || n in unlocked) return true
        }
        return false
    }

    fun bonuses(unlocked: Set<Int>): GridBonus {
        var power = 0
        var defense = 0
        var vitality = 0
        var speed = 0
        var crit = 0
        var regen = 0
        var xp = 0
        for (id in unlocked) {
            if (id < 0 || id >= nodes.size) continue
            when (nodes[id].kind) {
                GridKind.POWER -> power += 1
                GridKind.DEFENSE -> defense += 2
                GridKind.VITALITY -> vitality += 10
                GridKind.SPEED -> speed += 1
                GridKind.CRIT -> crit += 3
                GridKind.BULWARK -> defense += 6
                GridKind.REGEN -> regen += 2
                GridKind.SCHOLAR -> xp += 4
                GridKind.START -> {}
            }
        }
        return GridBonus(power, defense, vitality, speed, crit, regen, xp)
    }
}
